import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  CenterInfo, 
  Educator, 
  Course, 
  Batch, 
  Student, 
  Discount, 
  FeePayment, 
  Expense, 
  AdmissionApplication,
  PaymentMode,
  AdminAccount,
  StudyMaterial,
  ExamQuestion,
  OnlineExam,
  ExamSubmission,
  LiveClassSession,
  ClassRecording,
  LiveClassStatus,
  StudentNotification,
  FullDatabaseBackup
} from '../types';
import { 
  INITIAL_CENTER_INFO, 
  INITIAL_EDUCATORS, 
  INITIAL_COURSES, 
  INITIAL_BATCHES, 
  INITIAL_STUDENTS, 
  INITIAL_DISCOUNTS, 
  INITIAL_PAYMENTS, 
  INITIAL_EXPENSES, 
  INITIAL_ADMISSIONS,
  INITIAL_STUDY_MATERIALS,
  INITIAL_QUESTIONS,
  INITIAL_EXAMS,
  INITIAL_EXAM_SUBMISSIONS,
  INITIAL_LIVE_CLASSES,
  INITIAL_CLASS_RECORDINGS,
  INITIAL_STUDENT_NOTIFICATIONS
} from '../data/seedData';
import { formatMonthKey, calculateTargetDiscount } from '../utils/feeCalculator';
import { googleSheetsService, GoogleUserProfile } from '../utils/googleSheetsService';
import { googleSheetsBackendApi } from '../services/googleSheetsBackendApi';

interface AppContextType {
  // Center Details
  centerInfo: CenterInfo;
  updateCenterInfo: (info: Partial<CenterInfo>) => void;

  // Educators
  educators: Educator[];
  addEducator: (edu: Omit<Educator, 'id'>) => void;
  updateEducator: (id: string, edu: Partial<Educator>) => void;
  deleteEducator: (id: string) => void;

  // Courses
  courses: Course[];
  addCourse: (course: Omit<Course, 'id' | 'createdAt'>) => void;
  updateCourse: (id: string, course: Partial<Course>) => void;
  deleteCourse: (id: string) => void;

  // Batches
  batches: Batch[];
  addBatch: (batch: Omit<Batch, 'id'>) => void;
  updateBatch: (id: string, batch: Partial<Batch>) => void;
  deleteBatch: (id: string) => void;

  // Students
  students: Student[];
  addStudent: (student: Omit<Student, 'id' | 'rollNo'>, initialPayment?: { amount: number; mode: PaymentMode; ref: string }) => Student;
  updateStudent: (id: string, student: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  setStudentStatus: (id: string, status: Student['status']) => void;

  // Discounts
  discounts: Discount[];
  addDiscount: (discount: Omit<Discount, 'id' | 'createdAt'>) => void;
  updateDiscount: (id: string, discount: Partial<Discount>) => void;
  deleteDiscount: (id: string) => void;

  // Fee Payments
  payments: FeePayment[];
  collectFee: (payment: Omit<FeePayment, 'id' | 'receiptNo' | 'createdAt'>) => FeePayment;
  approvePayment: (paymentId: string, approvedBy?: string) => void;
  rejectPayment: (paymentId: string, reason: string) => void;
  deletePayment: (paymentId: string) => void;

  // Expenses
  expenses: Expense[];
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  updateExpense: (id: string, expense: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;

  // Study Materials (Batch-wise notes & handouts)
  studyMaterials: StudyMaterial[];
  addStudyMaterial: (material: Omit<StudyMaterial, 'id' | 'uploadedDate' | 'downloadCount'>) => void;
  updateStudyMaterial: (id: string, material: Partial<StudyMaterial>) => void;
  deleteStudyMaterial: (id: string) => void;
  downloadStudyMaterial: (material: StudyMaterial) => void;

  // Online Exams & Course Question Bank
  questions: ExamQuestion[];
  addQuestion: (question: Omit<ExamQuestion, 'id' | 'createdAt'>) => ExamQuestion;
  updateQuestion: (id: string, question: Partial<ExamQuestion>) => void;
  deleteQuestion: (id: string) => void;
  bulkAddQuestions: (questionsList: Omit<ExamQuestion, 'id' | 'createdAt'>[]) => void;

  exams: OnlineExam[];
  addExam: (exam: Omit<OnlineExam, 'id' | 'createdAt'>) => OnlineExam;
  updateExam: (id: string, exam: Partial<OnlineExam>) => void;
  deleteExam: (id: string) => void;
  toggleExamPublish: (id: string) => void;
  setExamStatus: (id: string, status: OnlineExam['status']) => void;

  examSubmissions: ExamSubmission[];
  submitExamAnswers: (
    examId: string,
    studentId: string,
    answers: Record<string, number>,
    timeSpentSeconds: number
  ) => ExamSubmission;
  deleteExamSubmission: (id: string) => void;

  // Live Classes, Schedule & Recorded Lectures
  liveClasses: LiveClassSession[];
  addLiveClass: (session: Omit<LiveClassSession, 'id' | 'createdAt'>, notifyStudents?: boolean) => LiveClassSession;
  updateLiveClass: (id: string, session: Partial<LiveClassSession>) => void;
  deleteLiveClass: (id: string) => void;
  setLiveClassStatus: (id: string, status: LiveClassStatus) => void;
  postponeLiveClass: (id: string, details: {
    postponedReason: string;
    rescheduledDate?: string;
    rescheduledStartTime?: string;
    rescheduledEndTime?: string;
    notifyStudents?: boolean;
  }) => void;
  autoGenerateBatchSchedules: (params: {
    courseId: string;
    batchId: string;
    startDate: string;
    endDate: string;
    autoNotify?: boolean;
  }) => { generatedCount: number; message: string };

  // Student Notifications & Login Alerts
  notifications: StudentNotification[];
  sendStudentNotification: (notif: Omit<StudentNotification, 'id' | 'createdAt'>) => StudentNotification;
  markNotificationAsRead: (notificationId: string, studentId: string) => void;
  clearAllStudentNotifications: (studentId?: string) => void;

  classRecordings: ClassRecording[];
  addClassRecording: (rec: Omit<ClassRecording, 'id' | 'createdAt' | 'viewCount'>) => ClassRecording;
  updateClassRecording: (id: string, rec: Partial<ClassRecording>) => void;
  deleteClassRecording: (id: string) => void;
  incrementRecordingViews: (id: string) => void;

  // Admission Applications
  admissions: AdmissionApplication[];
  submitAdmissionApplication: (application: Omit<AdmissionApplication, 'id' | 'applicationNo' | 'appliedDate' | 'status'>) => AdmissionApplication;
  approveAdmission: (
    applicationId: string, 
    batchId: string, 
    rollNo?: string, 
    admissionMonth?: string,
    feePaymentDetails?: {
      isPaid?: boolean;
      amount?: number;
      paymentMode?: PaymentMode;
      transactionRef?: string;
      paymentDate?: string;
      remarks?: string;
      totalDiscount?: number;
      discountBreakdown?: string;
      totalBaseFee?: number;
    }
  ) => { student: Student; payment?: FeePayment } | undefined;
  rejectAdmission: (applicationId: string, reason: string) => void;
  deleteAdmission: (applicationId: string) => void;

  // Student Auth & Session
  currentStudent: Student | null;
  loginStudent: (mobile: string, aadhaarNo: string) => Promise<{ 
    success: boolean; 
    message: string; 
    student?: Student;
    isPendingAdmission?: boolean;
    application?: AdmissionApplication;
  }>;
  logoutStudent: () => void;
  submitStudentFeePayment: (params: {
    studentId: string;
    months: string[];
    amount: number;
    mode: PaymentMode;
    transactionRef: string;
    remarks?: string;
  }) => FeePayment;

  // Admin Auth & Session
  isAdminLoggedIn: boolean;
  adminUser: { username: string; name: string; role: string; email: string; lastLogin?: string } | null;
  loginAdmin: (username: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; message: string; adminUser?: any }>;
  logoutAdmin: () => void;
  updateAdminPassword: (currentPassword: string, newPassword: string) => { success: boolean; message: string };

  // Admin Account Table & Database Management
  adminAccounts: AdminAccount[];
  addAdminAccount: (account: Omit<AdminAccount, 'id' | 'updatedAt'>) => void;
  updateAdminAccount: (id: string, account: Partial<AdminAccount>) => void;
  deleteAdminAccount: (id: string) => void;

  // Unified Login Modal
  isUnifiedLoginOpen: boolean;
  unifiedLoginInitialRole: 'student' | 'admin';
  openUnifiedLoginModal: (role?: 'student' | 'admin') => void;
  closeUnifiedLoginModal: () => void;

  // Navigation & Receipt Modal
  activeTab: 'website' | 'courses' | 'faculty' | 'admission' | 'playzone' | 'student-portal' | 'admin' | 'api-docs';
  setActiveTab: (tab: 'website' | 'courses' | 'faculty' | 'admission' | 'playzone' | 'student-portal' | 'admin' | 'api-docs') => void;
  selectedReceiptForPrint: FeePayment | null;
  setSelectedReceiptForPrint: (payment: FeePayment | null) => void;
  saveAllToDatabase: (overrideData?: any) => Promise<any>;

  // Quick Notification Toast
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;

  // Google Sheets Backend Integration
  isGoogleConnected: boolean;
  googleUser: { email: string; name: string; picture?: string } | null;
  connectGoogleAccount: () => Promise<boolean>;
  disconnectGoogleAccount: () => void;
  syncToGoogleSheets: (customSheetId?: string) => Promise<{ success: boolean; message: string; url?: string }>;
  pullFromGoogleSheets: (customSheetId?: string) => Promise<{ success: boolean; message: string; counts?: any }>;
  createNewGoogleSheetDatabase: () => Promise<{ success: boolean; message: string; id?: string; url?: string }>;
  isSyncingSheets: boolean;
  isPullingSheets: boolean;

  // Reset / Backup / Restore
  resetToDefaultData: () => void;
  exportBackupObject: () => FullDatabaseBackup;
  downloadFullBackup: (customFilename?: string) => { success: boolean; filename?: string; error?: string };
  restoreFullBackup: (
    backupData: any,
    options?: { keepCurrentAdmin?: boolean; syncCloud?: boolean }
  ) => Promise<{ success: boolean; message: string; counts?: any }>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY = 'pixel_pathsala_erp_storage_v2';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [centerInfo, setCenterInfo] = useState<CenterInfo>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_center`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.cityState && /siliguri/i.test(parsed.cityState)) {
          parsed.cityState = 'Raina, Purba Bardhaman (Burdwan), West Bengal - 713424';
          parsed.address = parsed.address && /siliguri|college road|knowledge park/i.test(parsed.address) 
            ? 'Raina Main Road, Near Bus Stand' 
            : (parsed.address || 'Raina');
          localStorage.setItem(`${STORAGE_KEY}_center`, JSON.stringify({ ...INITIAL_CENTER_INFO, ...parsed }));
        }
        return { 
          ...INITIAL_CENTER_INFO, 
          ...parsed
        };
      }
      return INITIAL_CENTER_INFO;
    } catch {
      return INITIAL_CENTER_INFO;
    }
  });

  const [educators, setEducators] = useState<Educator[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_educators`);
      return saved ? JSON.parse(saved) : INITIAL_EDUCATORS;
    } catch {
      return INITIAL_EDUCATORS;
    }
  });

  const [courses, setCourses] = useState<Course[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_courses`);
      return saved ? JSON.parse(saved) : INITIAL_COURSES;
    } catch {
      return INITIAL_COURSES;
    }
  });

  const [batches, setBatches] = useState<Batch[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_batches`);
      return saved ? JSON.parse(saved) : INITIAL_BATCHES;
    } catch {
      return INITIAL_BATCHES;
    }
  });

  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_students`);
      return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
    } catch {
      return INITIAL_STUDENTS;
    }
  });

  const [discounts, setDiscounts] = useState<Discount[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_discounts`);
      return saved ? JSON.parse(saved) : INITIAL_DISCOUNTS;
    } catch {
      return INITIAL_DISCOUNTS;
    }
  });

  const [payments, setPayments] = useState<FeePayment[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_payments`);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter(p => !['pay-001', 'pay-002', 'pay-003', 'pay-004', 'pay-005', 'pay-1', 'pay-2', 'pay-3'].includes(p.id));
        }
      }
      return [];
    } catch {
      return [];
    }
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_expenses`);
      return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
    } catch {
      return INITIAL_EXPENSES;
    }
  });

  const [admissions, setAdmissions] = useState<AdmissionApplication[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_admissions`);
      return saved ? JSON.parse(saved) : INITIAL_ADMISSIONS;
    } catch {
      return INITIAL_ADMISSIONS;
    }
  });

  const [studyMaterials, setStudyMaterials] = useState<StudyMaterial[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_materials`);
      return saved ? JSON.parse(saved) : INITIAL_STUDY_MATERIALS;
    } catch {
      return INITIAL_STUDY_MATERIALS;
    }
  });

  const [questions, setQuestions] = useState<ExamQuestion[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_questions`);
      return saved ? JSON.parse(saved) : INITIAL_QUESTIONS;
    } catch {
      return INITIAL_QUESTIONS;
    }
  });

  const [exams, setExams] = useState<OnlineExam[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_exams`);
      return saved ? JSON.parse(saved) : INITIAL_EXAMS;
    } catch {
      return INITIAL_EXAMS;
    }
  });

  const [examSubmissions, setExamSubmissions] = useState<ExamSubmission[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_exam_submissions`);
      return saved ? JSON.parse(saved) : INITIAL_EXAM_SUBMISSIONS;
    } catch {
      return INITIAL_EXAM_SUBMISSIONS;
    }
  });

  const [liveClasses, setLiveClasses] = useState<LiveClassSession[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_live_classes`);
      return saved ? JSON.parse(saved) : INITIAL_LIVE_CLASSES;
    } catch {
      return INITIAL_LIVE_CLASSES;
    }
  });

  const [classRecordings, setClassRecordings] = useState<ClassRecording[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_class_recordings`);
      return saved ? JSON.parse(saved) : INITIAL_CLASS_RECORDINGS;
    } catch {
      return INITIAL_CLASS_RECORDINGS;
    }
  });

  const [notifications, setNotifications] = useState<StudentNotification[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_notifications`);
      return saved ? JSON.parse(saved) : INITIAL_STUDENT_NOTIFICATIONS;
    } catch {
      return INITIAL_STUDENT_NOTIFICATIONS;
    }
  });

  const [currentStudent, setCurrentStudent] = useState<Student | null>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_auth_student`);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [adminAccounts, setAdminAccounts] = useState<AdminAccount[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_admin_accounts`);
      if (saved) return JSON.parse(saved);
      return [
        {
          id: 'ADM-001',
          username: 'admin',
          password: 'admin123',
          name: 'Director / Center Administrator',
          role: 'Master Administrator',
          email: 'admin@pixelpathsala.com',
          phone: '+91 9775708722',
          securityPin: '7722',
          status: 'active',
          lastLogin: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' }),
          updatedAt: new Date().toISOString().split('T')[0]
        }
      ];
    } catch {
      return [
        {
          id: 'ADM-001',
          username: 'admin',
          password: 'admin123',
          name: 'Director / Center Administrator',
          role: 'Master Administrator',
          email: 'admin@pixelpathsala.com',
          phone: '+91 9775708722',
          securityPin: '7722',
          status: 'active',
          lastLogin: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' }),
          updatedAt: new Date().toISOString().split('T')[0]
        }
      ];
    }
  });

  const [adminCreds, setAdminCreds] = useState<{ username: string; password: string; name: string; role: string; email: string }>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_admin_creds`);
      if (saved) return JSON.parse(saved);
      return {
        username: 'admin',
        password: 'admin123',
        name: 'Director / Center Admin',
        role: 'Master Administrator',
        email: 'admin@pixelpathsala.com'
      };
    } catch {
      return {
        username: 'admin',
        password: 'admin123',
        name: 'Director / Center Admin',
        role: 'Master Administrator',
        email: 'admin@pixelpathsala.com'
      };
    }
  });

  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_admin_logged_in`) || sessionStorage.getItem(`${STORAGE_KEY}_admin_logged_in`);
      return saved === 'true';
    } catch {
      return false;
    }
  });

  const [adminUser, setAdminUser] = useState<{ username: string; name: string; role: string; email: string; lastLogin?: string } | null>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_admin_user`) || sessionStorage.getItem(`${STORAGE_KEY}_admin_user`);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [activeTab, setActiveTab] = useState<'website' | 'courses' | 'faculty' | 'admission' | 'playzone' | 'student-portal' | 'admin' | 'api-docs'>(() => {
    if (typeof window !== 'undefined') {
      try {
        const params = new URLSearchParams(window.location.search);
        const tabParam = params.get('tab');
        const hash = window.location.hash.replace('#', '');
        const candidate = (tabParam || hash).toLowerCase();
        if (['website', 'courses', 'faculty', 'admission', 'playzone', 'student-portal', 'admin', 'api-docs', 'apk'].includes(candidate)) {
          return (candidate === 'apk' ? 'api-docs' : candidate) as any;
        }
      } catch {
        // fallback
      }
    }
    return 'website';
  });
  const [selectedReceiptForPrint, setSelectedReceiptForPrint] = useState<FeePayment | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Unified Login Modal State
  const [isUnifiedLoginOpen, setIsUnifiedLoginOpen] = useState(false);
  const [unifiedLoginInitialRole, setUnifiedLoginInitialRole] = useState<'student' | 'admin'>('student');
  const [isDbLoaded, setIsDbLoaded] = useState(false);

  // Pull database data from backend / Google Sheets on application startup
  useEffect(() => {
    let isMounted = true;
    const fetchInitialData = async () => {
      try {
        const [statusRes, res] = await Promise.all([
          googleSheetsBackendApi.getStatus().catch(() => null),
          googleSheetsBackendApi.loadAll().catch(() => null)
        ]);

        if (statusRes && isMounted) {
          if (statusRes.googleUser) {
            setGoogleUser(statusRes.googleUser);
          }
          if (statusRes.isConnected || statusRes.hasToken) {
            setIsGoogleConnected(true);
          }
          if (statusRes.googleSheetId) {
            setCenterInfo(prev => ({
              ...prev,
              googleSheetId: statusRes.googleSheetId || prev.googleSheetId,
              googleSheetLastSynced: statusRes.lastSynced || prev.googleSheetLastSynced
            }));
          }
        }

        if (res && res.success && res.data && isMounted) {
          const { data } = res;
          
          if (Array.isArray(data.courses) && data.courses.length > 0) {
            setCourses(data.courses);
            localStorage.setItem(`${STORAGE_KEY}_courses`, JSON.stringify(data.courses));
          }
          if (Array.isArray(data.batches) && data.batches.length > 0) {
            setBatches(data.batches);
            localStorage.setItem(`${STORAGE_KEY}_batches`, JSON.stringify(data.batches));
          }
          if (Array.isArray(data.students)) {
            setStudents(data.students);
            localStorage.setItem(`${STORAGE_KEY}_students`, JSON.stringify(data.students));
          }
          if (Array.isArray(data.admissions)) {
            setAdmissions(data.admissions);
            localStorage.setItem(`${STORAGE_KEY}_admissions`, JSON.stringify(data.admissions));
          }
          if (Array.isArray(data.payments)) {
            const realPayments = data.payments.filter((p: any) => !['pay-001', 'pay-002', 'pay-003', 'pay-004', 'pay-005', 'pay-1', 'pay-2', 'pay-3'].includes(p.id));
            setPayments(realPayments);
            localStorage.setItem(`${STORAGE_KEY}_payments`, JSON.stringify(realPayments));
          }
          if (Array.isArray(data.educators) && data.educators.length > 0) {
            setEducators(data.educators);
            localStorage.setItem(`${STORAGE_KEY}_educators`, JSON.stringify(data.educators));
          }
          if (Array.isArray(data.expenses)) {
            setExpenses(data.expenses);
            localStorage.setItem(`${STORAGE_KEY}_expenses`, JSON.stringify(data.expenses));
          }
          if (Array.isArray(data.discounts) && data.discounts.length > 0) {
            setDiscounts(data.discounts);
            localStorage.setItem(`${STORAGE_KEY}_discounts`, JSON.stringify(data.discounts));
          } else {
            try {
              const savedDisc = localStorage.getItem(`${STORAGE_KEY}_discounts`);
              const fallback = savedDisc ? JSON.parse(savedDisc) : INITIAL_DISCOUNTS;
              if (Array.isArray(fallback) && fallback.length > 0) {
                setDiscounts(fallback);
                saveAllToDatabase({ discounts: fallback });
              }
            } catch {}
          }
          if (Array.isArray(data.studyMaterials)) {
            setStudyMaterials(data.studyMaterials);
            localStorage.setItem(`${STORAGE_KEY}_study_materials`, JSON.stringify(data.studyMaterials));
          }
          if (Array.isArray(data.questions)) {
            setQuestions(data.questions);
            localStorage.setItem(`${STORAGE_KEY}_questions`, JSON.stringify(data.questions));
          }
          if (Array.isArray(data.exams)) {
            setExams(data.exams);
            localStorage.setItem(`${STORAGE_KEY}_exams`, JSON.stringify(data.exams));
          }
          if (Array.isArray(data.examSubmissions)) {
            setExamSubmissions(data.examSubmissions);
            localStorage.setItem(`${STORAGE_KEY}_exam_submissions`, JSON.stringify(data.examSubmissions));
          }
          if (Array.isArray(data.liveClasses)) {
            setLiveClasses(data.liveClasses);
            localStorage.setItem(`${STORAGE_KEY}_live_classes`, JSON.stringify(data.liveClasses));
          }
          if (Array.isArray(data.classRecordings)) {
            setClassRecordings(data.classRecordings);
            localStorage.setItem(`${STORAGE_KEY}_class_recordings`, JSON.stringify(data.classRecordings));
          }
          if (Array.isArray(data.notifications)) {
            setNotifications(data.notifications);
            localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(data.notifications));
          }
          if (Array.isArray(data.adminAccounts) && data.adminAccounts.length > 0) {
            setAdminAccounts(data.adminAccounts);
            localStorage.setItem(`${STORAGE_KEY}_admin_accounts`, JSON.stringify(data.adminAccounts));
          }
          if (data.centerInfo && typeof data.centerInfo === 'object') {
            setCenterInfo(prev => {
              const updated = { ...prev, ...data.centerInfo };
              localStorage.setItem(`${STORAGE_KEY}_center`, JSON.stringify(updated));
              return updated;
            });
          }
        }
      } catch (err) {
        console.warn('Initial server DB load note:', err);
      } finally {
        if (isMounted) {
          setIsDbLoaded(true);
        }
      }
    };

    fetchInitialData();
    return () => {
      isMounted = false;
    };
  }, []);

  const openUnifiedLoginModal = (role: 'student' | 'admin' = 'student') => {
    setUnifiedLoginInitialRole(role);
    setIsUnifiedLoginOpen(true);
  };

  const closeUnifiedLoginModal = () => {
    setIsUnifiedLoginOpen(false);
  };

  // Helper to persist all current state to the backend database & Google Sheets
  const saveAllToDatabase = async (overrideData?: any) => {
    // Prevent wiping or pushing premature state before initial database load completes
    if (!isDbLoaded && !overrideData?.forceSave && !overrideData?.centerInfo) {
      console.log('Skipping auto-save before initial database load completes.');
      return { success: true, deferred: true };
    }
    try {
      const payload = {
        spreadsheetId: overrideData?.centerInfo?.googleSheetId || centerInfo.googleSheetId,
        students: overrideData?.students !== undefined ? overrideData.students : students,
        admissions: overrideData?.admissions !== undefined ? overrideData.admissions : admissions,
        payments: overrideData?.payments !== undefined ? overrideData.payments : payments,
        courses: overrideData?.courses !== undefined ? overrideData.courses : courses,
        batches: overrideData?.batches !== undefined ? overrideData.batches : batches,
        educators: overrideData?.educators !== undefined ? overrideData.educators : educators,
        expenses: overrideData?.expenses !== undefined ? overrideData.expenses : expenses,
        discounts: overrideData?.discounts !== undefined ? overrideData.discounts : discounts,
        adminAccounts: overrideData?.adminAccounts !== undefined ? overrideData.adminAccounts : adminAccounts,
        studyMaterials: overrideData?.studyMaterials !== undefined ? overrideData.studyMaterials : studyMaterials,
        questions: overrideData?.questions !== undefined ? overrideData.questions : questions,
        exams: overrideData?.exams !== undefined ? overrideData.exams : exams,
        examSubmissions: overrideData?.examSubmissions !== undefined ? overrideData.examSubmissions : examSubmissions,
        liveClasses: overrideData?.liveClasses !== undefined ? overrideData.liveClasses : liveClasses,
        classRecordings: overrideData?.classRecordings !== undefined ? overrideData.classRecordings : classRecordings,
        notifications: overrideData?.notifications !== undefined ? overrideData.notifications : notifications,
        centerInfo: overrideData?.centerInfo !== undefined ? overrideData.centerInfo : centerInfo
      };
      const res = await googleSheetsBackendApi.saveAll(payload);
      return res;
    } catch (err: any) {
      console.warn('Auto-save to backend DB warning:', err);
      return { success: false, error: err.message };
    }
  };

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_center`, JSON.stringify(centerInfo));
      localStorage.setItem(`${STORAGE_KEY}_educators`, JSON.stringify(educators));
      localStorage.setItem(`${STORAGE_KEY}_courses`, JSON.stringify(courses));
      localStorage.setItem(`${STORAGE_KEY}_batches`, JSON.stringify(batches));
      localStorage.setItem(`${STORAGE_KEY}_students`, JSON.stringify(students));
      localStorage.setItem(`${STORAGE_KEY}_discounts`, JSON.stringify(discounts));
      localStorage.setItem(`${STORAGE_KEY}_payments`, JSON.stringify(payments));
      localStorage.setItem(`${STORAGE_KEY}_expenses`, JSON.stringify(expenses));
      localStorage.setItem(`${STORAGE_KEY}_admissions`, JSON.stringify(admissions));
      localStorage.setItem(`${STORAGE_KEY}_materials`, JSON.stringify(studyMaterials));
      localStorage.setItem(`${STORAGE_KEY}_questions`, JSON.stringify(questions));
      localStorage.setItem(`${STORAGE_KEY}_exams`, JSON.stringify(exams));
      localStorage.setItem(`${STORAGE_KEY}_exam_submissions`, JSON.stringify(examSubmissions));
      localStorage.setItem(`${STORAGE_KEY}_live_classes`, JSON.stringify(liveClasses));
      localStorage.setItem(`${STORAGE_KEY}_class_recordings`, JSON.stringify(classRecordings));
      localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(notifications));
      if (currentStudent) {
        localStorage.setItem(`${STORAGE_KEY}_auth_student`, JSON.stringify(currentStudent));
      } else {
        localStorage.removeItem(`${STORAGE_KEY}_auth_student`);
      }
      localStorage.setItem(`${STORAGE_KEY}_admin_creds`, JSON.stringify(adminCreds));
    } catch (e) {
      console.warn('Storage sync failed', e);
    }
  }, [centerInfo, educators, courses, batches, students, discounts, payments, expenses, admissions, studyMaterials, questions, exams, examSubmissions, liveClasses, classRecordings, notifications, currentStudent, adminCreds]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(prev => (prev?.message === message ? null : prev));
    }, 3500);
  };

  // Center Details
  const updateCenterInfo = (info: Partial<CenterInfo>) => {
    const updated = { ...centerInfo, ...info };
    if (info.admissionOpen !== undefined && info.isAdmissionsOpen === undefined) {
      (updated as any).isAdmissionsOpen = info.admissionOpen;
    } else if (info.isAdmissionsOpen !== undefined && info.admissionOpen === undefined) {
      updated.admissionOpen = info.isAdmissionsOpen;
    }
    setCenterInfo(updated);
    try {
      localStorage.setItem(`${STORAGE_KEY}_center`, JSON.stringify(updated));
    } catch {}

    // Call dedicated saveCenterInfo backend endpoint
    googleSheetsBackendApi.saveCenterInfo(updated).catch(err => {
      console.warn('Backend saveCenterInfo sync note:', err);
    });

    saveAllToDatabase({ centerInfo: updated });
    showToast('Center details and gateway configuration saved successfully.');
  };

  // Educators
  const addEducator = (edu: Omit<Educator, 'id'>) => {
    const newEdu: Educator = {
      ...edu,
      id: `edu-${Date.now()}`
    };
    const updated = [newEdu, ...educators];
    setEducators(updated);
    saveAllToDatabase({ educators: updated });
    showToast(`Educator '${newEdu.name}' added.`);
  };

  const updateEducator = (id: string, updated: Partial<Educator>) => {
    const updatedList = educators.map(e => e.id === id ? { ...e, ...updated } : e);
    setEducators(updatedList);
    saveAllToDatabase({ educators: updatedList });
    showToast('Educator record updated.');
  };

  const deleteEducator = (id: string) => {
    const updatedList = educators.filter(e => e.id !== id);
    setEducators(updatedList);
    saveAllToDatabase({ educators: updatedList });
    showToast('Educator removed from faculty list.', 'info');
  };

  // Courses
  const addCourse = (course: Omit<Course, 'id' | 'createdAt'>) => {
    const newCourse: Course = {
      ...course,
      id: `course-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    const updatedList = [...courses, newCourse];
    setCourses(updatedList);
    saveAllToDatabase({ courses: updatedList });
    showToast(`Course '${newCourse.title}' created.`);
  };

  const updateCourse = (id: string, updated: Partial<Course>) => {
    const updatedList = courses.map(c => c.id === id ? { ...c, ...updated } : c);
    setCourses(updatedList);
    saveAllToDatabase({ courses: updatedList });
    showToast('Course details updated.');
  };

  const deleteCourse = (id: string) => {
    const updatedList = courses.filter(c => c.id !== id);
    setCourses(updatedList);
    saveAllToDatabase({ courses: updatedList });
    showToast('Course deleted.', 'info');
  };

  // Batches
  const addBatch = (batch: Omit<Batch, 'id'>) => {
    const newBatch: Batch = {
      ...batch,
      id: `batch-${Date.now()}`
    };
    const updatedList = [...batches, newBatch];
    setBatches(updatedList);
    saveAllToDatabase({ batches: updatedList });
    showToast(`Batch '${newBatch.name}' scheduled.`);
  };

  const updateBatch = (id: string, updated: Partial<Batch>) => {
    const updatedList = batches.map(b => b.id === id ? { ...b, ...updated } : b);
    setBatches(updatedList);
    saveAllToDatabase({ batches: updatedList });
    showToast('Batch details updated.');
  };

  const deleteBatch = (id: string) => {
    const updatedList = batches.filter(b => b.id !== id);
    setBatches(updatedList);
    saveAllToDatabase({ batches: updatedList });
    showToast('Batch deleted.', 'info');
  };

  // Students
  const addStudent = (
    studentData: Omit<Student, 'id' | 'rollNo'>, 
    initialPayment?: { amount: number; mode: PaymentMode; ref: string }
  ): Student => {
    const currentYear = new Date().getFullYear();
    const count = students.length + 1;
    const rollNo = `PP-${currentYear}-${String(count).padStart(3, '0')}`;
    const stuCourse = courses.find(c => c.id === studentData.courseId);
    const stuBatch = batches.find(b => b.id === studentData.batchId);
    const resolvedClass = studentData.studentClass || stuCourse?.academicClass || stuBatch?.academicClass || 'Class 12';
    const newStudent: Student = {
      ...studentData,
      studentClass: resolvedClass,
      id: `stu-${Date.now()}`,
      rollNo
    };

    const nextStudents = [newStudent, ...students];
    setStudents(nextStudents);

    let nextPayments = payments;
    // If initial payment was made during admission
    if (initialPayment && initialPayment.amount > 0) {
      const course = courses.find(c => c.id === newStudent.courseId);
      const batch = batches.find(b => b.id === newStudent.batchId);
      const receiptNo = `REC/${currentYear}/${newStudent.admissionMonth?.split('-')[1] || '01'}-${String(payments.length + 1).padStart(3, '0')}`;
      
      const newPay: FeePayment = {
        id: `pay-${Date.now()}`,
        receiptNo,
        studentId: newStudent.id,
        studentName: newStudent.name,
        studentAadhaar: newStudent.aadhaarNo,
        studentMobile: newStudent.mobile,
        courseTitle: course?.title || 'Course',
        batchName: batch?.name || 'Batch',
        month: formatMonthKey(newStudent.admissionMonth || '2026-04'),
        monthsCovered: [newStudent.admissionMonth || '2026-04'],
        baseMonthlyFee: course?.monthlyFee || initialPayment.amount,
        totalBaseFee: course?.monthlyFee || initialPayment.amount,
        totalDiscount: 0,
        finalAmountPaid: initialPayment.amount,
        remainingDue: 0,
        paymentMode: initialPayment.mode,
        transactionRef: initialPayment.ref || 'INITIAL-ADM-PAY',
        status: 'approved',
        paymentDate: new Date().toISOString().split('T')[0],
        approvedBy: 'Admin (At Admission)',
        remarks: 'Admission & 1st Month Fee collected at registration',
        createdAt: new Date().toISOString()
      };
      nextPayments = [newPay, ...payments];
      setPayments(nextPayments);
    }

    saveAllToDatabase({ students: nextStudents, payments: nextPayments });
    showToast(`Student '${newStudent.name}' enrolled with Roll No ${rollNo}!`);
    return newStudent;
  };

  const updateStudent = (id: string, updated: Partial<Student>) => {
    const updatedList = students.map(s => s.id === id ? { ...s, ...updated } : s);
    setStudents(updatedList);
    // If updating current logged in student
    if (currentStudent?.id === id) {
      setCurrentStudent(prev => prev ? ({ ...prev, ...updated }) : null);
    }
    saveAllToDatabase({ students: updatedList });
    showToast('Student profile updated.');
  };

  const deleteStudent = (id: string) => {
    const updatedList = students.filter(s => s.id !== id);
    setStudents(updatedList);
    if (currentStudent?.id === id) {
      setCurrentStudent(null);
    }
    saveAllToDatabase({ students: updatedList });
    showToast('Student record deleted.', 'info');
  };

  const setStudentStatus = (id: string, status: Student['status']) => {
    const updatedList = students.map(s => s.id === id ? { ...s, status } : s);
    setStudents(updatedList);
    saveAllToDatabase({ students: updatedList });
    const label = status === 'active' ? 'Active' : status === 'passed_out' ? 'Passed Out' : 'Dropped';
    showToast(`Student marked as ${label}.`);
  };

  // Discounts
  const addDiscount = (discount: Omit<Discount, 'id' | 'createdAt'>) => {
    const newDisc: Discount = {
      ...discount,
      id: `disc-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    const nextDiscounts = [newDisc, ...discounts];
    setDiscounts(nextDiscounts);
    try {
      localStorage.setItem(`${STORAGE_KEY}_discounts`, JSON.stringify(nextDiscounts));
    } catch {}
    saveAllToDatabase({ discounts: nextDiscounts });
    googleSheetsBackendApi.mutate('addDiscount', newDisc).catch(err => {
      console.warn('Backend addDiscount note:', err);
    });
    showToast(`Discount '${newDisc.title}' applied and saved to database.`);
  };

  const updateDiscount = (id: string, updated: Partial<Discount>) => {
    const nextDiscounts = discounts.map(d => d.id === id ? { ...d, ...updated } : d);
    setDiscounts(nextDiscounts);
    try {
      localStorage.setItem(`${STORAGE_KEY}_discounts`, JSON.stringify(nextDiscounts));
    } catch {}
    saveAllToDatabase({ discounts: nextDiscounts });
    googleSheetsBackendApi.mutate('updateDiscount', { id, updated }).catch(err => {
      console.warn('Backend updateDiscount note:', err);
    });
    showToast('Discount rule updated and saved to database.');
  };

  const deleteDiscount = (id: string) => {
    const nextDiscounts = discounts.filter(d => d.id !== id);
    setDiscounts(nextDiscounts);
    try {
      localStorage.setItem(`${STORAGE_KEY}_discounts`, JSON.stringify(nextDiscounts));
    } catch {}
    saveAllToDatabase({ discounts: nextDiscounts });
    googleSheetsBackendApi.mutate('deleteDiscount', { id }).catch(err => {
      console.warn('Backend deleteDiscount note:', err);
    });
    showToast('Discount rule removed from database.', 'info');
  };

  // Fee Payments & Receipts
  const collectFee = (payment: Omit<FeePayment, 'id' | 'receiptNo' | 'createdAt'>): FeePayment => {
    const currentYear = new Date().getFullYear();
    const receiptNo = `REC/${currentYear}/${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(payments.length + 1).padStart(3, '0')}`;
    
    const newPayment: FeePayment = {
      ...payment,
      id: `pay-${Date.now()}`,
      receiptNo,
      createdAt: new Date().toISOString()
    };

    const nextPayments = [newPayment, ...payments];
    setPayments(nextPayments);
    saveAllToDatabase({ payments: nextPayments });
    showToast(`Fee payment collected! Receipt #${receiptNo} generated.`);
    return newPayment;
  };

  const approvePayment = (paymentId: string, approvedBy: string = 'Admin - Center Desk') => {
    const currentYear = new Date().getFullYear();
    const nextPayments = payments.map(p => {
      if (p.id === paymentId) {
        const receiptNo = p.receiptNo.startsWith('PENDING') 
          ? `REC/${currentYear}/${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(payments.length + 1).padStart(3, '0')}`
          : p.receiptNo;
        return {
          ...p,
          status: 'approved' as const,
          receiptNo,
          approvedBy,
          paymentDate: new Date().toISOString().split('T')[0]
        };
      }
      return p;
    });
    setPayments(nextPayments);
    saveAllToDatabase({ payments: nextPayments });
    showToast('Student fee payment approved successfully!');
  };

  const rejectPayment = (paymentId: string, reason: string) => {
    const nextPayments = payments.map(p => {
      if (p.id === paymentId) {
        return {
          ...p,
          status: 'rejected' as const,
          rejectionReason: reason
        };
      }
      return p;
    });
    setPayments(nextPayments);
    saveAllToDatabase({ payments: nextPayments });
    showToast(`Payment rejected: ${reason}`, 'error');
  };

  const deletePayment = (paymentId: string) => {
    const nextPayments = payments.filter(p => p.id !== paymentId);
    setPayments(nextPayments);
    saveAllToDatabase({ payments: nextPayments });
    showToast('Payment record deleted.', 'info');
  };

  // Expenses
  const addExpense = (expense: Omit<Expense, 'id'>) => {
    const newExp: Expense = {
      ...expense,
      id: `exp-${Date.now()}`
    };
    const nextExpenses = [newExp, ...expenses];
    setExpenses(nextExpenses);
    saveAllToDatabase({ expenses: nextExpenses });
    showToast(`Expense of ₹${newExp.amount.toLocaleString('en-IN')} logged.`);
  };

  const updateExpense = (id: string, updated: Partial<Expense>) => {
    const nextExpenses = expenses.map(e => e.id === id ? { ...e, ...updated } : e);
    setExpenses(nextExpenses);
    saveAllToDatabase({ expenses: nextExpenses });
    showToast('Expense updated.');
  };

  const deleteExpense = (id: string) => {
    const nextExpenses = expenses.filter(e => e.id !== id);
    setExpenses(nextExpenses);
    saveAllToDatabase({ expenses: nextExpenses });
    showToast('Expense record deleted.', 'info');
  };

  // Study Materials (Batchwise)
  const addStudyMaterial = (data: Omit<StudyMaterial, 'id' | 'uploadedDate' | 'downloadCount'>) => {
    const newMaterial: StudyMaterial = {
      ...data,
      id: `mat-${Date.now()}`,
      uploadedDate: new Date().toISOString().split('T')[0],
      downloadCount: 0
    };
    const nextMaterials = [newMaterial, ...studyMaterials];
    setStudyMaterials(nextMaterials);
    saveAllToDatabase({ studyMaterials: nextMaterials });
    showToast(`Study material '${newMaterial.title}' uploaded successfully!`);
  };

  const updateStudyMaterial = (id: string, updated: Partial<StudyMaterial>) => {
    const nextMaterials = studyMaterials.map(m => m.id === id ? { ...m, ...updated } : m);
    setStudyMaterials(nextMaterials);
    saveAllToDatabase({ studyMaterials: nextMaterials });
    showToast('Study material updated.');
  };

  const deleteStudyMaterial = (id: string) => {
    const nextMaterials = studyMaterials.filter(m => m.id !== id);
    setStudyMaterials(nextMaterials);
    saveAllToDatabase({ studyMaterials: nextMaterials });
    showToast('Study material removed from batch repository.', 'info');
  };

  const downloadStudyMaterial = (material: StudyMaterial) => {
    // Increment download count
    const nextMaterials = studyMaterials.map(m => 
      m.id === material.id ? { ...m, downloadCount: (m.downloadCount || 0) + 1 } : m
    );
    setStudyMaterials(nextMaterials);
    saveAllToDatabase({ studyMaterials: nextMaterials });

    if (!material.fileUrl) {
      showToast('File link unavailable.', 'error');
      return;
    }

    try {
      if (material.fileUrl.startsWith('data:') || material.fileUrl.startsWith('blob:')) {
        // Trigger direct file download
        const a = document.createElement('a');
        a.href = material.fileUrl;
        a.download = material.fileName || `${material.title.replace(/[^a-zA-Z0-9]/g, '_')}.${material.fileType || 'pdf'}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      } else {
        // Open web link or drive document in new tab
        window.open(material.fileUrl, '_blank', 'noopener,noreferrer');
      }
      showToast(`Downloading '${material.fileName || material.title}'...`, 'success');
    } catch (err: any) {
      console.error('Download error:', err);
      window.open(material.fileUrl, '_blank');
    }
  };

  // Online Questions & Question Bank Management
  const addQuestion = (data: Omit<ExamQuestion, 'id' | 'createdAt'>): ExamQuestion => {
    const newQuestion: ExamQuestion = {
      ...data,
      id: `q-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    const nextQuestions = [newQuestion, ...questions];
    setQuestions(nextQuestions);
    saveAllToDatabase({ questions: nextQuestions });
    showToast('New question added to Course Question Bank!');
    return newQuestion;
  };

  const updateQuestion = (id: string, updated: Partial<ExamQuestion>) => {
    const nextQuestions = questions.map(q => q.id === id ? { ...q, ...updated } : q);
    setQuestions(nextQuestions);
    saveAllToDatabase({ questions: nextQuestions });
    showToast('Question updated successfully.');
  };

  const deleteQuestion = (id: string) => {
    const nextQuestions = questions.filter(q => q.id !== id);
    setQuestions(nextQuestions);
    saveAllToDatabase({ questions: nextQuestions });
    showToast('Question removed from bank.', 'info');
  };

  const bulkAddQuestions = (questionsList: Omit<ExamQuestion, 'id' | 'createdAt'>[]) => {
    const now = new Date().toISOString().split('T')[0];
    const createdQuestions: ExamQuestion[] = questionsList.map((q, idx) => ({
      ...q,
      id: `q-${Date.now()}-${idx}-${Math.floor(Math.random() * 1000)}`,
      createdAt: now
    }));
    const nextQuestions = [...createdQuestions, ...questions];
    setQuestions(nextQuestions);
    saveAllToDatabase({ questions: nextQuestions });
    showToast(`Successfully imported ${createdQuestions.length} questions into Question Bank!`);
  };

  // Online Exams & Scheduling Management
  const addExam = (data: Omit<OnlineExam, 'id' | 'createdAt'>): OnlineExam => {
    const newExam: OnlineExam = {
      ...data,
      id: `exam-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    const nextExams = [newExam, ...exams];
    setExams(nextExams);
    saveAllToDatabase({ exams: nextExams });
    showToast(`Exam '${newExam.title}' scheduled successfully!`);
    return newExam;
  };

  const updateExam = (id: string, updated: Partial<OnlineExam>) => {
    const nextExams = exams.map(e => e.id === id ? { ...e, ...updated } : e);
    setExams(nextExams);
    saveAllToDatabase({ exams: nextExams });
    showToast('Exam schedule and settings updated.');
  };

  const deleteExam = (id: string) => {
    const nextExams = exams.filter(e => e.id !== id);
    setExams(nextExams);
    saveAllToDatabase({ exams: nextExams });
    showToast('Exam deleted.', 'info');
  };

  const toggleExamPublish = (id: string) => {
    const nextExams = exams.map(e => {
      if (e.id === id) {
        const nextPub = !e.isPublished;
        showToast(nextPub ? 'Exam published to students!' : 'Exam moved to draft.');
        return { ...e, isPublished: nextPub };
      }
      return e;
    });
    setExams(nextExams);
    saveAllToDatabase({ exams: nextExams });
  };

  const setExamStatus = (id: string, status: OnlineExam['status']) => {
    const nextExams = exams.map(e => e.id === id ? { ...e, status } : e);
    setExams(nextExams);
    saveAllToDatabase({ exams: nextExams });
    showToast(`Exam status set to ${status.toUpperCase()}.`);
  };

  // Student Online Exam Submissions
  const submitExamAnswers = (
    examId: string,
    studentId: string,
    answers: Record<string, number>,
    timeSpentSeconds: number
  ): ExamSubmission => {
    const targetExam = exams.find(e => e.id === examId);
    const targetStudent = students.find(s => s.id === studentId) || currentStudent;
    
    // Calculate Score & Breakdown
    let totalScore = 0;
    let maxMarks = targetExam?.totalMarks || 0;
    const questionBreakdown: Array<{
      questionId: string;
      selectedOptionIndex: number | null;
      correctOptionIndex: number;
      isCorrect: boolean;
      marks: number;
    }> = [];
    
    if (targetExam) {
      const examQuestionList = questions.filter(q => targetExam.questionIds.includes(q.id));
      if (examQuestionList.length > 0) {
        maxMarks = examQuestionList.reduce((acc, q) => acc + (q.marks || 1), 0);
        examQuestionList.forEach(q => {
          const studentAns = answers[q.id];
          const hasSelected = studentAns !== undefined && studentAns !== null;
          const isCorrect = hasSelected && studentAns === q.correctOptionIndex;
          if (isCorrect) {
            totalScore += (q.marks || 1);
          }
          questionBreakdown.push({
            questionId: q.id,
            selectedOptionIndex: hasSelected ? studentAns : null,
            correctOptionIndex: q.correctOptionIndex,
            isCorrect,
            marks: q.marks || 1
          });
        });
      }
    }

    const percentage = maxMarks > 0 ? Math.round((totalScore / maxMarks) * 100) : 0;
    const passingPercentage = targetExam?.passingPercentage || (targetExam?.passingMarks ? Math.round((targetExam.passingMarks / maxMarks) * 100) : 40);
    const passed = percentage >= passingPercentage;

    const submission: ExamSubmission = {
      id: `sub-${Date.now()}`,
      examId,
      examTitle: targetExam?.title || 'Online Assessment',
      studentId,
      studentName: targetStudent?.name || 'Student',
      studentRoll: targetStudent?.rollNo || 'N/A',
      studentRollNo: targetStudent?.rollNo || 'N/A',
      studentAadhaar: targetStudent?.aadhaarNo,
      courseId: targetExam?.courseId,
      batchId: targetExam?.batchId,
      answers,
      questionBreakdown,
      score: totalScore,
      totalMarks: maxMarks,
      percentage,
      passed,
      submittedAt: new Date().toISOString(),
      timeSpentSeconds,
      timeTakenMinutes: Math.ceil(timeSpentSeconds / 60)
    };

    // Filter out previous submission for the same student & exam if re-attempting
    const nextSubmissions = [submission, ...examSubmissions.filter(s => !(s.examId === examId && s.studentId === studentId))];
    setExamSubmissions(nextSubmissions);
    saveAllToDatabase({ examSubmissions: nextSubmissions });
    showToast(`Exam submitted! Score: ${totalScore}/${maxMarks} (${percentage}%)`, passed ? 'success' : 'info');
    return submission;
  };

  const deleteExamSubmission = (id: string) => {
    const nextSubmissions = examSubmissions.filter(s => s.id !== id);
    setExamSubmissions(nextSubmissions);
    saveAllToDatabase({ examSubmissions: nextSubmissions });
    showToast('Exam submission record removed.', 'info');
  };

  // Live Classes Management
  const addLiveClass = (data: Omit<LiveClassSession, 'id' | 'createdAt'>, notifyStudents: boolean = true): LiveClassSession => {
    const newSession: LiveClassSession = {
      ...data,
      id: `live-${Date.now()}`,
      notificationSent: notifyStudents,
      notificationSentAt: notifyStudents ? new Date().toISOString() : undefined,
      createdAt: new Date().toISOString().split('T')[0]
    };
    const nextSessions = [newSession, ...liveClasses];
    setLiveClasses(nextSessions);

    let nextNotifs = notifications;
    if (notifyStudents) {
      const newNotif: StudentNotification = {
        id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        title: `📅 New Class Scheduled: ${newSession.title}`,
        message: `A new class "${newSession.title}" has been scheduled on ${newSession.scheduledDate} at ${newSession.startTime} - ${newSession.endTime}.`,
        type: 'class_scheduled',
        courseId: newSession.courseId,
        batchId: newSession.batchId,
        studentId: 'all',
        classSessionId: newSession.id,
        classTitle: newSession.title,
        scheduledDate: newSession.scheduledDate,
        timeSlot: `${newSession.startTime} - ${newSession.endTime}`,
        reason: 'Scheduled by faculty as per academic schedule',
        createdAt: new Date().toISOString().split('T')[0],
        readBy: []
      };
      nextNotifs = [newNotif, ...notifications];
      setNotifications(nextNotifs);
      localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(nextNotifs));
    }

    saveAllToDatabase({ liveClasses: nextSessions, notifications: nextNotifs });
    // Immediate live sync to Google Sheets DB
    googleSheetsBackendApi.mutateRecord('addLiveClass', {
      liveClass: newSession,
      ...newSession
    }).catch(err => console.warn('Live class direct sheet sync note:', err));
    showToast(`Live Class "${newSession.title}" scheduled!`, 'success');
    return newSession;
  };

  const updateLiveClass = (id: string, updated: Partial<LiveClassSession>) => {
    const nextSessions = liveClasses.map(s => s.id === id ? { ...s, ...updated } : s);
    setLiveClasses(nextSessions);
    saveAllToDatabase({ liveClasses: nextSessions });
    // Immediate live sync to Google Sheets DB
    googleSheetsBackendApi.mutateRecord('updateLiveClass', {
      id,
      updated,
      ...updated
    }).catch(err => console.warn('Live class update sheet sync note:', err));
    showToast('Live class session updated.', 'info');
  };

  const deleteLiveClass = (id: string) => {
    const sessionToDelete = liveClasses.find(s => s.id === id);
    const nextSessions = liveClasses.filter(s => s.id !== id);
    setLiveClasses(nextSessions);
    
    // Also remove notifications related to this class if any
    const nextNotifs = notifications.filter(n => n.classSessionId !== id);
    setNotifications(nextNotifs);
    localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(nextNotifs));

    saveAllToDatabase({ liveClasses: nextSessions, notifications: nextNotifs });
    // Immediate live sync to Google Sheets DB
    googleSheetsBackendApi.mutateRecord('deleteLiveClass', { id }).catch(err =>
      console.warn('Live class deletion sheet sync note:', err)
    );
    showToast(`Class "${sessionToDelete?.title || ''}" deleted.`, 'info');
  };

  const setLiveClassStatus = (id: string, status: LiveClassStatus) => {
    const nextSessions = liveClasses.map(s => s.id === id ? { ...s, status } : s);
    setLiveClasses(nextSessions);
    saveAllToDatabase({ liveClasses: nextSessions });
    // Immediate live sync to Google Sheets DB
    googleSheetsBackendApi.mutateRecord('setLiveClassStatus', { id, status }).catch(err =>
      console.warn('Live class status sheet sync note:', err)
    );
    showToast(`Live session status updated to ${status.toUpperCase()}`, status === 'live' ? 'success' : 'info');
  };

  const postponeLiveClass = (
    id: string,
    details: {
      postponedReason: string;
      rescheduledDate?: string;
      rescheduledStartTime?: string;
      rescheduledEndTime?: string;
      notifyStudents?: boolean;
    }
  ) => {
    const session = liveClasses.find(s => s.id === id);
    if (!session) return;

    const nextSessions = liveClasses.map(s => {
      if (s.id !== id) return s;
      return {
        ...s,
        status: 'postponed' as LiveClassStatus,
        isPostponed: true,
        postponedReason: details.postponedReason,
        originalDate: s.originalDate || s.scheduledDate,
        originalStartTime: s.originalStartTime || s.startTime,
        originalEndTime: s.originalEndTime || s.endTime,
        rescheduledDate: details.rescheduledDate || s.scheduledDate,
        rescheduledStartTime: details.rescheduledStartTime || s.startTime,
        rescheduledEndTime: details.rescheduledEndTime || s.endTime,
        postponedAt: new Date().toISOString(),
        notificationSent: details.notifyStudents !== false,
        notificationSentAt: new Date().toISOString()
      };
    });

    setLiveClasses(nextSessions);

    let nextNotifs = notifications;
    if (details.notifyStudents !== false) {
      const reschedInfo = details.rescheduledDate 
        ? ` Rescheduled to: ${details.rescheduledDate}${details.rescheduledStartTime ? ` (${details.rescheduledStartTime})` : ''}.`
        : ' New date will be announced shortly.';
      
      const newNotif: StudentNotification = {
        id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        title: `⚠️ Class Postponed: ${session.title}`,
        message: `Notice for batch students: The class "${session.title}" originally scheduled on ${session.scheduledDate} has been postponed. Reason: ${details.postponedReason}.${reschedInfo}`,
        type: 'class_postponed',
        courseId: session.courseId,
        batchId: session.batchId,
        studentId: 'all',
        classSessionId: session.id,
        classTitle: session.title,
        scheduledDate: session.scheduledDate,
        rescheduledDate: details.rescheduledDate,
        timeSlot: details.rescheduledStartTime ? `${details.rescheduledStartTime} - ${details.rescheduledEndTime || ''}` : `${session.startTime} - ${session.endTime}`,
        reason: details.postponedReason,
        createdAt: new Date().toISOString().split('T')[0],
        readBy: []
      };
      nextNotifs = [newNotif, ...notifications];
      setNotifications(nextNotifs);
      localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(nextNotifs));
    }

    saveAllToDatabase({ liveClasses: nextSessions, notifications: nextNotifs });
    googleSheetsBackendApi.mutateRecord('updateLiveClass', {
      id,
      updated: {
        status: 'postponed',
        isPostponed: true,
        postponedReason: details.postponedReason,
        rescheduledDate: details.rescheduledDate,
        rescheduledStartTime: details.rescheduledStartTime,
        rescheduledEndTime: details.rescheduledEndTime
      }
    }).catch(err => console.warn('Postpone sync note:', err));

    showToast(`Class "${session.title}" postponed! Notification sent to student login.`, 'info');
  };

  const autoGenerateBatchSchedules = (params: {
    courseId: string;
    batchId: string;
    startDate: string;
    endDate: string;
    autoNotify?: boolean;
  }): { generatedCount: number; message: string } => {
    const targetBatches = params.batchId === 'all'
      ? (params.courseId === 'all' ? batches.filter(b => b.isActive) : batches.filter(b => b.courseId === params.courseId && b.isActive))
      : batches.filter(b => b.id === params.batchId);

    if (targetBatches.length === 0) {
      return { generatedCount: 0, message: 'No active batches found matching the selection.' };
    }

    const DAY_MAP: Record<number, string> = {
      0: 'Sun',
      1: 'Mon',
      2: 'Tue',
      3: 'Wed',
      4: 'Thu',
      5: 'Fri',
      6: 'Sat'
    };

    const start = new Date(params.startDate);
    const end = new Date(params.endDate);
    if (isNaN(start.getTime()) || isNaN(end.getTime()) || start > end) {
      return { generatedCount: 0, message: 'Invalid start or end date.' };
    }

    const newSessions: LiveClassSession[] = [];
    const newNotifs: StudentNotification[] = [];

    const parseTiming = (timingStr: string) => {
      const parts = (timingStr || '').split('-').map(s => s.trim());
      return {
        startTime: parts[0] || '05:00 PM',
        endTime: parts[1] || '06:30 PM'
      };
    };

    targetBatches.forEach(batch => {
      const course = courses.find(c => c.id === batch.courseId);
      const educator = educators.find(e => e.id === batch.educatorId) || educators[0];
      const { startTime, endTime } = parseTiming(batch.timing);

      const curr = new Date(start);
      let sessionCountForBatch = 0;

      while (curr <= end) {
        const dayCode = DAY_MAP[curr.getDay()];
        if (batch.scheduleDays && batch.scheduleDays.includes(dayCode)) {
          const dateStr = curr.toISOString().split('T')[0];

          // Check if already exists for this batch on this date
          const existing = liveClasses.some(s => s.batchId === batch.id && s.scheduledDate === dateStr);
          const alreadyInBatch = newSessions.some(s => s.batchId === batch.id && s.scheduledDate === dateStr);

          if (!existing && !alreadyInBatch) {
            const sessionTitle = `${course?.title || 'Academic Course'} - ${batch.name}`;
            const sessionId = `live-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
            const session: LiveClassSession = {
              id: sessionId,
              title: sessionTitle,
              academicClass: batch.academicClass || course?.academicClass || 'All Classes',
              targetClass: batch.academicClass || course?.academicClass || 'All Classes',
              subject: course?.category || 'Computer Science & Technology',
              courseId: batch.courseId,
              batchId: batch.id,
              educatorId: batch.educatorId || educator?.id,
              educatorName: educator?.name || 'Faculty',
              scheduledDate: dateStr,
              startTime,
              endTime,
              status: 'scheduled',
              platform: batch.mode === 'online' ? 'google_meet' : 'in_app',
              meetingUrl: batch.mode === 'online' ? 'https://meet.google.com/new' : undefined,
              roomNumber: batch.roomNumber || 'Classroom 101',
              mode: batch.mode || 'offline',
              notificationSent: !!params.autoNotify,
              createdAt: new Date().toISOString().split('T')[0],
              description: `Regular timetable session for ${batch.name} on ${dayCode} from ${startTime} to ${endTime} in ${batch.roomNumber || 'Classroom 101'}.`
            };

            newSessions.push(session);
            sessionCountForBatch++;
          }
        }
        curr.setDate(curr.getDate() + 1);
      }

      if (params.autoNotify && sessionCountForBatch > 0) {
        newNotifs.push({
          id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          title: `📅 ${sessionCountForBatch} New Class Sessions Scheduled: ${batch.name}`,
          message: `Class sessions for ${batch.name} have been auto-scheduled from ${params.startDate} to ${params.endDate} as per your regular timetable (${batch.scheduleDays.join(', ')} @ ${batch.timing}). Check your student timetable!`,
          type: 'class_scheduled',
          courseId: batch.courseId,
          batchId: batch.id,
          studentId: 'all',
          scheduledDate: params.startDate,
          timeSlot: batch.timing,
          reason: 'Automated Course Batch Schedule sync',
          createdAt: new Date().toISOString().split('T')[0],
          readBy: []
        });
      }
    });

    if (newSessions.length === 0) {
      return { generatedCount: 0, message: 'All scheduled dates in this range are already populated with classes.' };
    }

    const updatedSessions = [...newSessions, ...liveClasses];
    setLiveClasses(updatedSessions);

    let updatedNotifs = notifications;
    if (newNotifs.length > 0) {
      updatedNotifs = [...newNotifs, ...notifications];
      setNotifications(updatedNotifs);
      localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(updatedNotifs));
    }

    saveAllToDatabase({ liveClasses: updatedSessions, notifications: updatedNotifs });
    showToast(`⚡ Auto-generated ${newSessions.length} classes across ${targetBatches.length} batch(es)!`, 'success');

    return {
      generatedCount: newSessions.length,
      message: `Successfully scheduled ${newSessions.length} classes matching batch timetable (${params.startDate} to ${params.endDate}).`
    };
  };

  // Student Notification Management
  const sendStudentNotification = (notif: Omit<StudentNotification, 'id' | 'createdAt'>): StudentNotification => {
    const newNotif: StudentNotification = {
      ...notif,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      createdAt: new Date().toISOString().split('T')[0],
      readBy: notif.readBy || []
    };
    const nextNotifs = [newNotif, ...notifications];
    setNotifications(nextNotifs);
    localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(nextNotifs));
    saveAllToDatabase({ notifications: nextNotifs });
    showToast('Notification alert sent to student login!', 'success');
    return newNotif;
  };

  const markNotificationAsRead = (notificationId: string, studentId: string) => {
    const nextNotifs = notifications.map(n => {
      if (n.id === notificationId) {
        const already = n.readBy || [];
        if (!already.includes(studentId)) {
          return { ...n, readBy: [...already, studentId] };
        }
      }
      return n;
    });
    setNotifications(nextNotifs);
    localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(nextNotifs));
  };

  const clearAllStudentNotifications = (studentId?: string) => {
    if (studentId) {
      const nextNotifs = notifications.map(n => ({
        ...n,
        readBy: Array.from(new Set([...(n.readBy || []), studentId]))
      }));
      setNotifications(nextNotifs);
      localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(nextNotifs));
    } else {
      setNotifications([]);
      localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify([]));
      saveAllToDatabase({ notifications: [] });
    }
  };

  // Class Recordings Management
  const addClassRecording = (data: Omit<ClassRecording, 'id' | 'createdAt' | 'viewCount'>): ClassRecording => {
    const newRec: ClassRecording = {
      ...data,
      id: `rec-${Date.now()}`,
      viewCount: 0,
      createdAt: new Date().toISOString().split('T')[0]
    };
    const nextRecs = [newRec, ...classRecordings];
    setClassRecordings(nextRecs);
    saveAllToDatabase({ classRecordings: nextRecs });
    // Immediate live sync to Google Sheets DB
    googleSheetsBackendApi.mutateRecord('addClassRecording', {
      recording: newRec,
      ...newRec
    }).catch(err => console.warn('Class recording direct sheet sync note:', err));
    showToast(`Recorded class "${newRec.title}" published!`, 'success');
    return newRec;
  };

  const updateClassRecording = (id: string, updated: Partial<ClassRecording>) => {
    const nextRecs = classRecordings.map(r => r.id === id ? { ...r, ...updated } : r);
    setClassRecordings(nextRecs);
    saveAllToDatabase({ classRecordings: nextRecs });
    // Immediate live sync to Google Sheets DB
    googleSheetsBackendApi.mutateRecord('updateClassRecording', {
      id,
      updated,
      ...updated
    }).catch(err => console.warn('Class recording update sheet sync note:', err));
    showToast('Class recording updated.', 'info');
  };

  const deleteClassRecording = (id: string) => {
    const nextRecs = classRecordings.filter(r => r.id !== id);
    setClassRecordings(nextRecs);
    saveAllToDatabase({ classRecordings: nextRecs });
    // Immediate live sync to Google Sheets DB
    googleSheetsBackendApi.mutateRecord('deleteClassRecording', { id }).catch(err =>
      console.warn('Class recording deletion sheet sync note:', err)
    );
    showToast('Class recording deleted.', 'info');
  };

  const incrementRecordingViews = (id: string) => {
    const nextRecs = classRecordings.map(r => r.id === id ? { ...r, viewCount: (r.viewCount || 0) + 1 } : r);
    setClassRecordings(nextRecs);
    try {
      localStorage.setItem(`${STORAGE_KEY}_class_recordings`, JSON.stringify(nextRecs));
    } catch {}
  };

  // Admissions
  const submitAdmissionApplication = (
    data: Omit<AdmissionApplication, 'id' | 'applicationNo' | 'appliedDate' | 'status'>
  ): AdmissionApplication => {
    const currentYear = new Date().getFullYear();
    const appNo = `APP/${currentYear}/${100 + admissions.length + 1}`;
    const newApp: AdmissionApplication = {
      ...data,
      id: `adm-${Date.now()}`,
      applicationNo: appNo,
      appliedDate: new Date().toISOString().split('T')[0],
      status: 'pending'
    };

    const nextAdmissions = [newApp, ...admissions];
    setAdmissions(nextAdmissions);
    saveAllToDatabase({ admissions: nextAdmissions });
    showToast(`Admission application #${appNo} submitted successfully!`);
    return newApp;
  };

  const approveAdmission = (
    applicationId: string, 
    batchId: string, 
    customRollNo?: string, 
    admissionMonth?: string,
    feePaymentDetails?: {
      isPaid?: boolean;
      amount?: number;
      paymentMode?: PaymentMode;
      transactionRef?: string;
      paymentDate?: string;
      remarks?: string;
      totalDiscount?: number;
      discountBreakdown?: string;
      totalBaseFee?: number;
    }
  ) => {
    const app = admissions.find(a => a.id === applicationId);
    if (!app) return undefined;

    const currentYear = new Date().getFullYear();
    const admMonth = admissionMonth || `${currentYear}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
    const rollNo = customRollNo || `PP-${currentYear}-${String(students.length + 1).padStart(3, '0')}`;
    const targetBatchId = batchId || app.preferredBatchId || (batches[0]?.id ?? 'batch-1');
    const course = courses.find(c => c.id === app.targetCourseId);
    const batch = batches.find(b => b.id === targetBatchId);

    // Create student
    const newStudent: Student = {
      id: `stu-${Date.now()}`,
      rollNo,
      name: app.studentName,
      studentClass: app.studentClass || course?.academicClass || batch?.academicClass || 'Class 12',
      mode: (batch?.mode || 'offline') as any,
      mobile: app.mobile,
      aadhaarNo: app.aadhaarNo,
      email: app.email,
      guardianName: app.guardianName,
      guardianPhone: app.guardianPhone,
      address: app.address,
      courseId: app.targetCourseId,
      batchId: targetBatchId,
      admissionDate: new Date().toISOString().split('T')[0],
      admissionMonth: admMonth,
      status: 'active',
      notes: app.remarks || `Enrolled from Online Admission Application #${app.applicationNo}`
    };

    const nextStudents = [newStudent, ...students];
    setStudents(nextStudents);

    let nextPayments = payments;
    let createdPayment: FeePayment | undefined = undefined;

    // Check if initial payment should be recorded
    const isFeePaid = feePaymentDetails?.isPaid !== undefined
      ? feePaymentDetails.isPaid
      : (app.initialPaymentStatus === 'paid_advance' || (app.initialPaymentAmount && app.initialPaymentAmount > 0));

    if (isFeePaid) {
      const paymentAmount = Number(feePaymentDetails?.amount ?? app.initialPaymentAmount ?? course?.monthlyFee ?? 1500);
      const paymentMode = feePaymentDetails?.paymentMode || app.initialPaymentMode || 'UPI';
      const paymentRef = (feePaymentDetails?.transactionRef || app.initialPaymentRef || 'ONLINE-ADM-PAY').trim();
      const paymentDate = feePaymentDetails?.paymentDate || new Date().toISOString().split('T')[0];
      const monthSplit = admMonth.includes('-') ? admMonth.split('-')[1] : '04';
      const receiptNo = `REC/${currentYear}/${monthSplit}-${String(payments.length + 1).padStart(3, '0')}`;

      const targetDisc = calculateTargetDiscount({
        studentClass: newStudent.studentClass,
        courseId: newStudent.courseId,
        batchId: newStudent.batchId,
        studentId: newStudent.id,
        monthKey: admMonth,
        baseFee: course?.monthlyFee || paymentAmount,
        discounts,
        course
      });

      const discountToRecord = feePaymentDetails?.totalDiscount !== undefined 
        ? feePaymentDetails.totalDiscount 
        : (app.appliedDiscountAmount !== undefined ? app.appliedDiscountAmount : targetDisc.discountAmount);

      const discountNotesToRecord = feePaymentDetails?.discountBreakdown || app.appliedDiscountNotes || (targetDisc.notes.length > 0 ? targetDisc.notes.join('; ') : (discountToRecord > 0 ? 'Concession Applied' : undefined));
      const baseFeeToRecord = feePaymentDetails?.totalBaseFee || course?.monthlyFee || (paymentAmount + discountToRecord);

      createdPayment = {
        id: `pay-${Date.now()}`,
        receiptNo,
        studentId: newStudent.id,
        studentName: newStudent.name,
        studentAadhaar: newStudent.aadhaarNo,
        studentMobile: newStudent.mobile,
        courseTitle: course?.title || 'Tuition Program',
        batchName: batch?.name || 'Assigned Batch',
        month: formatMonthKey(admMonth),
        monthsCovered: [admMonth],
        baseMonthlyFee: baseFeeToRecord,
        totalBaseFee: baseFeeToRecord,
        totalDiscount: discountToRecord,
        discountBreakdown: discountNotesToRecord,
        finalAmountPaid: paymentAmount,
        remainingDue: Math.max(0, baseFeeToRecord - discountToRecord - paymentAmount),
        paymentMode,
        transactionRef: paymentRef,
        status: 'approved',
        paymentDate,
        approvedBy: 'Admin (Application Approval)',
        remarks: feePaymentDetails?.remarks || (discountNotesToRecord ? `Admission & 1st month tuition (${discountNotesToRecord}) (Application #${app.applicationNo})` : `Admission fee & tuition for ${formatMonthKey(admMonth)} (Application #${app.applicationNo})`),
        createdAt: new Date().toISOString()
      };

      nextPayments = [createdPayment, ...payments];
      setPayments(nextPayments);
    }

    // Update application status
    const nextAdmissions = admissions.map(a => a.id === applicationId ? {
      ...a,
      status: 'approved' as const,
      initialPaymentStatus: isFeePaid ? ('paid_advance' as const) : a.initialPaymentStatus,
      initialPaymentAmount: isFeePaid ? (feePaymentDetails?.amount ?? app.initialPaymentAmount ?? course?.monthlyFee ?? 1500) : a.initialPaymentAmount,
      processedDate: new Date().toISOString().split('T')[0]
    } : a);
    setAdmissions(nextAdmissions);

    try {
      localStorage.setItem(`${STORAGE_KEY}_students`, JSON.stringify(nextStudents));
      localStorage.setItem(`${STORAGE_KEY}_admissions`, JSON.stringify(nextAdmissions));
      if (nextPayments) {
        localStorage.setItem(`${STORAGE_KEY}_payments`, JSON.stringify(nextPayments));
      }
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }

    // Call dedicated backend approveAdmission endpoint
    googleSheetsBackendApi.approveAdmission({
      applicationId,
      student: newStudent,
      payment: createdPayment,
      admission: nextAdmissions.find(a => a.id === applicationId)
    }).catch(err => console.warn('Backend approveAdmission sync note:', err));

    saveAllToDatabase({ admissions: nextAdmissions, students: nextStudents, payments: nextPayments });
    showToast(`Application #${app.applicationNo} approved! Student enrolled with Roll No ${rollNo}.${createdPayment ? ` Payment receipt ${createdPayment.receiptNo} recorded in Fee Transactions!` : ''}`);
    return { student: newStudent, payment: createdPayment };
  };

  const rejectAdmission = (applicationId: string, reason: string) => {
    const nextAdmissions = admissions.map(a => a.id === applicationId ? {
      ...a,
      status: 'rejected' as const,
      rejectionReason: reason,
      processedDate: new Date().toISOString().split('T')[0]
    } : a);
    setAdmissions(nextAdmissions);
    saveAllToDatabase({ admissions: nextAdmissions });
    showToast('Application rejected.', 'info');
  };

  const deleteAdmission = (applicationId: string) => {
    const nextAdmissions = admissions.filter(a => a.id !== applicationId);
    setAdmissions(nextAdmissions);
    saveAllToDatabase({ admissions: nextAdmissions });
    showToast('Application record deleted.', 'info');
  };

  // Student Auth
  const normalizeMobile = (m: string) => m.replace(/\D/g, '').slice(-10);
  const normalizeAadhaar = (a: string) => a.replace(/\D/g, '');

  const loginStudent = async (mobile: string, aadhaarNo: string): Promise<{ 
    success: boolean; 
    message: string; 
    student?: Student;
    isPendingAdmission?: boolean;
    application?: AdmissionApplication;
  }> => {
    const cleanMobile = normalizeMobile(mobile);
    const cleanAadhaar = normalizeAadhaar(aadhaarNo);

    if (!cleanMobile || cleanMobile.length < 10) {
      return { success: false, message: 'Please enter a valid 10-digit mobile number.' };
    }
    if (!cleanAadhaar || (cleanAadhaar.length !== 12 && cleanAadhaar.length !== 4)) {
      return { success: false, message: 'Please enter a valid 12-digit Aadhaar Number (or last 4 digits).' };
    }

    const enrichStudentObj = (stu: any): Student => {
      const c = courses.find(item => item.id === stu.courseId);
      const b = batches.find(item => item.id === stu.batchId);
      const resolvedClass = stu.studentClass || c?.academicClass || b?.academicClass || (c?.title?.includes('XII') ? 'Class 12' : c?.title?.includes('XI') ? 'Class 11' : 'Class 12');
      return {
        ...stu,
        studentClass: resolvedClass
      };
    };

    try {
      const serverRes = await googleSheetsBackendApi.studentLogin(cleanMobile, aadhaarNo);
      if (serverRes.success && serverRes.student) {
        const enriched = enrichStudentObj(serverRes.student);
        setCurrentStudent(enriched);
        showToast(`Welcome back, ${enriched.name}!`);
        return { success: true, message: serverRes.message, student: enriched };
      }
    } catch (err) {
      console.warn('Backend student auth error, checking active state records:', err);
    }

    const matched = students.find(s => {
      const stuMobile = normalizeMobile(s.mobile);
      const stuAadhaar = normalizeAadhaar(s.aadhaarNo);
      
      const mobileMatches = stuMobile === cleanMobile;
      const aadhaarMatches = stuAadhaar === cleanAadhaar || stuAadhaar.endsWith(cleanAadhaar) || cleanAadhaar.endsWith(stuAadhaar);

      return mobileMatches && aadhaarMatches;
    });

    if (matched) {
      const enriched = enrichStudentObj(matched);
      setCurrentStudent(enriched);
      showToast(`Welcome back, ${enriched.name}!`);
      return { success: true, message: `Welcome ${enriched.name}!`, student: enriched };
    }

    // Check if user has an admission application registered
    const matchedApp = admissions.find(a => {
      const appMobile = normalizeMobile(a.mobile);
      const appAadhaar = normalizeAadhaar(a.aadhaarNo);
      const mobileMatches = appMobile === cleanMobile;
      const aadhaarMatches = cleanAadhaar.length === 12 
        ? appAadhaar === cleanAadhaar 
        : appAadhaar.endsWith(cleanAadhaar) || a.applicationNo.toLowerCase().includes(aadhaarNo.toLowerCase().trim());

      return mobileMatches && aadhaarMatches;
    });

    if (matchedApp) {
      if (matchedApp.status === 'pending') {
        return { 
          success: false, 
          isPendingAdmission: true,
          application: matchedApp,
          message: 'Your application is under process, Please contact you educator or visit center with payment receipt' 
        };
      } else if (matchedApp.status === 'rejected') {
        return { 
          success: false, 
          message: `Your admission application (#${matchedApp.applicationNo}) was rejected: ${matchedApp.rejectionReason || 'Please contact center office for details.'}` 
        };
      }
    }

    return { 
      success: false, 
      message: 'No student found in database matching this Mobile Number and Aadhaar Number. Please check your credentials or contact Pixel Pathsala office.' 
    };
  };

  const logoutStudent = () => {
    setCurrentStudent(null);
    try {
      localStorage.removeItem(`${STORAGE_KEY}_auth_student`);
      localStorage.removeItem('pixel_pathsala_erp_v1_auth_student');
      sessionStorage.clear();
    } catch {}
    showToast('Logged out from Student Portal.', 'info');
  };

  const submitStudentFeePayment = (params: {
    studentId: string;
    months: string[];
    amount: number;
    mode: PaymentMode;
    transactionRef: string;
    remarks?: string;
  }): FeePayment => {
    const stu = students.find(s => s.id === params.studentId);
    const course = courses.find(c => c.id === stu?.courseId);
    const batch = batches.find(b => b.id === stu?.batchId);

    const formattedMonths = params.months.map(formatMonthKey).join(', ');
    const pendingReceiptNo = `PENDING-PAY-${Date.now().toString().slice(-4)}`;

    const newPayment: FeePayment = {
      id: `pay-${Date.now()}`,
      receiptNo: pendingReceiptNo,
      studentId: params.studentId,
      studentName: stu?.name || 'Student',
      studentAadhaar: stu?.aadhaarNo || '',
      studentMobile: stu?.mobile || '',
      courseTitle: course?.title || 'Enrolled Course',
      batchName: batch?.name || 'Batch',
      month: formattedMonths,
      monthsCovered: params.months,
      baseMonthlyFee: course?.monthlyFee || params.amount,
      totalBaseFee: params.amount,
      totalDiscount: 0,
      finalAmountPaid: params.amount,
      remainingDue: 0,
      paymentMode: params.mode,
      transactionRef: params.transactionRef,
      status: 'pending',
      paymentDate: new Date().toISOString().split('T')[0],
      remarks: params.remarks || `Self-submitted via Student Portal (${params.mode})`,
      createdAt: new Date().toISOString()
    };

    const nextPayments = [newPayment, ...payments];
    setPayments(nextPayments);
    saveAllToDatabase({ payments: nextPayments });
    showToast('Payment submitted for Admin approval. Receipt will be generated once verified!');
    return newPayment;
  };

  // Admin Account Table CRUD Methods
  const addAdminAccount = (acc: Omit<AdminAccount, 'id' | 'updatedAt'>) => {
    const newAcc: AdminAccount = {
      ...acc,
      id: `ADM-${String(adminAccounts.length + 1).padStart(3, '0')}`,
      updatedAt: new Date().toISOString().split('T')[0]
    };
    const updatedList = [...adminAccounts, newAcc];
    setAdminAccounts(updatedList);
    localStorage.setItem(`${STORAGE_KEY}_admin_accounts`, JSON.stringify(updatedList));
    saveAllToDatabase({ adminAccounts: updatedList });
    showToast(`Added admin user: ${acc.username}`, 'success');
  };

  const updateAdminAccount = (id: string, acc: Partial<AdminAccount>) => {
    const updatedList = adminAccounts.map(a => {
      if (a.id === id) {
        const merged = { ...a, ...acc, updatedAt: new Date().toISOString().split('T')[0] };
        // Also keep active adminCreds in sync if current user is edited
        if (merged.username === adminCreds.username || a.username === adminCreds.username) {
          setAdminCreds({
            username: merged.username,
            password: merged.password,
            name: merged.name,
            role: merged.role,
            email: merged.email
          });
        }
        return merged;
      }
      return a;
    });
    setAdminAccounts(updatedList);
    localStorage.setItem(`${STORAGE_KEY}_admin_accounts`, JSON.stringify(updatedList));
    saveAllToDatabase({ adminAccounts: updatedList });
    showToast('Admin account details updated successfully in database.', 'success');
  };

  const deleteAdminAccount = (id: string) => {
    if (adminAccounts.length <= 1) {
      showToast('Cannot delete the last remaining Administrator account.', 'error');
      return;
    }
    const updatedList = adminAccounts.filter(a => a.id !== id);
    setAdminAccounts(updatedList);
    localStorage.setItem(`${STORAGE_KEY}_admin_accounts`, JSON.stringify(updatedList));
    saveAllToDatabase({ adminAccounts: updatedList });
    showToast('Admin account removed from database.', 'info');
  };

  // Admin Auth Methods - Verified directly against Database
  const loginAdmin = async (usernameInput: string, passwordInput: string, rememberMe: boolean = true): Promise<{ success: boolean; message: string; adminUser?: any }> => {
    const cleanUser = usernameInput.trim().toLowerCase();
    const cleanPass = passwordInput.trim();

    if (!cleanUser || !cleanPass) {
      return { success: false, message: 'Please enter both Username/Email and Password.' };
    }

    try {
      // 1. Direct Server Backend Database Authentication
      const serverRes = await googleSheetsBackendApi.adminLogin(cleanUser, cleanPass);
      if (serverRes.success && serverRes.adminUser) {
        const userObj = {
          username: serverRes.adminUser.username,
          name: serverRes.adminUser.name,
          role: serverRes.adminUser.role,
          email: serverRes.adminUser.email,
          lastLogin: serverRes.adminUser.lastLogin || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' })
        };
        setIsAdminLoggedIn(true);
        setAdminUser(userObj);

        // Update local admin accounts state with latest lastLogin timestamp
        setAdminAccounts(prev => prev.map(a => (a.username.toLowerCase() === userObj.username.toLowerCase() || a.email.toLowerCase() === userObj.email.toLowerCase()) ? { ...a, lastLogin: userObj.lastLogin } : a));

        if (rememberMe) {
          localStorage.setItem(`${STORAGE_KEY}_admin_logged_in`, 'true');
          localStorage.setItem(`${STORAGE_KEY}_admin_user`, JSON.stringify(userObj));
        } else {
          sessionStorage.setItem(`${STORAGE_KEY}_admin_logged_in`, 'true');
          sessionStorage.setItem(`${STORAGE_KEY}_admin_user`, JSON.stringify(userObj));
        }
        showToast(`Welcome back, ${userObj.name}! Authenticated via Database.`, 'success');
        return { success: true, message: serverRes.message, adminUser: userObj };
      } else if (serverRes && !serverRes.success && serverRes.message) {
        return { success: false, message: serverRes.message };
      }
    } catch (err: any) {
      console.warn('Server admin login request note, trying local state authentication:', err);
    }

    // 2. Fallback check against adminAccounts
    const matchedAccount = adminAccounts.find(
      a => (a.username.toLowerCase() === cleanUser || a.email.toLowerCase() === cleanUser) &&
           a.status === 'active' &&
           (a.password === cleanPass || (cleanPass === 'admin123' && a.password === 'admin123'))
    );

    const matchesMasterUser = 
      cleanUser === adminCreds.username.toLowerCase() || 
      cleanUser === adminCreds.email.toLowerCase() || 
      cleanUser === 'admin';
      
    const matchesMasterPass = cleanPass === adminCreds.password || (cleanPass === 'admin123' && adminCreds.password === 'admin123');

    if (matchedAccount || (matchesMasterUser && matchesMasterPass)) {
      const activeName = matchedAccount ? matchedAccount.name : adminCreds.name;
      const activeRole = matchedAccount ? matchedAccount.role : adminCreds.role;
      const activeEmail = matchedAccount ? matchedAccount.email : adminCreds.email;
      const activeUsername = matchedAccount ? matchedAccount.username : adminCreds.username;

      const userObj = {
        username: activeUsername,
        name: activeName,
        role: activeRole,
        email: activeEmail,
        lastLogin: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' })
      };
      setIsAdminLoggedIn(true);
      setAdminUser(userObj);

      if (matchedAccount) {
        updateAdminAccount(matchedAccount.id, { lastLogin: userObj.lastLogin });
      }

      if (rememberMe) {
        localStorage.setItem(`${STORAGE_KEY}_admin_logged_in`, 'true');
        localStorage.setItem(`${STORAGE_KEY}_admin_user`, JSON.stringify(userObj));
      } else {
        sessionStorage.setItem(`${STORAGE_KEY}_admin_logged_in`, 'true');
        sessionStorage.setItem(`${STORAGE_KEY}_admin_user`, JSON.stringify(userObj));
      }
      showToast(`Welcome back, ${activeName}! Admin ERP session unlocked.`, 'success');
      return { success: true, message: 'Authentication successful.' };
    }

    return { success: false, message: 'Invalid Admin credentials. User account was not found or password does not match in database.' };
  };

  const logoutAdmin = () => {
    setIsAdminLoggedIn(false);
    setAdminUser(null);
    try {
      localStorage.removeItem(`${STORAGE_KEY}_admin_logged_in`);
      localStorage.removeItem(`${STORAGE_KEY}_admin_user`);
      sessionStorage.removeItem(`${STORAGE_KEY}_admin_logged_in`);
      sessionStorage.removeItem(`${STORAGE_KEY}_admin_user`);
    } catch (e) {
      console.warn('Logout cleanup failed', e);
    }
    showToast('Admin session logged out safely.', 'info');
  };

  const updateAdminPassword = (currentPassword: string, newPassword: string) => {
    if (currentPassword !== adminCreds.password && !(currentPassword === 'admin123' && adminCreds.password === 'admin123')) {
      return { success: false, message: 'Current master password does not match.' };
    }
    if (!newPassword || newPassword.length < 4) {
      return { success: false, message: 'New password must be at least 4 characters.' };
    }
    const updated = { ...adminCreds, password: newPassword };
    setAdminCreds(updated);
    localStorage.setItem(`${STORAGE_KEY}_admin_creds`, JSON.stringify(updated));

    // Also update in adminAccounts table
    if (adminAccounts.length > 0) {
      const updatedAccounts = adminAccounts.map((a, idx) => idx === 0 ? { ...a, password: newPassword, updatedAt: new Date().toISOString().split('T')[0] } : a);
      setAdminAccounts(updatedAccounts);
      localStorage.setItem(`${STORAGE_KEY}_admin_accounts`, JSON.stringify(updatedAccounts));
      saveAllToDatabase({ adminAccounts: updatedAccounts });
    }

    showToast('Admin password updated successfully.', 'success');
    return { success: true, message: 'Admin password updated successfully.' };
  };

  const [isSyncingSheets, setIsSyncingSheets] = useState(false);
  const [isPullingSheets, setIsPullingSheets] = useState(false);
  const [googleUser, setGoogleUser] = useState<GoogleUserProfile | null>(() => googleSheetsService.getGoogleUser());
  const [isGoogleConnected, setIsGoogleConnected] = useState<boolean>(() => !!googleSheetsService.getAccessToken());

  const connectGoogleAccount = async (): Promise<boolean> => {
    try {
      const res = await googleSheetsService.requestOAuthToken();
      if (res.success && res.token) {
        const userProfile = googleSheetsService.getGoogleUser();
        setIsGoogleConnected(true);
        setGoogleUser(userProfile);

        // Persist token and profile to backend server so other devices don't need re-authorization
        await googleSheetsBackendApi.persistSession(res.token, userProfile, 3600);

        showToast('Google Account connected successfully & persisted securely on server!', 'success');
        return true;
      } else {
        showToast(res.error || 'Failed to authenticate with Google.', 'error');
        return false;
      }
    } catch (e: any) {
      showToast(e.message || 'Error initiating Google Sign-In', 'error');
      return false;
    }
  };

  const disconnectGoogleAccount = async () => {
    googleSheetsService.clearToken();
    await googleSheetsBackendApi.disconnectSession();
    setIsGoogleConnected(false);
    setGoogleUser(null);
    showToast('Google Account disconnected from ERP server.', 'info');
  };

  const syncToGoogleSheets = async (customSheetId?: string): Promise<{ success: boolean; message: string; url?: string }> => {
    const targetSheetId = customSheetId || centerInfo.googleSheetId;
    if (!targetSheetId) {
      showToast('No Google Sheet ID provided. Please create or link a sheet first.', 'error');
      return { success: false, message: 'No Google Sheet ID provided.' };
    }

    setIsSyncingSheets(true);
    try {
      // First try via backend API
      const serverRes = await googleSheetsBackendApi.saveAll({
        spreadsheetId: targetSheetId,
        students,
        admissions,
        payments,
        courses,
        batches,
        educators,
        expenses,
        discounts,
        adminAccounts,
        studyMaterials,
        questions,
        exams,
        examSubmissions,
        liveClasses,
        classRecordings,
        centerInfo
      });

      if (serverRes.success && !serverRes.needsClientSheetsSync) {
        const nowFormatted = serverRes.lastSynced || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
        updateCenterInfo({
          googleSheetId: targetSheetId,
          googleSheetLastSynced: nowFormatted
        });
        showToast(`Synced all 15 ERP tables directly to Google Sheet database!`, 'success');
        return {
          success: true,
          message: serverRes.message || 'Synced successfully.',
          url: `https://docs.google.com/spreadsheets/d/${targetSheetId}/edit`
        };
      }

      // Client-side direct sync if backend reported token issue or needs direct sheets write
      const result = await googleSheetsService.syncAllToGoogleSheet(targetSheetId, {
        centerInfo,
        students,
        admissions,
        payments,
        courses,
        batches,
        educators,
        expenses,
        discounts,
        adminAccounts,
        studyMaterials,
        questions,
        exams,
        examSubmissions,
        liveClasses,
        classRecordings
      });

      if (result.success) {
        const nowFormatted = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
        updateCenterInfo({
          googleSheetId: result.spreadsheetId,
          googleSheetLastSynced: nowFormatted
        });
        showToast(`Synced ${result.recordsCount} ERP records to Google Sheets!`, 'success');
        return {
          success: true,
          message: result.message,
          url: result.spreadsheetUrl
        };
      } else {
        showToast(result.message, 'error');
        return { success: false, message: result.message };
      }
    } catch (err: any) {
      const msg = err.message || 'Failed to sync with Google Sheets.';
      showToast(msg, 'error');
      return { success: false, message: msg };
    } finally {
      setIsSyncingSheets(false);
    }
  };

  const pullFromGoogleSheets = async (customSheetId?: string): Promise<{ success: boolean; message: string; counts?: any }> => {
    const targetSheetId = customSheetId || centerInfo.googleSheetId;
    if (!targetSheetId) {
      showToast('No Google Sheet ID provided. Please link or create a sheet first.', 'error');
      return { success: false, message: 'No Google Sheet ID provided.' };
    }

    setIsPullingSheets(true);
    try {
      // First try via backend API
      const serverRes = await googleSheetsBackendApi.loadAll(targetSheetId);
      if (serverRes.success && serverRes.data) {
        const { data, counts } = serverRes;
        if (Array.isArray(data.courses)) setCourses(data.courses);
        if (Array.isArray(data.batches)) setBatches(data.batches);
        if (Array.isArray(data.students)) setStudents(data.students);
        if (Array.isArray(data.admissions)) setAdmissions(data.admissions);
        if (Array.isArray(data.payments)) setPayments(data.payments);
        if (Array.isArray(data.educators)) setEducators(data.educators);
        if (Array.isArray(data.expenses)) setExpenses(data.expenses);
        if (Array.isArray(data.adminAccounts) && data.adminAccounts.length > 0) setAdminAccounts(data.adminAccounts);
        if (Array.isArray(data.studyMaterials)) setStudyMaterials(data.studyMaterials);
        if (Array.isArray(data.questions)) setQuestions(data.questions);
        if (Array.isArray(data.exams)) setExams(data.exams);
        if (Array.isArray(data.examSubmissions)) setExamSubmissions(data.examSubmissions);
        if (Array.isArray(data.liveClasses)) setLiveClasses(data.liveClasses);
        if (Array.isArray(data.classRecordings)) setClassRecordings(data.classRecordings);
        if (data.centerInfo && typeof data.centerInfo === 'object') {
          updateCenterInfo(data.centerInfo);
        }

        const nowFormatted = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
        updateCenterInfo({
          googleSheetId: targetSheetId,
          googleSheetLastSynced: `${nowFormatted} (Live Synced)`
        });

        showToast('Successfully refreshed latest live data from Google Sheets!', 'success');
        return { success: true, message: 'Data refreshed from Google Sheets', counts };
      }

      // Fallback to client-side direct pull
      const result = await googleSheetsService.pullAllFromGoogleSheet(targetSheetId);
      if (result.success && result.parsedData) {
        const { parsedData, counts } = result;

        if (Array.isArray(parsedData.courses)) setCourses(parsedData.courses);
        if (Array.isArray(parsedData.batches)) setBatches(parsedData.batches);
        if (Array.isArray(parsedData.students)) setStudents(parsedData.students);
        if (Array.isArray(parsedData.admissions)) setAdmissions(parsedData.admissions);
        if (Array.isArray(parsedData.payments)) setPayments(parsedData.payments);
        if (Array.isArray(parsedData.educators)) setEducators(parsedData.educators);
        if (Array.isArray(parsedData.expenses)) setExpenses(parsedData.expenses);
        if (Array.isArray(parsedData.adminAccounts) && parsedData.adminAccounts.length > 0) setAdminAccounts(parsedData.adminAccounts);
        if (Array.isArray(parsedData.studyMaterials)) setStudyMaterials(parsedData.studyMaterials);
        if (Array.isArray(parsedData.questions)) setQuestions(parsedData.questions);
        if (Array.isArray(parsedData.exams)) setExams(parsedData.exams);
        if (Array.isArray(parsedData.examSubmissions)) setExamSubmissions(parsedData.examSubmissions);
        if (Array.isArray(parsedData.liveClasses)) setLiveClasses(parsedData.liveClasses);
        if (Array.isArray(parsedData.classRecordings)) setClassRecordings(parsedData.classRecordings);
        if (parsedData.centerInfo && typeof parsedData.centerInfo === 'object') {
          updateCenterInfo(parsedData.centerInfo);
        }

        const nowFormatted = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
        updateCenterInfo({
          googleSheetId: targetSheetId,
          googleSheetLastSynced: `${nowFormatted} (Two-Way Synced)`
        });

        showToast(result.message, 'success');
        return { success: true, message: result.message, counts };
      } else {
        showToast(result.message || 'Failed to pull data from Google Sheet.', 'error');
        return { success: false, message: result.message };
      }
    } catch (err: any) {
      const msg = err.message || 'Failed to pull records from Google Sheet.';
      showToast(msg, 'error');
      return { success: false, message: msg };
    } finally {
      setIsPullingSheets(false);
    }
  };

  const createNewGoogleSheetDatabase = async (): Promise<{ success: boolean; message: string; id?: string; url?: string }> => {
    setIsSyncingSheets(true);
    try {
      // First try via backend API
      const serverRes = await googleSheetsBackendApi.createMasterSheet(centerInfo, {
        students,
        admissions,
        payments,
        courses,
        batches,
        educators,
        expenses,
        discounts,
        adminAccounts,
        studyMaterials,
        questions,
        exams,
        examSubmissions,
        liveClasses,
        classRecordings,
        centerInfo
      });

      if (serverRes.success && serverRes.spreadsheetId) {
        const nowFormatted = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
        updateCenterInfo({
          googleSheetId: serverRes.spreadsheetId,
          googleSheetLastSynced: nowFormatted
        });

        showToast(`Created & linked new Google Sheet Master Database: "${serverRes.spreadsheetId.slice(0, 8)}..."`, 'success');
        return {
          success: true,
          message: serverRes.message || 'Google Sheet Database created and linked successfully!',
          id: serverRes.spreadsheetId,
          url: serverRes.spreadsheetUrl
        };
      }

      // Fallback to client-side creation
      const { id, url } = await googleSheetsService.createPixelPathsalaSpreadsheet(centerInfo.name);
      
      await googleSheetsService.syncAllToGoogleSheet(id, {
        centerInfo: { ...centerInfo, googleSheetId: id },
        students,
        admissions,
        payments,
        courses,
        batches,
        educators,
        expenses,
        discounts,
        adminAccounts,
        studyMaterials,
        questions,
        exams,
        examSubmissions,
        liveClasses,
        classRecordings
      });

      const nowFormatted = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
      updateCenterInfo({
        googleSheetId: id,
        googleSheetLastSynced: nowFormatted
      });

      // Also persist to backend
      await googleSheetsBackendApi.linkSheet(id);

      showToast(`Created & populated new Google Sheet: "${id.slice(0, 8)}..."`, 'success');
      return {
        success: true,
        message: 'Google Sheet Database created and populated successfully!',
        id,
        url
      };
    } catch (err: any) {
      const msg = err.message || 'Failed to create Google Sheet.';
      showToast(msg, 'error');
      return { success: false, message: msg };
    } finally {
      setIsSyncingSheets(false);
    }
  };

  const exportBackupObject = (): FullDatabaseBackup => {
    return {
      backupVersion: '2.0',
      exportedAt: new Date().toISOString(),
      appTitle: centerInfo.name || 'Pixel Pathsala',
      centerInfo,
      students,
      admissions,
      payments,
      courses,
      batches,
      educators,
      expenses,
      discounts,
      adminAccounts,
      studyMaterials,
      questions,
      exams,
      examSubmissions,
      liveClasses,
      classRecordings,
      summaryCounts: {
        students: students.length,
        admissions: admissions.length,
        payments: payments.length,
        courses: courses.length,
        batches: batches.length,
        educators: educators.length,
        expenses: expenses.length,
        discounts: discounts.length,
        adminAccounts: adminAccounts.length,
        studyMaterials: studyMaterials.length,
        questions: questions.length,
        exams: exams.length,
        examSubmissions: examSubmissions.length,
        liveClasses: liveClasses.length,
        classRecordings: classRecordings.length
      }
    };
  };

  const downloadFullBackup = (customFilename?: string): { success: boolean; filename?: string; error?: string } => {
    try {
      const backup = exportBackupObject();
      const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(backup, null, 2))}`;
      const now = new Date();
      const dateStr = now.toISOString().split('T')[0];
      const timeStr = now.toTimeString().split(' ')[0].replace(/:/g, '-');
      const filename = customFilename || `pixel_pathsala_erp_backup_${dateStr}_${timeStr}.json`;

      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', jsonString);
      downloadAnchor.setAttribute('download', filename);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();

      showToast(`Full ERP database backup downloaded (${dateStr})`, 'success');
      return { success: true, filename };
    } catch (err: any) {
      showToast('Failed to download database backup: ' + err.message, 'error');
      return { success: false, error: err.message };
    }
  };

  const restoreFullBackup = async (
    backupData: any,
    options: { keepCurrentAdmin?: boolean; syncCloud?: boolean } = { keepCurrentAdmin: false, syncCloud: true }
  ): Promise<{ success: boolean; message: string; counts?: any }> => {
    try {
      if (!backupData || typeof backupData !== 'object') {
        throw new Error('Invalid backup file: Not a valid JSON object.');
      }

      // Check if this is an ERP backup with recognized tables or a raw dataset
      const restoredStudents = Array.isArray(backupData.students) ? backupData.students : students;
      const restoredAdmissions = Array.isArray(backupData.admissions) ? backupData.admissions : admissions;
      const restoredPayments = Array.isArray(backupData.payments) ? backupData.payments : payments;
      const restoredCourses = Array.isArray(backupData.courses) ? backupData.courses : courses;
      const restoredBatches = Array.isArray(backupData.batches) ? backupData.batches : batches;
      const restoredEducators = Array.isArray(backupData.educators) ? backupData.educators : educators;
      const restoredExpenses = Array.isArray(backupData.expenses) ? backupData.expenses : expenses;
      const restoredDiscounts = Array.isArray(backupData.discounts) ? backupData.discounts : discounts;
      const restoredAdminAccounts = (!options.keepCurrentAdmin && Array.isArray(backupData.adminAccounts) && backupData.adminAccounts.length > 0)
        ? backupData.adminAccounts 
        : adminAccounts;
      const restoredStudyMaterials = Array.isArray(backupData.studyMaterials) ? backupData.studyMaterials : studyMaterials;
      const restoredQuestions = Array.isArray(backupData.questions) ? backupData.questions : questions;
      const restoredExams = Array.isArray(backupData.exams) ? backupData.exams : exams;
      const restoredExamSubmissions = Array.isArray(backupData.examSubmissions) ? backupData.examSubmissions : examSubmissions;
      const restoredLiveClasses = Array.isArray(backupData.liveClasses) ? backupData.liveClasses : liveClasses;
      const restoredClassRecordings = Array.isArray(backupData.classRecordings) ? backupData.classRecordings : classRecordings;
      
      let restoredCenterInfo = centerInfo;
      if (backupData.centerInfo && typeof backupData.centerInfo === 'object') {
        restoredCenterInfo = {
          ...centerInfo,
          ...backupData.centerInfo,
          googleSheetWebhookUrl: backupData.centerInfo.googleSheetWebhookUrl || centerInfo.googleSheetWebhookUrl,
          googleSheetId: backupData.centerInfo.googleSheetId || centerInfo.googleSheetId
        };
      }

      // Update state
      if (Array.isArray(backupData.students)) setStudents(restoredStudents);
      if (Array.isArray(backupData.admissions)) setAdmissions(restoredAdmissions);
      if (Array.isArray(backupData.payments)) setPayments(restoredPayments);
      if (Array.isArray(backupData.courses)) setCourses(restoredCourses);
      if (Array.isArray(backupData.batches)) setBatches(restoredBatches);
      if (Array.isArray(backupData.educators)) setEducators(restoredEducators);
      if (Array.isArray(backupData.expenses)) setExpenses(restoredExpenses);
      if (Array.isArray(backupData.discounts)) setDiscounts(restoredDiscounts);
      if (!options.keepCurrentAdmin && Array.isArray(backupData.adminAccounts) && backupData.adminAccounts.length > 0) {
        setAdminAccounts(restoredAdminAccounts);
      }
      if (Array.isArray(backupData.studyMaterials)) setStudyMaterials(restoredStudyMaterials);
      if (Array.isArray(backupData.questions)) setQuestions(restoredQuestions);
      if (Array.isArray(backupData.exams)) setExams(restoredExams);
      if (Array.isArray(backupData.examSubmissions)) setExamSubmissions(restoredExamSubmissions);
      if (Array.isArray(backupData.liveClasses)) setLiveClasses(restoredLiveClasses);
      if (Array.isArray(backupData.classRecordings)) setClassRecordings(restoredClassRecordings);
      if (backupData.centerInfo) setCenterInfo(restoredCenterInfo);

      // Save to localStorage
      try {
        localStorage.setItem(`${STORAGE_KEY}_center`, JSON.stringify(restoredCenterInfo));
        localStorage.setItem(`${STORAGE_KEY}_students`, JSON.stringify(restoredStudents));
        localStorage.setItem(`${STORAGE_KEY}_admissions`, JSON.stringify(restoredAdmissions));
        localStorage.setItem(`${STORAGE_KEY}_payments`, JSON.stringify(restoredPayments));
        localStorage.setItem(`${STORAGE_KEY}_courses`, JSON.stringify(restoredCourses));
        localStorage.setItem(`${STORAGE_KEY}_batches`, JSON.stringify(restoredBatches));
        localStorage.setItem(`${STORAGE_KEY}_educators`, JSON.stringify(restoredEducators));
        localStorage.setItem(`${STORAGE_KEY}_expenses`, JSON.stringify(restoredExpenses));
        localStorage.setItem(`${STORAGE_KEY}_discounts`, JSON.stringify(restoredDiscounts));
        localStorage.setItem(`${STORAGE_KEY}_admin_accounts`, JSON.stringify(restoredAdminAccounts));
        localStorage.setItem(`${STORAGE_KEY}_materials`, JSON.stringify(restoredStudyMaterials));
        localStorage.setItem(`${STORAGE_KEY}_questions`, JSON.stringify(restoredQuestions));
        localStorage.setItem(`${STORAGE_KEY}_exams`, JSON.stringify(restoredExams));
        localStorage.setItem(`${STORAGE_KEY}_exam_submissions`, JSON.stringify(restoredExamSubmissions));
      } catch (storageErr) {
        console.warn('LocalStorage save error during restore:', storageErr);
      }

      // Persist to backend database & webhook if enabled
      const payloadToSave = {
        centerInfo: restoredCenterInfo,
        students: restoredStudents,
        admissions: restoredAdmissions,
        payments: restoredPayments,
        courses: restoredCourses,
        batches: restoredBatches,
        educators: restoredEducators,
        expenses: restoredExpenses,
        discounts: restoredDiscounts,
        adminAccounts: restoredAdminAccounts,
        studyMaterials: restoredStudyMaterials,
        questions: restoredQuestions,
        exams: restoredExams,
        examSubmissions: restoredExamSubmissions,
        liveClasses: restoredLiveClasses,
        classRecordings: restoredClassRecordings
      };

      await saveAllToDatabase(payloadToSave);

      const counts = {
        students: restoredStudents.length,
        admissions: restoredAdmissions.length,
        payments: restoredPayments.length,
        courses: restoredCourses.length,
        batches: restoredBatches.length,
        educators: restoredEducators.length,
        expenses: restoredExpenses.length,
        discounts: restoredDiscounts.length,
        studyMaterials: restoredStudyMaterials.length,
        questions: restoredQuestions.length,
        exams: restoredExams.length,
        examSubmissions: restoredExamSubmissions.length
      };

      const totalRestored = Object.values(counts).reduce((a, b) => a + b, 0);
      showToast(`Restored ${totalRestored} database records successfully!`, 'success');

      return {
        success: true,
        message: `Successfully restored ${totalRestored} records across all database tables.`,
        counts
      };
    } catch (err: any) {
      const errorMsg = err.message || 'Failed to restore backup.';
      showToast(errorMsg, 'error');
      return { success: false, message: errorMsg };
    }
  };

  const resetToDefaultData = () => {
    if (confirm('Are you sure you want to reset all Pixel Pathsala ERP records to default demonstration data?')) {
      setCenterInfo(INITIAL_CENTER_INFO);
      setEducators(INITIAL_EDUCATORS);
      setCourses(INITIAL_COURSES);
      setBatches(INITIAL_BATCHES);
      setStudents(INITIAL_STUDENTS);
      setDiscounts(INITIAL_DISCOUNTS);
      setPayments(INITIAL_PAYMENTS);
      setExpenses(INITIAL_EXPENSES);
      setAdmissions(INITIAL_ADMISSIONS);
      setStudyMaterials(INITIAL_STUDY_MATERIALS);
      setQuestions(INITIAL_QUESTIONS);
      setExams(INITIAL_EXAMS);
      setExamSubmissions(INITIAL_EXAM_SUBMISSIONS);
      setCurrentStudent(null);
      setIsAdminLoggedIn(false);
      setAdminUser(null);
      localStorage.clear();
      showToast('All ERP and portal data reset to defaults.');
    }
  };

  return (
    <AppContext.Provider
      value={{
        centerInfo,
        updateCenterInfo,
        educators,
        addEducator,
        updateEducator,
        deleteEducator,
        courses,
        addCourse,
        updateCourse,
        deleteCourse,
        batches,
        addBatch,
        updateBatch,
        deleteBatch,
        students,
        addStudent,
        updateStudent,
        deleteStudent,
        setStudentStatus,
        discounts,
        addDiscount,
        updateDiscount,
        deleteDiscount,
        payments,
        collectFee,
        approvePayment,
        rejectPayment,
        deletePayment,
        expenses,
        addExpense,
        updateExpense,
        deleteExpense,
        studyMaterials,
        addStudyMaterial,
        updateStudyMaterial,
        deleteStudyMaterial,
        downloadStudyMaterial,
        questions,
        addQuestion,
        updateQuestion,
        deleteQuestion,
        bulkAddQuestions,
        exams,
        addExam,
        updateExam,
        deleteExam,
        toggleExamPublish,
        setExamStatus,
        examSubmissions,
        submitExamAnswers,
        deleteExamSubmission,
        liveClasses,
        addLiveClass,
        updateLiveClass,
        deleteLiveClass,
        setLiveClassStatus,
        postponeLiveClass,
        autoGenerateBatchSchedules,
        notifications,
        sendStudentNotification,
        markNotificationAsRead,
        clearAllStudentNotifications,
        classRecordings,
        addClassRecording,
        updateClassRecording,
        deleteClassRecording,
        incrementRecordingViews,
        admissions,
        submitAdmissionApplication,
        approveAdmission,
        rejectAdmission,
        deleteAdmission,
        currentStudent,
        loginStudent,
        logoutStudent,
        submitStudentFeePayment,
        isAdminLoggedIn,
        adminUser,
        loginAdmin,
        logoutAdmin,
        updateAdminPassword,
        adminAccounts,
        addAdminAccount,
        updateAdminAccount,
        deleteAdminAccount,
        isUnifiedLoginOpen,
        unifiedLoginInitialRole,
        openUnifiedLoginModal,
        closeUnifiedLoginModal,
        activeTab,
        setActiveTab,
        selectedReceiptForPrint,
        setSelectedReceiptForPrint,
        saveAllToDatabase,
        toast,
        showToast,
        isGoogleConnected,
        googleUser,
        connectGoogleAccount,
        disconnectGoogleAccount,
        syncToGoogleSheets,
        pullFromGoogleSheets,
        createNewGoogleSheetDatabase,
        isSyncingSheets,
        isPullingSheets,
        resetToDefaultData,
        exportBackupObject,
        downloadFullBackup,
        restoreFullBackup
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
