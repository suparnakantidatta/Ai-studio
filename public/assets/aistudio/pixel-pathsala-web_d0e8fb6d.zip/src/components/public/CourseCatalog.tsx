import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Course, Batch } from '../../types';
import { getModesForCourse, formatModeLabel, getDistinctAcademicClasses } from '../../utils/classCourseMatcher';
import { getCourseDiscountInfo, getBatchDiscountInfo } from '../../utils/feeCalculator';
import { DiscountRibbonBadge } from '../common/DiscountRibbonBadge';
import { 
  BookOpen, 
  CheckCircle, 
  ArrowRight, 
  X, 
  GraduationCap, 
  Building2, 
  Globe, 
  Sparkles, 
  Tag, 
  Layers, 
  Clock, 
  Calendar, 
  DoorOpen 
} from 'lucide-react';

export const CourseCatalog: React.FC = () => {
  const { courses, batches, discounts, setActiveTab } = useApp();
  const [selectedClass, setSelectedClass] = useState<string>('All');
  const [activeSyllabusCourse, setActiveSyllabusCourse] = useState<Course | null>(null);

  const websiteCourses = courses.filter(c => c.showOnWebsite);
  const distinctClasses = getDistinctAcademicClasses(courses);
  const classFilterList = ['All', ...distinctClasses];

  const filteredCourses = websiteCourses.filter(c => {
    return selectedClass === 'All' || c.academicClass === selectedClass;
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold mb-3 border border-indigo-200">
          <BookOpen className="w-3.5 h-3.5" />
          <span>Curriculum, Classes & Batches</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Courses & Academic Classes Offered
        </h2>
        <p className="text-slate-600 text-sm sm:text-base mt-2">
          Tailored learning tracks designed for school board success, competitive exams, and technical career preparation with practical coding practice.
        </p>

        {/* Academic Class Section Filters */}
        <div className="flex flex-wrap justify-center gap-2 mt-6">
          {classFilterList.map((cls) => (
            <button
              key={cls}
              onClick={() => setSelectedClass(cls)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center gap-1.5 ${
                selectedClass === cls
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              {cls !== 'All' && <GraduationCap className="w-3.5 h-3.5 opacity-80" />}
              <span>{cls}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map((course) => {
          const availableModes = getModesForCourse(batches, course.id);
          const discountInfo = getCourseDiscountInfo(course, discounts, batches);
          const courseBatches = batches.filter(b => b.courseId === course.id && b.isActive !== false);

          return (
            <div
              key={course.id}
              className="relative bg-white rounded-3xl border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group hover:border-indigo-300"
            >
              {/* Corner Red Ribbon with Golden Text for Single Highest Discount (Never Summed) */}
              {discountInfo.hasDiscount && (
                <DiscountRibbonBadge
                  variant="corner"
                  text={discountInfo.ribbonText}
                  subtitle={discountInfo.discountTitle}
                />
              )}

              <div className="p-6 sm:p-7">
                {/* Header tags with Class, Modes, and Discount Badge */}
                <div className="flex items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-600 text-white shadow-xs">
                      {course.academicClass || 'General Class'}
                    </span>
                    
                    {/* Available mode badges from database */}
                    {availableModes.map((mode) => (
                      <span
                        key={mode}
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-bold border ${
                          mode === 'online'
                            ? 'bg-blue-50 text-blue-800 border-blue-200'
                            : 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        }`}
                      >
                        {mode === 'online' ? (
                          <Globe className="w-3 h-3 text-blue-600" />
                        ) : (
                          <Building2 className="w-3 h-3 text-emerald-600" />
                        )}
                        <span>{mode === 'online' ? 'Online' : 'Offline'}</span>
                      </span>
                    ))}
                  </div>
                  <span className="font-mono text-xs text-slate-400 font-semibold">
                    {course.code}
                  </span>
                </div>

                {/* Course Title */}
                <h3 className="text-lg sm:text-xl font-bold text-slate-900 group-hover:text-indigo-600 transition-colors mb-2 line-clamp-2 pr-6">
                  {course.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 line-clamp-3 mb-4 leading-relaxed">
                  {course.description}
                </p>

                {/* Highlights */}
                <div className="space-y-1.5 mb-4 bg-slate-50/70 p-3 rounded-2xl border border-slate-100">
                  {course.highlights?.slice(0, 3).map((hl, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-slate-700">
                      <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span className="line-clamp-1">{hl}</span>
                    </div>
                  ))}
                </div>

                {/* Batch-Wise Discount Breakdown Inside Course Tile */}
                {courseBatches.length > 0 && (
                  <div className="mb-2 space-y-2">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                      <span className="flex items-center gap-1.5 text-indigo-950">
                        <Layers className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Batches & Concessions</span>
                      </span>
                      <span className="text-[10px] text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">
                        {courseBatches.length} {courseBatches.length === 1 ? 'Batch' : 'Batches'}
                      </span>
                    </div>

                    <div className="space-y-2">
                      {courseBatches.map(b => {
                        const bDiscount = getBatchDiscountInfo(b, course, discounts);
                        return (
                          <div
                            key={b.id}
                            className="p-2.5 rounded-2xl bg-gradient-to-r from-slate-50 to-indigo-50/30 border border-slate-200/90 flex flex-col gap-1.5 text-xs shadow-2xs"
                          >
                            <div className="flex items-center justify-between gap-1.5">
                              <div className="flex items-center gap-1.5 font-bold text-slate-800 min-w-0">
                                <span className={`w-2 h-2 rounded-full shrink-0 ${b.mode === 'online' ? 'bg-blue-500' : 'bg-emerald-500'}`} />
                                <span className="truncate text-xs font-bold text-slate-900">{b.name}</span>
                              </div>
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-extrabold uppercase shrink-0 border ${
                                b.mode === 'online' 
                                  ? 'bg-blue-50 text-blue-700 border-blue-200' 
                                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              }`}>
                                {b.mode === 'online' ? 'Online' : 'Offline'}
                              </span>
                            </div>

                            <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-200/60 text-[11px]">
                              <div className="text-slate-500 text-[10px] truncate flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400 shrink-0" />
                                <span>{b.scheduleDays?.slice(0, 3).join(', ')} • {b.timing}</span>
                              </div>

                              <div className="flex items-center gap-1.5 shrink-0">
                                {bDiscount.hasDiscount ? (
                                  <>
                                    <div className="flex items-baseline gap-1">
                                      <span className="font-mono font-black text-slate-900 text-xs">
                                        ₹{bDiscount.finalFee.toLocaleString('en-IN')}
                                      </span>
                                      <span className="text-[10px] text-slate-400 line-through font-mono">
                                        ₹{course.monthlyFee.toLocaleString('en-IN')}
                                      </span>
                                    </div>
                                    <DiscountRibbonBadge
                                      variant="tag"
                                      text={bDiscount.discountText}
                                      showIcon={false}
                                      className="!px-1.5 !py-0.5 !text-[9px]"
                                    />
                                  </>
                                ) : (
                                  <span className="font-mono font-bold text-slate-800 text-xs">
                                    ₹{course.monthlyFee.toLocaleString('en-IN')}<span className="text-[9px] font-normal text-slate-500">/mo</span>
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Batch-specific discount note if available */}
                            {bDiscount.hasDiscount && bDiscount.discountTitle && (
                              <div className="text-[10px] text-red-700 font-medium flex items-center gap-1 bg-red-50/80 px-2 py-0.5 rounded-lg border border-red-100">
                                <Tag className="w-2.5 h-2.5 text-red-600 shrink-0" />
                                <span className="truncate">{bDiscount.discountTitle}</span>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Card Footer with Course Info, Highest Fee Discount Badge, and Apply Button */}
              <div className="p-6 pt-0 mt-auto space-y-3">
                {/* Tuition Fee & Highest Discount Box */}
                <div className="p-3 bg-gradient-to-r from-slate-50 to-indigo-50/40 rounded-2xl border border-slate-200/90 flex items-center justify-between gap-2">
                  <div>
                    <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                      Monthly Tuition Fee
                    </div>
                    <div className="flex items-baseline gap-1.5">
                      {discountInfo.hasDiscount ? (
                        <>
                          <span className="text-base sm:text-lg font-black text-slate-900 font-mono">
                            ₹{discountInfo.finalFee.toLocaleString('en-IN')}
                          </span>
                          <span className="text-xs text-slate-400 line-through font-mono">
                            ₹{course.monthlyFee.toLocaleString('en-IN')}
                          </span>
                          <span className="text-[10px] text-slate-500 font-medium">/mo</span>
                        </>
                      ) : (
                        <>
                          <span className="text-base sm:text-lg font-black text-slate-900 font-mono">
                            ₹{course.monthlyFee.toLocaleString('en-IN')}
                          </span>
                          <span className="text-[10px] text-slate-500 font-medium">/mo</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Red Ribbon Background with Golden Text Badge (Highest Discount with UPTO) */}
                  {discountInfo.hasDiscount ? (
                    <DiscountRibbonBadge
                      variant="tag"
                      text={discountInfo.ribbonText}
                      showIcon={true}
                    />
                  ) : (
                    <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-lg border border-emerald-200">
                      0% Reg Fee
                    </span>
                  )}
                </div>

                <div className="bg-indigo-50/60 rounded-2xl p-3 flex items-center justify-between border border-indigo-100/80">
                  <div>
                    <div className="text-[10px] text-indigo-800 font-bold uppercase tracking-wider">Target Level</div>
                    <div className="text-xs sm:text-sm font-extrabold text-indigo-950 line-clamp-1">
                      {course.academicClass || 'Academic Section'}
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveSyllabusCourse(course)}
                    className="text-xs font-bold text-indigo-600 hover:text-indigo-800 underline cursor-pointer bg-white px-2.5 py-1 rounded-lg border border-indigo-200 shadow-2xs shrink-0"
                  >
                    View Syllabus & Batches
                  </button>
                </div>

                <button
                  onClick={() => setActiveTab('admission')}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
                >
                  <span>Apply for this Course</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Syllabus & Batch Breakdown Modal */}
      {activeSyllabusCourse && (() => {
        const modalDiscountInfo = getCourseDiscountInfo(activeSyllabusCourse, discounts, batches);
        const modalCourseBatches = batches.filter(b => b.courseId === activeSyllabusCourse.id);

        return (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
            <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn my-6">
              <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-200 mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                      {activeSyllabusCourse.academicClass}
                    </span>
                    {getModesForCourse(batches, activeSyllabusCourse.id).map(m => (
                      <span key={m} className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {formatModeLabel(m)}
                      </span>
                    ))}
                    {modalDiscountInfo.hasDiscount && (
                      <DiscountRibbonBadge
                        variant="pill"
                        text={modalDiscountInfo.ribbonText}
                        subtitle={modalDiscountInfo.discountTitle}
                      />
                    )}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1">
                    {activeSyllabusCourse.title}
                  </h3>
                </div>
                <button
                  onClick={() => setActiveSyllabusCourse(null)}
                  className="p-2 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-5 text-xs sm:text-sm text-slate-700 mb-6">
                <p className="leading-relaxed text-slate-600">
                  {activeSyllabusCourse.description}
                </p>

                {/* Tuition Fee Breakdown Callout */}
                <div className="p-3.5 bg-gradient-to-r from-slate-50 to-indigo-50/40 rounded-2xl border border-slate-200 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <span className="text-[10px] font-bold uppercase text-slate-500 tracking-wider">Course Fee (Highest Concession)</span>
                    <div className="flex items-baseline gap-2">
                      {modalDiscountInfo.hasDiscount ? (
                        <>
                          <span className="text-xl font-black text-slate-900 font-mono">
                            ₹{modalDiscountInfo.finalFee.toLocaleString('en-IN')}
                          </span>
                          <span className="text-sm text-slate-400 line-through font-mono">
                            ₹{activeSyllabusCourse.monthlyFee.toLocaleString('en-IN')}
                          </span>
                          <span className="text-xs text-slate-500 font-semibold">/month</span>
                        </>
                      ) : (
                        <>
                          <span className="text-xl font-black text-slate-900 font-mono">
                            ₹{activeSyllabusCourse.monthlyFee.toLocaleString('en-IN')}
                          </span>
                          <span className="text-xs text-slate-500 font-semibold">/month</span>
                        </>
                      )}
                    </div>
                  </div>

                  {modalDiscountInfo.hasDiscount && (
                    <DiscountRibbonBadge
                      variant="banner"
                      text={modalDiscountInfo.ribbonText}
                      subtitle={modalDiscountInfo.notes.join(' • ')}
                    />
                  )}
                </div>

                {/* Available Batches & Concession Details */}
                {modalCourseBatches.length > 0 && (
                  <div>
                    <h4 className="font-bold text-slate-900 mb-2 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-indigo-600" />
                      <span>Available Batches & Batch-Specific Discounts:</span>
                    </h4>
                    <div className="space-y-2.5">
                      {modalCourseBatches.map(b => {
                        const bDiscount = getBatchDiscountInfo(b, activeSyllabusCourse, discounts);
                        return (
                          <div key={b.id} className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                            <div className="flex items-center justify-between flex-wrap gap-2">
                              <div className="flex items-center gap-2">
                                <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${b.mode === 'online' ? 'bg-blue-500' : 'bg-emerald-500'}`} />
                                <span className="font-extrabold text-slate-900 text-sm">{b.name}</span>
                              </div>
                              <span className={`px-2 py-0.5 rounded-lg text-xs font-bold border ${
                                b.mode === 'online' ? 'bg-blue-100 text-blue-800 border-blue-200' : 'bg-emerald-100 text-emerald-800 border-emerald-200'
                              }`}>
                                {b.mode === 'online' ? 'Online Live' : 'Offline Classroom'}
                              </span>
                            </div>

                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600">
                              <div className="flex items-center gap-1.5">
                                <Calendar className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                                <span>Days: {b.scheduleDays?.join(', ')}</span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <Clock className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                                <span>Timing: {b.timing}</span>
                              </div>
                              {b.roomNumber && (
                                <div className="flex items-center gap-1.5">
                                  <DoorOpen className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                                  <span>Venue: {b.roomNumber}</span>
                                </div>
                              )}
                            </div>

                            {/* Batch Concession Summary */}
                            <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between flex-wrap gap-2">
                              <div className="text-xs">
                                <span className="text-slate-500">Monthly Tuition: </span>
                                {bDiscount.hasDiscount ? (
                                  <span className="font-mono font-bold text-slate-900">
                                    ₹{bDiscount.finalFee.toLocaleString('en-IN')} <span className="text-slate-400 line-through text-[11px]">₹{activeSyllabusCourse.monthlyFee.toLocaleString('en-IN')}</span>
                                  </span>
                                ) : (
                                  <span className="font-mono font-bold text-slate-900">
                                    ₹{activeSyllabusCourse.monthlyFee.toLocaleString('en-IN')}/mo
                                  </span>
                                )}
                              </div>

                              {bDiscount.hasDiscount ? (
                                <DiscountRibbonBadge
                                  variant="tag"
                                  text={bDiscount.discountText}
                                  subtitle={bDiscount.discountTitle}
                                />
                              ) : (
                                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                                  Standard Fee • 0% Reg Fee
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div>
                  <h4 className="font-bold text-slate-900 mb-2">Detailed Syllabus & Curriculum Topics:</h4>
                  <ul className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                    {activeSyllabusCourse.syllabusPoints.map((pt, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                          {i + 1}
                        </span>
                        <span className="font-medium text-slate-800">{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {activeSyllabusCourse.highlights && activeSyllabusCourse.highlights.length > 0 && (
                  <div>
                    <h4 className="font-bold text-slate-900 mb-2">Key Course Highlights:</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {activeSyllabusCourse.highlights.map((hl, idx) => (
                        <div key={idx} className="flex items-center gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700">
                          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>{hl}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  onClick={() => setActiveSyllabusCourse(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition cursor-pointer"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    setActiveSyllabusCourse(null);
                    setActiveTab('admission');
                  }}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-sm"
                >
                  Apply for this Course
                </button>
              </div>
            </div>
          </div>
        );
      })()}
    </div>
  );
};

