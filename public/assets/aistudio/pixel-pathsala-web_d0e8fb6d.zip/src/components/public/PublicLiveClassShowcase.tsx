import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LiveClassSession, ClassRecording } from '../../types';
import { 
  Video, 
  PlayCircle, 
  Calendar, 
  Clock, 
  Users, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  Radio, 
  BookOpen, 
  FileText, 
  ExternalLink,
  ShieldCheck,
  MonitorPlay,
  Layers,
  GraduationCap,
  Download
} from 'lucide-react';

export const PublicLiveClassShowcase: React.FC = () => {
  const { 
    liveClasses = [], 
    classRecordings = [], 
    courses = [], 
    batches = [], 
    educators = [],
    setActiveTab, 
    openUnifiedLoginModal,
    currentStudent 
  } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'live' | 'upcoming' | 'recordings'>('all');

  const nowLive = liveClasses.filter(c => c.status === 'live');
  const upcoming = liveClasses.filter(c => c.status === 'scheduled');
  const past = liveClasses.filter(c => c.status === 'completed');

  const filteredSessions = activeFilter === 'live'
    ? nowLive
    : activeFilter === 'upcoming'
    ? upcoming
    : liveClasses;

  // Smart resolution helpers to prevent batch ID or placeholder IDs from showing as educator name
  const getResolvedEducatorName = (session: LiveClassSession | any): string => {
    // 1. Check if session has direct educatorId
    if (session.educatorId) {
      const matchedEdu = educators.find(e => e.id === session.educatorId);
      if (matchedEdu) return matchedEdu.name;
    }

    let raw = (session.educatorName || '').trim();

    // 2. Check if raw name matches an educator ID directly
    const eduById = educators.find(e => e.id === raw);
    if (eduById) return eduById.name;

    // 3. Check if raw name matches an educator name in list
    const eduByName = educators.find(e => e.name.toLowerCase() === raw.toLowerCase());
    if (eduByName) return eduByName.name;

    // 4. If raw is empty, 'all', 'Faculty', or is a batch ID (e.g. starts with 'batch-' or in batches array)
    const isBatchId = raw.startsWith('batch-') || batches.some(b => b.id === raw);
    if (!raw || raw.toLowerCase() === 'all' || raw.toLowerCase() === 'faculty' || isBatchId) {
      const targetBatchId = isBatchId ? raw : session.batchId;
      if (targetBatchId && targetBatchId !== 'all') {
        const batch = batches.find(b => b.id === targetBatchId);
        if (batch && batch.educatorId) {
          const batchEdu = educators.find(e => e.id === batch.educatorId);
          if (batchEdu) return batchEdu.name;
        }
      }

      if (session.courseId && session.courseId !== 'all') {
        const batchWithEdu = batches.find(b => b.courseId === session.courseId && b.educatorId);
        if (batchWithEdu && batchWithEdu.educatorId) {
          const courseEdu = educators.find(e => e.id === batchWithEdu.educatorId);
          if (courseEdu) return courseEdu.name;
        }
      }

      return educators[0]?.name || 'Senior Faculty';
    }

    return raw;
  };

  const getResolvedBatchName = (session: LiveClassSession | any): string => {
    let bId = session.batchId;
    if ((!bId || bId === 'all') && session.educatorName && (session.educatorName.startsWith('batch-') || batches.some(b => b.id === session.educatorName))) {
      bId = session.educatorName;
    }
    if (!bId || bId === 'all') return '🌟 All Batches (Open Session)';
    const foundBatch = batches.find(b => b.id === bId);
    return foundBatch ? `${foundBatch.name} (${foundBatch.mode === 'online' ? 'Online' : 'Offline'})` : bId;
  };

  const getRecordingEducatorName = (rec: ClassRecording | any): string => {
    let raw = (rec.educatorName || '').trim();
    const eduById = educators.find(e => e.id === raw);
    if (eduById) return eduById.name;

    const eduByName = educators.find(e => e.name.toLowerCase() === raw.toLowerCase());
    if (eduByName) return eduByName.name;

    const isBatchId = raw.startsWith('batch-') || batches.some(b => b.id === raw);
    if (!raw || raw.toLowerCase() === 'all' || raw.toLowerCase() === 'faculty' || isBatchId) {
      const targetBatchId = isBatchId ? raw : rec.batchId;
      if (targetBatchId && targetBatchId !== 'all') {
        const batch = batches.find(b => b.id === targetBatchId);
        if (batch && batch.educatorId) {
          const edu = educators.find(e => e.id === batch.educatorId);
          if (edu) return edu.name;
        }
      }
      return educators[0]?.name || 'Senior Faculty';
    }
    return raw;
  };

  return (
    <section className="py-14 bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-900 text-white relative overflow-hidden">
      {/* Ambient background glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Top Advertising Banner & Badge */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-cyan-300 text-xs font-bold uppercase tracking-wider mb-4 shadow-sm backdrop-blur-md">
            <Radio className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
            <span>Interactive Online Learning & Live Masterclasses</span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white mb-4 leading-tight">
            Attend Live Interactive Classes <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-cyan-400 via-indigo-300 to-pink-400 bg-clip-text text-transparent">
              With 24/7 Recorded Class Archives
            </span>
          </h2>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            Never miss a single concept. Registered students in our online batches attend interactive HD live lectures, solve doubts in real-time, and get unlimited replay access to previous classes with lecture notes.
          </p>

          {/* Quick Stats Highlights */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8 max-w-2xl mx-auto">
            <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-700/80 backdrop-blur-xs text-center">
              <div className="text-lg font-black text-rose-400 flex items-center justify-center gap-1.5">
                {nowLive.length > 0 ? (
                  <>
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                    <span>{nowLive.length} Active</span>
                  </>
                ) : (
                  <span>Interactive</span>
                )}
              </div>
              <div className="text-[11px] text-slate-400 font-medium mt-0.5">Live Sessions</div>
            </div>

            <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-700/80 backdrop-blur-xs text-center">
              <div className="text-lg font-black text-cyan-400">
                {upcoming.length} Scheduled
              </div>
              <div className="text-[11px] text-slate-400 font-medium mt-0.5">Upcoming Masterclasses</div>
            </div>

            <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-700/80 backdrop-blur-xs text-center">
              <div className="text-lg font-black text-emerald-400">
                {classRecordings.length}+ Lectures
              </div>
              <div className="text-[11px] text-slate-400 font-medium mt-0.5">Recorded Library</div>
            </div>

            <div className="p-3 bg-slate-800/60 rounded-2xl border border-slate-700/80 backdrop-blur-xs text-center">
              <div className="text-lg font-black text-amber-400">100% Free</div>
              <div className="text-[11px] text-slate-400 font-medium mt-0.5">Lecture Notes PDF</div>
            </div>
          </div>
        </div>

        {/* Live Filter Controls */}
        <div className="flex items-center justify-center gap-2 mb-8 flex-wrap">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeFilter === 'all'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
            }`}
          >
            All Live Classes ({liveClasses.length})
          </button>

          {nowLive.length > 0 && (
            <button
              onClick={() => setActiveFilter('live')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                activeFilter === 'live'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30 animate-pulse'
                  : 'bg-rose-950/60 text-rose-300 hover:bg-rose-900 border border-rose-800'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
              <span>Happening Now ({nowLive.length})</span>
            </button>
          )}

          <button
            onClick={() => setActiveFilter('upcoming')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeFilter === 'upcoming'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
            }`}
          >
            Upcoming Schedule ({upcoming.length})
          </button>

          <button
            onClick={() => setActiveFilter('recordings')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeFilter === 'recordings'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
            }`}
          >
            <PlayCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span>Recorded Vault ({classRecordings.length})</span>
          </button>
        </div>

        {/* Live Classes Grid or Recordings Showcase */}
        {activeFilter === 'recordings' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {classRecordings.slice(0, 6).map((rec) => {
              const crs = courses.find(c => c.id === rec.courseId);
              return (
                <div
                  key={rec.id}
                  className="bg-slate-800/80 backdrop-blur-md rounded-3xl border border-slate-700/80 p-6 flex flex-col justify-between hover:border-emerald-500/50 transition-all group shadow-lg"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="px-2.5 py-1 rounded-lg text-[10px] font-extrabold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        {rec.subject}
                      </span>
                      <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{rec.durationMinutes} mins</span>
                      </span>
                    </div>

                    <h4 className="text-base font-bold text-white group-hover:text-emerald-300 transition-colors mb-1.5 line-clamp-2">
                      {rec.title}
                    </h4>

                    <p className="text-xs text-slate-400 mb-4 line-clamp-2">
                      {rec.topic ? `Topic: ${rec.topic} • ` : ''}{rec.chapter || 'Comprehensive Video Lecture'}
                    </p>

                    <div className="text-[11px] text-slate-300 flex items-center gap-2 mb-4 bg-slate-900/60 p-2.5 rounded-xl border border-slate-700/60">
                      <GraduationCap className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                      <span className="truncate">Faculty: <strong className="text-emerald-400 font-semibold">{getRecordingEducatorName(rec)}</strong></span>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-slate-700/80 flex items-center justify-between gap-2">
                    <span className="text-[11px] text-slate-400">
                      {rec.recordedDate}
                    </span>
                    <button
                      onClick={() => {
                        if (currentStudent) {
                          setActiveTab('student-portal');
                        } else {
                          openUnifiedLoginModal('student');
                        }
                      }}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <PlayCircle className="w-3.5 h-3.5" />
                      <span>Watch in Portal</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {filteredSessions.length > 0 ? (
              filteredSessions.map((session) => {
                const isLive = session.status === 'live';
                const crs = courses.find(c => c.id === session.courseId);

                return (
                  <div
                    key={session.id}
                    className={`rounded-3xl p-6 flex flex-col justify-between backdrop-blur-md transition-all border ${
                      isLive
                        ? 'bg-gradient-to-b from-rose-950/40 via-slate-900 to-slate-900 border-rose-500/60 shadow-xl shadow-rose-950/50'
                        : 'bg-slate-800/80 border-slate-700/80 hover:border-indigo-500/50 shadow-lg'
                    }`}
                  >
                    <div>
                      {/* Session Header Status */}
                      <div className="flex items-center justify-between gap-2 mb-3.5">
                        <div className="flex items-center gap-2">
                          {isLive ? (
                            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-rose-600 text-white shadow-md shadow-rose-600/40 animate-pulse">
                              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                              <span>LIVE NOW</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                              <Clock className="w-3.5 h-3.5 text-indigo-400" />
                              <span>Scheduled</span>
                            </span>
                          )}

                          <span className="text-[11px] font-bold text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded-lg border border-cyan-800/60">
                            {session.subject}
                          </span>
                        </div>

                        <span className="text-[11px] font-bold text-slate-400 capitalize">
                          {session.platform === 'google_meet' ? 'Google Meet' : session.platform === 'youtube_live' ? 'YouTube Live' : session.platform === 'zoom' ? 'Zoom Live' : 'Interactive Lab'}
                        </span>
                      </div>

                      {/* Title */}
                      <h3 className="text-lg font-bold text-white mb-2 line-clamp-2">
                        {session.title}
                      </h3>

                      {/* Course / Batch / Class context */}
                      <div className="space-y-1.5 mb-4 text-xs text-slate-300 bg-slate-900/60 p-3 rounded-2xl border border-slate-700/60">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Class Standard:</span>
                          <span className="font-bold text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded-md border border-cyan-800/40">
                            {session.academicClass || session.targetClass || 'All Classes'}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Course / Program:</span>
                          <span className="font-semibold text-indigo-300 truncate max-w-[180px]">
                            {session.courseId === 'all' ? 'All Courses' : (crs?.title || 'Academic Program')}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Batch:</span>
                          <span className="font-medium text-slate-200 truncate max-w-[180px]">
                            {getResolvedBatchName(session)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Educator:</span>
                          <span className="font-semibold text-emerald-400">{getResolvedEducatorName(session)}</span>
                        </div>
                      </div>

                      {/* Schedule Timing Box */}
                      <div className="flex items-center justify-between text-xs text-slate-300 py-2 border-y border-slate-700/60 mb-4">
                        <div className="flex items-center gap-1.5 text-slate-300">
                          <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                          <span>{session.scheduledDate || (session as any).date}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-amber-300 font-mono font-semibold">
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          <span>{session.startTime} - {session.endTime}</span>
                        </div>
                      </div>
                    </div>

                    {/* Footer Actions */}
                    <div className="pt-2 flex items-center justify-between gap-3">
                      {(session.isRecordingAvailable || (session as any).recordingAvailable) && (
                        <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>Recording Available</span>
                        </span>
                      )}

                      <div className="ml-auto flex items-center gap-2">
                        {isLive ? (
                          <button
                            onClick={() => {
                              if (currentStudent) {
                                setActiveTab('student-portal');
                              } else {
                                openUnifiedLoginModal('student');
                              }
                            }}
                            className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white text-xs font-black transition-all flex items-center gap-2 shadow-lg shadow-rose-600/40 cursor-pointer"
                          >
                            <Video className="w-4 h-4" />
                            <span>Join Live Class</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => setActiveTab('admission')}
                            className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                          >
                            <span>Enroll for Access</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="col-span-full py-12 text-center bg-slate-800/40 rounded-3xl border border-slate-700/60">
                <Video className="w-10 h-10 text-slate-500 mx-auto mb-3" />
                <h4 className="text-base font-bold text-white mb-1">No Live Classes In This Filter</h4>
                <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
                  New interactive live lectures and masterclasses are scheduled regularly across academic subjects.
                </p>
                <button
                  onClick={() => setActiveFilter('all')}
                  className="px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-500 transition cursor-pointer"
                >
                  View Full Schedule
                </button>
              </div>
            )}
          </div>
        )}

        {/* Feature Advertising Callout Box */}
        <div className="p-6 sm:p-8 bg-gradient-to-r from-indigo-900/60 via-purple-900/40 to-slate-900/80 rounded-3xl border border-indigo-500/30 backdrop-blur-md flex flex-col md:flex-row items-center justify-between gap-6 shadow-2xl">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-amber-300">
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Full Online Batch Privileges for Enrolled Students</span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-white">
              Want to join our next live batch with full recording archives?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Get immediate admission, custom scholarship discounts, personalized mentor access, and unlimited recorded lecture revision in your Student Portal.
            </p>
          </div>

          <div className="flex items-center flex-wrap gap-3 shrink-0">
            <button
              onClick={() => setActiveTab('admission')}
              className="px-5 py-3 rounded-2xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs sm:text-sm font-black transition-all shadow-lg hover:shadow-amber-400/30 cursor-pointer flex items-center gap-2"
            >
              <span>Apply for Online Batch</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => openUnifiedLoginModal('student')}
              className="px-4 py-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs sm:text-sm font-bold border border-slate-600 transition cursor-pointer flex items-center gap-2"
            >
              <ShieldCheck className="w-4 h-4 text-indigo-400" />
              <span>Student Portal Login</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
