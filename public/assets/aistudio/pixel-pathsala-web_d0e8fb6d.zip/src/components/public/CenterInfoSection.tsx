import React from 'react';
import { useApp } from '../../context/AppContext';
import { CenterLogo } from '../common/CenterLogo';
import { InteractiveContactTabs } from '../common/InteractiveContactTabs';
import { getDirectApkDownloadUrl } from '../../utils/apkHelper';
import { 
  Sparkles,
  ShieldCheck,
  MessageCircle,
  PhoneCall,
  Mail,
  MapPin,
  Smartphone,
  Download
} from 'lucide-react';

export const CenterInfoSection: React.FC = () => {
  const { centerInfo } = useApp();

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl border border-indigo-500/20 space-y-8">
        
        {/* Top Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-800">
          <div className="flex items-center gap-4">
            <CenterLogo size="lg" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                  Official Center Desk & Help Center
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Admissions Active
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-0.5">
                {centerInfo.name}
              </h2>
              <p className="text-slate-300 text-xs sm:text-sm mt-1">
                "{centerInfo.tagline || 'Code your dream, decode the future'}" &bull; Estd. {centerInfo.establishedYear}
              </p>
            </div>
          </div>

          <div className="hidden lg:block text-right">
            <div className="text-xs text-slate-400 font-mono">
              Reg. No: <strong className="text-slate-200">{centerInfo.regNumber || 'PP/EDU/2021/WB'}</strong>
            </div>
            <div className="text-xs text-indigo-300 font-mono mt-0.5">
              UPI: <strong className="text-white">{centerInfo.upiId}</strong>
            </div>
          </div>
        </div>

        {/* Public Website Direct Download Option Banner */}
        <div className="p-6 sm:p-7 rounded-2xl bg-gradient-to-r from-emerald-950/70 via-slate-900 to-indigo-950 border border-emerald-500/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-md">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center shrink-0 text-emerald-400 shadow-inner">
              <Smartphone className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500 text-slate-950">
                  Direct Download
                </span>
                <span className="text-[11px] font-mono text-emerald-300">
                  PixelPathsala.apk (Android 7.0+)
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-white">
                Official Android Mobile Application
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
                Direct APK download without Google Play Store delays. Get real-time notices for live classes, test schedules, monthly fee receipts, and interactive practice.
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0 w-full md:w-auto">
            <a
              id="center-info-direct-download-btn"
              href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
              download="PixelPathsala.apk"
              className="w-full sm:w-auto flex items-center justify-center gap-2.5 px-6 py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black rounded-xl shadow-lg shadow-emerald-500/20 transition-all transform hover:scale-[1.02] cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-950" />
              <span>Download Mobile App (.APK)</span>
            </a>
          </div>
        </div>

        {/* Interactive Clickable Contact Cards (WhatsApp, Phone, Email, Campus) */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Interactive Direct Reach Channels (Clickable)</span>
            </h3>
            <span className="text-[11px] text-slate-400">
              Instant one-click WhatsApp chat & voice call
            </span>
          </div>

          <InteractiveContactTabs variant="cards" />
        </div>

      </div>
    </div>
  );
};
