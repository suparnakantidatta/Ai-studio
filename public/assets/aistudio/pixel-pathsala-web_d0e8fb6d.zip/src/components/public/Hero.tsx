import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { CenterLogo } from '../common/CenterLogo';
import { DiscountRibbonBadge } from '../common/DiscountRibbonBadge';
import { getWhatsAppUrl, getPhoneTelUrl, getEmailMailtoUrl } from '../../utils/contactHelper';
import { getDirectApkDownloadUrl } from '../../utils/apkHelper';
import { 
  Sparkles, 
  ArrowRight, 
  Code2, 
  GraduationCap, 
  BookOpen, 
  Award, 
  PhoneCall, 
  MapPin, 
  CheckCircle, 
  QrCode, 
  Users, 
  CreditCard, 
  ShieldCheck, 
  MessageCircle, 
  Mail, 
  ExternalLink, 
  Globe, 
  Building2, 
  MonitorPlay,
  Tag,
  Download,
  Smartphone
} from 'lucide-react';

export const Hero: React.FC = () => {
  const { centerInfo, courses, students, educators, discounts, setActiveTab, openUnifiedLoginModal } = useApp();
  const [bgError, setBgError] = useState(false);

  const activeStudentsCount = students.filter(s => s.status === 'active').length;

  // Find active discount highlights
  const activeDiscounts = discounts.filter(d => d.active !== false && String(d.active).toLowerCase() !== 'false');
  const maxPercentDiscount = activeDiscounts
    .filter(d => d.type === 'percentage')
    .reduce((max, d) => Math.max(max, Number(d.value) || 0), 0);
  const maxFlatDiscount = activeDiscounts
    .filter(d => d.type === 'flat')
    .reduce((max, d) => Math.max(max, Number(d.value) || 0), 0);

  let topDiscountText = '';
  if (maxPercentDiscount > 0) {
    topDiscountText = `UPTO ${maxPercentDiscount}% OFF`;
  } else if (maxFlatDiscount > 0) {
    topDiscountText = `UPTO ₹${maxFlatDiscount} OFF`;
  } else if (activeDiscounts.length > 0) {
    topDiscountText = 'SPECIAL SCHOLARSHIP';
  }

  return (
    <div className="relative overflow-hidden pt-4 pb-12">
      {/* Real Center Background Image with Opacity & Gradient Overlay */}
      {Boolean(centerInfo.bgUrl && centerInfo.bgUrl.trim()) && !bgError && (
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none opacity-20 transition-opacity">
          <img
            src={centerInfo.bgUrl?.trim()}
            alt="Center Background"
            onError={() => setBgError(true)}
            className="w-full h-full object-cover object-center filter blur-xs scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#F8FAFC]/90 via-[#F8FAFC]/75 to-[#F8FAFC]" />
        </div>
      )}

      {/* Decorative ambient glowing backdrops */}
      <div className="absolute -top-40 -right-40 w-96 h-96 bg-indigo-400/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 -left-40 w-96 h-96 bg-pink-400/15 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Notice announcement banner */}
        {centerInfo.announcement && (
          <div className="mb-4 p-3.5 px-5 bg-gradient-to-r from-amber-500/15 via-indigo-500/15 to-pink-500/15 border border-amber-300/70 rounded-2xl flex items-center justify-between gap-4 text-xs sm:text-sm text-slate-800 shadow-xs backdrop-blur-xs">
            <div className="flex items-center gap-2 font-medium">
              <span className="animate-pulse flex h-2.5 w-2.5 rounded-full bg-amber-500" />
              <span>{centerInfo.announcement}</span>
            </div>
            <button
              onClick={() => setActiveTab('admission')}
              className="shrink-0 text-xs font-bold text-indigo-700 hover:text-indigo-900 underline cursor-pointer"
            >
              Apply Now &rarr;
            </button>
          </div>
        )}

        {/* Public Website Banner: Online & Offline Learning Modes Available */}
        <div className="mb-6 p-4 sm:p-4.5 bg-gradient-to-r from-indigo-900 via-slate-900 to-purple-950 text-white rounded-3xl shadow-lg border border-indigo-500/30 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="p-2.5 bg-indigo-500/20 border border-indigo-400/30 rounded-2xl shrink-0 text-indigo-300">
              <MonitorPlay className="w-6 h-6 animate-pulse text-cyan-300" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500 text-slate-950">
                  New Update
                </span>
                <h2 className="font-extrabold text-sm sm:text-base tracking-tight text-white">
                  Online & Offline Batch Modes Available Now!
                </h2>
              </div>
              <p className="text-xs sm:text-xs text-slate-300 mt-1 max-w-xl">
                Attend classroom sessions at our modern lab center or join live interactive online batches with recorded lecture access & coding playzone.
              </p>
            </div>
          </div>

          <div className="flex items-center flex-wrap gap-2 shrink-0">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800/80 border border-slate-700 text-xs font-bold text-emerald-400">
              <Building2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Offline Center</span>
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800/80 border border-slate-700 text-xs font-bold text-cyan-400">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>Online Live</span>
            </span>
            <a
              href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
              download="PixelPathsala.apk"
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/50 text-xs font-bold text-emerald-300 transition"
              title="Download Official Mobile App (.apk)"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
              <span>Direct APK</span>
            </a>
            <button
              onClick={() => setActiveTab('admission')}
              className="px-3.5 py-1.5 bg-indigo-500 hover:bg-indigo-400 text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer ml-1"
            >
              Enroll Mode &rarr;
            </button>
          </div>
        </div>

        {/* Hero Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center mb-14">
          <div className="lg:col-span-7 space-y-6">
            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100/90 text-emerald-900 text-xs font-bold tracking-wide border border-emerald-300 shadow-xs">
                <Sparkles className="w-4 h-4 text-emerald-600 animate-spin" />
                <span>0% Registration Fee • Zero Admission Fee • Admissions Open</span>
              </div>

              {/* Red Ribbon Background with Golden Text Badge on Public Homepage */}
              {topDiscountText && (
                <DiscountRibbonBadge
                  variant="pill"
                  text={topDiscountText}
                  subtitle="Scholarship Offer"
                  showIcon={true}
                />
              )}
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-4">
                <CenterLogo size="lg" />
                <div>
                  <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 leading-tight">
                    {centerInfo.name}
                  </h1>
                  <h2 className="text-xs sm:text-sm font-bold text-indigo-700 uppercase tracking-wider mt-1">
                    Premier Coaching Institute & Computer Academy • Raina, Purba Bardhaman
                  </h2>
                  <p className="text-xs sm:text-sm font-semibold text-slate-500 italic mt-0.5">
                    "{centerInfo.tagline || 'Code your dream, decode the future'}"
                  </p>
                </div>
              </div>
            </div>

            <p className="text-base sm:text-lg text-slate-700 max-w-2xl leading-relaxed">
              {centerInfo.welcomeMessage} Learn from experienced faculties, practice live in our interactive Coding Playzone, and track syllabus, attendance, and monthly fees transparently.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 pt-2">
              <button
                id="hero-apply-btn"
                onClick={() => setActiveTab('admission')}
                className="flex items-center gap-2 px-6 py-3.5 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white font-bold rounded-2xl shadow-lg shadow-indigo-600/25 transition-all transform hover:scale-[1.02] cursor-pointer text-sm sm:text-base"
              >
                <span>Free Admission Form</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                id="hero-playzone-btn"
                onClick={() => setActiveTab('playzone')}
                className="flex items-center gap-2 px-5 py-3.5 bg-white hover:bg-slate-50 text-slate-800 font-bold rounded-2xl border border-slate-300 shadow-sm transition-all cursor-pointer text-sm sm:text-base"
              >
                <Code2 className="w-4 h-4 text-indigo-600" />
                <span>Code Practice Zone</span>
              </button>

              <button
                id="hero-student-login-btn"
                onClick={() => openUnifiedLoginModal('student')}
                className="flex items-center gap-2 px-5 py-3.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl shadow-sm transition-all cursor-pointer text-sm sm:text-base"
              >
                <CreditCard className="w-4 h-4 text-emerald-400" />
                <span>Student Fee & Portal</span>
              </button>

              {/* Direct APK Download Button on Public Website */}
              <a
                id="hero-direct-download-btn"
                href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
                download="PixelPathsala.apk"
                className="flex items-center gap-2 px-5 py-3.5 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-2xl shadow-lg shadow-emerald-600/20 border border-emerald-400/40 transition-all transform hover:scale-[1.02] cursor-pointer text-sm sm:text-base"
              >
                <Smartphone className="w-4 h-4 text-emerald-200" />
                <span>Download Mobile App</span>
                <span className="text-[10px] bg-emerald-950/60 text-emerald-200 px-1.5 py-0.5 rounded font-mono border border-emerald-400/30">
                  .APK
                </span>
              </a>
            </div>
          </div>

          {/* Right Hero Visual Card with Indian Students and Highlight Badges */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-indigo-200 bg-white group">
              {/* Photo of Indian Students Learning */}
              <div className="relative h-72 sm:h-80 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&w=1200&q=80" 
                  alt="Indian Students Learning at Pixel Pathsala"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                <div className="absolute top-4 left-4 flex gap-2">
                  <span className="px-3 py-1 bg-emerald-500 text-white rounded-full text-xs font-bold shadow-md">
                    ✓ Admissions Open
                  </span>
                  <span className="px-3 py-1 bg-indigo-600 text-white rounded-full text-xs font-bold shadow-md">
                    ₹0 Registration Fee
                  </span>
                </div>

                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <div className="font-bold text-lg leading-tight flex items-center gap-2">
                    <span>Academic & Practical Coding Excellence</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 line-clamp-2">
                    Interactive classroom sessions with top educators and hands-on C, Python, Web & DBMS lab training.
                  </p>
                </div>
              </div>

              {/* Stats Highlights below photo */}
              <div className="p-5 bg-gradient-to-br from-slate-900 to-indigo-950 text-white">
                <div className="grid grid-cols-3 gap-3 mb-4 text-center">
                  <div className="bg-slate-800/80 rounded-xl p-2.5 border border-slate-700">
                    <div className="text-[11px] text-slate-400 font-medium">Students</div>
                    <div className="text-lg font-black text-indigo-400 mt-0.5">{activeStudentsCount}+ Enrolled</div>
                  </div>
                  <div className="bg-slate-800/80 rounded-xl p-2.5 border border-slate-700">
                    <div className="text-[11px] text-slate-400 font-medium">Educators</div>
                    <div className="text-lg font-black text-amber-400 mt-0.5">{educators.length} Mentors</div>
                  </div>
                  <div className="bg-slate-800/80 rounded-xl p-2.5 border border-slate-700">
                    <div className="text-[11px] text-slate-400 font-medium">Programs</div>
                    <div className="text-lg font-black text-emerald-400 mt-0.5">{courses.length} Batches</div>
                  </div>
                </div>

                {/* Center Direct Info Footer with Clickable WhatsApp & Phone Buttons */}
                <div className="pt-3 border-t border-slate-800/80 space-y-2">
                  <div className="flex items-center gap-2 text-xs text-slate-300">
                    <MapPin className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span className="truncate">{centerInfo.address}, {centerInfo.cityState}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <a
                      href={getWhatsAppUrl(centerInfo.whatsapp || centerInfo.phonePrimary, centerInfo.name)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1.5 py-1.5 px-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition"
                    >
                      <MessageCircle className="w-3.5 h-3.5 fill-current" />
                      <span>WhatsApp Chat</span>
                    </a>

                    <a
                      href={getPhoneTelUrl(centerInfo.phonePrimary)}
                      className="flex items-center justify-center gap-1.5 py-1.5 px-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>Call Helpline</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
