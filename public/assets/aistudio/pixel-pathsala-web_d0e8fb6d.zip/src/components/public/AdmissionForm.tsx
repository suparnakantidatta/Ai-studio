import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PaymentMode, AdmissionApplication } from '../../types';
import { getUpiQrCodeUrl, getUpiDeepLink } from '../../utils/qrHelper';
import { calculateTargetDiscount, getBatchDiscountInfo } from '../../utils/feeCalculator';
import { 
  getCoursesForClass, 
  getBatchesForCourse, 
  getModesForCourse, 
  getBatchesForCourseAndMode, 
  formatModeLabel,
  getDistinctAcademicClasses,
  DeliveryMode 
} from '../../utils/classCourseMatcher';
import { AdmissionReceiptModal } from '../common/AdmissionReceiptModal';
import { DiscountRibbonBadge } from '../common/DiscountRibbonBadge';
import confetti from 'canvas-confetti';
import { 
  Sparkles, 
  CheckCircle, 
  QrCode, 
  CreditCard, 
  Building2, 
  Copy, 
  Check, 
  ArrowRight, 
  Send, 
  Info,
  Calendar,
  Phone,
  User,
  MapPin,
  BookOpen,
  ExternalLink,
  Smartphone,
  GraduationCap,
  Printer,
  Download,
  Code2,
  Clock,
  AlertCircle,
  Radio,
  Globe
} from 'lucide-react';

export const AdmissionForm: React.FC = () => {
  const { courses, batches, discounts, centerInfo, submitAdmissionApplication, setActiveTab } = useApp();

  const distinctClasses = getDistinctAcademicClasses(courses);
  const defaultClass = distinctClasses[0] || 'Class 10';

  const [studentName, setStudentName] = useState('');
  const [studentClass, setStudentClass] = useState<string>(defaultClass);
  const [mobile, setMobile] = useState('');
  const [aadhaarNo, setAadhaarNo] = useState('');
  const [email, setEmail] = useState('');
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [address, setAddress] = useState('');
  
  // Cascading Selection State: Class -> Course -> Mode -> Batch -> Fee
  const [targetCourseId, setTargetCourseId] = useState(() => {
    const matched = getCoursesForClass(courses, defaultClass);
    return matched[0]?.id || courses[0]?.id || '';
  });
  const [selectedMode, setSelectedMode] = useState<string>('offline');
  const [preferredBatchId, setPreferredBatchId] = useState(() => {
    const matchedCourses = getCoursesForClass(courses, defaultClass);
    const initialCourseId = matchedCourses[0]?.id || courses[0]?.id || '';
    const matchedBatches = getBatchesForCourse(batches, initialCourseId);
    return matchedBatches[0]?.id || batches[0]?.id || '';
  });
  const [previousSchool, setPreviousSchool] = useState('');
  const [remarks, setRemarks] = useState('');

  // Payment Options
  const [paymentOption, setPaymentOption] = useState<'pay_upi' | 'pay_cash_center' | 'pay_later'>('pay_upi');
  const [upiUtr, setUpiUtr] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);

  // Success state & receipt modal state
  const [submittedApp, setSubmittedApp] = useState<AdmissionApplication | null>(null);
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);

  // Dynamically filtered courses based on selected class
  const availableCourses = getCoursesForClass(courses, studentClass);
  // Dynamically filtered modes based on selected course
  const availableModes = getModesForCourse(batches, targetCourseId);
  // Dynamically filtered batches based on selected course and mode
  const filteredBatches = getBatchesForCourseAndMode(batches, targetCourseId, selectedMode);

  const handleClassChange = (newClass: string) => {
    setStudentClass(newClass);
    const matchedCourses = getCoursesForClass(courses, newClass);
    const nextCourseId = matchedCourses[0]?.id || '';
    setTargetCourseId(nextCourseId);

    const modes = getModesForCourse(batches, nextCourseId);
    const nextMode = modes.includes(selectedMode as DeliveryMode) ? selectedMode : (modes[0] || 'offline');
    setSelectedMode(nextMode);

    const matchedBatches = getBatchesForCourseAndMode(batches, nextCourseId, nextMode);
    setPreferredBatchId(matchedBatches[0]?.id || '');
  };

  const handleCourseChange = (newCourseId: string) => {
    setTargetCourseId(newCourseId);
    const modes = getModesForCourse(batches, newCourseId);
    const nextMode = modes.includes(selectedMode as DeliveryMode) ? selectedMode : (modes[0] || 'offline');
    setSelectedMode(nextMode);

    const matchedBatches = getBatchesForCourseAndMode(batches, newCourseId, nextMode);
    setPreferredBatchId(matchedBatches[0]?.id || '');
  };

  const handleModeChange = (newMode: string) => {
    setSelectedMode(newMode);
    const matchedBatches = getBatchesForCourseAndMode(batches, targetCourseId, newMode);
    setPreferredBatchId(matchedBatches[0]?.id || '');
  };

  const selectedCourse = courses.find(c => c.id === targetCourseId);
  const selectedBatch = batches.find(b => b.id === preferredBatchId);

  // Form submission date automatically captured
  const todaySubmissionDate = new Date().toISOString().split('T')[0];
  const submissionMonth = todaySubmissionDate.substring(0, 7);

  // Registration Fee is ₹0 for Pixel Pathsala
  const admissionFee = 0;
  const baseMonthlyFee = selectedCourse?.monthlyFee || 1200;

  // Calculate dynamic concession / scholarship based on class, course, batch, and month
  const discountCalculation = calculateTargetDiscount({
    studentClass,
    courseId: targetCourseId,
    batchId: preferredBatchId,
    monthKey: submissionMonth,
    baseFee: baseMonthlyFee,
    discounts,
    course: selectedCourse
  });

  const appliedDiscountAmount = discountCalculation.discountAmount;
  const appliedDiscountNotes = discountCalculation.notes.join('; ');
  const totalPayableAmount = discountCalculation.finalFee;

  const qrCodeUrl = getUpiQrCodeUrl({
    upiId: centerInfo.upiId,
    payeeName: centerInfo.upiName,
    amount: totalPayableAmount,
    transactionNote: `Adm:${studentName || 'Student'}`,
    size: 200
  });

  const upiDeepLink = getUpiDeepLink({
    upiId: centerInfo.upiId,
    payeeName: centerInfo.upiName,
    amount: totalPayableAmount,
    note: `Adm:${studentName || 'Student'}`
  });

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(centerInfo.upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!studentName.trim() || !mobile.trim() || !aadhaarNo.trim()) {
      alert('Please fill in all mandatory student personal details (Name, Mobile, Aadhaar).');
      return;
    }

    let initialPaymentStatus: 'unpaid' | 'paid_advance' | 'at_center' = 'unpaid';
    let initialPaymentMode: PaymentMode | undefined = undefined;
    let initialPaymentRef: string | undefined = undefined;
    let initialPaymentAmount: number | undefined = undefined;

    if (paymentOption === 'pay_upi') {
      initialPaymentStatus = 'paid_advance';
      initialPaymentMode = 'UPI';
      initialPaymentRef = upiUtr.trim() || 'UPI-ADVANCE-SUBMITTED';
      initialPaymentAmount = totalPayableAmount;
    } else if (paymentOption === 'pay_cash_center') {
      initialPaymentStatus = 'at_center';
      initialPaymentMode = 'CASH';
      initialPaymentAmount = totalPayableAmount;
    }

    const application = submitAdmissionApplication({
      studentName: studentName.trim(),
      studentClass,
      mobile: mobile.trim(),
      aadhaarNo: aadhaarNo.trim(),
      email: email.trim() || undefined,
      guardianName: guardianName.trim(),
      guardianPhone: guardianPhone.trim(),
      address: address.trim(),
      targetCourseId,
      preferredBatchId: preferredBatchId || undefined,
      previousSchool: previousSchool.trim() || undefined,
      remarks: remarks.trim() || undefined,
      baseFee: baseMonthlyFee,
      appliedDiscountAmount,
      appliedDiscountNotes: appliedDiscountNotes || undefined,
      initialPaymentMode,
      initialPaymentRef,
      initialPaymentAmount,
      initialPaymentStatus
    });

    setSubmittedApp(application);

    try {
      confetti({
        particleCount: 70,
        spread: 80,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }
  };

  if (submittedApp) {
    return (
      <div className="w-full max-w-3xl mx-auto px-4 py-12 text-center animate-fadeIn">
        <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-slate-200">
          
          {/* Top Status Header */}
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-inner">
            <CheckCircle className="w-8 h-8" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-xs font-extrabold uppercase tracking-wider mb-2">
            <Clock className="w-3.5 h-3.5 text-amber-700" />
            <span>Status: Pending Approval</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2 mb-1">
            Application Received Successfully!
          </h2>

          <p className="text-xs sm:text-sm text-slate-600 max-w-lg mx-auto mb-6 leading-relaxed">
            Your admission application is registered with <strong>{centerInfo.name}</strong>. Please download or print your provisional receipt below.
          </p>

          {/* Under Process Notice Callout */}
          <div className="bg-amber-50/90 border-2 border-amber-300 rounded-2xl p-4 sm:p-5 text-left mb-6 space-y-1 text-amber-950">
            <div className="flex items-center gap-2 font-black text-xs sm:text-sm text-amber-900">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Your application is under process, Please contact you educator or visit center with payment receipt</span>
            </div>
            <p className="text-[11px] sm:text-xs text-amber-800 leading-relaxed">
              Keep your Application Ref No (<strong>{submittedApp.applicationNo}</strong>) safe. You can present this provisional receipt at the center desk or during classroom induction.
            </p>
          </div>

          {/* Application Summary Card */}
          <div className="bg-slate-50 p-5 sm:p-6 rounded-2xl border border-slate-200 text-left space-y-2.5 mb-6 text-xs">
            <div className="flex justify-between items-center pb-2.5 border-b border-slate-200">
              <span className="font-semibold text-slate-500 uppercase">Application Reference:</span>
              <span className="font-mono font-black text-indigo-700 text-sm sm:text-base">{submittedApp.applicationNo}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Applicant Name:</span>
              <span className="font-bold text-slate-900">{submittedApp.studentName}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Academic Class:</span>
              <span className="font-bold text-indigo-700">{submittedApp.studentClass || studentClass}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Selected Course:</span>
              <span className="font-bold text-slate-800">{selectedCourse?.title}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Mobile & Aadhaar:</span>
              <span className="font-mono text-slate-700">{submittedApp.mobile} • XXXX-XXXX-{submittedApp.aadhaarNo.slice(-4)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500">Payment Mode:</span>
              <span className="font-semibold text-slate-800">
                {submittedApp.initialPaymentMode === 'UPI' ? 'UPI Advance Payment' : 'Pay Cash at Center Desk'}
              </span>
            </div>
            {submittedApp.initialPaymentRef && (
              <div className="flex justify-between items-center">
                <span className="text-slate-500">Transaction Reference:</span>
                <span className="font-mono text-indigo-700 font-semibold">{submittedApp.initialPaymentRef}</span>
              </div>
            )}
            {submittedApp.appliedDiscountAmount && submittedApp.appliedDiscountAmount > 0 ? (
              <div className="flex justify-between items-center bg-emerald-50/80 -mx-2 px-2 py-1 rounded-lg border border-emerald-200">
                <span className="text-emerald-800 font-semibold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Concession / Scholarship:</span>
                </span>
                <span className="font-mono font-bold text-emerald-700">
                  -₹{submittedApp.appliedDiscountAmount.toLocaleString('en-IN')} {submittedApp.appliedDiscountNotes ? `(${submittedApp.appliedDiscountNotes})` : ''}
                </span>
              </div>
            ) : null}
            <div className="flex justify-between items-center">
              <span className="text-slate-500 font-semibold">1st Month Fee:</span>
              <span className="font-mono font-bold text-slate-900">
                ₹{(submittedApp.initialPaymentAmount ?? totalPayableAmount).toLocaleString('en-IN')}
              </span>
            </div>
            <div className="flex justify-between items-center pt-2 border-t border-slate-200">
              <span className="font-bold text-slate-700">Application Status:</span>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-extrabold text-[11px] border border-amber-300">
                Pending Approval
              </span>
            </div>
          </div>

          {/* Action Buttons: Print / Download Receipt / Coders Zone / Student Portal */}
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => setIsReceiptModalOpen(true)}
              className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Download Receipt</span>
            </button>

            <button
              onClick={() => setActiveTab('playzone')}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
            >
              <Code2 className="w-4 h-4 text-amber-300" />
              <span>Go to Coders Zone</span>
            </button>

            <button
              onClick={() => setActiveTab('student-portal')}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs sm:text-sm transition border border-slate-200 cursor-pointer"
            >
              <span>Student Portal</span>
            </button>

            <button
              onClick={() => {
                setSubmittedApp(null);
                setStudentName('');
                setStudentClass('Class 10 (Secondary)');
                setMobile('');
                setAadhaarNo('');
                setEmail('');
                setGuardianName('');
                setGuardianPhone('');
                setAddress('');
                setPreviousSchool('');
                setRemarks('');
                setUpiUtr('');
              }}
              className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold rounded-xl text-xs sm:text-sm transition cursor-pointer"
            >
              Submit Another Application
            </button>
          </div>
        </div>

        {/* Print Receipt Modal */}
        {isReceiptModalOpen && (
          <AdmissionReceiptModal
            application={submittedApp}
            onClose={() => setIsReceiptModalOpen(false)}
          />
        )}
      </div>
    );
  }

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold mb-3 border border-emerald-200">
          <Sparkles className="w-3.5 h-3.5" />
          <span>0% Registration Fee • Direct Student Admission</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Online Admission Form
        </h1>
        <p className="text-slate-600 text-sm sm:text-base mt-2">
          Apply online with zero registration charges. Fill your details, select your batch, and join Pixel Pathsala.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Form Fields (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Personal Information */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
              <User className="w-5 h-5 text-indigo-600" />
              <span>Student Personal Information</span>
            </h2>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Student Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="adm-input-name"
                    type="text"
                    required
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="e.g. Sourav Banerjee"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1 flex items-center gap-1">
                    <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Academic Class Section <span className="text-red-500">*</span></span>
                  </label>
                  <select
                    id="adm-select-class"
                    value={studentClass}
                    onChange={(e) => handleClassChange(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-semibold bg-white"
                  >
                    {distinctClasses.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Mobile Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="adm-input-mobile"
                    type="tel"
                    required
                    maxLength={10}
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                    placeholder="10-digit mobile number"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    AADHAAR Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    id="adm-input-aadhaar"
                    type="text"
                    required
                    maxLength={14}
                    value={aadhaarNo}
                    onChange={(e) => setAadhaarNo(e.target.value)}
                    placeholder="e.g. 7890 1234 5678"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Email Address (Optional)
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="student@example.com"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Guardian / Parent Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={guardianName}
                    onChange={(e) => setGuardianName(e.target.value)}
                    placeholder="Parent or Guardian"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Guardian Phone <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={guardianPhone}
                    onChange={(e) => setGuardianPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="Emergency Contact"
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Residential Address <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="House / Street, Locality, City & Pincode"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm resize-none"
                />
              </div>
            </div>
          </div>

          {/* Academic / Course Selection */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
              <BookOpen className="w-5 h-5 text-indigo-600" />
              <span>Course & Academic Preferences</span>
            </h2>

            <div className="space-y-4">
              {/* Admission Date Note */}
              <div className="p-3 bg-indigo-50/70 rounded-xl border border-indigo-100 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-indigo-600 shrink-0" />
                  <div>
                    <span className="font-bold text-indigo-950">Admission Date: </span>
                    <span className="font-semibold text-indigo-700">{todaySubmissionDate} (Today)</span>
                  </div>
                </div>
                <span className="text-[11px] font-bold text-indigo-600 bg-white px-2 py-0.5 rounded-md border border-indigo-200">
                  Fees active from {new Date().toLocaleString('default', { month: 'short', year: 'numeric' })}
                </span>
              </div>

              {/* Course Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  1. Select Course (Filtered by {studentClass}) <span className="text-red-500">*</span>
                </label>
                {availableCourses.length > 0 ? (
                  <select
                    id="adm-select-course"
                    value={targetCourseId}
                    onChange={(e) => handleCourseChange(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-medium"
                  >
                    {availableCourses.map((course) => (
                      <option key={course.id} value={course.id}>
                        {course.title} — ₹{course.monthlyFee}/month (0 Reg Fee)
                      </option>
                    ))}
                  </select>
                ) : (
                  <div>
                    <select
                      disabled
                      className="w-full px-4 py-2.5 rounded-xl border border-amber-300 bg-amber-50 text-amber-900 text-sm font-medium cursor-not-allowed"
                    >
                      <option value="">No course found for {studentClass}</option>
                    </select>
                    <p className="text-xs text-amber-700 font-semibold mt-1">
                      ⚠️ No course found for this academic class. Please select another class or contact admin.
                    </p>
                  </div>
                )}
              </div>

              {/* Mode Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1 flex items-center justify-between">
                  <span>2. Select Learning Mode</span>
                  <span className="text-[11px] font-normal text-slate-500">Available from database</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {availableModes.map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => handleModeChange(mode)}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                        selectedMode === mode
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      {mode === 'online' ? (
                        <Globe className={`w-3.5 h-3.5 ${selectedMode === mode ? 'text-white' : 'text-blue-500'}`} />
                      ) : (
                        <Building2 className={`w-3.5 h-3.5 ${selectedMode === mode ? 'text-white' : 'text-emerald-500'}`} />
                      )}
                      <span>{formatModeLabel(mode)}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Batch Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  3. Preferred Batch & Timing (Filtered by Course & Mode)
                </label>
                <select
                  value={preferredBatchId}
                  onChange={(e) => setPreferredBatchId(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                >
                  {filteredBatches.length > 0 ? (
                    filteredBatches.map((batch) => {
                      const bDiscount = selectedCourse ? getBatchDiscountInfo(batch, selectedCourse, discounts) : null;
                      const discountLabel = bDiscount && bDiscount.hasDiscount ? ` [${bDiscount.discountText} • ₹${bDiscount.finalFee}/mo]` : '';
                      return (
                        <option key={batch.id} value={batch.id}>
                          {batch.name} • {batch.timing} ({batch.scheduleDays.join(', ')})${discountLabel}
                        </option>
                      );
                    })
                  ) : (
                    <option value="">No batches scheduled for this mode/course yet (Direct Admission)</option>
                  )}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Previous School / College / Last Exam Passed
                </label>
                <input
                  type="text"
                  value={previousSchool}
                  onChange={(e) => setPreviousSchool(e.target.value)}
                  placeholder="e.g. Raina High School / Burdwan CMS High School, Class 10 (88%)"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Special Notes / Aspirations
                </label>
                <input
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="Any specific goal, batch timing request, or query"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Fee Summary & UPI / Cash Payment Option (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Fee Breakdown Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2 mb-4 pb-2 border-b border-slate-100">
              <CreditCard className="w-5 h-5 text-indigo-600" />
              <span>Fee Summary & Payment Option</span>
            </h2>

            <div className="space-y-3 text-xs sm:text-sm">
              <div className="flex justify-between py-1 text-slate-600">
                <span>Admission / Registration Fee</span>
                <span className="font-mono font-bold text-emerald-600">₹0 (FREE)</span>
              </div>
              <div className="flex justify-between py-1 text-slate-600">
                <span>1st Month Base Tuition Fee</span>
                <span className="font-mono font-semibold text-slate-900">₹{baseMonthlyFee.toLocaleString('en-IN')}</span>
              </div>
              {appliedDiscountAmount > 0 && (
                <div className="p-3 bg-gradient-to-r from-red-50/80 via-rose-50/60 to-amber-50/60 rounded-2xl border border-red-200 space-y-2">
                  <div className="flex justify-between items-center flex-wrap gap-2">
                    <DiscountRibbonBadge
                      variant="pill"
                      text={`UPTO ₹${appliedDiscountAmount.toLocaleString('en-IN')} OFF`}
                      subtitle="Highest Concession"
                      showIcon={true}
                    />
                    <span className="font-mono text-red-700 font-extrabold text-xs">
                      UPTO -₹{appliedDiscountAmount.toLocaleString('en-IN')} OFF
                    </span>
                  </div>
                  {discountCalculation.notes.map((note, idx) => (
                    <div key={idx} className="text-[11px] text-red-800 font-medium flex items-center gap-1.5 pl-1">
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-red-500"></span>
                      <span>{note}</span>
                    </div>
                  ))}
                </div>
              )}
              <div className="flex justify-between py-2 border-t-2 border-slate-200 text-sm sm:text-base font-bold text-slate-900 items-center">
                <span>Total Payable for 1st Month:</span>
                <div className="text-right">
                  {appliedDiscountAmount > 0 && (
                    <span className="line-through text-slate-400 mr-2 text-xs sm:text-sm font-normal">
                      ₹{baseMonthlyFee.toLocaleString('en-IN')}
                    </span>
                  )}
                  <span className="font-mono text-indigo-700 font-black">₹{totalPayableAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="mt-6 space-y-3">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                Choose Payment Mode:
              </label>

              <div className="grid grid-cols-1 gap-2.5">
                <button
                  type="button"
                  id="pay-opt-upi"
                  onClick={() => setPaymentOption('pay_upi')}
                  className={`p-3.5 rounded-xl border text-left flex items-start gap-3 transition cursor-pointer ${
                    paymentOption === 'pay_upi'
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 ring-1 ring-indigo-600'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <QrCode className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-sm">Pay via UPI QR / Direct Link</div>
                    <div className="text-xs text-slate-500">Scan & pay via GPay, PhonePe, Paytm, BHIM to <span className="font-mono font-semibold text-indigo-700">{centerInfo.upiId}</span></div>
                  </div>
                </button>

                <button
                  type="button"
                  id="pay-opt-cash"
                  onClick={() => setPaymentOption('pay_cash_center')}
                  className={`p-3.5 rounded-xl border text-left flex items-start gap-3 transition cursor-pointer ${
                    paymentOption === 'pay_cash_center'
                      ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 ring-1 ring-indigo-600'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <Building2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold text-sm">Pay Cash at Center Desk</div>
                    <div className="text-xs text-slate-500">Submit form and deposit cash at Pixel Pathsala reception desk</div>
                  </div>
                </button>
              </div>
            </div>

            {/* If UPI Selected, display QR Code and Clickable Link */}
            {paymentOption === 'pay_upi' && (
              <div className="mt-6 p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                <div className="font-bold text-slate-900 text-sm mb-1">
                  Scan QR to Pay ₹{totalPayableAmount.toLocaleString('en-IN')}
                </div>
                <p className="text-xs text-slate-500 mb-3">
                  All UPI Apps accepted (Google Pay, PhonePe, Paytm, BHIM)
                </p>

                <div className="inline-block p-2 bg-white rounded-2xl border border-slate-200 shadow-xs mb-3">
                  {qrCodeUrl ? (
                    <img
                      src={qrCodeUrl}
                      alt="Pixel Pathsala UPI QR"
                      className="w-40 h-40 object-contain mx-auto"
                    />
                  ) : null}
                </div>

                {/* Clickable UPI direct link */}
                <div className="mb-3">
                  <a
                    href={upiDeepLink}
                    className="inline-flex items-center justify-center gap-2 w-full py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md transition transform hover:scale-[1.01]"
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>Click to Open UPI App</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                {/* UPI ID copy pill */}
                <div className="flex items-center justify-center gap-2 mb-4">
                  <span className="font-mono text-xs font-bold text-indigo-900 bg-indigo-100/80 px-3 py-1.5 rounded-lg">
                    {centerInfo.upiId}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyUpi}
                    className="p-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs transition cursor-pointer flex items-center gap-1"
                  >
                    {copiedUpi ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedUpi ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>

                {/* UTR Input */}
                <div className="text-left">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Enter UPI Reference / UTR Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required={paymentOption === 'pay_upi'}
                    value={upiUtr}
                    onChange={(e) => setUpiUtr(e.target.value)}
                    placeholder="e.g. 423987123490 (12-digit UTR)"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono bg-white"
                  />
                </div>
              </div>
            )}

            {/* Submit Application Button */}
            <div className="mt-6">
              <button
                type="submit"
                id="btn-submit-admission"
                className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-base shadow-lg shadow-indigo-600/30 transition-all transform hover:scale-[1.01] cursor-pointer"
              >
                <Send className="w-5 h-5" />
                <span>Submit Admission Application</span>
              </button>
              <p className="text-[11px] text-slate-400 text-center mt-2">
                Your admission will be reviewed and verified by Pixel Pathsala Admin.
              </p>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
