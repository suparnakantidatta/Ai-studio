import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Educator } from '../../types';
import { getWhatsAppUrl } from '../../utils/contactHelper';
import { normalizeImageUrl } from '../../utils/imageHelper';
import { 
  Award, 
  GraduationCap, 
  BookOpen, 
  Clock, 
  Calendar, 
  MessageCircle, 
  Phone, 
  Mail, 
  Sparkles, 
  CheckCircle2, 
  X, 
  ArrowRight,
  UserCheck,
  Search,
  Filter
} from 'lucide-react';

export const FacultyList: React.FC = () => {
  const { educators, batches, courses, centerInfo, setActiveTab } = useApp();
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedEducator, setSelectedEducator] = useState<Educator | null>(null);

  // Active faculty list
  const activeEducators = educators.filter(e => e.status === 'active' || !e.status);

  // Distinct subjects for filter
  const subjects = ['All', ...Array.from(new Set(activeEducators.map(e => e.subject).filter(Boolean)))];

  const filteredEducators = activeEducators.filter(edu => {
    const matchesSubject = selectedSubject === 'All' || edu.subject === selectedSubject;
    const matchesSearch = 
      edu.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      edu.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      edu.qualification.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSubject && matchesSearch;
  });

  // Helper to find batches taught by an educator
  const getEducatorBatches = (educatorId: string, educator?: Educator) => {
    return batches.filter(b => 
      b.educatorId === educatorId || 
      (educator?.assignedBatchIds && educator.assignedBatchIds.includes(b.id))
    );
  };

  return (
    <section id="faculty-section" className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-violet-50 text-violet-700 text-xs font-bold mb-3 border border-violet-200">
          <GraduationCap className="w-4 h-4 text-violet-600" />
          <span>Our Distinguished Academic & Technical Faculty</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Learn from Experienced Educators
        </h2>
        <p className="text-slate-600 text-sm sm:text-base mt-2 leading-relaxed">
          Our mentors bring decades of combined academic pedagogy and industry expertise. They focus on foundational clarity, live problem solving, and individualized student care.
        </p>

        {/* Search & Subject Filter Bar */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3 max-w-2xl mx-auto">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="faculty-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search faculty by name or subject..."
              className="w-full pl-10 pr-4 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-xs"
            />
          </div>

          <div className="flex flex-wrap items-center justify-center gap-1.5 w-full sm:w-auto">
            {subjects.map(subj => (
              <button
                key={subj}
                onClick={() => setSelectedSubject(subj)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer ${
                  selectedSubject === subj
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {subj}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Faculty Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredEducators.map((edu) => {
          const eduBatches = getEducatorBatches(edu.id, edu);
          const eduCourses = courses.filter(c => eduBatches.some(b => b.courseId === c.id));

          return (
            <div
              key={edu.id}
              className="bg-white rounded-3xl border border-slate-200/90 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden group hover:border-indigo-400/80"
            >
              <div className="p-6">
                {/* Educator Photo with online badge */}
                <div className="relative w-24 h-24 mx-auto mb-4">
                  {(() => {
                    const photo = normalizeImageUrl(edu.photoUrl);
                    return photo ? (
                      <img
                        src={photo}
                        alt={edu.name}
                        className="w-24 h-24 rounded-full object-cover shadow-md border-2 border-indigo-200 group-hover:border-indigo-600 transition-colors"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLImageElement).onerror = null;
                          (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(edu.name)}&background=4f46e5&color=fff&bold=true`;
                        }}
                      />
                    ) : (
                      <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-indigo-600 via-indigo-700 to-purple-700 text-white font-black text-2xl flex items-center justify-center shadow-md border-2 border-indigo-200 group-hover:border-indigo-600 transition-colors">
                        {edu.name.split(' ').slice(0, 2).map(n => n[0]).join('')}
                      </div>
                    );
                  })()}
                  <span 
                    className="absolute bottom-0 right-0 p-1 bg-emerald-500 rounded-full text-white border-2 border-white shadow-xs" 
                    title="Active Faculty Mentor"
                  >
                    <span className="block w-2.5 h-2.5 rounded-full bg-white animate-pulse" />
                  </span>
                </div>

                {/* Name & Specialization */}
                <div className="text-center">
                  <h3 className="text-lg font-black text-slate-900 group-hover:text-indigo-600 transition-colors">
                    {edu.name}
                  </h3>
                  <div className="inline-block px-2.5 py-0.5 mt-1 bg-indigo-50 text-indigo-700 text-xs font-bold rounded-lg border border-indigo-100">
                    {edu.subject}
                  </div>
                </div>

                {/* Qualification badge */}
                <div className="mt-3 p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-600 text-center">
                  <span className="font-semibold text-slate-700 block">{edu.qualification}</span>
                </div>

                {/* Experience, Mobile & Batches Taught */}
                <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-600">
                    <span className="flex items-center gap-1.5 text-slate-500">
                      <Award className="w-3.5 h-3.5 text-amber-500" />
                      Experience:
                    </span>
                    <span className="font-bold text-slate-800 bg-amber-50 text-amber-900 px-2 py-0.5 rounded-md border border-amber-200">
                      {edu.experienceYears}+ Years
                    </span>
                  </div>

                  {/* Educator Mobile Number */}
                  {edu.phone ? (
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="flex items-center gap-1.5 text-slate-500">
                        <Phone className="w-3.5 h-3.5 text-emerald-600" />
                        Mobile No:
                      </span>
                      <a
                        href={`tel:${edu.phone}`}
                        className="font-bold text-indigo-700 hover:text-indigo-900 hover:underline flex items-center gap-1 bg-indigo-50/70 px-2 py-0.5 rounded-md border border-indigo-100"
                        onClick={(e) => e.stopPropagation()}
                        title={`Call ${edu.name}`}
                      >
                        <span>{edu.phone}</span>
                      </a>
                    </div>
                  ) : null}

                  {eduBatches.length > 0 && (
                    <div className="flex items-center justify-between text-slate-600">
                      <span className="flex items-center gap-1.5 text-slate-500">
                        <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                        Batches:
                      </span>
                      <span className="font-bold text-indigo-700">
                        {eduBatches.length} Active {eduBatches.length === 1 ? 'Batch' : 'Batches'}
                      </span>
                    </div>
                  )}
                </div>

                {/* Batches Preview Pills */}
                {eduBatches.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1">
                    {eduBatches.slice(0, 2).map(b => (
                      <span key={b.id} className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-medium truncate max-w-full">
                        {b.name} ({b.timing})
                      </span>
                    ))}
                    {eduBatches.length > 2 && (
                      <span className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-md">
                        +{eduBatches.length - 2} more
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Action Buttons Footer */}
              <div className="p-4 bg-slate-50/90 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => setSelectedEducator(edu)}
                  className="flex-1 py-2 px-3 bg-white hover:bg-slate-100 text-slate-800 text-xs font-bold rounded-xl border border-slate-200 shadow-2xs transition cursor-pointer flex items-center justify-center gap-1"
                >
                  <UserCheck className="w-3.5 h-3.5 text-indigo-600" />
                  <span>View Bio</span>
                </button>

                <a
                  href={getWhatsAppUrl(
                    centerInfo.whatsapp || centerInfo.phonePrimary, 
                    `${centerInfo.name} - Inquiry regarding Faculty Mentor: ${edu.name} (${edu.subject})`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl shadow-2xs transition cursor-pointer"
                  title={`Connect regarding ${edu.name} on WhatsApp`}
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                </a>
              </div>
            </div>
          );
        })}
      </div>

      {filteredEducators.length === 0 && (
        <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-8 max-w-md mx-auto">
          <GraduationCap className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h4 className="text-base font-bold text-slate-800">No Educators Found</h4>
          <p className="text-xs text-slate-500 mt-1">Try adjusting your search query or subject filter.</p>
          <button
            onClick={() => { setSelectedSubject('All'); setSearchQuery(''); }}
            className="mt-4 px-4 py-2 bg-indigo-600 text-white text-xs font-bold rounded-xl cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      )}

      {/* Detailed Educator Modal */}
      {selectedEducator && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-6 bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 text-white flex items-start justify-between">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-indigo-600/80 border-2 border-indigo-400 flex items-center justify-center text-white font-black text-xl overflow-hidden shadow-md">
                  {(() => {
                    const modalPhoto = normalizeImageUrl(selectedEducator.photoUrl);
                    return modalPhoto ? (
                      <img 
                        src={modalPhoto} 
                        alt={selectedEducator.name} 
                        className="w-full h-full object-cover" 
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLImageElement).onerror = null;
                          (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(selectedEducator.name)}&background=4f46e5&color=fff&bold=true`;
                        }}
                      />
                    ) : (
                      selectedEducator.name.split(' ').slice(0, 2).map(n => n[0]).join('')
                    );
                  })()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Verified Faculty
                    </span>
                    <span className="text-xs text-indigo-300">
                      {selectedEducator.experienceYears}+ Years Experience
                    </span>
                  </div>
                  <h3 className="text-xl font-black text-white mt-0.5">
                    {selectedEducator.name}
                  </h3>
                  <p className="text-xs text-indigo-200">
                    {selectedEducator.subject} Specialization
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedEducator(null)}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white cursor-pointer transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5 text-slate-700 text-sm">
              {/* Contact Information */}
              {selectedEducator.phone && (
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                    Contact Educator Directly
                  </h4>
                  <div className="p-3.5 bg-emerald-50/60 rounded-2xl border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                        <Phone className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-[11px] text-emerald-800 font-medium">Faculty Direct Mobile No</div>
                        <div className="text-sm font-extrabold text-slate-900 font-mono tracking-wide">
                          {selectedEducator.phone}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <a
                        href={`tel:${selectedEducator.phone}`}
                        className="px-3 py-1.5 bg-white hover:bg-slate-50 text-indigo-700 rounded-xl text-xs font-bold border border-indigo-200 shadow-2xs transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>Call Now</span>
                      </a>
                      <a
                        href={getWhatsAppUrl(
                          selectedEducator.phone,
                          `Hello ${selectedEducator.name} Sir/Ma'am, I would like to inquire regarding classes at ${centerInfo.name}.`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-2xs transition flex items-center gap-1.5 cursor-pointer"
                      >
                        <MessageCircle className="w-3.5 h-3.5 fill-current" />
                        <span>WhatsApp</span>
                      </a>
                    </div>
                  </div>
                </div>
              )}

              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Academic Qualifications & Background
                </h4>
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 font-medium text-slate-900">
                  {selectedEducator.qualification}
                </div>
              </div>

              {/* Batches Handled */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Assigned Batches & Class Schedule
                </h4>
                {getEducatorBatches(selectedEducator.id, selectedEducator).length > 0 ? (
                  <div className="space-y-2">
                    {getEducatorBatches(selectedEducator.id, selectedEducator).map(b => (
                      <div key={b.id} className="p-3 rounded-2xl bg-indigo-50/50 border border-indigo-100 flex items-center justify-between">
                        <div>
                          <div className="font-bold text-slate-900 text-xs">{b.name}</div>
                          <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3 text-indigo-500" />
                              {b.timing}
                            </span>
                            <span>&bull;</span>
                            <span>{b.scheduleDays.join(', ')}</span>
                          </div>
                        </div>
                        <span className="text-[11px] font-bold text-indigo-700 bg-white px-2.5 py-1 rounded-lg border border-indigo-200">
                          {b.roomNumber || 'Smart Room'}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-xs text-slate-500 italic">
                    Faculty mentors open classroom batches and practical lab doubt hours.
                  </div>
                )}
              </div>

              {/* Pedagogical Strengths */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  Teaching Strengths & Methodology
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>Focus on step-by-step fundamentals and exam-oriented problem solving.</span>
                  </div>
                  <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>Daily doubt resolution and chapter-wise formula drill sheets.</span>
                  </div>
                  <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>Practical coding demos & interactive code playzone guidance.</span>
                  </div>
                  <div className="flex items-start gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>Regular monthly assessment tracking and parent performance updates.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Modal Footer CTA */}
            <div className="p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-slate-500">
                Want to learn in batches taught by <strong className="text-slate-800">{selectedEducator.name}</strong>?
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <a
                  href={getWhatsAppUrl(
                    centerInfo.whatsapp || centerInfo.phonePrimary,
                    `Hello Pixel Pathsala! I would like to inquire about admission into batches taught by ${selectedEducator.name} (${selectedEducator.subject}).`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 sm:flex-none px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>WhatsApp Inquiry</span>
                </a>

                <button
                  onClick={() => {
                    setSelectedEducator(null);
                    setActiveTab('admission');
                  }}
                  className="flex-1 sm:flex-none px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
                >
                  <span>Apply for Admission</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
