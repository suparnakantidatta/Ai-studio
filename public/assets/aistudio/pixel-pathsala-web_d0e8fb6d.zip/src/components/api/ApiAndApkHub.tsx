import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Smartphone,
  Terminal,
  Code2,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  ShieldCheck,
  Send,
  Layers,
  Database,
  Globe,
  Radio,
  BookOpen,
  Users,
  Clock,
  Key,
  Play,
  FileCode,
  Sparkles,
  ArrowRight,
  Package,
  Cpu
} from 'lucide-react';

interface EndpointDefinition {
  id: string;
  name: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  path: string;
  category: 'Auth' | 'Student' | 'Public' | 'Admin';
  description: string;
  requiresAuth: boolean;
  defaultBody?: any;
  defaultParams?: Record<string, string>;
}

export const ApiAndApkHub: React.FC = () => {
  const { centerInfo, students, courses, batches, payments, admissions } = useApp();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'Auth' | 'Student' | 'Public' | 'Admin'>('All');
  const [selectedEndpointId, setSelectedEndpointId] = useState<string>('auth-student-login');
  const [requestBodyText, setRequestBodyText] = useState<string>('');
  const [requestHeadersText, setRequestHeadersText] = useState<string>('{\n  "Content-Type": "application/json"\n}');
  const [codeLang, setCodeLang] = useState<'flutter' | 'kotlin' | 'react-native' | 'curl'>('flutter');
  const [apkGuideTab, setApkGuideTab] = useState<'pwa-twa' | 'capacitor' | 'native-api'>('pwa-twa');

  // Response state
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseData, setResponseData] = useState<any>(null);
  const [responseHeaders, setResponseHeaders] = useState<any>(null);
  const [executionTimeMs, setExecutionTimeMs] = useState<number | null>(null);

  const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:3000';

  const ENDPOINTS: EndpointDefinition[] = [
    {
      id: 'system-meta',
      name: 'System Metadata & Health',
      method: 'GET',
      path: '/api/v1/meta',
      category: 'Public',
      description: 'Returns API server status, available tables, database record counts, and center details.',
      requiresAuth: false
    },
    {
      id: 'center-info',
      name: 'Center Profile & Address',
      method: 'GET',
      path: '/api/v1/center',
      category: 'Public',
      description: 'Returns official institute contact details, Raina campus address, WhatsApp number, and UPI details.',
      requiresAuth: false
    },
    {
      id: 'auth-student-login',
      name: 'Student Mobile Login',
      method: 'POST',
      path: '/api/v1/auth/student-login',
      category: 'Auth',
      description: 'Authenticates student via registered 10-digit mobile number and last 4 digits of Aadhaar or Roll Number. Returns bearer token and profile.',
      requiresAuth: false,
      defaultBody: {
        mobile: '9647750688',
        aadhaarNo: '9454'
      }
    },
    {
      id: 'auth-admin-login',
      name: 'Admin Mobile Login',
      method: 'POST',
      path: '/api/v1/auth/admin-login',
      category: 'Auth',
      description: 'Authenticates director or administrator using username/email and password. Returns admin token.',
      requiresAuth: false,
      defaultBody: {
        username: 'admin',
        password: 'admin123'
      }
    },
    {
      id: 'auth-verify',
      name: 'Verify Token Session',
      method: 'GET',
      path: '/api/v1/auth/verify',
      category: 'Auth',
      description: 'Validates Bearer token in Authorization header and returns current user account details.',
      requiresAuth: true
    },
    {
      id: 'student-profile',
      name: 'Student Profile',
      method: 'GET',
      path: `/api/v1/student/profile?studentId=${students[0]?.id || 'stu-1788672835416'}`,
      category: 'Student',
      description: 'Returns student personal profile, enrolled course, assigned batch, and contact details.',
      requiresAuth: false
    },
    {
      id: 'student-fees',
      name: 'Student Fee Ledger & Dues',
      method: 'GET',
      path: `/api/v1/student/fees?studentId=${students[0]?.id || 'stu-1788672835416'}`,
      category: 'Student',
      description: 'Returns full fee payment history, total amount paid, remaining balance, and center UPI details.',
      requiresAuth: false
    },
    {
      id: 'student-pay-fee',
      name: 'Submit Fee Payment (Student)',
      method: 'POST',
      path: '/api/v1/student/pay-fee',
      category: 'Student',
      description: 'Allows student or guardian to submit UPI transaction reference or cash fee payment for admin verification.',
      requiresAuth: false,
      defaultBody: {
        studentId: students[0]?.id || 'stu-1788672835416',
        studentName: students[0]?.name || 'Abhinaba Som',
        rollNo: students[0]?.rollNo || 'PP-2026-255',
        amount: 400,
        month: 'October 2026',
        paymentMode: 'UPI',
        transactionRef: 'UPI-APP-' + Math.floor(100000 + Math.random() * 900000),
        notes: 'Submitted via Android APK Mobile App'
      }
    },
    {
      id: 'student-materials',
      name: 'Study Materials & PDFs',
      method: 'GET',
      path: '/api/v1/student/materials?batchId=all',
      category: 'Student',
      description: 'Returns downloadable study notes, reference manuals, formula sheets, and programming assignment files.',
      requiresAuth: false
    },
    {
      id: 'student-exams',
      name: 'Exams & Scorecards',
      method: 'GET',
      path: '/api/v1/student/exams?studentId=stu-101',
      category: 'Student',
      description: 'Returns scheduled tests, mock exams, and previous scorecard submissions.',
      requiresAuth: false
    },
    {
      id: 'courses-list',
      name: 'List Courses Catalog',
      method: 'GET',
      path: '/api/v1/courses',
      category: 'Public',
      description: 'Returns public list of courses, monthly fees, categories, and syllabus overviews.',
      requiresAuth: false
    },
    {
      id: 'batches-list',
      name: 'List Batches & Timings',
      method: 'GET',
      path: '/api/v1/batches',
      category: 'Public',
      description: 'Returns active batches, days of week, timings, educator names, and seat statuses.',
      requiresAuth: false
    },
    {
      id: 'admissions-apply',
      name: 'Submit Admission (Online Form)',
      method: 'POST',
      path: '/api/v1/admissions/apply',
      category: 'Public',
      description: 'Allows prospective students to apply directly through the APK app. Saves into master admissions database.',
      requiresAuth: false,
      defaultBody: {
        name: 'Arindam Banerjee',
        gender: 'Male',
        academicClass: 'Class 10 (Secondary)',
        school: 'Raina High School',
        mobile: '9832014567',
        guardianName: 'Dilip Banerjee',
        guardianPhone: '9832014567',
        email: 'arindam.banerjee@gmail.com',
        address: 'Raina Bus Stand Road, Purba Bardhaman',
        courseId: 'course-1',
        preferredBatch: 'batch-1',
        notes: 'Online admission from Android APK application'
      }
    },
    {
      id: 'admissions-status',
      name: 'Check Admission Status',
      method: 'GET',
      path: '/api/v1/admissions/status?mobile=9832014567',
      category: 'Public',
      description: 'Checks application review status (Pending / Approved) and assigned roll number.',
      requiresAuth: false
    },
    {
      id: 'admin-dashboard',
      name: 'Admin Dashboard Stats',
      method: 'GET',
      path: '/api/v1/admin/dashboard',
      category: 'Admin',
      description: 'Returns summary metrics: total active students, monthly fee collections, pending admissions, and active batches.',
      requiresAuth: false
    },
    {
      id: 'admin-students',
      name: 'Admin Student Records',
      method: 'GET',
      path: '/api/v1/admin/students',
      category: 'Admin',
      description: 'Lists all student profiles with filtering, batch assignment, and payment balances.',
      requiresAuth: false
    },
    {
      id: 'admin-admissions',
      name: 'Admin Admission Applications',
      method: 'GET',
      path: '/api/v1/admin/admissions?status=pending',
      category: 'Admin',
      description: 'Lists pending admission forms for director approval.',
      requiresAuth: false
    },
    {
      id: 'admin-payments',
      name: 'Admin Fee Payments Ledger',
      method: 'GET',
      path: '/api/v1/admin/payments',
      category: 'Admin',
      description: 'Lists all payment transactions and receipts with approval statuses.',
      requiresAuth: false
    }
  ];

  const currentEndpoint = ENDPOINTS.find(e => e.id === selectedEndpointId) || ENDPOINTS[0];

  // Update default body when endpoint changes
  React.useEffect(() => {
    if (currentEndpoint.defaultBody) {
      setRequestBodyText(JSON.stringify(currentEndpoint.defaultBody, null, 2));
    } else {
      setRequestBodyText('');
    }
  }, [selectedEndpointId]);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleExecuteRequest = async () => {
    setIsLoading(true);
    setResponseStatus(null);
    setResponseData(null);
    setResponseHeaders(null);
    const startTime = performance.now();

    try {
      let url = `${baseUrl}${currentEndpoint.path}`;
      const options: RequestInit = {
        method: currentEndpoint.method,
        headers: {
          'Accept': 'application/json'
        }
      };

      if (requestHeadersText) {
        try {
          const parsedHeaders = JSON.parse(requestHeadersText);
          options.headers = { ...options.headers, ...parsedHeaders };
        } catch {}
      }

      if (currentEndpoint.method !== 'GET' && requestBodyText) {
        options.body = requestBodyText;
      }

      const res = await fetch(url, options);
      const endTime = performance.now();
      setExecutionTimeMs(Math.round(endTime - startTime));
      setResponseStatus(res.status);

      const hdrs: Record<string, string> = {};
      res.headers.forEach((val, key) => {
        hdrs[key] = val;
      });
      setResponseHeaders(hdrs);

      try {
        const json = await res.json();
        setResponseData(json);
      } catch {
        const text = await res.text();
        setResponseData(text);
      }
    } catch (err: any) {
      const endTime = performance.now();
      setExecutionTimeMs(Math.round(endTime - startTime));
      setResponseStatus(500);
      setResponseData({ error: err.message });
    } finally {
      setIsLoading(false);
    }
  };

  // Generate code snippet according to selected endpoint and language
  const getCodeSnippet = () => {
    const fullUrl = `${baseUrl}${currentEndpoint.path}`;
    const method = currentEndpoint.method;

    if (codeLang === 'curl') {
      if (method === 'GET') {
        return `curl -X GET "${fullUrl}" \\
  -H "Accept: application/json"`;
      }
      return `curl -X ${method} "${fullUrl}" \\
  -H "Content-Type: application/json" \\
  -H "Accept: application/json" \\
  -d '${requestBodyText || "{}"}'`;
    }

    if (codeLang === 'flutter') {
      if (method === 'GET') {
        return `// Flutter (Dart) using 'http' package
import 'dart:convert';
import 'package:http/http.dart' as http;

Future<void> fetch${currentEndpoint.name.replace(/\s+/g, '')}() async {
  final url = Uri.parse('$fullUrl');
  final response = await http.get(
    url,
    headers: {
      'Accept': 'application/json',
      // 'Authorization': 'Bearer YOUR_TOKEN_HERE',
    },
  );

  if (response.statusCode == 200) {
    final Map<String, dynamic> data = jsonDecode(response.body);
    print('Response Data: $data');
  } else {
    print('Failed with status: \${response.statusCode}');
  }
}`;
      }
      return `// Flutter (Dart) using 'http' package
import 'dart:convert';
import 'package:http/http.dart' as http;

Future<void> ${currentEndpoint.name.replace(/\s+/g, '')}() async {
  final url = Uri.parse('$fullUrl');
  final response = await http.${method.toLowerCase()}(
    url,
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      // 'Authorization': 'Bearer YOUR_TOKEN_HERE',
    },
    body: jsonEncode(${requestBodyText || "{}"}),
  );

  if (response.statusCode == 200 || response.statusCode == 201) {
    final Map<String, dynamic> data = jsonDecode(response.body);
    print('Success: $data');
  } else {
    print('Error \${response.statusCode}: \${response.body}');
  }
}`;
    }

    if (codeLang === 'kotlin') {
      return `// Android Kotlin (Retrofit 2 / OkHttp)
import retrofit2.http.*
import retrofit2.Response

data class ApiResponse(
    val success: Boolean,
    val message: String? = null
)

interface PixelPathsalaApi {
    @${method}("${currentEndpoint.path}")
    suspend fun executeEndpoint(
        @Header("Authorization") token: String? = null,
        ${method !== 'GET' ? '@Body body: Map<String, Any>' : ''}
    ): Response<Map<String, Any>>
}

// Client initialization
val retrofit = Retrofit.Builder()
    .baseUrl("${baseUrl}/")
    .addConverterFactory(GsonConverterFactory.create())
    .build()

val api = retrofit.create(PixelPathsalaApi::class.java)`;
    }

    if (codeLang === 'react-native') {
      return `// React Native / TypeScript (Axios)
import axios from 'axios';

const API_BASE_URL = '${baseUrl}';

export const callEndpoint = async () => {
  try {
    const response = await axios({
      method: '${method.toLowerCase()}',
      url: \`\${API_BASE_URL}${currentEndpoint.path}\`,
      headers: {
        'Content-Type': 'application/json',
        // 'Authorization': \`Bearer \${userToken}\`,
      },
      ${method !== 'GET' ? `data: ${requestBodyText || '{}'},` : ''}
    });

    console.log('Server Result:', response.data);
    return response.data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
};`;
    }

    return '';
  };

  const filteredEndpoints = ENDPOINTS.filter(e => selectedCategory === 'All' || e.category === selectedCategory);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-indigo-500/20 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-80 h-80 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full text-xs font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5 shadow-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                REST API v1.0 • LIVE & ACTIVE
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Android APK & Mobile Backend
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                CORS Enabled
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
              Mobile APK & REST API Integration Portal
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              Connect your native Android APK, Flutter, React Native, or WebView application directly to the <strong>Pixel Pathsala Master Database</strong>. All endpoints share live data with the web ERP and Google Sheets in real-time.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-slate-300">
              <span className="flex items-center gap-1.5">
                <Database className="w-4 h-4 text-emerald-400" />
                <span>Single Shared Database</span>
              </span>
              <span className="flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-indigo-400" />
                <span>Raina, Purba Bardhaman Campus</span>
              </span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-sky-400" />
                <span>Bearer & API Key Auth</span>
              </span>
            </div>
          </div>

          {/* Quick Action Downloads */}
          <div className="flex flex-col sm:flex-row lg:flex-col gap-2.5 w-full lg:w-auto shrink-0">
            <a
              href="/api/v1/postman-collection.json"
              download="Pixel_Pathsala_API_v1.postman_collection.json"
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs shadow-lg transition-all transform hover:scale-[1.02]"
            >
              <Download className="w-4 h-4" />
              <span>Download Postman Collection</span>
            </a>

            <a
              href="/api/v1/openapi.json"
              download="Pixel_Pathsala_OpenAPI.json"
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition-all transform hover:scale-[1.02]"
            >
              <FileCode className="w-4 h-4" />
              <span>Download OpenAPI 3.0 Spec</span>
            </a>

            <a
              href="/manifest.json"
              download="manifest.json"
              className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition"
            >
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>Download Web App Manifest</span>
            </a>
          </div>
        </div>

        {/* Live Base URL Bar */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="font-mono uppercase font-bold text-indigo-300">Base URL:</span>
            <code className="px-3 py-1.5 rounded-lg bg-slate-950/80 text-emerald-400 font-mono text-xs border border-slate-800 select-all">
              {baseUrl}/api/v1
            </code>
          </div>

          <button
            onClick={() => copyToClipboard(`${baseUrl}/api/v1`, 'base-url')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold cursor-pointer border border-slate-700 transition"
          >
            {copiedKey === 'base-url' ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-bold">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-slate-300" />
                <span>Copy Base URL</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Database Snapshot Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Students</span>
            <Users className="w-4 h-4 text-indigo-500" />
          </div>
          <p className="text-xl font-black text-slate-900">{students.length}</p>
          <span className="text-[10px] text-slate-500">Live in same DB</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Courses</span>
            <BookOpen className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-xl font-black text-slate-900">{courses.length}</p>
          <span className="text-[10px] text-slate-500">Curriculums</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Batches</span>
            <Layers className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-xl font-black text-slate-900">{batches.length}</p>
          <span className="text-[10px] text-slate-500">Scheduled classes</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Receipts</span>
            <Package className="w-4 h-4 text-sky-500" />
          </div>
          <p className="text-xl font-black text-slate-900">{payments.length}</p>
          <span className="text-[10px] text-slate-500">Fee records</span>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs col-span-2 sm:col-span-1">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Admissions</span>
            <FileCode className="w-4 h-4 text-purple-500" />
          </div>
          <p className="text-xl font-black text-slate-900">{admissions.length}</p>
          <span className="text-[10px] text-slate-500">Applications</span>
        </div>
      </div>

      {/* APK Generation Guide Tabs */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">
                How to Build the Android APK App (3 Recommended Options)
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Choose the APK build method that best fits your development timeline and tech stack.
            </p>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setApkGuideTab('pwa-twa')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                apkGuideTab === 'pwa-twa' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Option 1: PWA to APK (Fastest)
            </button>
            <button
              onClick={() => setApkGuideTab('capacitor')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                apkGuideTab === 'capacitor' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Option 2: Capacitor Native
            </button>
            <button
              onClick={() => setApkGuideTab('native-api')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                apkGuideTab === 'native-api' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Option 3: Flutter / React Native
            </button>
          </div>
        </div>

        {/* Tab 1: PWA / TWA to APK */}
        {apkGuideTab === 'pwa-twa' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div className="text-xs text-indigo-900 leading-relaxed">
                <strong>Zero-Code APK in 3 Minutes:</strong> The website is already equipped with an official <strong>PWA Web App Manifest</strong> (`/manifest.json`), high-resolution app icons, theme colors, and standalone mobile display mode. You can generate a signed production APK or Google Play AAB instantly using <strong>PWABuilder</strong> or Google's <strong>Bubblewrap CLI</strong>!
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-black flex items-center justify-center text-xs">1</span>
                <h4 className="font-bold text-slate-900">Open PWABuilder</h4>
                <p className="text-slate-600">
                  Visit <a href="https://www.pwabuilder.com" target="_blank" rel="noreferrer" className="text-indigo-600 font-bold hover:underline">pwabuilder.com</a> and enter your website URL:
                </p>
                <div className="p-2 rounded-lg bg-slate-200/60 font-mono text-[11px] text-slate-800 break-all select-all">
                  {baseUrl}
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-black flex items-center justify-center text-xs">2</span>
                <h4 className="font-bold text-slate-900">Click &ldquo;Package for Android&rdquo;</h4>
                <p className="text-slate-600">
                  PWABuilder will automatically read the <code className="font-mono text-indigo-600">manifest.json</code> from your site, validate app icons, and configure package name <code className="font-mono">com.pixelpathsala.app</code>.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white font-black flex items-center justify-center text-xs">3</span>
                <h4 className="font-bold text-slate-900">Download Ready .APK</h4>
                <p className="text-slate-600">
                  Download the signed APK directly to your Android device or share the APK link with students, teachers, and guardians for direct one-tap install.
                </p>
              </div>
            </div>

            {/* Bubblewrap CLI command block */}
            <div className="mt-4 p-4 rounded-2xl bg-slate-900 text-slate-200 font-mono text-xs space-y-2">
              <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
                <span className="flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Alternative CLI Build with Bubblewrap (Google TWA)</span>
                </span>
                <button
                  onClick={() => copyToClipboard(`npx @bubblewrap/cli init --manifest=${baseUrl}/manifest.json\nnpx @bubblewrap/cli build`, 'bubblewrap-cmd')}
                  className="hover:text-white cursor-pointer"
                >
                  {copiedKey === 'bubblewrap-cmd' ? 'Copied!' : 'Copy Commands'}
                </button>
              </div>
              <pre className="text-emerald-400 overflow-x-auto py-1">
{`# 1. Initialize Android project from live manifest
npx @bubblewrap/cli init --manifest=${baseUrl}/manifest.json

# 2. Build signed Android release APK
npx @bubblewrap/cli build`}
              </pre>
            </div>
          </div>
        )}

        {/* Tab 2: Capacitor Native */}
        {apkGuideTab === 'capacitor' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100 flex items-start gap-3">
              <Cpu className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div className="text-xs text-emerald-900 leading-relaxed">
                <strong>Native Android Studio Project:</strong> Capacitor wraps the React frontend into an official Android Studio project where you can compile debug and release `.apk` files, add native plugins (Camera, Push Notifications, Local Storage, Biometric Auth), and build without any external cloud service.
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 text-slate-200 font-mono text-xs space-y-3">
              <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
                <span className="flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Capacitor Android Build Steps</span>
                </span>
                <button
                  onClick={() => copyToClipboard(`npm install @capacitor/core @capacitor/cli @capacitor/android\nnpx cap init "Pixel Pathsala" "com.pixelpathsala.app" --web-dir dist\nnpx cap add android\nnpx cap open android`, 'cap-cmd')}
                  className="hover:text-white cursor-pointer"
                >
                  {copiedKey === 'cap-cmd' ? 'Copied!' : 'Copy Commands'}
                </button>
              </div>
              <pre className="text-emerald-400 overflow-x-auto py-1">
{`# 1. Install Capacitor dependencies
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Initialize Capacitor Configuration
npx cap init "Pixel Pathsala" "com.pixelpathsala.app" --web-dir dist

# 3. Add Android platform
npx cap add android

# 4. Open in Android Studio & Generate Signed APK
npx cap open android`}
              </pre>
            </div>
          </div>
        )}

        {/* Tab 3: Native API via Flutter / React Native */}
        {apkGuideTab === 'native-api' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-sky-50 border border-sky-100 flex items-start gap-3">
              <Code2 className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
              <div className="text-xs text-sky-900 leading-relaxed">
                <strong>Pure Native Mobile App (Flutter / React Native):</strong> Build your own separate mobile application UI with Flutter or React Native and consume the <code className="font-mono bg-sky-100 px-1 py-0.5 rounded text-sky-900">{baseUrl}/api/v1</code> REST APIs below. All authentication, students, admissions, and payments sync directly with the web application and Google Sheets database!
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
                <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Mobile Authentication Flow</span>
                </h4>
                <p className="text-slate-600">
                  Call <code className="font-mono text-indigo-600">POST /api/v1/auth/student-login</code> with mobile & Aadhaar. The server returns a 60-day Bearer token (<code className="font-mono text-slate-700">stk_...</code>).
                </p>
                <p className="text-slate-600">
                  Store this token in Flutter Secure Storage or React Native Keychain and pass as:
                  <br />
                  <code className="font-mono bg-slate-200/60 p-1 rounded block mt-1 text-[11px]">
                    Authorization: Bearer &lt;token&gt;
                  </code>
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2">
                <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
                  <Database className="w-4 h-4 text-indigo-600" />
                  <span>Same Shared Database Guarantee</span>
                </h4>
                <p className="text-slate-600">
                  Any admission submitted via the mobile APK immediately appears in the Admin Web portal.
                </p>
                <p className="text-slate-600">
                  Any fee payment approved by the administrator on the web portal immediately reflects as &ldquo;Paid&rdquo; on the student&apos;s mobile APK app.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Interactive REST API Explorer */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">
                Interactive API Explorer & Live Tester
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Select any endpoint to inspect headers, test request payloads, and view live JSON responses directly from the active database.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
            {(['All', 'Auth', 'Student', 'Public', 'Admin'] as const).map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                  selectedCategory === cat ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Endpoint Selector Bar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Endpoint Navigation List */}
          <div className="lg:col-span-4 space-y-1.5 max-h-[580px] overflow-y-auto pr-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block px-1 mb-2">
              Available Endpoints ({filteredEndpoints.length})
            </span>
            {filteredEndpoints.map(ep => {
              const isSelected = ep.id === selectedEndpointId;
              const methodBg = ep.method === 'GET' ? 'bg-emerald-500/10 text-emerald-700 border-emerald-500/30' : 'bg-indigo-500/10 text-indigo-700 border-indigo-500/30';

              return (
                <div
                  key={ep.id}
                  onClick={() => setSelectedEndpointId(ep.id)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer space-y-1 ${
                    isSelected
                      ? 'bg-indigo-50/70 border-indigo-500/80 shadow-xs'
                      : 'bg-white border-slate-200/80 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-black border font-mono ${methodBg}`}>
                      {ep.method}
                    </span>
                    <span className="text-[10px] font-semibold text-slate-500 px-1.5 py-0.5 rounded bg-slate-100">
                      {ep.category}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 leading-tight">
                    {ep.name}
                  </h4>
                  <p className="text-[11px] font-mono text-slate-500 truncate">
                    {ep.path}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Right Column: Active Endpoint Request & Response Console */}
          <div className="lg:col-span-8 space-y-4">
            {/* Active Endpoint Info Bar */}
            <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-2 border border-slate-800">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 rounded-md text-xs font-black font-mono ${
                    currentEndpoint.method === 'GET' ? 'bg-emerald-500 text-slate-950' : 'bg-indigo-500 text-white'
                  }`}>
                    {currentEndpoint.method}
                  </span>
                  <code className="text-xs font-mono text-emerald-400 break-all">
                    {currentEndpoint.path}
                  </code>
                </div>

                <button
                  onClick={handleExecuteRequest}
                  disabled={isLoading}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition-all cursor-pointer disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Sending...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Send Request</span>
                    </>
                  )}
                </button>
              </div>

              <p className="text-xs text-slate-300">
                {currentEndpoint.description}
              </p>
            </div>

            {/* Request Body & Headers (if POST/PUT) */}
            {currentEndpoint.method !== 'GET' && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                  <span>JSON Request Body:</span>
                  <span className="text-[11px] text-slate-400 font-normal">Editable</span>
                </div>
                <textarea
                  value={requestBodyText}
                  onChange={e => setRequestBodyText(e.target.value)}
                  rows={6}
                  className="w-full p-3 rounded-xl bg-slate-950 text-emerald-400 font-mono text-xs border border-slate-800 focus:outline-indigo-500 resize-y"
                  placeholder="Enter JSON body"
                />
              </div>
            )}

            {/* Response Console */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                <div className="flex items-center gap-2">
                  <span>Response Output:</span>
                  {responseStatus !== null && (
                    <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      responseStatus >= 200 && responseStatus < 300
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-red-100 text-red-800 border border-red-300'
                    }`}>
                      HTTP {responseStatus}
                    </span>
                  )}
                  {executionTimeMs !== null && (
                    <span className="text-[10px] text-slate-400 font-mono">
                      {executionTimeMs} ms
                    </span>
                  )}
                </div>

                {responseData && (
                  <button
                    onClick={() => copyToClipboard(JSON.stringify(responseData, null, 2), 'response-json')}
                    className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer"
                  >
                    {copiedKey === 'response-json' ? 'Copied Response!' : 'Copy JSON'}
                  </button>
                )}
              </div>

              <div className="p-4 rounded-2xl bg-slate-950 text-slate-100 font-mono text-xs border border-slate-800 min-h-[160px] max-h-[360px] overflow-auto">
                {isLoading ? (
                  <div className="flex items-center justify-center py-12 text-slate-500 gap-2">
                    <div className="w-4 h-4 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin"></div>
                    <span>Querying database cache & Google Sheets webhook...</span>
                  </div>
                ) : responseData ? (
                  <pre className="text-emerald-400 whitespace-pre-wrap break-all">
                    {typeof responseData === 'object' ? JSON.stringify(responseData, null, 2) : responseData}
                  </pre>
                ) : (
                  <div className="text-slate-500 italic py-10 text-center">
                    Click &ldquo;Send Request&rdquo; above to test this endpoint live against the database.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Multi-Language Mobile Code Generator */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <Code2 className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">
                Copy-Paste Mobile Client Code ({codeLang.toUpperCase()})
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Ready-to-use SDK code snippets for <strong className="text-slate-800">{currentEndpoint.name}</strong>.
            </p>
          </div>

          {/* Language Selector */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
            {(['flutter', 'kotlin', 'react-native', 'curl'] as const).map(lang => (
              <button
                key={lang}
                onClick={() => setCodeLang(lang)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  codeLang === lang ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {lang === 'flutter' ? 'Flutter (Dart)' : lang === 'kotlin' ? 'Android (Kotlin)' : lang === 'react-native' ? 'React Native' : 'cURL'}
              </button>
            ))}
          </div>
        </div>

        {/* Code Snippet Box */}
        <div className="relative rounded-2xl bg-slate-900 text-slate-200 font-mono text-xs border border-slate-800 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950 border-b border-slate-800 text-slate-400 text-[11px]">
            <span>Code snippet for {currentEndpoint.method} {currentEndpoint.path}</span>
            <button
              onClick={() => copyToClipboard(getCodeSnippet(), 'code-snippet')}
              className="flex items-center gap-1.5 hover:text-white cursor-pointer"
            >
              {copiedKey === 'code-snippet' ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-bold">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-slate-400" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>

          <pre className="p-4 text-emerald-300 overflow-x-auto leading-relaxed max-h-[340px]">
            {getCodeSnippet()}
          </pre>
        </div>
      </div>

      {/* Test Accounts & Credentials Card */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl space-y-5">
        <div className="flex items-center gap-2">
          <Key className="w-5 h-5 text-amber-400" />
          <h3 className="text-lg font-bold text-white">Default Test Credentials for Mobile APK</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Student Role
            </span>
            <div className="space-y-1 text-slate-300">
              <p>Registered Mobile: <strong className="text-white font-mono">9647750688</strong></p>
              <p>Aadhaar (Last 4): <strong className="text-white font-mono">9454</strong> (or full 3056 3793 9454)</p>
              <p>Roll No: <strong className="text-white font-mono">PP-2026-255</strong> (Abhinaba Som)</p>
            </div>
            <p className="text-[11px] text-slate-500">
              Pass to <code className="font-mono text-indigo-400">/api/v1/auth/student-login</code>
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Administrator Role
            </span>
            <div className="space-y-1 text-slate-300">
              <p>Username: <strong className="text-white font-mono">admin</strong></p>
              <p>Password: <strong className="text-white font-mono">admin123</strong></p>
              <p>Center Security PIN: <strong className="text-white font-mono">7722</strong></p>
            </div>
            <p className="text-[11px] text-slate-500">
              Pass to <code className="font-mono text-emerald-400">/api/v1/auth/admin-login</code>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
