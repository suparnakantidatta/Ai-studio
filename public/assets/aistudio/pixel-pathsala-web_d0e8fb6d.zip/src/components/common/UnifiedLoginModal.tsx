import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  User, 
  ShieldCheck, 
  X, 
  Lock, 
  Phone, 
  CreditCard, 
  LogIn, 
  CheckCircle2, 
  AlertCircle,
  KeyRound,
  Sparkles,
  ArrowRight,
  Smartphone,
  Download,
  LogOut
} from 'lucide-react';
import { getDirectApkDownloadUrl } from '../../utils/apkHelper';

export const UnifiedLoginModal: React.FC = () => {
  const { 
    isUnifiedLoginOpen, 
    closeUnifiedLoginModal, 
    unifiedLoginInitialRole,
    loginStudent,
    loginAdmin,
    setActiveTab,
    currentStudent,
    isAdminLoggedIn,
    logoutStudent,
    logoutAdmin,
    adminUser,
    students,
    centerInfo
  } = useApp();

  const [activeTab, setActiveTabLocal] = useState<'student' | 'admin'>('student');

  // Student form state
  const [studentMobile, setStudentMobile] = useState('');
  const [studentAadhaar, setStudentAadhaar] = useState('');
  const [studentError, setStudentError] = useState('');

  // Admin form state
  const [adminUsername, setAdminUsername] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminRemember, setAdminRemember] = useState(true);
  const [adminError, setAdminError] = useState('');

  useEffect(() => {
    if (isUnifiedLoginOpen) {
      setActiveTabLocal(unifiedLoginInitialRole);
      setStudentError('');
      setAdminError('');
    }
  }, [isUnifiedLoginOpen, unifiedLoginInitialRole]);

  if (!isUnifiedLoginOpen) return null;

  const handleStudentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStudentError('');
    const res = await loginStudent(studentMobile, studentAadhaar);
    if (res.success || res.isPendingAdmission) {
      closeUnifiedLoginModal();
      setActiveTab('student-portal');
    } else {
      setStudentError(res.message);
    }
  };

  const handleAdminSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError('');
    const res = await loginAdmin(adminUsername, adminPassword, adminRemember);
    if (res.success) {
      closeUnifiedLoginModal();
      setActiveTab('admin');
    } else {
      setAdminError(res.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white relative">
          <button
            onClick={closeUnifiedLoginModal}
            className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-2">
            <KeyRound className="w-4 h-4" />
            <span>Secure Access Gateway</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
            Portal Sign In
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Choose your portal role below to access your account.
          </p>

          {/* Unified Role Switcher Tabs */}
          <div className="grid grid-cols-2 gap-2 mt-5 p-1 bg-slate-800/90 rounded-2xl border border-slate-700/80">
            <button
              id="unified-tab-student"
              onClick={() => {
                setActiveTabLocal('student');
                setStudentError('');
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'student'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Student Portal</span>
            </button>

            <button
              id="unified-tab-admin"
              onClick={() => {
                setActiveTabLocal('admin');
                setAdminError('');
              }}
              className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Admin ERP</span>
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-7">
          {activeTab === 'student' ? (
            /* Student Login View */
            <div>
              {currentStudent ? (
                /* Already logged in as student */
                <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-5 text-center">
                  <div className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center mx-auto mb-3 font-black text-lg">
                    {currentStudent.name.charAt(0)}
                  </div>
                  <h3 className="font-bold text-slate-900 text-base">{currentStudent.name}</h3>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">Roll: {currentStudent.rollNo} • {currentStudent.mobile}</p>
                  
                  <div className="flex flex-col gap-2 mt-5">
                    <button
                      onClick={() => {
                        closeUnifiedLoginModal();
                        setActiveTab('student-portal');
                      }}
                      className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-2"
                    >
                      <span>Continue to Student Portal</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <a
                      id="modal-logged-student-download-apk"
                      href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
                      download="PixelPathsala.apk"
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                      title="Download Student Android App"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Student App (.APK)</span>
                    </a>
                    <button
                      type="button"
                      onClick={() => {
                        logoutStudent();
                        closeUnifiedLoginModal();
                      }}
                      className="w-full py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl border border-rose-200 transition cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <LogOut className="w-3.5 h-3.5 text-rose-600" />
                      <span>Sign Out from Student Portal</span>
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleStudentSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      Registered Mobile Number *
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="student-login-mobile"
                        type="tel"
                        required
                        value={studentMobile}
                        onChange={(e) => setStudentMobile(e.target.value)}
                        placeholder="e.g. 9832011223"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      Last 4 Digits of Aadhaar or Roll No *
                    </label>
                    <div className="relative">
                      <CreditCard className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="student-login-aadhaar"
                        type="text"
                        required
                        value={studentAadhaar}
                        onChange={(e) => setStudentAadhaar(e.target.value)}
                        placeholder="e.g. 1234 or PP-2026-001"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition-all"
                      />
                    </div>
                  </div>

                  {studentError && (
                    <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                      <span>{studentError}</span>
                    </div>
                  )}

                  <button
                    id="submit-student-login-btn"
                    type="submit"
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 mt-2"
                  >
                    <LogIn className="w-4 h-4" />
                    <span>Sign In to Student Portal</span>
                  </button>

                  <div className="pt-2 text-center">
                    <p className="text-[11px] text-slate-500">
                      Need help? Contact center helpline at{' '}
                      <span className="font-semibold text-slate-700">+91 9775708722</span>
                    </p>
                  </div>

                  {/* Direct APK Download in Student Login Modal */}
                  <div className="pt-3.5 mt-2 border-t border-slate-100">
                    <div className="p-3 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-200/80 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                          <Smartphone className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                            <span>Student Android App</span>
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-emerald-200 text-emerald-800 uppercase">
                              APK
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-500">Direct mobile download (no Drive viewer)</p>
                        </div>
                      </div>

                      <a
                        id="modal-student-download-apk"
                        href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
                        download="PixelPathsala.apk"
                        className="shrink-0 flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition shadow-xs cursor-pointer"
                        title="Download Android App APK"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </a>
                    </div>
                  </div>
                </form>
              )}
            </div>
          ) : (
            /* Admin Login View */
            <div>
              {isAdminLoggedIn && adminUser ? (
                /* Already logged in as Admin */
                <div className="bg-emerald-50 border border-emerald-100 rounded-2xl p-5 text-center">
                  <div className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center mx-auto mb-3 font-black text-lg">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-slate-900 text-base">{adminUser.name}</h3>
                  <p className="text-xs text-emerald-700 font-semibold mt-0.5">{adminUser.role}</p>
                  <p className="text-[11px] text-slate-500 mt-1 font-mono">Logged in as: {adminUser.username}</p>
                  
                  <div className="flex flex-col gap-2 mt-5">
                    <button
                      onClick={() => {
                        closeUnifiedLoginModal();
                        setActiveTab('admin');
                      }}
                      className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer flex items-center justify-center gap-2"
                    >
                      <span>Open Admin ERP Dashboard</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => logoutAdmin()}
                      className="w-full py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs rounded-xl transition cursor-pointer"
                    >
                      Sign Out Admin Session
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleAdminSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      Admin Username / Email *
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="admin-login-username"
                        type="text"
                        required
                        value={adminUsername}
                        onChange={(e) => setAdminUsername(e.target.value)}
                        placeholder="e.g. admin"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      Password *
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="admin-login-password"
                        type="password"
                        required
                        value={adminPassword}
                        onChange={(e) => setAdminPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500 transition-all"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs">
                    <label className="flex items-center gap-2 text-slate-600 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={adminRemember}
                        onChange={(e) => setAdminRemember(e.target.checked)}
                        className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <span>Stay signed in</span>
                    </label>
                  </div>

                  {adminError && (
                    <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                      <span>{adminError}</span>
                    </div>
                  )}

                  <button
                    id="submit-admin-login-btn"
                    type="submit"
                    className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 mt-2"
                  >
                    <ShieldCheck className="w-4 h-4 text-indigo-400" />
                    <span>Sign In to Admin ERP</span>
                  </button>

                  <div className="pt-2 text-center">
                    <p className="text-[11px] text-slate-500">
                      Authorized Center Administration only.
                    </p>
                  </div>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
