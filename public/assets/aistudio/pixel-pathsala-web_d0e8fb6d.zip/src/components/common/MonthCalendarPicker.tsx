import React, { useState, useRef, useEffect } from 'react';
import { 
  Calendar as CalendarIcon, 
  CalendarDays, 
  ChevronLeft, 
  ChevronRight, 
  Check, 
  Clock, 
  Sparkles,
  ChevronDown
} from 'lucide-react';
import { MONTH_NAMES, formatMonthKey } from '../../utils/feeCalculator';

interface MonthCalendarPickerProps {
  value: string; // Format: "YYYY-MM" (e.g. "2026-09")
  onChange: (monthKey: string) => void;
  label?: string;
  required?: boolean;
  helperText?: string;
  applicationMonth?: string; // Optional: e.g. month when student applied
  minYear?: number;
  maxYear?: number;
  id?: string;
}

export const MonthCalendarPicker: React.FC<MonthCalendarPickerProps> = ({
  value,
  onChange,
  label = 'Billing Month',
  required = false,
  helperText = 'Monthly fees will be billed starting from this month',
  applicationMonth,
  minYear = 2022,
  maxYear = 2035,
  id = 'month-calendar-picker'
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const nativeInputRef = useRef<HTMLInputElement>(null);

  // Parse current year & month from value or fallback to current date
  const now = new Date();
  const currentRealYear = now.getFullYear();
  const currentRealMonth = now.getMonth() + 1;
  const currentRealMonthKey = `${currentRealYear}-${String(currentRealMonth).padStart(2, '0')}`;

  const parseYearFromValue = (val: string): number => {
    if (val && val.includes('-')) {
      const y = parseInt(val.split('-')[0], 10);
      if (!isNaN(y) && y > 1900 && y < 2100) return y;
    }
    return currentRealYear;
  };

  const [viewYear, setViewYear] = useState<number>(() => parseYearFromValue(value));

  // Sync viewYear when value changes externally
  useEffect(() => {
    if (value && value.includes('-')) {
      const parsedY = parseInt(value.split('-')[0], 10);
      if (!isNaN(parsedY)) {
        setViewYear(parsedY);
      }
    }
  }, [value]);

  // Handle outside click & ESC key to close calendar popover
  useEffect(() => {
    if (!isOpen) return;

    const handleMouseDown = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleMouseDown);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleMouseDown);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen]);

  const handleSelectMonth = (monthIndex: number) => {
    const formattedMonth = String(monthIndex + 1).padStart(2, '0');
    const newMonthKey = `${viewYear}-${formattedMonth}`;
    onChange(newMonthKey);
    setIsOpen(false);
  };

  const handlePrevYear = () => {
    setViewYear(prev => Math.max(minYear, prev - 1));
  };

  const handleNextYear = () => {
    setViewYear(prev => Math.min(maxYear, prev + 1));
  };

  const handleNativePickerClick = () => {
    try {
      if (nativeInputRef.current) {
        if ('showPicker' in HTMLInputElement.prototype) {
          nativeInputRef.current.showPicker();
        } else {
          nativeInputRef.current.focus();
        }
      }
    } catch {
      setIsOpen(true);
    }
  };

  // Generate years list for dropdown
  const yearOptions: number[] = [];
  for (let y = minYear; y <= maxYear; y++) {
    yearOptions.push(y);
  }

  // Next month calculation
  const nextMonthDate = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const nextMonthKey = `${nextMonthDate.getFullYear()}-${String(nextMonthDate.getMonth() + 1).padStart(2, '0')}`;

  // Academic year start (April of current session)
  const academicStartKey = `${currentRealYear}-04`;

  return (
    <div className="relative" ref={containerRef} id={id}>
      {label && (
        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <CalendarDays className="w-3.5 h-3.5 text-indigo-600" />
            <span>{label}</span>
            {required && <span className="text-red-500">*</span>}
          </span>
          <span className="text-[10px] font-semibold text-indigo-600 font-mono">
            {value || 'YYYY-MM'}
          </span>
        </label>
      )}

      {/* Main Interactive Trigger Field */}
      <div className="relative flex items-center">
        <button
          type="button"
          onClick={() => setIsOpen(prev => !prev)}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl border text-left transition cursor-pointer bg-white ${
            isOpen 
              ? 'border-indigo-500 ring-2 ring-indigo-500/20 shadow-sm' 
              : 'border-slate-300 hover:border-slate-400 hover:bg-slate-50/50'
          }`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 shrink-0">
              <CalendarIcon className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="font-bold text-slate-900 text-xs sm:text-sm truncate">
                {value ? formatMonthKey(value) : 'Select Billing Month'}
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                Code: <span className="font-semibold text-indigo-700">{value || 'None'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0 ml-2">
            <span className="hidden sm:inline-block text-[10px] font-semibold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200">
              Calendar Picker
            </span>
            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180 text-indigo-600' : ''}`} />
          </div>
        </button>

        {/* Hidden Native Input (Allows direct OS/browser month picker if desired) */}
        <input
          ref={nativeInputRef}
          type="month"
          value={value}
          onChange={(e) => {
            if (e.target.value) {
              onChange(e.target.value);
            }
          }}
          className="sr-only"
          tabIndex={-1}
          aria-hidden="true"
        />
      </div>

      {helperText && (
        <span className="text-[10px] text-slate-400 mt-1 block">
          {helperText}
        </span>
      )}

      {/* Floating Calendar Month Picker Popover */}
      {isOpen && (
        <div className="absolute z-50 left-0 right-0 sm:left-auto sm:w-84 mt-2 bg-white rounded-2xl border border-slate-200 shadow-xl p-4 animate-in fade-in zoom-in-95 duration-150">
          {/* Header with Year Selector & Navigation */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <button
              type="button"
              onClick={handlePrevYear}
              disabled={viewYear <= minYear}
              className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer transition"
              title="Previous Year"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-1.5">
              <select
                value={viewYear}
                onChange={(e) => setViewYear(Number(e.target.value))}
                className="font-bold text-sm text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg px-2.5 py-1 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer font-mono"
              >
                {yearOptions.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
              {viewYear !== currentRealYear && (
                <button
                  type="button"
                  onClick={() => setViewYear(currentRealYear)}
                  className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-1.5 py-0.5 rounded cursor-pointer"
                  title="Jump to Current Year"
                >
                  This Year
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={handleNextYear}
              disabled={viewYear >= maxYear}
              className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600 disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer transition"
              title="Next Year"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* 12-Month Calendar Grid */}
          <div className="grid grid-cols-3 gap-2 py-3">
            {MONTH_NAMES.map((mName, idx) => {
              const monthCode = String(idx + 1).padStart(2, '0');
              const itemKey = `${viewYear}-${monthCode}`;
              const isSelected = value === itemKey;
              const isCurrentMonth = currentRealMonthKey === itemKey;
              const isApplicationMonth = applicationMonth === itemKey;

              return (
                <button
                  key={monthCode}
                  type="button"
                  onClick={() => handleSelectMonth(idx)}
                  className={`relative py-2.5 px-2 rounded-xl text-xs font-semibold flex flex-col items-center justify-center transition cursor-pointer border ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : isCurrentMonth
                      ? 'bg-indigo-50/70 text-indigo-900 border-indigo-200 hover:bg-indigo-100'
                      : isApplicationMonth
                      ? 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
                      : 'bg-slate-50/60 text-slate-700 border-slate-100 hover:bg-slate-100 hover:border-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-1">
                    <span className="font-bold">{mName.substring(0, 3)}</span>
                    {isSelected && <Check className="w-3 h-3 text-white" />}
                  </div>
                  <span className={`text-[9px] font-mono ${isSelected ? 'text-indigo-100' : 'text-slate-400'}`}>
                    {monthCode}/{viewYear}
                  </span>

                  {/* Indicators for Today / Application */}
                  {isCurrentMonth && !isSelected && (
                    <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-indigo-500" title="Current Real-world Month" />
                  )}
                  {isApplicationMonth && !isSelected && (
                    <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-amber-500" title="Month of Student Application" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Presets / Shortcuts */}
          <div className="pt-2.5 border-t border-slate-100 space-y-2">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Quick Shortcuts
            </div>
            <div className="flex flex-wrap gap-1.5 text-[11px]">
              <button
                type="button"
                onClick={() => {
                  onChange(currentRealMonthKey);
                  setViewYear(currentRealYear);
                  setIsOpen(false);
                }}
                className={`px-2 py-1 rounded-lg border font-medium cursor-pointer transition flex items-center gap-1 ${
                  value === currentRealMonthKey
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                <Clock className="w-3 h-3 text-indigo-500" />
                <span>Current Month ({formatMonthKey(currentRealMonthKey)})</span>
              </button>

              {nextMonthKey !== currentRealMonthKey && (
                <button
                  type="button"
                  onClick={() => {
                    onChange(nextMonthKey);
                    setViewYear(nextMonthDate.getFullYear());
                    setIsOpen(false);
                  }}
                  className={`px-2 py-1 rounded-lg border font-medium cursor-pointer transition ${
                    value === nextMonthKey
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  Next Month ({formatMonthKey(nextMonthKey)})
                </button>
              )}

              {applicationMonth && applicationMonth !== currentRealMonthKey && (
                <button
                  type="button"
                  onClick={() => {
                    onChange(applicationMonth);
                    const appYear = parseInt(applicationMonth.split('-')[0], 10);
                    if (!isNaN(appYear)) setViewYear(appYear);
                    setIsOpen(false);
                  }}
                  className={`px-2 py-1 rounded-lg border font-medium cursor-pointer transition flex items-center gap-1 ${
                    value === applicationMonth
                      ? 'bg-amber-600 text-white border-amber-600'
                      : 'bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100'
                  }`}
                >
                  <Sparkles className="w-3 h-3 text-amber-600" />
                  <span>Applied Month ({formatMonthKey(applicationMonth)})</span>
                </button>
              )}

              {academicStartKey !== currentRealMonthKey && (
                <button
                  type="button"
                  onClick={() => {
                    onChange(academicStartKey);
                    setViewYear(currentRealYear);
                    setIsOpen(false);
                  }}
                  className={`px-2 py-1 rounded-lg border font-medium cursor-pointer transition ${
                    value === academicStartKey
                      ? 'bg-indigo-600 text-white border-indigo-600'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  April {currentRealYear} (Session Start)
                </button>
              )}
            </div>

            {/* Native OS Picker Fallback Option */}
            <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500">
              <button
                type="button"
                onClick={handleNativePickerClick}
                className="text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer underline flex items-center gap-1"
              >
                <CalendarIcon className="w-3 h-3" />
                <span>Open Browser Native Calendar</span>
              </button>

              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-slate-400 hover:text-slate-600 font-medium cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
