import React, { useRef } from 'react';
import { FeePayment } from '../../types';
import { useApp } from '../../context/AppContext';
import { numberToIndianRupees } from '../../utils/numberToWords';
import { getUpiQrCodeUrl } from '../../utils/qrHelper';
import { Printer, X, CheckCircle, ShieldCheck, Download, Sparkles, ExternalLink, Copy } from 'lucide-react';

interface PrintReceiptModalProps {
  payment?: FeePayment | null;
  onClose?: () => void;
}

export const PrintReceiptModal: React.FC<PrintReceiptModalProps> = ({ 
  payment: propPayment, 
  onClose: propOnClose 
}) => {
  const { 
    centerInfo, 
    selectedReceiptForPrint, 
    setSelectedReceiptForPrint, 
    showToast 
  } = useApp();
  const receiptRef = useRef<HTMLDivElement>(null);

  // Use props if provided, otherwise fallback to global AppContext
  const activePayment = propPayment ?? selectedReceiptForPrint;
  const handleClose = propOnClose ?? (() => setSelectedReceiptForPrint(null));

  if (!activePayment) return null;

  const payment = activePayment;
  const amountInWords = numberToIndianRupees(payment.finalAmountPaid);
  const qrVerificationUrl = getUpiQrCodeUrl({
    upiId: centerInfo.upiId,
    payeeName: centerInfo.upiName,
    amount: payment.finalAmountPaid,
    transactionNote: `Receipt:${payment.receiptNo}`,
    size: 150
  });

  const handlePrint = () => {
    try {
      // 1. Direct browser print dialog
      window.print();
    } catch (e) {
      console.warn('Direct print error, attempting popout window print:', e);
      handleOpenPrintTab();
    }
  };

  const handleOpenPrintTab = () => {
    const printContent = receiptRef.current;
    if (!printContent) return;

    try {
      const printWindow = window.open('', '_blank', 'width=850,height=900');
      if (printWindow) {
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Fee Receipt ${payment.receiptNo} - ${centerInfo.name}</title>
              <meta charset="utf-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <link rel="preconnect" href="https://fonts.googleapis.com">
              <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
              <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fira+Code:wght@400;600&display=swap" rel="stylesheet">
              <script src="https://cdn.tailwindcss.com"></script>
              <style>
                body {
                  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
                  background: #f8fafc;
                  color: #0f172a;
                  margin: 0;
                  padding: 30px 20px;
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                @page {
                  size: A4 portrait;
                  margin: 10mm;
                }
                @media print {
                  body {
                    background: white !important;
                    padding: 0 !important;
                  }
                  .no-print {
                    display: none !important;
                  }
                  .receipt-card {
                    box-shadow: none !important;
                    border: none !important;
                    padding: 0 !important;
                  }
                }
              </style>
            </head>
            <body>
              <div class="max-w-3xl mx-auto mb-6 text-center no-print flex items-center justify-center gap-3">
                <button onclick="window.print()" style="background:#4f46e5;color:white;padding:10px 24px;border-radius:12px;font-weight:bold;cursor:pointer;border:none;box-shadow:0 4px 12px rgba(79,70,229,0.3);font-size:14px;">
                  🖨️ Click to Print / Save as PDF
                </button>
                <button onclick="window.close()" style="background:#e2e8f0;color:#334155;padding:10px 18px;border-radius:12px;font-weight:bold;cursor:pointer;border:none;font-size:14px;">
                  Close Window
                </button>
              </div>
              <div class="receipt-card max-w-3xl mx-auto bg-white p-8 sm:p-12 rounded-2xl shadow-xl border border-slate-200">
                ${printContent.innerHTML}
              </div>
              <script>
                // Auto prompt print after styling loads
                window.onload = function() {
                  setTimeout(function() {
                    window.focus();
                    window.print();
                  }, 400);
                };
              </script>
            </body>
          </html>
        `);
        printWindow.document.close();
      } else {
        window.print();
      }
    } catch {
      window.print();
    }
  };

  const handleDownloadReceiptHtml = () => {
    const printContent = receiptRef.current;
    if (!printContent) return;

    const fullHtml = `<!DOCTYPE html>
<html>
  <head>
    <title>Fee Receipt ${payment.receiptNo} - ${centerInfo.name}</title>
    <meta charset="utf-8" />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fira+Code:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
      body { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; background: #fff; padding: 20px; }
      @page { size: A4 portrait; margin: 10mm; }
    </style>
  </head>
  <body>
    <div style="max-w-3xl; margin: 0 auto;">
      ${printContent.innerHTML}
    </div>
  </body>
</html>`;

    const blob = new Blob([fullHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Receipt_${payment.receiptNo}_${payment.studentName.replace(/\s+/g, '_')}.html`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Receipt file downloaded! Open in any browser to print.', 'success');
  };

  const handleCopyReceiptSummary = () => {
    const summaryText = `*FEE RECEIPT - ${centerInfo.name}*
Receipt No: ${payment.receiptNo}
Date: ${payment.paymentDate}
Student: ${payment.studentName} (Aadhaar: ${payment.studentAadhaar || 'N/A'})
Course: ${payment.courseTitle}
Billing Month: ${payment.month}
Amount Paid: ₹${payment.finalAmountPaid.toLocaleString('en-IN')} (${amountInWords})
Payment Mode: ${payment.paymentMode} ${payment.transactionRef ? `(Ref: ${payment.transactionRef})` : ''}
Status: VERIFIED & APPROVED
Official Helpline: ${centerInfo.phonePrimary} | UPI: ${centerInfo.upiId}`;

    navigator.clipboard.writeText(summaryText);
    showToast('Receipt summary copied to clipboard!', 'info');
  };

  return (
    <div className="print-modal-container fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-xs p-4 overflow-y-auto">
      {/* Top Action Bar */}
      <div className="fixed top-4 right-4 z-50 flex flex-wrap items-center gap-2 sm:gap-3 no-print">
        <button
          id="btn-trigger-print"
          onClick={handlePrint}
          className="flex items-center gap-2 px-4 sm:px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-all transform hover:scale-105 cursor-pointer"
          title="Direct print to printer or save as PDF"
        >
          <Printer className="w-4 h-4" />
          <span>Print / PDF</span>
        </button>

        <button
          id="btn-open-tab-receipt"
          onClick={handleOpenPrintTab}
          className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer border border-slate-700"
          title="Open in dedicated tab for direct printing"
        >
          <ExternalLink className="w-3.5 h-3.5 text-indigo-400" />
          <span className="hidden sm:inline">Popout Print Tab</span>
        </button>

        <button
          onClick={handleDownloadReceiptHtml}
          className="hidden md:flex items-center gap-1.5 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer border border-slate-700"
          title="Download HTML receipt file"
        >
          <Download className="w-3.5 h-3.5 text-emerald-400" />
          <span>Save File</span>
        </button>

        <button
          onClick={handleCopyReceiptSummary}
          className="hidden lg:flex items-center gap-1.5 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer border border-slate-700"
          title="Copy text summary for WhatsApp or SMS"
        >
          <Copy className="w-3.5 h-3.5 text-amber-400" />
          <span>Copy Info</span>
        </button>

        <button
          id="btn-close-receipt-modal"
          onClick={handleClose}
          className="p-2.5 bg-white hover:bg-slate-100 text-slate-700 rounded-xl shadow-md transition-all cursor-pointer"
          title="Close Receipt Modal"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Printable Sheet */}
      <div 
        id="printable-receipt"
        ref={receiptRef}
        className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 text-slate-900 p-6 sm:p-12 my-auto relative overflow-hidden print:p-6 print:border-none print:shadow-none print:max-w-none print:rounded-none"
      >
        {/* Watermark for authenticity */}
        <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none">
          <span className="text-7xl sm:text-8xl font-black tracking-widest text-slate-900 rotate-[-30deg]">
            PIXEL PATHSALA
          </span>
        </div>

        {/* Receipt Header */}
        <div className="border-b-2 border-indigo-600 pb-5 mb-5">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 flex items-center justify-center text-white font-black text-xl sm:text-2xl shadow-md">
                PP
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-3xl font-extrabold tracking-tight text-slate-900 font-sans">
                    {centerInfo.name}
                  </h1>
                </div>
                <p className="text-xs sm:text-sm text-indigo-700 font-medium mt-0.5">
                  {centerInfo.tagline}
                </p>
                <p className="text-[11px] sm:text-xs text-slate-500 mt-1">
                  {centerInfo.address}, {centerInfo.cityState} • Helpline: {centerInfo.phonePrimary}
                </p>
              </div>
            </div>

            <div className="text-left sm:text-right sm:border-l sm:border-slate-200 sm:pl-6">
              <div className="inline-block px-3 py-1 bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold uppercase rounded-lg tracking-wider">
                FEE RECEIPT
              </div>
              <div className="text-xs text-slate-500 mt-1">
                Receipt No: <span className="font-mono font-bold text-slate-800">{payment.receiptNo}</span>
              </div>
              <div className="text-xs text-slate-500">
                Date: <span className="font-semibold text-slate-800">{payment.paymentDate}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Student & Course Details Section */}
        <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 mb-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs sm:text-sm">
            <div>
              <span className="text-slate-500 block text-xs">Student Name</span>
              <span className="font-bold text-slate-900 text-base">{payment.studentName}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-xs">Aadhaar Number</span>
              <span className="font-mono font-semibold text-slate-800">
                {payment.studentAadhaar || 'Not Provided'}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-xs">Contact Mobile</span>
              <span className="font-semibold text-slate-800">{payment.studentMobile || '-'}</span>
            </div>
            <div className="sm:col-span-2">
              <span className="text-slate-500 block text-xs">Enrolled Course</span>
              <span className="font-semibold text-indigo-900">{payment.courseTitle}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-xs">Batch</span>
              <span className="font-semibold text-slate-800">{payment.batchName}</span>
            </div>
          </div>
        </div>

        {/* Itemized Fee Breakdown Table */}
        <div className="mb-5">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-indigo-900 text-white font-semibold">
                <th className="p-2.5 rounded-tl-lg">Sl.</th>
                <th className="p-2.5">Fee Particulars & Billing Month</th>
                <th className="p-2.5 text-right">Base Amount</th>
                <th className="p-2.5 text-right">Discount</th>
                <th className="p-2.5 rounded-tr-lg text-right">Net Paid</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 border border-slate-200">
              <tr>
                <td className="p-2.5 font-mono text-slate-500">01</td>
                <td className="p-2.5">
                  <div className="font-bold text-slate-900">
                    Tuition & Lab Training Fee ({payment.month})
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {payment.monthsCovered?.length ? `Months: ${payment.monthsCovered.join(', ')}` : 'Monthly Tuition'}
                    {payment.remarks && ` • Note: ${payment.remarks}`}
                  </div>
                </td>
                <td className="p-2.5 text-right font-mono text-slate-700">
                  ₹{(payment.totalBaseFee || payment.finalAmountPaid).toLocaleString('en-IN')}
                </td>
                <td className="p-2.5 text-right font-mono text-emerald-600">
                  {payment.totalDiscount > 0 ? `-₹${payment.totalDiscount.toLocaleString('en-IN')}` : '₹0'}
                  {payment.discountBreakdown && (
                    <span className="block text-[10px] text-emerald-700">
                      ({payment.discountBreakdown})
                    </span>
                  )}
                </td>
                <td className="p-2.5 text-right font-mono font-bold text-slate-900">
                  ₹{payment.finalAmountPaid.toLocaleString('en-IN')}
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr className="bg-slate-100 font-bold border-t-2 border-slate-300">
                <td colSpan={4} className="p-2.5 text-right text-slate-700 uppercase text-xs">
                  Grand Total Paid Amount:
                </td>
                <td className="p-2.5 text-right font-mono text-base text-indigo-950 font-extrabold">
                  ₹{payment.finalAmountPaid.toLocaleString('en-IN')}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Amount in Words */}
        <div className="bg-indigo-50/70 border border-indigo-100 rounded-xl p-3 mb-5">
          <div className="text-xs text-indigo-900 font-medium">
            <span className="font-bold">Amount in Words: </span>
            <span className="italic">{amountInWords}</span>
          </div>
        </div>

        {/* Transaction Details & Mode */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-50 p-3.5 rounded-xl border border-slate-200 mb-6">
          <div>
            <div className="text-slate-500 font-medium">Payment Mode & Reference</div>
            <div className="font-semibold text-slate-900 text-xs sm:text-sm mt-0.5 flex items-center gap-2">
              <span className="px-2 py-0.5 bg-slate-200 text-slate-800 rounded font-mono text-xs">
                {payment.paymentMode}
              </span>
              {payment.transactionRef && (
                <span className="font-mono text-slate-700 text-xs">
                  Ref: {payment.transactionRef}
                </span>
              )}
            </div>
          </div>
          <div>
            <div className="text-slate-500 font-medium">Payment Verification Status</div>
            <div className="font-bold text-emerald-700 text-xs sm:text-sm mt-0.5 flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>PAID & VERIFIED ({payment.approvedBy || 'Admin Desk'})</span>
            </div>
          </div>
        </div>

        {/* Signatures and QR Code Bottom Row */}
        <div className="flex flex-col sm:flex-row justify-between items-end gap-5 pt-3 border-t border-slate-200">
          <div className="flex items-center gap-3">
            {qrVerificationUrl ? (
              <img 
                src={qrVerificationUrl} 
                alt="Verification QR"
                className="w-18 h-18 border border-slate-200 rounded-lg p-1 bg-white"
              />
            ) : null}
            <div className="text-[11px] text-slate-500 max-w-xs">
              <div className="font-bold text-slate-700 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-600" />
                <span>Pixel Pathsala Authenticated</span>
              </div>
              <p className="mt-0.5">UPI ID: <span className="font-mono font-semibold text-slate-800">{centerInfo.upiId}</span></p>
            </div>
          </div>

          <div className="text-center sm:text-right">
            <div className="h-10 flex items-end justify-center sm:justify-end pb-1">
              <span className="font-serif italic font-semibold text-indigo-900 text-sm sm:text-base tracking-wide border-b border-slate-400 px-6">
                Suparna Kanti Datta
              </span>
            </div>
            <div className="text-xs font-bold text-slate-800 mt-1">Authorized Signatory</div>
            <div className="text-[10px] text-slate-500">{centerInfo.name} Administration</div>
          </div>
        </div>

        {/* Footer Notice */}
        <div className="text-center text-[10px] text-slate-400 mt-6 border-t border-dashed border-slate-200 pt-2">
          This is an official computer-generated fee receipt. Fees once paid are non-refundable & non-transferable.
        </div>
      </div>
    </div>
  );
};
