import React, { useEffect } from 'react';
import { useApp } from '../../context/AppContext';

export const SEOMetadataManager: React.FC = () => {
  const { activeTab, centerInfo } = useApp();

  useEffect(() => {
    if (typeof document === 'undefined') return;

    let pageTitle = 'Pixel Pathsala ERP & Portal - Premier Coaching Institute & Computer Academy';
    let metaDescription = 'Pixel Pathsala Coaching Center & Computer Academy: Premier institute for School Syllabus (Class 8-12 CBSE/ICSE/WB Board), Science & Mathematics Tuition, Competitive Exam Prep, Coding & DBMS Training, Online Student Admissions, and Learning Portal.';
    let canonicalPath = '/';

    switch (activeTab) {
      case 'courses':
        pageTitle = `Courses, Batches & Syllabus 2026-27 | ${centerInfo.name || 'Pixel Pathsala'}`;
        metaDescription = `Explore courses for Class 8-10 Secondary Foundation, Class 11-12 Higher Secondary Science & Maths, and Computer Programming (Python, Java, Web). Special scholarships available at ${centerInfo.name}.`;
        canonicalPath = '/?tab=courses';
        break;
      case 'admission':
        pageTitle = `Online Student Admission 2026-27 | ${centerInfo.name || 'Pixel Pathsala'}`;
        metaDescription = `Apply online for 2026-27 admission at ${centerInfo.name}. Zero registration fee, instant enrollment, batch selection, and early-bird scholarship discounts.`;
        canonicalPath = '/?tab=admission';
        break;
      case 'faculty':
        pageTitle = `Faculty & Senior Educators | ${centerInfo.name || 'Pixel Pathsala'}`;
        metaDescription = `Meet expert mentors, Ph.D. faculty, and qualified teachers at ${centerInfo.name} guiding students in Science, Mathematics, and Computer Science.`;
        canonicalPath = '/?tab=faculty';
        break;
      case 'playzone':
        pageTitle = `Interactive Code Playzone & Python Compiler | ${centerInfo.name || 'Pixel Pathsala'}`;
        metaDescription = `Interactive coding playground for Python, Java, C++, and Web Development. Practice coding problems and test logic in the browser at ${centerInfo.name}.`;
        canonicalPath = '/?tab=playzone';
        break;
      case 'student-portal':
        pageTitle = `Student & Guardian Learning Portal | ${centerInfo.name || 'Pixel Pathsala'}`;
        metaDescription = `Access fee receipts, live online classes, study materials, examination results, and attendance records on the ${centerInfo.name} Student Portal.`;
        canonicalPath = '/?tab=student-portal';
        break;
      case 'admin':
        pageTitle = `Admin Management ERP | ${centerInfo.name || 'Pixel Pathsala'}`;
        metaDescription = `Secure administrative management portal for admissions, fees, faculty, expenses, and reporting.`;
        canonicalPath = '/?tab=admin';
        break;
      default:
        pageTitle = `${centerInfo.name || 'Pixel Pathsala ERP & Portal'} - Premier Coaching Institute & Computer Academy`;
        metaDescription = `Pixel Pathsala is a premier coaching institute and computer academy in Raina, Purba Bardhaman (Burdwan), West Bengal offering tuition for Class 8-12 (CBSE, ICSE, WB Board), Science, Math, Competitive Exam Prep & Coding. Admissions Open 2026-27.`;
        canonicalPath = '/';
        break;
    }

    // 1. Update Title
    document.title = pageTitle;

    // 2. Update Meta Description
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', metaDescription);
    }

    // 3. Update Open Graph Meta
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute('content', pageTitle);
    }
    const ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc) {
      ogDesc.setAttribute('content', metaDescription);
    }
    const ogUrl = document.querySelector('meta[property="og:url"]');
    if (ogUrl) {
      ogUrl.setAttribute('content', `${window.location.origin}${canonicalPath}`);
    }

    // 4. Update Twitter Cards
    const twTitle = document.querySelector('meta[name="twitter:title"]');
    if (twTitle) {
      twTitle.setAttribute('content', pageTitle);
    }
    const twDesc = document.querySelector('meta[name="twitter:description"]');
    if (twDesc) {
      twDesc.setAttribute('content', metaDescription);
    }
    const twUrl = document.querySelector('meta[name="twitter:url"]');
    if (twUrl) {
      twUrl.setAttribute('content', `${window.location.origin}${canonicalPath}`);
    }

    // 5. Update Canonical Link
    const canonical = document.querySelector('link[rel="canonical"]');
    if (canonical) {
      canonical.setAttribute('href', `${window.location.origin}${canonicalPath}`);
    }

    // 6. Update URL query parameter without full reload for easy sharing and Google indexing
    try {
      const currentUrl = new URL(window.location.href);
      if (activeTab === 'website') {
        currentUrl.searchParams.delete('tab');
      } else {
        currentUrl.searchParams.set('tab', activeTab);
      }
      window.history.replaceState({}, '', currentUrl.toString());
    } catch {
      // safe fallback
    }
  }, [activeTab, centerInfo]);

  return null;
};
