import React from 'react';
import { Sparkles, Tag, Percent } from 'lucide-react';

interface DiscountRibbonBadgeProps {
  text: string;
  subtitle?: string;
  variant?: 'corner' | 'badge' | 'pill' | 'banner' | 'tag';
  className?: string;
  showIcon?: boolean;
}

export const DiscountRibbonBadge: React.FC<DiscountRibbonBadgeProps> = ({
  text,
  subtitle,
  variant = 'badge',
  className = '',
  showIcon = true
}) => {
  if (!text) return null;

  if (variant === 'corner') {
    return (
      <div className={`absolute top-0 right-0 z-20 overflow-hidden w-32 h-32 pointer-events-none ${className}`}>
        <div className="absolute top-6 -right-8 w-40 text-center py-1.5 bg-gradient-to-r from-red-700 via-red-600 to-rose-700 text-amber-300 font-black text-[11px] tracking-wider uppercase shadow-lg transform rotate-45 border-y border-amber-400/40 drop-shadow-md select-none">
          <div className="flex items-center justify-center gap-1">
            {showIcon && <Sparkles className="w-3 h-3 text-amber-300 animate-pulse fill-amber-300/30" />}
            <span className="drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)] text-amber-300 font-extrabold">{text}</span>
          </div>
          {subtitle && (
            <div className="text-[8px] text-amber-200 font-medium tracking-tight -mt-0.5 opacity-90 drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]">
              {subtitle}
            </div>
          )}
        </div>
      </div>
    );
  }

  if (variant === 'banner') {
    return (
      <div
        className={`relative inline-flex items-center gap-2 px-3.5 py-1.5 bg-gradient-to-r from-red-700 via-red-600 to-rose-600 text-amber-300 font-black text-xs rounded-xl shadow-md border border-amber-400/40 drop-shadow-sm select-none ${className}`}
      >
        {/* Ribbon edge decorations */}
        <div className="absolute -left-1 top-1/2 -translate-y-1/2 w-2 h-2 bg-red-800 rotate-45 -z-10" />
        {showIcon && <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse shrink-0 fill-amber-300/30" />}
        <div className="flex flex-col">
          <span className="tracking-wide uppercase drop-shadow-[0_1px_1px_rgba(0,0,0,0.7)] text-amber-300 font-extrabold">
            {text}
          </span>
          {subtitle && (
            <span className="text-[10px] text-amber-200/90 font-medium normal-case drop-shadow-[0_1px_1px_rgba(0,0,0,0.7)]">
              {subtitle}
            </span>
          )}
        </div>
      </div>
    );
  }

  if (variant === 'tag') {
    return (
      <span
        className={`inline-flex items-center gap-1 px-2.5 py-1 bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-amber-300 font-black text-[11px] rounded-lg shadow-sm border border-amber-400/30 select-none ${className}`}
      >
        {showIcon && <Tag className="w-3 h-3 text-amber-300 shrink-0 fill-amber-300/20" />}
        <span className="drop-shadow-[0_1px_1px_rgba(0,0,0,0.7)] text-amber-300 font-extrabold">{text}</span>
      </span>
    );
  }

  // Default 'badge' / 'pill'
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-red-700 via-red-600 to-rose-700 text-amber-300 font-black text-xs rounded-full shadow-md border border-amber-400/40 select-none ${className}`}
    >
      {showIcon && <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse shrink-0 fill-amber-300/30" />}
      <span className="drop-shadow-[0_1px_1px_rgba(0,0,0,0.7)] text-amber-300 font-extrabold tracking-wide uppercase">
        {text}
      </span>
      {subtitle && (
        <span className="text-[10px] text-amber-200/90 font-medium normal-case drop-shadow-[0_1px_1px_rgba(0,0,0,0.7)]">
          • {subtitle}
        </span>
      )}
    </span>
  );
};
