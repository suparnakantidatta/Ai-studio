import React, { useRef } from 'react';
import { AdmissionApplication } from '../../types';
import { useApp } from '../../context/AppContext';
import { CenterLogo } from './CenterLogo';
import { 
  Printer, 
  Download, 
  X, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  Code2, 
  Building2, 
  CreditCard, 
  Phone, 
  Mail, 
  MapPin, 
  User, 
  BookOpen, 
  GraduationCap, 
  Sparkles,
  ExternalLink
} from 'lucide-react';

interface AdmissionReceiptModalProps {
  application: AdmissionApplication | null;
  onClose: () => void;
}

export const AdmissionReceiptModal: React.FC<AdmissionReceiptModalProps> = ({
  application,
  onClose
}) => {
  const { centerInfo, courses, batches, setActiveTab } = useApp();
  const receiptRef = useRef<HTMLDivElement>(null);

  if (!application) return null;

  const targetCourse = courses.find(c => c.id === application.targetCourseId);
  const preferredBatch = batches.find(b => b.id === application.preferredBatchId);

  const handlePrint = () => {
    const printContent = receiptRef.current;
    if (!printContent) {
      window.print();
      return;
    }

    try {
      const printWindow = window.open('', '_blank', 'width=850,height=900');
      if (printWindow) {
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Admission Acknowledgment ${application.applicationNo} - ${centerInfo.name}</title>
              <meta charset="utf-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1" />
              <link rel="preconnect" href="https://fonts.googleapis.com">
              <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
              <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fira+Code:wght@400;600&display=swap" rel="stylesheet">
              <script src="https://cdn.tailwindcss.com"></script>
              <style>
                body {
                  font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif;
                  background: #f8fafc;
                  color: #0f172a;
                  margin: 0;
                  padding: 24px;
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                @page {
                  size: A4 portrait;
                  margin: 10mm;
                }
                @media print {
                  body {
                    background: white !important;
                    padding: 0 !important;
                  }
                  .no-print {
                    display: none !important;
                  }
                  .receipt-card {
                    box-shadow: none !important;
                    border: 1px solid #cbd5e1 !important;
                    padding: 24px !important;
                  }
                }
              </style>
            </head>
            <body>
              <div class="max-w-3xl mx-auto mb-6 text-center no-print flex items-center justify-center gap-3">
                <button onclick="window.print()" style="background:#4f46e5;color:white;padding:10px 24px;border-radius:12px;font-weight:bold;cursor:pointer;border:none;box-shadow:0 4px 12px rgba(79,70,229,0.3);font-size:14px;">
                  🖨️ Click to Print / Save as PDF
                </button>
                <button onclick="window.close()" style="background:#e2e8f0;color:#334155;padding:10px 18px;border-radius:12px;font-weight:bold;cursor:pointer;border:none;font-size:14px;">
                  Close Window
                </button>
              </div>
              <div class="receipt-card max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow-xl border border-slate-200">
                ${printContent.innerHTML}
              </div>
              <script>
                window.onload = function() {
                  setTimeout(function() {
                    window.focus();
                    window.print();
                  }, 400);
                };
              </script>
            </body>
          </html>
        `);
        printWindow.document.close();
      } else {
        window.print();
      }
    } catch {
      window.print();
    }
  };

  const handleDownloadHtml = () => {
    const printContent = receiptRef.current;
    if (!printContent) return;

    const fullHtml = `<!DOCTYPE html>
<html>
  <head>
    <title>Admission Receipt ${application.applicationNo} - ${centerInfo.name}</title>
    <meta charset="utf-8" />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Fira+Code:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
      body { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; background: #fff; padding: 24px; }
      @page { size: A4 portrait; margin: 10mm; }
    </style>
  </head>
  <body>
    <div style="max-width: 800px; margin: 0 auto;">
      ${printContent.innerHTML}
    </div>
  </body>
</html>`;

    const blob = new Blob([fullHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AdmissionReceipt_${application.applicationNo.replace(/[^a-zA-Z0-9]/g, '_')}_${application.studentName.replace(/\s+/g, '_')}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-slate-200 flex flex-col max-h-[92vh] animate-fadeIn">
        
        {/* Modal Top Control Bar */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <GraduationCap className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="font-bold text-sm sm:text-base leading-tight">
                Admission Application Receipt
              </h2>
              <p className="text-[11px] text-amber-300/90 font-mono">
                Status: Pending Approval • Ref: {application.applicationNo}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer"
              title="Print Receipt"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print</span>
            </button>

            <button
              onClick={handleDownloadHtml}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition border border-slate-700 cursor-pointer"
              title="Download Receipt Document"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Download</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Body */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 bg-slate-50">
          <div 
            ref={receiptRef}
            className="bg-white p-6 sm:p-8 rounded-2xl border-2 border-slate-300 shadow-sm relative text-slate-900"
          >
            {/* Watermark */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03] select-none">
              <span className="text-8xl font-black rotate-[-25deg] tracking-widest text-slate-900">
                PENDING
              </span>
            </div>

            {/* Header / Institution info */}
            <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-5 border-b-2 border-slate-800">
              <div className="flex items-center gap-3.5">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-900 via-indigo-800 to-indigo-950 text-white flex items-center justify-center font-black text-xl shadow-md border-2 border-indigo-700 shrink-0">
                  PP
                </div>
                <div>
                  <h1 className="text-2xl font-black tracking-tight text-slate-900 leading-tight">
                    {centerInfo.name}
                  </h1>
                  <p className="text-xs font-semibold text-indigo-700 italic">
                    "{centerInfo.tagline || 'Code your dream, decode the future'}"
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {centerInfo.address}, {centerInfo.cityState} • Tel: {centerInfo.phonePrimary}
                  </p>
                </div>
              </div>

              {/* Status Badge */}
              <div className="text-right sm:self-center shrink-0">
                <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 border-2 border-amber-400 text-amber-900 font-extrabold text-xs uppercase tracking-wider shadow-2xs">
                  <Clock className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                  <span>Status: Pending Approval</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-1 font-mono">
                  Provisional Admission Receipt
                </div>
              </div>
            </div>

            {/* Title Bar */}
            <div className="my-4 py-2 px-4 bg-slate-100 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between text-xs font-bold text-slate-700">
              <span>ADMISSION APPLICATION ACKNOWLEDGMENT RECEIPT</span>
              <span className="font-mono text-indigo-800">Ref: {application.applicationNo}</span>
              <span className="text-slate-500 font-medium">Date: {application.appliedDate}</span>
            </div>

            {/* Student & Academic Info Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs my-4">
              {/* Student Details */}
              <div className="bg-slate-50/80 p-4 rounded-xl border border-slate-200 space-y-2">
                <div className="font-bold text-indigo-900 uppercase tracking-wide text-[11px] pb-1 border-b border-slate-200 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Applicant Personal Details</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Applicant Name:</span>
                  <span className="font-bold text-slate-900 text-sm">{application.studentName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Academic Class:</span>
                  <span className="font-bold text-indigo-700">{application.studentClass || 'Class 10 (Secondary)'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Mobile Number:</span>
                  <span className="font-mono font-bold text-slate-800">{application.mobile}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">AADHAAR No:</span>
                  <span className="font-mono font-bold text-slate-800">
                    {application.aadhaarNo.length === 12 
                      ? `XXXX-XXXX-${application.aadhaarNo.slice(-4)}`
                      : application.aadhaarNo}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Guardian Name:</span>
                  <span className="font-medium text-slate-800">{application.guardianName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Guardian Phone:</span>
                  <span className="font-mono text-slate-800">{application.guardianPhone}</span>
                </div>
                {application.address && (
                  <div className="pt-1 text-[11px] text-slate-600 border-t border-slate-200/60">
                    <span className="text-slate-400">Address: </span>
                    <span>{application.address}</span>
                  </div>
                )}
              </div>

              {/* Course & Payment Details */}
              <div className="bg-slate-50/80 p-4 rounded-xl border border-slate-200 space-y-2">
                <div className="font-bold text-indigo-900 uppercase tracking-wide text-[11px] pb-1 border-b border-slate-200 flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Course & Payment Details</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Applied Course:</span>
                  <span className="font-bold text-slate-900 text-right">{targetCourse?.title || 'Academic Course'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Program Track:</span>
                  <span className="font-semibold text-slate-700">{targetCourse?.category || 'General'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Preferred Batch:</span>
                  <span className="font-semibold text-slate-800">
                    {preferredBatch ? `${preferredBatch.name} (${preferredBatch.timing})` : 'To be assigned'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Admission Fee:</span>
                  <span className="font-bold text-emerald-600">₹0 (100% FREE)</span>
                </div>
                {targetCourse?.monthlyFee && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">1st Month Base Fee:</span>
                    <span className="font-semibold text-slate-800">₹{targetCourse.monthlyFee.toLocaleString('en-IN')}</span>
                  </div>
                )}
                {application.appliedDiscountAmount && application.appliedDiscountAmount > 0 ? (
                  <div className="flex justify-between text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    <span className="font-medium flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-emerald-600" />
                      <span>Concession / Scholarship:</span>
                    </span>
                    <span className="font-mono font-bold">-₹{application.appliedDiscountAmount.toLocaleString('en-IN')}</span>
                  </div>
                ) : null}
                <div className="flex justify-between">
                  <span className="text-slate-500">Payment Option:</span>
                  <span className="font-bold text-slate-800">
                    {application.initialPaymentMode === 'UPI' 
                      ? 'UPI QR Transfer' 
                      : application.initialPaymentMode === 'CASH' 
                      ? 'Cash at Center Desk' 
                      : 'Desk Confirmation'}
                  </span>
                </div>
                {application.initialPaymentRef && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">UPI / Ref UTR:</span>
                    <span className="font-mono font-bold text-indigo-700">{application.initialPaymentRef}</span>
                  </div>
                )}
                <div className="flex justify-between pt-1 border-t border-slate-200">
                  <span className="font-bold text-slate-700">Initial Amount Payable/Paid:</span>
                  <span className="font-mono font-bold text-slate-900">
                    {application.initialPaymentAmount !== undefined ? `₹${application.initialPaymentAmount.toLocaleString('en-IN')}` : 'To be verified at center'}
                  </span>
                </div>
              </div>
            </div>

            {/* Official Under-Process Status Banner */}
            <div className="p-4 bg-amber-50/90 rounded-xl border-2 border-amber-300 text-amber-950 text-xs my-4 space-y-1">
              <div className="font-extrabold flex items-center gap-1.5 text-amber-900 text-sm">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Your application is under process, Please contact you educator or visit center with payment receipt</span>
              </div>
              <p className="text-[11px] text-amber-800 leading-relaxed">
                Thank you for applying to {centerInfo.name}. Please preserve this provisional receipt. Our administrative desk will verify your payment and finalize your roll number and batch timing.
              </p>
            </div>

            {/* Signatures & Footer */}
            <div className="mt-8 pt-4 border-t border-slate-300 grid grid-cols-2 text-xs">
              <div>
                <p className="text-[10px] text-slate-400">Issued for: {application.studentName}</p>
                <p className="text-[10px] text-slate-400 font-mono">Center Reg: {centerInfo.regNumber || 'PP/WB/2021'}</p>
              </div>
              <div className="text-right space-y-4">
                <div className="text-[11px] font-bold text-slate-800">For {centerInfo.name}</div>
                <div className="inline-block border-t border-slate-400 pt-1 text-[10px] text-slate-500 font-semibold">
                  Authorized Signatory / Admin Desk
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Footer Actions */}
        <div className="bg-slate-100 p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 shrink-0">
          <button
            onClick={() => {
              onClose();
              setActiveTab('playzone');
            }}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition transform hover:scale-[1.01] cursor-pointer"
          >
            <Code2 className="w-4 h-4 text-amber-300" />
            <span>Go to Coders Zone</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs sm:text-sm font-bold transition shadow-md cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Print Receipt</span>
            </button>

            <button
              onClick={handleDownloadHtml}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-white hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download HTML</span>
            </button>

            <button
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
