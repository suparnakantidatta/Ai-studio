import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { getWhatsAppUrl, getPhoneTelUrl, getEmailMailtoUrl } from '../../utils/contactHelper';
import { 
  PhoneCall, 
  Mail, 
  MessageCircle, 
  Copy, 
  Check, 
  ExternalLink, 
  Clock, 
  MapPin, 
  Sparkles,
  ChevronRight,
  ShieldCheck,
  Video,
  Share2
} from 'lucide-react';

interface InteractiveContactTabsProps {
  variant?: 'pills' | 'cards' | 'floating' | 'banner';
  className?: string;
  showSecondaryPhone?: boolean;
}

export const InteractiveContactTabs: React.FC<InteractiveContactTabsProps> = ({
  variant = 'pills',
  className = '',
  showSecondaryPhone = true
}) => {
  const { centerInfo, showToast } = useApp();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isFloatingOpen, setIsFloatingOpen] = useState(false);

  const whatsappNumber = centerInfo.whatsapp || centerInfo.phonePrimary || '+91 9775708722';
  const phonePrimary = centerInfo.phonePrimary || '+91 9775708722';
  const phoneSecondary = centerInfo.phoneSecondary;
  const email = centerInfo.email || 'pixelpathsala.edu@gmail.com';
  const facebookUrl = centerInfo.facebookUrl || 'https://facebook.com/pixelpathsala';
  const youtubeUrl = centerInfo.youtubeUrl || 'https://youtube.com/@pixelpathsala';

  const whatsappLink = getWhatsAppUrl(whatsappNumber, centerInfo.name);
  const phoneLink = getPhoneTelUrl(phonePrimary);
  const emailLink = getEmailMailtoUrl(email, centerInfo.name);

  const handleCopy = (text: string, label: string, key: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    showToast(`Copied ${label} (${text}) to clipboard!`, 'info');
    setTimeout(() => setCopiedKey(null), 2500);
  };

  // 1. PILLS VARIANT (Ideal for top bars, hero sections, interactive headers)
  if (variant === 'pills') {
    return (
      <div className={`flex flex-wrap items-center gap-2 sm:gap-3 ${className}`}>
        {/* WhatsApp Interactive Tab */}
        <a
          id="contact-tab-whatsapp"
          href={whatsappLink}
          target="_blank"
          rel="noopener noreferrer"
          className="group relative inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs font-bold shadow-sm shadow-emerald-600/20 hover:shadow-emerald-600/40 transition-all transform hover:-translate-y-0.5"
          title={`Chat with ${centerInfo.name} on WhatsApp`}
        >
          <span className="w-5 h-5 rounded-lg bg-emerald-500/80 flex items-center justify-center shrink-0">
            <MessageCircle className="w-3.5 h-3.5 fill-current" />
          </span>
          <div className="flex flex-col text-left">
            <span className="text-[10px] leading-tight text-emerald-100 uppercase tracking-wider font-semibold">WhatsApp Chat</span>
            <span className="font-mono text-xs font-bold tracking-tight">{whatsappNumber}</span>
          </div>
          <span className="hidden sm:inline-flex items-center ml-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-white/20 text-white">
            Live
          </span>
        </a>

        {/* Phone Call Interactive Tab */}
        <a
          id="contact-tab-phone"
          href={phoneLink}
          className="group relative inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold shadow-sm shadow-indigo-600/20 hover:shadow-indigo-600/40 transition-all transform hover:-translate-y-0.5"
          title={`Call ${centerInfo.name} Helpline`}
        >
          <span className="w-5 h-5 rounded-lg bg-indigo-500/80 flex items-center justify-center shrink-0">
            <PhoneCall className="w-3.5 h-3.5" />
          </span>
          <div className="flex flex-col text-left">
            <span className="text-[10px] leading-tight text-indigo-100 uppercase tracking-wider font-semibold">Call Helpline</span>
            <span className="font-mono text-xs font-bold tracking-tight">{phonePrimary}</span>
          </div>
          <span className="hidden sm:inline-flex items-center ml-1 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-white/20 text-white">
            Call
          </span>
        </a>

        {/* Facebook Page Tab */}
        {facebookUrl && (
          <a
            id="contact-tab-facebook"
            href={facebookUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="group relative inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white text-xs font-bold shadow-sm shadow-blue-600/20 transition-all transform hover:-translate-y-0.5"
            title={`Follow ${centerInfo.name} on Facebook`}
          >
            <span className="w-5 h-5 rounded-lg bg-blue-500/80 flex items-center justify-center shrink-0">
              <Share2 className="w-3.5 h-3.5" />
            </span>
            <div className="flex flex-col text-left">
              <span className="text-[10px] leading-tight text-blue-100 uppercase tracking-wider font-semibold">Facebook Page</span>
              <span className="text-xs font-bold tracking-tight">Follow Us</span>
            </div>
            <ExternalLink className="w-3 h-3 opacity-70 ml-0.5" />
          </a>
        )}

        {/* YouTube Channel Tab */}
        {youtubeUrl && (
          <a
            id="contact-tab-youtube"
            href={youtubeUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="group relative inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white text-xs font-bold shadow-sm shadow-rose-600/20 transition-all transform hover:-translate-y-0.5"
            title={`Subscribe to ${centerInfo.name} on YouTube`}
          >
            <span className="w-5 h-5 rounded-lg bg-rose-500/80 flex items-center justify-center shrink-0">
              <Video className="w-3.5 h-3.5" />
            </span>
            <div className="flex flex-col text-left">
              <span className="text-[10px] leading-tight text-rose-100 uppercase tracking-wider font-semibold">YouTube</span>
              <span className="text-xs font-bold tracking-tight">Watch Classes</span>
            </div>
            <ExternalLink className="w-3 h-3 opacity-70 ml-0.5" />
          </a>
        )}

        {/* Email Interactive Tab */}
        <a
          id="contact-tab-email"
          href={emailLink}
          className="group relative inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-white text-xs font-bold shadow-sm border border-slate-700 transition-all transform hover:-translate-y-0.5"
          title={`Email ${centerInfo.name}`}
        >
          <span className="w-5 h-5 rounded-lg bg-slate-700 flex items-center justify-center shrink-0 text-slate-200">
            <Mail className="w-3.5 h-3.5" />
          </span>
          <div className="flex flex-col text-left">
            <span className="text-[10px] leading-tight text-slate-300 uppercase tracking-wider font-semibold">Official Email</span>
            <span className="font-mono text-xs font-bold tracking-tight truncate max-w-[140px] sm:max-w-none">{email}</span>
          </div>
        </a>
      </div>
    );
  }

  // 2. BANNER VARIANT (For full-width horizontal bar on homepage or under announcements)
  if (variant === 'banner') {
    return (
      <div className={`w-full bg-slate-900/95 backdrop-blur-md text-white rounded-2xl p-4 sm:p-5 border border-indigo-500/30 shadow-lg ${className}`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center shrink-0">
              <MessageCircle className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Quick Direct Connect</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <h4 className="text-sm sm:text-base font-extrabold text-white">
                Have questions about courses, admissions, or fees?
              </h4>
              <p className="text-xs text-slate-300">
                Click any tab below for instant response on WhatsApp, Phone Helpline, or Email.
              </p>
            </div>
          </div>

          {/* Action Tabs in Banner */}
          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>WhatsApp: {whatsappNumber}</span>
              <ExternalLink className="w-3 h-3 opacity-70" />
            </a>

            <a
              href={phoneLink}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Call: {phonePrimary}</span>
            </a>

            <a
              href={emailLink}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-xs transition-all cursor-pointer"
            >
              <Mail className="w-4 h-4" />
              <span>Email Us</span>
            </a>

            {facebookUrl && (
              <a
                href={facebookUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 transition-all cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>Facebook</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>
            )}

            {youtubeUrl && (
              <a
                href={youtubeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-600/30 transition-all cursor-pointer"
              >
                <Video className="w-4 h-4" />
                <span>YouTube</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 3. CARDS VARIANT (For Center Info Section with full interactivity and copy triggers)
  return (
    <div className="space-y-4">
      <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 ${className}`}>
      
      {/* 1. WhatsApp Card */}
      <div className="group relative bg-gradient-to-b from-slate-800/90 to-slate-900/90 p-5 rounded-2xl border border-emerald-500/40 shadow-lg hover:border-emerald-400 transition-all flex flex-col justify-between">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center group-hover:scale-110 transition-transform">
              <MessageCircle className="w-5 h-5 fill-current" />
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              Instant Chat
            </span>
          </div>

          <div>
            <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
              Official WhatsApp
            </div>
            <p className="text-sm sm:text-base font-black text-white font-mono mt-0.5">
              {whatsappNumber}
            </p>
            <p className="text-[11px] text-slate-300 mt-1">
              Direct chat with center counselors for batch timings, fee doubts & syllabus queries.
            </p>
          </div>
        </div>

        <div className="pt-4 mt-3 border-t border-slate-700/60 flex items-center gap-2">
          <a
            id="card-action-whatsapp"
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-current" />
            <span>Chat on WhatsApp</span>
            <ExternalLink className="w-3 h-3 opacity-80 ml-0.5" />
          </a>
          <button
            type="button"
            onClick={(e) => handleCopy(whatsappNumber, 'WhatsApp Number', 'wa', e)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer"
            title="Copy WhatsApp Number"
          >
            {copiedKey === 'wa' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* 2. Helpline Phone Card */}
      <div className="group relative bg-gradient-to-b from-slate-800/90 to-slate-900/90 p-5 rounded-2xl border border-indigo-500/40 shadow-lg hover:border-indigo-400 transition-all flex flex-col justify-between">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center group-hover:scale-110 transition-transform">
              <PhoneCall className="w-5 h-5" />
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Helpline Desk
            </span>
          </div>

          <div>
            <div className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
              Phone Support
            </div>
            <p className="text-sm sm:text-base font-black text-white font-mono mt-0.5">
              {phonePrimary}
            </p>
            {showSecondaryPhone && phoneSecondary && (
              <p className="text-xs font-mono text-slate-300 mt-0.5">
                Alt: {phoneSecondary}
              </p>
            )}
            <p className="text-[11px] text-slate-300 mt-1">
              Direct voice call to center reception for admissions and student inquiries.
            </p>
          </div>
        </div>

        <div className="pt-4 mt-3 border-t border-slate-700/60 flex items-center gap-2">
          <a
            id="card-action-phone"
            href={phoneLink}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>Call Now</span>
          </a>
          <button
            type="button"
            onClick={(e) => handleCopy(phonePrimary, 'Phone Number', 'phone', e)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer"
            title="Copy Phone Number"
          >
            {copiedKey === 'phone' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* 3. Official Email Card */}
      <div className="group relative bg-gradient-to-b from-slate-800/90 to-slate-900/90 p-5 rounded-2xl border border-slate-700 shadow-lg hover:border-slate-500 transition-all flex flex-col justify-between">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Mail className="w-5 h-5" />
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Official Desk
            </span>
          </div>

          <div>
            <div className="text-xs font-bold text-purple-400 uppercase tracking-wider">
              Official Email
            </div>
            <p className="text-xs sm:text-sm font-bold text-white font-mono mt-0.5 truncate" title={email}>
              {email}
            </p>
            <p className="text-[11px] text-slate-300 mt-1">
              Email inquiries for certificates, receipts, course registration & official notices.
            </p>
          </div>
        </div>

        <div className="pt-4 mt-3 border-t border-slate-700/60 flex items-center gap-2">
          <a
            id="card-action-email"
            href={emailLink}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Send Email</span>
          </a>
          <button
            type="button"
            onClick={(e) => handleCopy(email, 'Email Address', 'email', e)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition cursor-pointer"
            title="Copy Email Address"
          >
            {copiedKey === 'email' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* 4. Campus Location & Hours Card */}
      <div className="group relative bg-gradient-to-b from-slate-800/90 to-slate-900/90 p-5 rounded-2xl border border-slate-700 shadow-lg hover:border-slate-500 transition-all flex flex-col justify-between">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center group-hover:scale-110 transition-transform">
              <MapPin className="w-5 h-5" />
            </div>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              Campus Visit
            </span>
          </div>

          <div>
            <div className="text-xs font-bold text-amber-400 uppercase tracking-wider">
              Campus Address
            </div>
            <p className="text-xs font-semibold text-white mt-0.5 line-clamp-2">
              {centerInfo.address}, {centerInfo.cityState}
            </p>
            <p className="text-[11px] text-slate-300 mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3 text-amber-400 shrink-0" />
              <span>Mon-Sat: 8 AM - 8:30 PM &bull; Sun: 9 AM - 2 PM</span>
            </p>
          </div>
        </div>

        <div className="pt-4 mt-3 border-t border-slate-700/60 flex items-center gap-2">
          <button
            type="button"
            onClick={(e) => handleCopy(`${centerInfo.address}, ${centerInfo.cityState}`, 'Campus Address', 'addr', e)}
            className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 transition cursor-pointer"
          >
            {copiedKey === 'addr' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
            <span>{copiedKey === 'addr' ? 'Address Copied!' : 'Copy Campus Address'}</span>
          </button>
        </div>
      </div>
    </div>

    {/* Social Media Strip in Cards Mode */}
    {(facebookUrl || youtubeUrl) && (
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 text-white">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>Connect with {centerInfo.name} on Official Channels:</span>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          {facebookUrl && (
            <a
              href={facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-xs transition cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Facebook Page</span>
              <ExternalLink className="w-3 h-3 opacity-75" />
            </a>
          )}
          {youtubeUrl && (
            <a
              href={youtubeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-xs transition cursor-pointer"
            >
              <Video className="w-3.5 h-3.5" />
              <span>YouTube Channel</span>
              <ExternalLink className="w-3 h-3 opacity-75" />
            </a>
          )}
        </div>
      </div>
    )}
  </div>
  );
};
