import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { normalizeImageUrl } from '../../utils/imageHelper';

interface CenterLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showText?: boolean;
}

export const CenterLogo: React.FC<CenterLogoProps> = ({ 
  size = 'md', 
  className = '', 
  showText = false 
}) => {
  const { centerInfo } = useApp();
  const [currentSrcIndex, setCurrentSrcIndex] = useState(0);

  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-11 h-11 text-sm',
    lg: 'w-16 h-16 text-lg',
    xl: 'w-24 h-24 text-2xl'
  };

  const rawLogo = centerInfo.logoUrl?.trim();
  const normalizedCustom = rawLogo ? normalizeImageUrl(rawLogo) : null;

  // Reset index if centerInfo.logoUrl changes
  useEffect(() => {
    setCurrentSrcIndex(0);
  }, [centerInfo.logoUrl]);

  // Fallback candidate chain for 100% reliable logo loading
  const candidateSources: string[] = [
    ...(normalizedCustom ? [normalizedCustom] : []),
    '/logo.png',
    '/logo.jpg',
    'https://yt3.googleusercontent.com/aJNkDnk_5T4VKkrCqRq2m_4STViT8Hj7Ivzh2YskfYbqfroMEZotPqDVl-Z6hnLD5Q-1e5HM=s900-c-k-c0x00ffffff-no-rj'
  ];

  const currentSrc = candidateSources[currentSrcIndex] || null;

  const handleImageError = () => {
    if (currentSrcIndex < candidateSources.length - 1) {
      setCurrentSrcIndex(prev => prev + 1);
    } else {
      setCurrentSrcIndex(candidateSources.length); // trigger fallback text
    }
  };

  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      <div 
        className={`${sizeClasses[size]} rounded-full relative shrink-0 overflow-hidden bg-white shadow-md border-2 border-indigo-400/40 flex items-center justify-center`}
      >
        {currentSrc ? (
          <img
            src={currentSrc}
            alt={centerInfo.name || 'Pixel Pathsala Logo'}
            onError={handleImageError}
            className="w-full h-full object-cover object-center rounded-full"
            loading="eager"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-full h-full rounded-full flex flex-col items-center justify-center bg-gradient-to-br from-indigo-600 via-blue-600 to-indigo-900 text-white font-black p-1 text-center select-none">
            <span className="tracking-tighter uppercase font-extrabold text-[40%] text-indigo-200">PIXEL</span>
            <span className="leading-none text-[85%] font-black tracking-wider text-amber-300">PP</span>
            <span className="tracking-widest uppercase font-bold text-[35%] text-indigo-200">PATHSALA</span>
          </div>
        )}
      </div>

      {showText && (
        <div className="flex flex-col text-left">
          <span className="font-extrabold text-white tracking-tight leading-tight">
            {centerInfo.name}
          </span>
          <span className="text-[10px] text-indigo-300 font-semibold tracking-wider uppercase">
            {centerInfo.tagline}
          </span>
        </div>
      )}
    </div>
  );
};
