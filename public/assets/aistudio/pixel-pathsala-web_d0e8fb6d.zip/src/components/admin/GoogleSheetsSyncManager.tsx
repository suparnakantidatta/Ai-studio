import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { googleSheetsService } from '../../utils/googleSheetsService';
import { googleSheetsBackendApi } from '../../services/googleSheetsBackendApi';
import { 
  FileSpreadsheet, 
  CloudUpload, 
  CloudDownload, 
  CheckCircle2, 
  AlertCircle, 
  ExternalLink, 
  RefreshCw, 
  Database, 
  Sparkles, 
  LogIn, 
  LogOut, 
  Table, 
  Copy, 
  Check, 
  FileText, 
  ArrowLeftRight, 
  Globe, 
  Code2, 
  Zap, 
  Send, 
  Activity, 
  BookOpen, 
  HelpCircle, 
  GraduationCap, 
  Award, 
  Users, 
  CreditCard, 
  Briefcase, 
  DollarSign, 
  ShieldCheck, 
  Layers,
  Percent
} from 'lucide-react';

export const GoogleSheetsSyncManager: React.FC = () => {
  const { 
    centerInfo, 
    updateCenterInfo, 
    isGoogleConnected, 
    googleUser, 
    connectGoogleAccount, 
    disconnectGoogleAccount, 
    syncToGoogleSheets, 
    pullFromGoogleSheets, 
    createNewGoogleSheetDatabase, 
    isSyncingSheets, 
    isPullingSheets, 
    students, 
    payments, 
    admissions, 
    courses, 
    batches, 
    educators, 
    expenses, 
    discounts,
    adminAccounts, 
    studyMaterials, 
    questions, 
    exams, 
    examSubmissions,
    liveClasses,
    classRecordings,
    restoreFullBackup,
    showToast 
  } = useApp();

  const [customSheetId, setCustomSheetId] = useState(centerInfo.googleSheetId || '');
  const [testingAccess, setTestingAccess] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; title?: string; sheets?: string[]; error?: string } | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);
  const [showScriptModal, setShowScriptModal] = useState(false);
  const [isEnsuringTabs, setIsEnsuringTabs] = useState(false);

  // Webhook Configuration State
  const [webhookUrl, setWebhookUrl] = useState(centerInfo.googleSheetWebhookUrl || '');
  const [autoWriteBack, setAutoWriteBack] = useState(centerInfo.googleSheetAutoWriteBack ?? true);
  const [testingWebhook, setTestingWebhook] = useState(false);
  const [savingWebhook, setSavingWebhook] = useState(false);
  const [pushingWebhook, setPushingWebhook] = useState(false);
  const [pullingWebhook, setPullingWebhook] = useState(false);
  const [webhookStatus, setWebhookStatus] = useState<{
    success: boolean;
    message: string;
    action?: string;
    timestamp?: string;
  } | null>(centerInfo.googleSheetWebhookLastStatus ? {
    success: true,
    message: centerInfo.googleSheetWebhookLastStatus
  } : null);

  const cleanSheetId = googleSheetsService.extractSpreadsheetId(customSheetId);
  const spreadsheetUrl = cleanSheetId ? `https://docs.google.com/spreadsheets/d/${cleanSheetId}/edit` : null;

  const handleConnectGoogle = async () => {
    try {
      const success = await connectGoogleAccount();
      if (success) {
        setTestResult(null);
      }
    } catch (e: any) {
      showToast(e.message || 'Error initiating Google Sign-In', 'error');
    }
  };

  const handleDisconnectGoogle = () => {
    disconnectGoogleAccount();
  };

  const handleTestSpreadsheet = async () => {
    if (!cleanSheetId) {
      showToast('Please enter a Google Sheet URL or Spreadsheet ID', 'error');
      return;
    }
    if (!isGoogleConnected) {
      showToast('Signing in to Google to verify spreadsheet permissions...', 'info');
      const connected = await connectGoogleAccount();
      if (!connected) return;
    }

    setTestingAccess(true);
    setTestResult(null);
    try {
      const res = await googleSheetsService.testSpreadsheetAccess(cleanSheetId);
      setTestResult({
        success: true,
        title: res.title,
        sheets: res.sheets
      });
      showToast(`Connected to spreadsheet: "${res.title}"`, 'success');
      updateCenterInfo({ googleSheetId: cleanSheetId });
    } catch (err: any) {
      setTestResult({
        success: false,
        error: err.message || 'Could not access spreadsheet. Make sure permissions are granted.'
      });
      showToast('Spreadsheet access test failed', 'error');
    } finally {
      setTestingAccess(false);
    }
  };

  const handleCreateAutoSheet = async () => {
    if (!isGoogleConnected) {
      showToast('Signing in to Google to create spreadsheet...', 'info');
      const connected = await connectGoogleAccount();
      if (!connected) return;
    }

    const res = await createNewGoogleSheetDatabase();
    if (res.success && res.id) {
      setCustomSheetId(res.id);
      setTestResult({
        success: true,
        title: `${centerInfo.name} - Master ERP Database`,
        sheets: [
          'Students', 'Admissions', 'Fee_Transactions', 'Courses_Batches', 
          'Educators', 'Expenses', 'Admin_Credentials', 'Center_Overview',
          'Study_Materials', 'Question_Bank', 'Exams', 'Exam_Submissions',
          'Live_Classes', 'Class_Recordings'
        ]
      });
    }
  };

  const handlePushToSheets = async () => {
    const targetId = cleanSheetId || centerInfo.googleSheetId;
    if (!targetId) {
      showToast('Please link or create a Google Sheet first.', 'error');
      return;
    }

    // If not connected and no webhook configured, prompt user to sign in
    if (!isGoogleConnected && !centerInfo.googleSheetWebhookUrl && !webhookUrl) {
      showToast('Signing in to Google to authorize Sheets API push...', 'info');
      const connected = await connectGoogleAccount();
      if (!connected) {
        showToast('Google Sign-In is required to push data directly via Google Sheets API (Google requires authentication even for "Anyone can edit" sheets). Alternatively, deploy the Apps Script Webhook.', 'error');
        return;
      }
    }

    await syncToGoogleSheets(targetId);
  };

  const handlePullFromSheets = async () => {
    const targetId = cleanSheetId || centerInfo.googleSheetId;
    if (!targetId) {
      showToast('Please link or create a Google Sheet first.', 'error');
      return;
    }

    if (!isGoogleConnected && !centerInfo.googleSheetWebhookUrl && !webhookUrl) {
      showToast('Signing in to Google to read spreadsheet data...', 'info');
      const connected = await connectGoogleAccount();
      if (!connected) {
        showToast('Google Sign-In is required to read data directly via Google Sheets API. Alternatively, deploy the Apps Script Webhook.', 'error');
        return;
      }
    }

    await pullFromGoogleSheets(targetId);
  };

  const handleEnsureAllTabs = async () => {
    const targetId = cleanSheetId || centerInfo.googleSheetId;
    if (!targetId) {
      showToast('Please link or create a Google Sheet first.', 'error');
      return;
    }

    setIsEnsuringTabs(true);
    try {
      const res = await googleSheetsBackendApi.ensureTables(targetId);
      if (res.success) {
        showToast(res.message || 'All 15 tables (including Discounts) verified and formatted in Google Sheet!', 'success');
        await syncToGoogleSheets(targetId);
      } else {
        showToast(res.error || 'Failed to auto-create missing tables in Google Sheet.', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Error ensuring tables in Google Sheet.', 'error');
    } finally {
      setIsEnsuringTabs(false);
    }
  };

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    showToast('Spreadsheet URL copied to clipboard!', 'info');
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyScript = () => {
    const script = googleSheetsService.generateAppsScriptCode(centerInfo.name);
    navigator.clipboard.writeText(script);
    setCopiedScript(true);
    showToast('Google Apps Script code copied to clipboard!', 'success');
    setTimeout(() => setCopiedScript(false), 2500);
  };

  // Webhook Test & Save Handlers
  const handleTestWebhook = async () => {
    if (!webhookUrl.trim()) {
      showToast('Please enter a Google Apps Script Web App URL first.', 'error');
      return;
    }

    setTestingWebhook(true);
    setWebhookStatus(null);
    try {
      const res = await googleSheetsBackendApi.testWebhook(webhookUrl.trim());
      if (res.success) {
        setWebhookStatus({
          success: true,
          message: res.message || 'Webhook ping acknowledged successfully by Apps Script!',
          action: res.action,
          timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        });
        showToast('Webhook endpoint verified & responsive!', 'success');
      } else {
        setWebhookStatus({
          success: false,
          message: res.error || 'Failed to ping webhook endpoint.',
          timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        });
        showToast(res.error || 'Webhook test failed', 'error');
      }
    } catch (err: any) {
      setWebhookStatus({
        success: false,
        message: err.message || 'Network error connecting to webhook endpoint.',
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      });
      showToast('Webhook test error', 'error');
    } finally {
      setTestingWebhook(false);
    }
  };

  const handleSaveWebhookConfig = async () => {
    setSavingWebhook(true);
    try {
      const res = await googleSheetsBackendApi.saveWebhookConfig(webhookUrl.trim(), autoWriteBack);
      if (res.success) {
        updateCenterInfo({
          googleSheetWebhookUrl: webhookUrl.trim(),
          googleSheetAutoWriteBack: autoWriteBack,
          googleSheetWebhookLastStatus: `Configured on ${new Date().toLocaleDateString('en-IN')} ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`
        });
        showToast('Automatic Live Webhook settings saved!', 'success');
      } else {
        showToast(res.error || 'Failed to save webhook settings', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Error saving webhook config', 'error');
    } finally {
      setSavingWebhook(false);
    }
  };

  const handlePushViaWebhook = async () => {
    if (!webhookUrl.trim()) {
      showToast('Please enter your Google Apps Script Web App URL first.', 'error');
      return;
    }
    setPushingWebhook(true);
    try {
      const res = await googleSheetsBackendApi.pushWebhook(webhookUrl.trim(), {
        students,
        admissions,
        payments,
        courses,
        batches,
        educators,
        expenses,
        adminAccounts,
        studyMaterials,
        questions,
        exams,
        examSubmissions,
        liveClasses,
        classRecordings,
        centerInfo
      });
      if (res.success) {
        const nowFormatted = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        setWebhookStatus({
          success: true,
          message: res.message || 'Successfully pushed all 14 tables to Google Sheets via Webhook!',
          timestamp: nowFormatted
        });
        updateCenterInfo({
          googleSheetWebhookUrl: webhookUrl.trim(),
          googleSheetWebhookLastStatus: `Pushed at ${nowFormatted}`
        });
        showToast('All 14 ERP tables synced to Google Sheets via Webhook!', 'success');
      } else {
        setWebhookStatus({
          success: false,
          message: res.error || 'Failed to push data to Google Sheets Webhook.',
          timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        });
        showToast(res.error || 'Webhook push failed', 'error');
      }
    } catch (err: any) {
      setWebhookStatus({
        success: false,
        message: err.message || 'Network error pushing to webhook.',
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      });
      showToast('Webhook push error', 'error');
    } finally {
      setPushingWebhook(false);
    }
  };

  const handlePullViaWebhook = async () => {
    if (!webhookUrl.trim()) {
      showToast('Please enter your Google Apps Script Web App URL first.', 'error');
      return;
    }
    setPullingWebhook(true);
    try {
      const res = await googleSheetsBackendApi.pullWebhook(webhookUrl.trim());
      if (res.success && res.data) {
        const nowFormatted = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        setWebhookStatus({
          success: true,
          message: res.message || 'Successfully pulled latest ERP dataset via Webhook!',
          timestamp: nowFormatted
        });
        updateCenterInfo({
          googleSheetWebhookUrl: webhookUrl.trim(),
          googleSheetWebhookLastStatus: `Pulled at ${nowFormatted}`
        });
        await restoreFullBackup(res.data, { syncCloud: false });
        showToast('Successfully pulled latest live data from Google Sheets via Webhook!', 'success');
      } else {
        setWebhookStatus({
          success: false,
          message: res.error || 'Failed to pull data from Webhook.',
          timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        });
        showToast(res.error || 'Webhook pull failed', 'error');
      }
    } catch (err: any) {
      setWebhookStatus({
        success: false,
        message: err.message || 'Network error pulling from webhook.',
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      });
      showToast('Webhook pull error', 'error');
    } finally {
      setPullingWebhook(false);
    }
  };

  const totalRecords = 
    students.length + 
    payments.length + 
    admissions.length + 
    courses.length + 
    batches.length + 
    educators.length + 
    expenses.length + 
    (adminAccounts?.length || 1) +
    studyMaterials.length +
    questions.length +
    exams.length +
    examSubmissions.length +
    liveClasses.length +
    classRecordings.length;

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-indigo-950 rounded-2xl p-6 text-white border border-emerald-500/30 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0 shadow-inner">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                  <ArrowLeftRight className="w-3 h-3" />
                  14-Table Two-Way Cloud Sync & Instant Webhooks
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white mt-1">
                Google Sheets Remote Database & Live Webhooks Engine
              </h2>
              <p className="text-xs text-slate-300 mt-0.5 max-w-2xl">
                Operate globally with full two-way sync: Push and pull all 14 ERP tables (Students, Admissions, Payments, Courses, Faculty, Expenses, Exams, Study Materials, Live Classes, Class Recordings) or enable automatic live webhooks for instant write-backs on every action.
              </p>
            </div>
          </div>

          {/* Database & Webhook Status Badge */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
            <div className="flex items-center gap-2.5 bg-slate-800/80 border border-emerald-500/40 rounded-xl px-3.5 py-2">
              <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold shadow-inner">
                <Database className="w-3.5 h-3.5" />
              </div>
              <div className="text-left">
                <div className="text-[11px] font-bold text-white leading-tight">
                  14-Table Cloud Database
                </div>
                <div className="text-[10px] text-emerald-400 font-mono leading-tight truncate max-w-[150px]">
                  {centerInfo.googleSheetId || '1HVB5lNLyCIh6Uw0KmSAvaUnlQjfJMroHzAKy1a-4_O4'}
                </div>
              </div>
            </div>

            {autoWriteBack && webhookUrl && (
              <div className="flex items-center gap-2 bg-indigo-950/80 border border-indigo-500/40 rounded-xl px-3 py-2">
                <Zap className="w-4 h-4 text-amber-400 animate-bounce" />
                <div className="text-left">
                  <div className="text-[10px] font-bold text-indigo-200 uppercase">Live Webhook</div>
                  <div className="text-[10px] text-emerald-300 font-semibold">Active & Live</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Configuration Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Two-Way Sync Actions & Live Webhooks */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Google Account Authentication & Authorization Card */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-slate-900">Google Account Authentication</h3>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                      isGoogleConnected 
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                        : 'bg-amber-50 text-amber-800 border-amber-200'
                    }`}>
                      {isGoogleConnected ? '🟢 Connected & Authorized' : '⚠️ Action Required'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Required for direct Google Drive creation, spreadsheet reading, and REST API pushes.
                  </p>
                </div>
              </div>

              <div>
                {isGoogleConnected ? (
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleConnectGoogle}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition cursor-pointer"
                    >
                      Re-authorize
                    </button>
                    <button
                      type="button"
                      onClick={handleDisconnectGoogle}
                      className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold rounded-lg border border-rose-200 transition cursor-pointer"
                    >
                      Disconnect
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={handleConnectGoogle}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white text-xs font-bold rounded-xl shadow-xs transition cursor-pointer"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path fill="#ffffff" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                      <path fill="#ffffff" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                      <path fill="#ffffff" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                      <path fill="#ffffff" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                    </svg>
                    <span>Sign In with Google</span>
                  </button>
                )}
              </div>
            </div>

            {isGoogleConnected ? (
              <div className="flex items-center gap-3 p-3 bg-emerald-50/70 border border-emerald-100 rounded-xl">
                {googleUser?.picture ? (
                  <img src={googleUser.picture} alt="Google" className="w-8 h-8 rounded-full border border-emerald-300" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
                    {googleUser?.name ? googleUser.name[0].toUpperCase() : 'G'}
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-slate-800 truncate">
                    {googleUser?.name || 'Google Authorized User'}
                  </p>
                  <p className="text-[11px] text-slate-500 truncate">
                    {googleUser?.email || 'OAuth Token Active & Valid for REST API'}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-semibold text-emerald-700 bg-white px-2 py-0.5 rounded border border-emerald-200">
                    Drive & Sheets Scope Active
                  </span>
                </div>
              </div>
            ) : (
              <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl space-y-2">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-xs text-amber-900 space-y-1">
                    <p className="font-semibold">
                      Why does Google Sheets require Sign-In even if "Anyone with link can edit" is enabled?
                    </p>
                    <p className="text-[11px] text-amber-800 leading-relaxed">
                      Google's official security rules require programmatic REST API write calls to have an authenticated user OAuth token. Even if a link is public in your browser, Google API endpoints require an active Google sign-in.
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-amber-200/60">
                  <span className="text-[11px] text-amber-700">Click to connect your Google account in 1 step:</span>
                  <button
                    type="button"
                    onClick={handleConnectGoogle}
                    className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-700 hover:bg-amber-800 text-white text-[11px] font-bold rounded-lg transition cursor-pointer"
                  >
                    <span>Authorize Google Account</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Automatic Live Webhooks & Instant Write-Backs Card */}
          <div className="bg-white rounded-2xl p-6 border border-indigo-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-indigo-50 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wide">
                    Automatic Live Webhooks & Instant Write-Backs
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Automatically writes back every new admission, payment, exam submission, material, or question straight to your Google Sheet instantly.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={autoWriteBack}
                    onChange={(e) => setAutoWriteBack(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                  <span className="ml-2 text-xs font-bold text-slate-700">
                    {autoWriteBack ? 'Auto Write-Back ON' : 'Paused'}
                  </span>
                </label>
              </div>
            </div>

            {/* Webhook URL Input & Actions */}
            <div className="space-y-3">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Google Apps Script Web App URL:
              </label>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <input
                  type="url"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  placeholder="https://script.google.com/macros/s/AKfycbx.../exec"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                />
                <button
                  type="button"
                  disabled={testingWebhook || !webhookUrl.trim()}
                  onClick={handleTestWebhook}
                  className="px-4 py-2.5 rounded-xl font-bold text-xs bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition flex items-center justify-center gap-1.5 shrink-0 cursor-pointer disabled:opacity-50"
                >
                  {testingWebhook ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Testing...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Test Endpoint</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  disabled={savingWebhook}
                  onClick={handleSaveWebhookConfig}
                  className="px-4 py-2.5 rounded-xl font-bold text-xs bg-slate-800 hover:bg-slate-900 text-white transition flex items-center justify-center gap-1.5 shrink-0 cursor-pointer disabled:opacity-50"
                >
                  {savingWebhook ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Save URL</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  disabled={pullingWebhook || !webhookUrl.trim()}
                  onClick={handlePullViaWebhook}
                  className="px-4 py-2.5 rounded-xl font-bold text-xs bg-emerald-600 hover:bg-emerald-700 text-white transition flex items-center justify-center gap-1.5 shrink-0 cursor-pointer disabled:opacity-50 shadow-sm"
                >
                  {pullingWebhook ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Pulling Data...</span>
                    </>
                  ) : (
                    <>
                      <CloudDownload className="w-3.5 h-3.5" />
                      <span>Pull from Sheet (Webhook)</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  disabled={pushingWebhook || !webhookUrl.trim()}
                  onClick={handlePushViaWebhook}
                  className="px-4 py-2.5 rounded-xl font-bold text-xs bg-indigo-600 hover:bg-indigo-700 text-white transition flex items-center justify-center gap-1.5 shrink-0 cursor-pointer disabled:opacity-50 shadow-sm"
                >
                  {pushingWebhook ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Pushing 14 Tables...</span>
                    </>
                  ) : (
                    <>
                      <Zap className="w-3.5 h-3.5" />
                      <span>Push via Webhook Now</span>
                    </>
                  )}
                </button>
              </div>

              {/* Webhook Status Display */}
              {webhookStatus && (
                <div className={`p-3.5 rounded-xl text-xs border flex items-start gap-2.5 ${
                  webhookStatus.success ? 'bg-emerald-50 text-emerald-900 border-emerald-200' : 'bg-rose-50 text-rose-900 border-rose-200'
                }`}>
                  {webhookStatus.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <div className="font-semibold leading-relaxed">{webhookStatus.message}</div>
                    {webhookStatus.timestamp && (
                      <div className="text-[10px] text-slate-500 mt-1 font-mono">
                        Last event timestamp: {webhookStatus.timestamp}
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span>Automatic live write-backs active for: <strong>Admissions, Fees, Exams, Study Notes &amp; Schema</strong></span>
                </div>
                <button
                  type="button"
                  onClick={() => setShowScriptModal(true)}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 underline flex items-center gap-1 cursor-pointer shrink-0"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>Get 14-Table Apps Script Code</span>
                </button>
              </div>
            </div>
          </div>

          {/* Two-Way Sync Hub Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                  <ArrowLeftRight className="w-4 h-4 text-emerald-600" />
                  <span>Two-Way 14-Table Data Synchronization Hub</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Synchronize all 14 tables: Upload local ERP state to Google Sheets or download remote modifications into local database.
                </p>
              </div>
              <span className="text-xs font-mono font-bold text-slate-400">
                <span className="text-emerald-600 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> 15 Tables Synchronized (Including Discounts)
                </span>
              </span>
            </div>

            {/* Auto-Create Missing Tables in Sheet Action Banner */}
            <div className="p-3.5 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                  <Table className="w-4 h-4" />
                </div>
                <div>
                  <h5 className="text-xs font-extrabold text-slate-900">Auto-Create Missing Data Tables in Google Sheet</h5>
                  <p className="text-[11px] text-slate-600">
                    Automatically creates and formats all missing tabs (especially <strong>Discounts</strong>, Live Classes, Recordings) with frozen headers in 1-click.
                  </p>
                </div>
              </div>

              <button
                type="button"
                disabled={isEnsuringTabs}
                onClick={handleEnsureAllTabs}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold rounded-xl text-xs shadow-xs transition cursor-pointer shrink-0 disabled:opacity-50 flex items-center gap-1.5"
              >
                {isEnsuringTabs ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Creating Tables...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5" />
                    <span>Auto-Create Missing Tables</span>
                  </>
                )}
              </button>
            </div>

            {/* Two Action Buttons: Push vs Pull */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              {/* Push Action */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4.5 space-y-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-indigo-700 font-bold text-xs uppercase tracking-wider">
                    <CloudUpload className="w-4 h-4" />
                    <span>Direction 1: Export to Sheets</span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 mt-1">Push Local ERP &rarr; Google Sheets</h4>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                    Overwrites and populates all 15 sheets with your latest student admissions, fee receipts, discounts, faculty, exams, study materials, questions, live classes, and recordings.
                  </p>
                </div>

                <button
                  type="button"
                  disabled={isSyncingSheets || isPullingSheets}
                  onClick={handlePushToSheets}
                  className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs text-white shadow-sm transition-all ${
                    isSyncingSheets
                      ? 'bg-indigo-800 cursor-wait'
                      : 'bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 cursor-pointer'
                  }`}
                >
                  {isSyncingSheets ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Pushing all 15 tables to Google Sheets...</span>
                    </>
                  ) : (
                    <>
                      <CloudUpload className="w-3.5 h-3.5" />
                      <span>Push All 15 Tables to Sheet</span>
                    </>
                  )}
                </button>
              </div>

              {/* Pull Action */}
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4.5 space-y-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs uppercase tracking-wider">
                    <CloudDownload className="w-4 h-4" />
                    <span>Direction 2: Import from Sheets</span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 mt-1">Pull Google Sheets &rarr; Local ERP</h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    Fetches all 15 tables from the remote Google Sheet database and updates students, payments, discounts, materials, exams, live classes, recordings, and settings instantly.
                  </p>
                </div>

                <button
                  type="button"
                  disabled={isSyncingSheets || isPullingSheets}
                  onClick={handlePullFromSheets}
                  className={`w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs text-white shadow-sm transition-all ${
                    isPullingSheets
                      ? 'bg-emerald-800 cursor-wait'
                      : 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 cursor-pointer'
                  }`}
                >
                  {isPullingSheets ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Pulling & Parsing Sheet Rows...</span>
                    </>
                  ) : (
                    <>
                      <CloudDownload className="w-3.5 h-3.5" />
                      <span>Pull & Import 15 Tables</span>
                    </>
                  )}
                </button>
              </div>

            </div>

            {/* Active Linked Sheet Status Bar */}
            {centerInfo.googleSheetId && (
              <div className="bg-slate-900 text-white rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Active Linked Cloud Database</span>
                  </div>
                  <div className="text-xs font-mono text-slate-200 truncate max-w-sm">
                    ID: {centerInfo.googleSheetId}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Last Synced: <span className="text-slate-200 font-semibold">{centerInfo.googleSheetLastSynced || 'Never'}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`https://docs.google.com/spreadsheets/d/${centerInfo.googleSheetId}/edit`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-xs transition"
                  >
                    <span>Open in Google Sheets</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>

                  <button
                    type="button"
                    onClick={() => handleCopyUrl(`https://docs.google.com/spreadsheets/d/${centerInfo.googleSheetId}/edit`)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition cursor-pointer"
                    title="Copy Spreadsheet URL"
                  >
                    {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Action Option A: 1-Click Auto Creation */}
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50/50 rounded-2xl p-5 border border-emerald-200 space-y-3">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 uppercase tracking-wider">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>Provision 14-Table Database</span>
                </div>
                <h4 className="text-sm font-bold text-slate-900 mt-1">
                  Create Structured 14-Table ERP Database in 1-Click
                </h4>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  Instantly creates a new Google Spreadsheet titled <strong>"{centerInfo.name} - Master ERP Database"</strong> initialized with all 14 tabs: Students, Admissions, Fee Transactions, Courses, Batches, Educators, Expenses, Admin Credentials, Center Overview, Study Materials, Question Bank, Exams, Exam Submissions, Live Classes, and Class Recordings.
                </p>
              </div>

              <div className="pt-1 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  disabled={isSyncingSheets}
                  onClick={handleCreateAutoSheet}
                  className={`inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-white shadow-md transition-all ${
                    isSyncingSheets
                      ? 'bg-emerald-700 cursor-wait'
                      : 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 cursor-pointer'
                  }`}
                >
                  {isSyncingSheets ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Creating & Initializing 14 Tables in Drive...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Auto-Create 14-Table Google Sheet Database</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setShowScriptModal(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
                >
                  <Code2 className="w-4 h-4 text-indigo-400" />
                  <span>View 14-Table Webhook Script</span>
                </button>
              </div>
            </div>

            {/* Action Option B: Link Existing Sheet ID/URL */}
            <div className="space-y-3 pt-2">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Or Link an Existing Google Sheet (By URL or ID)
              </div>
              
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    value={customSheetId}
                    onChange={(e) => setCustomSheetId(e.target.value)}
                    placeholder="e.g. 1HVB5lNLyCIh6Uw0KmSAvaUnlQjfJMroHzAKy1a-4_O4 or full Google Sheet URL"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-mono"
                  />
                </div>

                <button
                  type="button"
                  disabled={testingAccess || !customSheetId.trim()}
                  onClick={handleTestSpreadsheet}
                  className={`px-4 py-2.5 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                    !customSheetId.trim()
                      ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                      : 'bg-slate-900 hover:bg-slate-800 text-white cursor-pointer'
                  }`}
                >
                  {testingAccess ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Testing...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Test & Link Sheet</span>
                    </>
                  )}
                </button>
              </div>

              {testResult && (
                <div className={`p-3 rounded-xl text-xs border ${
                  testResult.success 
                    ? 'bg-emerald-50 text-emerald-900 border-emerald-200' 
                    : 'bg-red-50 text-red-900 border-red-200'
                }`}>
                  {testResult.success ? (
                    <div className="space-y-1">
                      <div className="font-bold flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Connected to: "{testResult.title}"</span>
                      </div>
                      <div className="text-[11px] text-emerald-700">
                        Existing tabs: {(testResult.sheets || []).join(', ') || 'None (14 new tabs will be created)'}
                      </div>
                    </div>
                  ) : (
                    <div className="font-medium flex items-center gap-1.5">
                      <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                      <span>{testResult.error}</span>
                    </div>
                  )}
                </div>
              )}
            </div>

          </div>

          {/* Database Metrics Overview Across All 14 Tables */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wide flex items-center gap-2">
                  <Database className="w-4 h-4 text-indigo-600" />
                  <span>Current ERP Database Population (14 Tables)</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Live record count across all 14 synchronized tables.
                </p>
              </div>

              <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                {totalRecords} Total Records
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-slate-500 flex items-center gap-1">
                  <Users className="w-3 h-3 text-indigo-600" /> Students
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{students.length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-slate-500 flex items-center gap-1">
                  <GraduationCap className="w-3 h-3 text-emerald-600" /> Admissions
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{admissions.length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-slate-500 flex items-center gap-1">
                  <CreditCard className="w-3 h-3 text-blue-600" /> Fee Receipts
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{payments.length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-slate-500 flex items-center gap-1">
                  <Layers className="w-3 h-3 text-purple-600" /> Courses & Batches
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{courses.length + batches.length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-slate-500 flex items-center gap-1">
                  <Briefcase className="w-3 h-3 text-amber-600" /> Faculty / Edu
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{educators.length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-slate-500 flex items-center gap-1">
                  <BookOpen className="w-3 h-3 text-teal-600" /> Study Materials
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{studyMaterials.length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-slate-500 flex items-center gap-1">
                  <HelpCircle className="w-3 h-3 text-cyan-600" /> Question Bank
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{questions.length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-slate-500 flex items-center gap-1">
                  <Award className="w-3 h-3 text-rose-600" /> Exams & Subs
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{exams.length + examSubmissions.length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-indigo-600 flex items-center gap-1">
                  <Activity className="w-3 h-3 text-indigo-600" /> Live Classes
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{(liveClasses || []).length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-purple-600 flex items-center gap-1">
                  <FileText className="w-3 h-3 text-purple-600" /> Recordings
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{(classRecordings || []).length}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                <span className="text-[10px] uppercase font-bold text-amber-600 flex items-center gap-1">
                  <Percent className="w-3 h-3 text-amber-600" /> Discounts
                </span>
                <p className="text-base font-black text-slate-900 mt-0.5">{(discounts || []).length}</p>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: Database Structure & Global Internet Guide */}
        <div className="space-y-6">
          
          {/* Global Access Instructions */}
          <div className="bg-gradient-to-b from-indigo-50 to-white rounded-2xl p-5 border border-indigo-100 shadow-xs space-y-3">
            <div className="flex items-center gap-2 text-xs font-extrabold text-indigo-900 uppercase tracking-wide">
              <Globe className="w-4 h-4 text-indigo-600" />
              <span>How Webhooks &amp; Two-Way Sync Work:</span>
            </div>

            <ol className="space-y-2.5 text-xs text-slate-700">
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">1</span>
                <div>
                  <strong>Live Instant Write-Backs:</strong> When you deploy the Google Apps Script Web App and enter the URL above, student registrations, fee collections, and test submissions write directly to the sheet in milliseconds.
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">2</span>
                <div>
                  <strong>Complete 14-Table Schema:</strong> Every section of the ERP has its own sheet tab (Live Classes, Class Recordings, Exam Submissions, Study Materials, Questions, Expenses, etc.).
                </div>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-indigo-600 text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">3</span>
                <div>
                  <strong>Bi-Directional Freedom:</strong> Click <strong>Push</strong> to export bulk data to Sheets, or <strong>Pull</strong> to refresh your ERP whenever someone edits rows in Google Sheets.
                </div>
              </li>
            </ol>
          </div>

          {/* Database Tabs Specification (14 Tables) */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
                <Table className="w-4 h-4 text-emerald-600" />
                <span>14 Synchronized Tables Schema</span>
              </h4>
              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">
                14 Tables
              </span>
            </div>

            <div className="space-y-1.5 text-xs max-h-96 overflow-y-auto pr-1">
              <div className="p-2 bg-slate-50 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-slate-800">1. Students</span>
                <span className="text-[10px] text-slate-500">Roll, Aadhaar, Course, Dues</span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-slate-800">2. Admissions</span>
                <span className="text-[10px] text-slate-500">Applications, Approvals, Status</span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-slate-800">3. Fee_Transactions</span>
                <span className="text-[10px] text-slate-500">Receipts, UPI Refs, Amounts</span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-slate-800">4. Courses_Batches</span>
                <span className="text-[10px] text-slate-500">Curriculums, Batches, Fees</span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-slate-800">5. Educators</span>
                <span className="text-[10px] text-slate-500">Faculty, Salaries, Subjects</span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-slate-800">6. Expenses</span>
                <span className="text-[10px] text-slate-500">Center Outflows, Categories</span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-slate-800">7. Admin_Credentials</span>
                <span className="text-[10px] text-slate-500">Sub-admins, Logins, Roles</span>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-slate-800">8. Center_Overview</span>
                <span className="text-[10px] text-slate-500">Center details, UPI, Metrics</span>
              </div>
              <div className="p-2 bg-indigo-50/70 border border-indigo-100 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-indigo-900">9. Study_Materials</span>
                <span className="text-[10px] text-indigo-700">Notes, PDFs, Drive Links</span>
              </div>
              <div className="p-2 bg-indigo-50/70 border border-indigo-100 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-indigo-900">10. Question_Bank</span>
                <span className="text-[10px] text-indigo-700">MCQs, Options, Explanations</span>
              </div>
              <div className="p-2 bg-indigo-50/70 border border-indigo-100 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-indigo-900">11. Exams</span>
                <span className="text-[10px] text-indigo-700">Schedules, Durations, Marks</span>
              </div>
              <div className="p-2 bg-indigo-50/70 border border-indigo-100 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-indigo-900">12. Exam_Submissions</span>
                <span className="text-[10px] text-indigo-700">Scores, Results, Timestamps</span>
              </div>
              <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-emerald-900">13. Live_Classes</span>
                <span className="text-[10px] text-emerald-700">Sessions, Dates, Platforms, Links</span>
              </div>
              <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between">
                <span className="font-mono font-bold text-emerald-900">14. Class_Recordings</span>
                <span className="text-[10px] text-emerald-700">Recorded Classes, Video &amp; Notes</span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Google Apps Script Modal */}
      {showScriptModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                  <Code2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">Complete 14-Table Google Apps Script Webhook API</h3>
                  <p className="text-xs text-slate-500">Deploy as Web App for automatic live write-backs &amp; full 14-table syncing</p>
                </div>
              </div>
              <button
                onClick={() => setShowScriptModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>How to Deploy in 3 Simple Steps:</span>
              </div>
              <ol className="list-decimal list-inside space-y-1 text-[11px] text-amber-800">
                <li>Open your Google Sheet &rarr; Click <strong>Extensions &gt; Apps Script</strong>.</li>
                <li>Delete existing code, paste the script below, and click the <strong>Save</strong> disk icon.</li>
                <li>Click <strong>Deploy &gt; New deployment</strong> &rarr; Select type <strong>Web app</strong> &rarr; Set "Who has access" to <strong>Anyone</strong> &rarr; Click <strong>Deploy</strong> &rarr; Copy the Web App URL and paste it into the Webhook URL field above!</li>
              </ol>
            </div>

            <pre className="bg-slate-900 text-emerald-400 p-4 rounded-xl text-[11px] font-mono overflow-x-auto max-h-80 border border-slate-800 leading-relaxed">
              {googleSheetsService.generateAppsScriptCode(centerInfo.name)}
            </pre>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={handleCopyScript}
                className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition cursor-pointer shadow-sm"
              >
                {copiedScript ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedScript ? 'Copied Code to Clipboard!' : 'Copy 14-Table Apps Script'}</span>
              </button>
              <button
                type="button"
                onClick={() => setShowScriptModal(false)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
