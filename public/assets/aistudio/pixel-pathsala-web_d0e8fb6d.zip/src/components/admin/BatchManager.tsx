import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Batch } from '../../types';
import { getCoursesForClass, getDistinctAcademicClasses } from '../../utils/classCourseMatcher';
import { 
  Layers, 
  Plus, 
  Edit3, 
  Trash2, 
  Clock, 
  Users, 
  User, 
  Calendar, 
  BookOpen,
  GraduationCap,
  Globe,
  Building2
} from 'lucide-react';

const DAYS_LIST = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export const BatchManager: React.FC = () => {
  const { batches, courses, educators, students, addBatch, updateBatch, deleteBatch } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [editingBatchId, setEditingBatchId] = useState<string | null>(null);

  const distinctClasses = getDistinctAcademicClasses(courses);

  // Form state
  const [name, setName] = useState('');
  const [academicClass, setAcademicClass] = useState<string>(distinctClasses[0] || 'Class 10');
  const [courseId, setCourseId] = useState(() => {
    const matched = getCoursesForClass(courses, distinctClasses[0] || 'Class 10');
    return matched[0]?.id || courses[0]?.id || '';
  });
  const [educatorId, setEducatorId] = useState(educators[0]?.id || '');
  const [scheduleDays, setScheduleDays] = useState<string[]>(['Mon', 'Wed', 'Fri']);
  const [timing, setTiming] = useState('04:30 PM - 06:00 PM');
  const [roomNumber, setRoomNumber] = useState('Classroom 101');
  const [maxCapacity, setMaxCapacity] = useState(30);
  const [mode, setMode] = useState<'offline' | 'online'>('offline');
  const [isActive, setIsActive] = useState(true);

  // Available courses dynamically matched for selected class
  const classMatchedCourses = getCoursesForClass(courses, academicClass);

  const handleClassChange = (newClass: string) => {
    setAcademicClass(newClass);
    const matched = getCoursesForClass(courses, newClass);
    if (matched.length > 0) {
      setCourseId(matched[0].id);
    } else {
      setCourseId('');
    }
  };

  const handleOpenAdd = () => {
    setEditingBatchId(null);
    setName('');
    const defaultClass = distinctClasses[0] || 'Class 10';
    setAcademicClass(defaultClass);
    const matched = getCoursesForClass(courses, defaultClass);
    setCourseId(matched[0]?.id || '');
    setEducatorId(educators[0]?.id || '');
    setScheduleDays(['Mon', 'Wed', 'Fri']);
    setTiming('04:30 PM - 06:00 PM');
    setRoomNumber('Classroom 101');
    setMaxCapacity(30);
    setMode('offline');
    setIsActive(true);
    setShowModal(true);
  };

  const handleOpenEdit = (b: Batch) => {
    setEditingBatchId(b.id);
    setName(b.name);
    setAcademicClass(b.academicClass || distinctClasses[0] || 'Class 10');
    setCourseId(b.courseId);
    setEducatorId(b.educatorId);
    setScheduleDays(b.scheduleDays);
    setTiming(b.timing);
    setRoomNumber(b.roomNumber || 'Classroom 101');
    setMaxCapacity(b.maxCapacity);
    setMode(b.mode === 'online' ? 'online' : 'offline');
    setIsActive(b.isActive);
    setShowModal(true);
  };

  const handleToggleDay = (day: string) => {
    setScheduleDays(prev =>
      prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
    );
  };

  const handleSaveBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !timing.trim()) {
      alert('Please fill batch name and timing.');
      return;
    }

    if (editingBatchId) {
      updateBatch(editingBatchId, {
        name: name.trim(),
        courseId,
        academicClass,
        educatorId,
        scheduleDays,
        timing: timing.trim(),
        roomNumber: roomNumber.trim(),
        maxCapacity: Number(maxCapacity),
        mode,
        isActive
      });
    } else {
      addBatch({
        name: name.trim(),
        courseId,
        academicClass,
        educatorId,
        scheduleDays,
        timing: timing.trim(),
        roomNumber: roomNumber.trim(),
        maxCapacity: Number(maxCapacity),
        mode,
        isActive,
        startDate: new Date().toISOString().split('T')[0]
      });
    }

    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header & Add Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            <span>Class Batches & Timetable</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Organize academic batches, map class standards, educators and courses, define weekly time-slots, and manage capacities.
          </p>
        </div>

        <button
          id="btn-add-batch-modal"
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Batch</span>
        </button>
      </div>

      {/* Batches Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {batches.map((batch) => {
          const course = courses.find(c => c.id === batch.courseId);
          const educator = educators.find(e => e.id === batch.educatorId);
          const enrolledCount = students.filter(s => s.batchId === batch.id && s.status === 'active').length;

          return (
            <div
              key={batch.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                    {course?.title || 'Academic Course'}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {/* Batch Mode Badge */}
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${
                      batch.mode === 'online'
                        ? 'bg-blue-50 text-blue-700 border-blue-200'
                        : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    }`}>
                      {batch.mode === 'online' ? (
                        <>
                          <Globe className="w-2.5 h-2.5" />
                          <span>Online</span>
                        </>
                      ) : (
                        <>
                          <Building2 className="w-2.5 h-2.5" />
                          <span>Offline</span>
                        </>
                      )}
                    </span>
                    
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      batch.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                    }`}>
                      {batch.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </div>

                <h3 className="font-bold text-slate-900 text-lg mb-1">
                  {batch.name}
                </h3>

                {/* Class Standard Badge */}
                <div className="mb-2">
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-xs font-bold bg-violet-50 text-violet-700 border border-violet-200">
                    <GraduationCap className="w-3.5 h-3.5 text-violet-600" />
                    <span>Class: {batch.academicClass || 'Class 8-12 & College'}</span>
                  </span>
                </div>

                {/* Meta details */}
                <div className="space-y-2 bg-slate-50 p-3.5 rounded-2xl border border-slate-100 my-3 text-xs text-slate-700">
                  <div className="flex items-center gap-2">
                    <User className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>Faculty: <strong>{educator?.name || 'Assigned Mentor'}</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>Timing: <strong>{batch.timing}</strong></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span>Days: <strong>{batch.scheduleDays.join(', ')}</strong></span>
                  </div>
                  <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-[11px]">
                    <span>Room: {batch.roomNumber || 'Room 101'}</span>
                    <span className="font-bold text-indigo-900">
                      Capacity: {enrolledCount} / {batch.maxCapacity} Seats
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  onClick={() => handleOpenEdit(batch)}
                  className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-xl transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Delete batch "${batch.name}"?`)) {
                      deleteBatch(batch.id);
                    }
                  }}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Batch Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Batch Configuration
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {editingBatchId ? 'Edit Batch Details' : 'Create New Batch'}
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveBatch} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Batch Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Batch 10-A (Evening)"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm"
                />
              </div>

              {/* Class Dropdown Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1 flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Academic Class Section <span className="text-red-500">*</span></span>
                </label>
                <select
                  value={academicClass}
                  onChange={(e) => handleClassChange(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold bg-white"
                >
                  {distinctClasses.map(cls => (
                    <option key={cls} value={cls}>{cls}</option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Assign the academic class level mapped to this batch.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Mapped Course (Filtered by Class) <span className="text-red-500">*</span>
                  </label>
                  {classMatchedCourses.length > 0 ? (
                    <select
                      value={courseId}
                      onChange={(e) => setCourseId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium"
                    >
                      {classMatchedCourses.map(c => (
                        <option key={c.id} value={c.id}>{c.title} ({c.academicClass})</option>
                      ))}
                    </select>
                  ) : (
                    <div>
                      <select
                        disabled
                        className="w-full px-3 py-2 rounded-xl border border-amber-300 bg-amber-50 text-amber-900 text-xs font-medium cursor-not-allowed"
                      >
                        <option value="">No course found for {academicClass}</option>
                      </select>
                      <p className="text-[11px] text-amber-700 font-semibold mt-1">
                        ⚠️ Course not found. Please create a course under {academicClass} first.
                      </p>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Primary Educator <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={educatorId}
                    onChange={(e) => setEducatorId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium"
                  >
                    {educators.map(e => (
                      <option key={e.id} value={e.id}>{e.name} ({e.subject})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Timetable Timing <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={timing}
                    onChange={(e) => setTiming(e.target.value)}
                    placeholder="e.g. 05:00 PM - 06:30 PM"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Room / Lab Number
                  </label>
                  <input
                    type="text"
                    value={roomNumber}
                    onChange={(e) => setRoomNumber(e.target.value)}
                    placeholder="e.g. Room 102"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Schedule Days
                </label>
                <div className="flex flex-wrap gap-2">
                  {DAYS_LIST.map(day => (
                    <button
                      key={day}
                      type="button"
                      onClick={() => handleToggleDay(day)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition ${
                        scheduleDays.includes(day)
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>

              {/* Batch Delivery Mode Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5 flex items-center justify-between">
                  <span>Batch Delivery Mode <span className="text-red-500">*</span></span>
                  <span className="text-[10px] text-slate-400 font-normal">Select Offline or Online</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setMode('offline')}
                    className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                      mode === 'offline'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-800 shadow-xs ring-2 ring-emerald-500/20'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Building2 className={`w-5 h-5 mb-1.5 ${mode === 'offline' ? 'text-emerald-600' : 'text-slate-400'}`} />
                    <span className="text-xs">Offline (Classroom)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMode('online')}
                    className={`flex flex-col items-center justify-center p-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                      mode === 'online'
                        ? 'bg-blue-50 border-blue-500 text-blue-800 shadow-xs ring-2 ring-blue-500/20'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Globe className={`w-5 h-5 mb-1.5 ${mode === 'online' ? 'text-blue-600' : 'text-slate-400'}`} />
                    <span className="text-xs">Online (Live Class)</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Max Student Capacity
                </label>
                <input
                  type="number"
                  min={1}
                  value={maxCapacity}
                  onChange={(e) => setMaxCapacity(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                />
              </div>

              <label className="flex items-center gap-2 text-xs font-bold text-slate-800 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                />
                <span>Active Batch (Allow student enrollments)</span>
              </label>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer"
                >
                  {editingBatchId ? 'Save Changes' : 'Create Batch'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
