import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { getUpiQrCodeUrl } from '../../utils/qrHelper';
import { 
  Building, 
  QrCode, 
  MapPin, 
  Phone, 
  Mail, 
  MessageCircle,
  CheckCircle, 
  Save, 
  Sparkles, 
  Globe, 
  Megaphone, 
  ShieldCheck,
  KeyRound,
  Lock,
  Eye,
  EyeOff,
  ExternalLink,
  HardDriveDownload,
  UploadCloud,
  FileJson,
  Smartphone,
  Download,
  Upload,
  Image as ImageIcon,
  Github,
  GitBranch,
  Loader2
} from 'lucide-react';
import { getWhatsAppUrl } from '../../utils/contactHelper';
import { InteractiveContactTabs } from '../common/InteractiveContactTabs';
import { 
  getDirectApkDownloadUrl, 
  extractGoogleDriveFileId,
  extractGitHubReleaseDetails,
  resolveDirectApkUrl
} from '../../utils/apkHelper';
import { normalizeImageUrl } from '../../utils/imageHelper';

export const CenterSettings: React.FC = () => {
  const { centerInfo, updateCenterInfo, updateAdminPassword, downloadFullBackup, restoreFullBackup, showToast } = useApp();

  const [name, setName] = useState(centerInfo.name);
  const [tagline, setTagline] = useState(centerInfo.tagline);
  const [address, setAddress] = useState(centerInfo.address);
  const [cityState, setCityState] = useState(centerInfo.cityState);
  const [phonePrimary, setPhonePrimary] = useState(centerInfo.phonePrimary);
  const [phoneSecondary, setPhoneSecondary] = useState(centerInfo.phoneSecondary || '');
  const [whatsapp, setWhatsapp] = useState(centerInfo.whatsapp || centerInfo.phonePrimary || '');
  const [email, setEmail] = useState(centerInfo.email);
  const [facebookUrl, setFacebookUrl] = useState(centerInfo.facebookUrl || 'https://facebook.com/pixelpathsala');
  const [youtubeUrl, setYoutubeUrl] = useState(centerInfo.youtubeUrl || 'https://youtube.com/@pixelpathsala');
  const [upiId, setUpiId] = useState(centerInfo.upiId);
  const [upiName, setUpiName] = useState(centerInfo.upiName);
  const [regNumber, setRegNumber] = useState(centerInfo.regNumber);
  const [establishedYear, setEstablishedYear] = useState(centerInfo.establishedYear);
  const [announcement, setAnnouncement] = useState(centerInfo.announcement || '');
  const [welcomeMessage, setWelcomeMessage] = useState(centerInfo.welcomeMessage);
  const [isAdmissionsOpen, setIsAdmissionsOpen] = useState(centerInfo.isAdmissionsOpen);
  const [apkDownloadUrl, setApkDownloadUrl] = useState(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl || '');
  const [logoUrl, setLogoUrl] = useState(centerInfo.logoUrl || '/logo.png');

  // Keep form synchronized when centerInfo is loaded/updated asynchronously
  useEffect(() => {
    if (centerInfo) {
      if (centerInfo.name) setName(centerInfo.name);
      if (centerInfo.tagline) setTagline(centerInfo.tagline);
      if (centerInfo.logoUrl) setLogoUrl(centerInfo.logoUrl);
      if (centerInfo.address) setAddress(centerInfo.address);
      if (centerInfo.cityState) setCityState(centerInfo.cityState);
      if (centerInfo.phonePrimary) setPhonePrimary(centerInfo.phonePrimary);
      if (centerInfo.phoneSecondary !== undefined) setPhoneSecondary(centerInfo.phoneSecondary || '');
      if (centerInfo.whatsapp !== undefined) setWhatsapp(centerInfo.whatsapp || '');
      if (centerInfo.email) setEmail(centerInfo.email);
      if (centerInfo.facebookUrl !== undefined) setFacebookUrl(centerInfo.facebookUrl || '');
      if (centerInfo.youtubeUrl !== undefined) setYoutubeUrl(centerInfo.youtubeUrl || '');
      if (centerInfo.upiId) setUpiId(centerInfo.upiId);
      if (centerInfo.upiName) setUpiName(centerInfo.upiName);
      if (centerInfo.regNumber !== undefined) setRegNumber(centerInfo.regNumber || '');
      if (centerInfo.establishedYear) setEstablishedYear(centerInfo.establishedYear);
      if (centerInfo.announcement !== undefined) setAnnouncement(centerInfo.announcement || '');
      if (centerInfo.welcomeMessage) setWelcomeMessage(centerInfo.welcomeMessage);
      if (centerInfo.isAdmissionsOpen !== undefined) setIsAdmissionsOpen(centerInfo.isAdmissionsOpen);
      if (centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) {
        setApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl || '');
      }
    }
  }, [
    centerInfo.logoUrl,
    centerInfo.name,
    centerInfo.tagline,
    centerInfo.phonePrimary,
    centerInfo.email,
    centerInfo.upiId,
    centerInfo.apkDownloadUrl,
    centerInfo.appDownloadUrl
  ]);

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) {
      showToast('Logo file should be under 3MB', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      const b64 = event.target?.result as string;
      setLogoUrl(b64);
      showToast('New logo loaded! Click Save Settings to apply.', 'info');
    };
    reader.readAsDataURL(file);
  };

  const directApkUrl = getDirectApkDownloadUrl(apkDownloadUrl);
  const driveFileId = extractGoogleDriveFileId(apkDownloadUrl);
  const ghDetails = extractGitHubReleaseDetails(apkDownloadUrl);

  const [resolvedGhAsset, setResolvedGhAsset] = useState<{
    fileName?: string;
    tagName?: string;
    size?: number;
    loading: boolean;
  }>({ loading: false });

  useEffect(() => {
    if (ghDetails) {
      setResolvedGhAsset(prev => ({ ...prev, loading: true }));
      const timer = setTimeout(() => {
        resolveDirectApkUrl(apkDownloadUrl)
          .then((res) => {
            setResolvedGhAsset({
              fileName: res.fileName,
              tagName: res.tagName,
              size: res.size,
              loading: false
            });
          })
          .catch(() => {
            setResolvedGhAsset(prev => ({ ...prev, loading: false }));
          });
      }, 400);
      return () => clearTimeout(timer);
    } else {
      setResolvedGhAsset({ loading: false });
    }
  }, [apkDownloadUrl, ghDetails?.owner, ghDetails?.repo, ghDetails?.tag]);

  // Admin Password Management State
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passMsg, setPassMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    setPassMsg(null);

    if (newPass !== confirmPass) {
      setPassMsg({ text: 'New passwords do not match.', type: 'error' });
      return;
    }

    const res = updateAdminPassword(currentPass, newPass);
    if (res.success) {
      setPassMsg({ text: res.message, type: 'success' });
      setCurrentPass('');
      setNewPass('');
      setConfirmPass('');
    } else {
      setPassMsg({ text: res.message, type: 'error' });
    }
  };

  const previewQrUrl = getUpiQrCodeUrl({
    upiId,
    payeeName: upiName,
    size: 180
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateCenterInfo({
      name: name.trim(),
      tagline: tagline.trim(),
      address: address.trim(),
      cityState: cityState.trim(),
      phonePrimary: phonePrimary.trim(),
      phoneSecondary: phoneSecondary.trim() || undefined,
      whatsapp: whatsapp.trim() || undefined,
      email: email.trim(),
      facebookUrl: facebookUrl.trim() || undefined,
      youtubeUrl: youtubeUrl.trim() || undefined,
      upiId: upiId.trim(),
      upiName: upiName.trim(),
      regNumber: regNumber ? regNumber.trim() : undefined,
      establishedYear: String(establishedYear),
      announcement: announcement.trim() || undefined,
      welcomeMessage: welcomeMessage.trim(),
      admissionOpen: isAdmissionsOpen,
      isAdmissionsOpen,
      logoUrl: logoUrl.trim() || '/logo.png',
      apkDownloadUrl: apkDownloadUrl.trim() || undefined,
      appDownloadUrl: apkDownloadUrl.trim() || undefined
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <Building className="w-5 h-5 text-indigo-600" />
            <span>Center Information & Gateway Configuration</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Configure institute profile, UPI payment gateway credentials, public website notices, and contact information.
          </p>
        </div>

        {savedSuccess && (
          <span className="flex items-center gap-1.5 px-4 py-2 bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold animate-fadeIn">
            <CheckCircle className="w-4 h-4 text-emerald-600" />
            <span>Settings Saved!</span>
          </span>
        )}
      </div>

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column (7 cols): Center Profile & Website Details */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-100">
              <Globe className="w-4 h-4 text-indigo-600" />
              <span>Public Website Identity</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Institute Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Tagline / Motto
                </label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                Announcement Notice Banner (Shown on top of public site)
              </label>
              <div className="flex items-center gap-2">
                <Megaphone className="w-4 h-4 text-amber-500 shrink-0" />
                <input
                  type="text"
                  value={announcement}
                  onChange={(e) => setAnnouncement(e.target.value)}
                  placeholder="e.g. 📢 Admissions Open for Session 2026-27! Free demo classes starting this week."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                Homepage Welcome Overview
              </label>
              <textarea
                rows={2}
                value={welcomeMessage}
                onChange={(e) => setWelcomeMessage(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs resize-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Registration Number
                </label>
                <input
                  type="text"
                  value={regNumber}
                  onChange={(e) => setRegNumber(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Established Year
                </label>
                <input
                  type="number"
                  value={establishedYear}
                  onChange={(e) => setEstablishedYear(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                />
              </div>
            </div>
          </div>

          {/* Institute Brand Logo & Icon Management */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-100">
              <ImageIcon className="w-4 h-4 text-indigo-600" />
              <span>Institute Brand Logo & Official Avatar</span>
            </h3>

            <div className="flex flex-col sm:flex-row items-center gap-6">
              {/* Live Round Logo Preview */}
              <div className="flex flex-col items-center gap-2 shrink-0">
                <div className="w-24 h-24 rounded-full border-4 border-indigo-100 shadow-md overflow-hidden bg-white flex items-center justify-center p-1 relative">
                  <img
                    src={logoUrl || '/logo.png'}
                    alt="Center Logo Preview"
                    onError={(e) => {
                      (e.currentTarget as HTMLImageElement).src = '/logo.png';
                    }}
                    className="w-full h-full object-cover object-center rounded-full"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  Active Logo Preview
                </span>
              </div>

              {/* Upload & Link Controls */}
              <div className="flex-1 space-y-3 w-full">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Upload Logo Image from Computer / Phone
                  </label>
                  <div className="flex flex-wrap items-center gap-2">
                    <label className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 font-bold text-xs cursor-pointer transition">
                      <Upload className="w-4 h-4" />
                      <span>Choose File (PNG/JPG/SVG)</span>
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/jpg,image/svg+xml,image/webp"
                        onChange={handleLogoUpload}
                        className="hidden"
                      />
                    </label>

                    <button
                      type="button"
                      onClick={() => {
                        setLogoUrl('/logo.png');
                        showToast('Reset to official Pixel Pathsala logo.', 'info');
                      }}
                      className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold cursor-pointer transition"
                    >
                      Reset to Official Logo
                    </button>
                  </div>
                  <span className="text-[11px] text-slate-500 mt-1 block">
                    Your logo will immediately be visible across the entire website, mobile APK, portals, and fee receipts.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Or Enter Logo Image URL / Google Drive link
                  </label>
                  <input
                    type="text"
                    value={logoUrl}
                    onChange={(e) => setLogoUrl(e.target.value)}
                    placeholder="/logo.png or https://..."
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Android Mobile App APK Direct Download Settings */}
          <div className="bg-white rounded-3xl border border-emerald-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-emerald-100">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-600" />
                <span>Android Mobile App APK Direct Download Link</span>
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                Direct Download Engine
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Input your <strong>GitHub Releases link</strong> (e.g. <code className="text-slate-800 font-mono bg-slate-100 px-1 py-0.5 rounded">https://github.com/owner/repo/releases/latest</code>), <strong>Google Drive sharing link</strong>, or direct APK URL below.
              The engine automatically converts release pages into <strong>direct automatic file downloads</strong> so visitors and students directly receive the <code className="text-emerald-700 font-mono font-bold">.apk</code> file without seeing any GitHub release webpage or Google Drive container!
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                APK Download Link (GitHub Releases / Google Drive / Direct URL)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-emerald-600">
                  {ghDetails ? <Github className="w-4 h-4 text-slate-800" /> : <Smartphone className="w-4 h-4" />}
                </div>
                <input
                  type="url"
                  value={apkDownloadUrl}
                  onChange={(e) => setApkDownloadUrl(e.target.value)}
                  placeholder="https://github.com/owner/repo/releases/latest or https://drive.google.com/file/d/..."
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs sm:text-sm font-mono text-slate-900"
                />
              </div>
            </div>

            {/* Direct Download Feedback & Test */}
            {apkDownloadUrl && (
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 text-xs space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-1.5">
                  <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" />
                    <span>Automatic Direct Download Active (Webpage Bypassed)</span>
                  </span>

                  {/* GitHub Release Badges */}
                  {ghDetails && (
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-mono text-[10px] bg-slate-900 text-white px-2 py-0.5 rounded font-bold flex items-center gap-1">
                        <Github className="w-3 h-3 text-white" />
                        {ghDetails.owner}/{ghDetails.repo}
                      </span>
                      <span className="font-mono text-[10px] bg-emerald-200 text-emerald-900 px-2 py-0.5 rounded font-bold flex items-center gap-1">
                        <GitBranch className="w-3 h-3" />
                        {ghDetails.tag || 'latest'}
                      </span>
                    </div>
                  )}

                  {/* Google Drive Badge */}
                  {driveFileId && (
                    <span className="font-mono text-[10px] bg-emerald-200/80 text-emerald-900 px-2 py-0.5 rounded font-bold">
                      Google Drive File ID: {driveFileId}
                    </span>
                  )}
                </div>

                {/* GitHub Live Resolved Asset Banner */}
                {ghDetails && (
                  <div className="p-2.5 rounded-xl bg-white border border-emerald-200 text-[11px] space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-700 flex items-center gap-1.5">
                        <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                        <span>GitHub Release Auto-Downloader:</span>
                      </span>
                      {resolvedGhAsset.loading ? (
                        <span className="text-[10px] text-indigo-600 flex items-center gap-1 font-semibold">
                          <Loader2 className="w-3 h-3 animate-spin" /> Resolving APK asset...
                        </span>
                      ) : resolvedGhAsset.fileName ? (
                        <span className="text-[10px] text-emerald-700 font-bold bg-emerald-100 px-2 py-0.5 rounded">
                          ✓ Asset: {resolvedGhAsset.fileName} ({resolvedGhAsset.tagName || 'latest'})
                        </span>
                      ) : null}
                    </div>
                    <p className="text-[11px] text-slate-600">
                      When users click <strong>Download Mobile App</strong>, our server automatically fetches the <code className="font-bold text-emerald-700 font-mono">.apk</code> asset from this GitHub release and directly starts the file download. <em>They will never see the GitHub release HTML page.</em>
                    </p>
                  </div>
                )}

                <div className="text-[11px] text-emerald-800">
                  <span className="font-semibold">Direct Streaming Endpoint:</span>
                  <div className="mt-1 p-2 rounded-lg bg-white border border-emerald-200 font-mono text-[11px] text-slate-700 break-all select-all">
                    {directApkUrl}
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                  <span className="text-[11px] text-slate-500">
                    Click to test immediate APK file download:
                  </span>
                  <a
                    href={directApkUrl}
                    download="PixelPathsala.apk"
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Test Direct Download</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            )}

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 space-y-1">
              <p className="font-semibold text-slate-700">Where this link appears for students & visitors:</p>
              <ul className="list-disc list-inside text-slate-500 space-y-0.5 pl-1">
                <li>Homepage Hero &amp; Top Navigation: Instant 1-Click "Download Mobile App" Button</li>
                <li>Student Login Portal: Instant 1-Click Direct APK Download (Sidebar &amp; Form)</li>
                <li>Unified Student Sign-In Modal: Direct APK Download Link</li>
                <li>Student Dashboard (Logged In): Direct Download Mobile App (.APK) Button</li>
                <li>Direct Download API: <code className="font-mono text-indigo-600">/api/download-apk</code> (bypasses GitHub &amp; Google Drive pages)</li>
              </ul>
            </div>
          </div>

          {/* Contact & Location */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-100">
              <MapPin className="w-4 h-4 text-indigo-600" />
              <span>Campus Address & Helplines</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Center Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  City & State <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={cityState}
                  onChange={(e) => setCityState(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Primary Helpline Phone <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={phonePrimary}
                  onChange={(e) => setPhonePrimary(e.target.value)}
                  placeholder="+91 9775708722"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-emerald-800 uppercase tracking-wide">
                    Official WhatsApp Number <span className="text-red-500">*</span>
                  </label>
                  {whatsapp && (
                    <a
                      href={getWhatsAppUrl(whatsapp, name)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] font-bold text-emerald-600 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                      title="Test live WhatsApp link"
                    >
                      <span>Test Chat</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-emerald-600">
                    <MessageCircle className="w-4 h-4 fill-current" />
                  </div>
                  <input
                    type="tel"
                    required
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    placeholder="+91 9775708722"
                    className="w-full pl-9 pr-3.5 py-2 rounded-xl border border-emerald-300 bg-emerald-50/40 text-emerald-950 focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-mono font-bold"
                  />
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Renders as 1-click interactive WhatsApp chat tab on the public website.
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Office Desk Phone (Alternate)
                </label>
                <input
                  type="tel"
                  value={phoneSecondary}
                  onChange={(e) => setPhoneSecondary(e.target.value)}
                  placeholder="+91 9832014567"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Official Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="pixelpathsala.edu@gmail.com"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>
            </div>

            {/* Social Channels: Facebook & YouTube */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-blue-800 uppercase tracking-wide">
                    Facebook Page URL
                  </label>
                  {facebookUrl && (
                    <a
                      href={facebookUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1 cursor-pointer"
                      title="Open Facebook Page in new tab"
                    >
                      <span>Visit</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
                <input
                  type="url"
                  value={facebookUrl}
                  onChange={(e) => setFacebookUrl(e.target.value)}
                  placeholder="https://facebook.com/pixelpathsala"
                  className="w-full px-3.5 py-2 rounded-xl border border-blue-200 bg-blue-50/30 text-blue-950 focus:outline-none focus:ring-2 focus:ring-blue-500 text-xs font-mono"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Displayed in website header, footer & quick contact buttons.
                </span>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-rose-800 uppercase tracking-wide">
                    YouTube Channel URL
                  </label>
                  {youtubeUrl && (
                    <a
                      href={youtubeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] font-bold text-rose-600 hover:text-rose-800 flex items-center gap-1 cursor-pointer"
                      title="Open YouTube Channel in new tab"
                    >
                      <span>Visit</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
                <input
                  type="url"
                  value={youtubeUrl}
                  onChange={(e) => setYoutubeUrl(e.target.value)}
                  placeholder="https://youtube.com/@pixelpathsala"
                  className="w-full px-3.5 py-2 rounded-xl border border-rose-200 bg-rose-50/30 text-rose-950 focus:outline-none focus:ring-2 focus:ring-rose-500 text-xs font-mono"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Links students to video tutorials, lectures & campus highlights.
                </span>
              </div>
            </div>

            {/* Interactive Preview in Center Settings */}
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Live Interactive Website Contact Tabs Preview:
              </label>
              <InteractiveContactTabs variant="pills" />
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): UPI Payment Gateway Configuration & Live QR */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-100">
              <QrCode className="w-4 h-4 text-indigo-600" />
              <span>Center UPI Payment Gateway</span>
            </h3>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                Official Center UPI ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="9775708722@apl"
                className="w-full px-3.5 py-2.5 rounded-xl border border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-mono font-bold text-indigo-900 bg-indigo-50/50"
              />
              <span className="text-[11px] text-slate-500 mt-1 block">
                This UPI ID is rendered in all student QR codes & online admission receipts.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                Payee Merchant Name
              </label>
              <input
                type="text"
                required
                value={upiName}
                onChange={(e) => setUpiName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium"
              />
            </div>

            {/* Live QR Display Box */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center">
              <span className="text-xs font-bold text-slate-700 block mb-2">
                Live Gateway QR Code Preview
              </span>

              <div className="inline-block p-2 bg-white rounded-2xl border border-slate-200 shadow-xs mb-2">
                {previewQrUrl ? (
                  <img
                    src={previewQrUrl}
                    alt="Live Center UPI QR"
                    className="w-40 h-40 object-contain mx-auto"
                  />
                ) : null}
              </div>

              <div className="text-xs font-mono font-bold text-indigo-900">
                {upiId}
              </div>
              <div className="text-[11px] text-slate-400">
                Merchant: {upiName}
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-sm shadow-md transition cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save All Center Settings</span>
              </button>
            </div>
          </div>

          {/* Admin Password & Security Settings Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 pb-2 border-b border-slate-100">
              <KeyRound className="w-4 h-4 text-indigo-600" />
              <span>Admin Password & Security</span>
            </h3>

            {passMsg && (
              <div className={`p-3 rounded-xl text-xs font-semibold ${passMsg.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'}`}>
                {passMsg.text}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Current Master Password
                </label>
                <input
                  type="password"
                  value={currentPass}
                  onChange={(e) => setCurrentPass(e.target.value)}
                  placeholder="Enter current password"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  New Admin Password
                </label>
                <input
                  type="password"
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  placeholder="At least 4 characters"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                  placeholder="Re-enter new password"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium"
                />
              </div>

              <button
                type="button"
                onClick={handlePasswordChange}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs transition cursor-pointer"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Update Admin Password</span>
              </button>
            </div>
          </div>

          {/* Quick Offline Backup Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <HardDriveDownload className="w-4 h-4 text-emerald-600" />
                <span>Offline JSON Database Backup</span>
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                PORTABLE
              </span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Export all student rosters, fee payments, admissions, and center configurations into a portable JSON snapshot.
            </p>
            <button
              type="button"
              onClick={() => downloadFullBackup()}
              className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs transition cursor-pointer"
            >
              <HardDriveDownload className="w-4 h-4" />
              <span>Download Complete Backup (.json)</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
