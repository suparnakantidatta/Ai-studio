import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Users, 
  BookOpen, 
  CreditCard, 
  Clock, 
  TrendingUp, 
  TrendingDown, 
  FileText, 
  Printer, 
  CheckCircle, 
  AlertCircle, 
  ArrowUpRight, 
  Layers, 
  GraduationCap, 
  Sparkles, 
  QrCode,
  Smartphone,
  Plus,
  FileSpreadsheet,
  Database,
  CloudUpload,
  BarChart3,
  PieChart as PieChartIcon,
  LineChart as LineChartIcon,
  IndianRupee,
  Calendar,
  Filter
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from 'recharts';

interface AdminDashboardProps {
  onNavigateTab: (tab: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigateTab }) => {
  const { 
    students, 
    courses, 
    batches, 
    educators, 
    payments, 
    expenses, 
    admissions, 
    centerInfo,
    setSelectedReceiptForPrint,
    setActiveTab
  } = useApp();

  const [timeRange, setTimeRange] = useState<'session' | 'last6' | 'all'>('session');

  const activeStudents = students.filter(s => s.status === 'active');
  const pendingApprovals = payments.filter(p => p.status === 'pending');
  const pendingAdmissions = admissions.filter(a => a.status === 'pending');

  const totalFeeCollected = payments
    .filter(p => p.status === 'approved')
    .reduce((sum, p) => sum + p.finalAmountPaid, 0);

  const totalPendingAmount = payments
    .filter(p => p.status === 'pending')
    .reduce((sum, p) => sum + p.finalAmountPaid, 0);

  const totalRejectedAmount = payments
    .filter(p => p.status === 'rejected')
    .reduce((sum, p) => sum + p.finalAmountPaid, 0);

  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const netSurplus = totalFeeCollected - totalExpenses;

  const recentPayments = [...payments]
    .sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime())
    .slice(0, 5);

  // Month labels helper
  const MONTH_NAMES = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  // 1. Compute Monthly Revenue Data (Collections vs Expenses)
  const monthlyRevenueData = useMemo(() => {
    // Standard academic session months or dynamic past months
    const sessionMonths = [
      { key: '2026-04', label: 'Apr 2026' },
      { key: '2026-05', label: 'May 2026' },
      { key: '2026-06', label: 'Jun 2026' },
      { key: '2026-07', label: 'Jul 2026' },
      { key: '2026-08', label: 'Aug 2026' },
      { key: '2026-09', label: 'Sep 2026' },
      { key: '2026-10', label: 'Oct 2026' },
      { key: '2026-11', label: 'Nov 2026' },
      { key: '2026-12', label: 'Dec 2026' },
      { key: '2027-01', label: 'Jan 2027' },
      { key: '2027-02', label: 'Feb 2027' },
      { key: '2027-03', label: 'Mar 2027' },
    ];

    return sessionMonths.map(({ key, label }) => {
      // Calculate fee collection for this month
      const collection = payments
        .filter(p => {
          if (p.status !== 'approved') return false;
          // Check paymentDate or monthsCovered
          if (p.paymentDate && p.paymentDate.startsWith(key)) return true;
          if (p.monthsCovered && p.monthsCovered.includes(key)) return true;
          return false;
        })
        .reduce((sum, p) => sum + p.finalAmountPaid, 0);

      // Calculate expenses for this month
      const expenseAmount = expenses
        .filter(e => e.date && e.date.startsWith(key))
        .reduce((sum, e) => sum + e.amount, 0);

      const netProfit = collection - expenseAmount;

      return {
        month: label.split(' ')[0], // 'Apr', 'May', etc.
        fullMonth: label,
        collections: collection,
        expenses: expenseAmount,
        netSurplus: netProfit
      };
    });
  }, [payments, expenses]);

  // 2. Compute New Student Admission Trends Data
  const admissionTrendsData = useMemo(() => {
    const sessionMonths = [
      { key: '2026-04', label: 'Apr 2026' },
      { key: '2026-05', label: 'May 2026' },
      { key: '2026-06', label: 'Jun 2026' },
      { key: '2026-07', label: 'Jul 2026' },
      { key: '2026-08', label: 'Aug 2026' },
      { key: '2026-09', label: 'Sep 2026' },
      { key: '2026-10', label: 'Oct 2026' },
      { key: '2026-11', label: 'Nov 2026' },
      { key: '2026-12', label: 'Dec 2026' },
    ];

    let cumulativeEnrolled = 0;

    return sessionMonths.map(({ key, label }) => {
      // New students enrolled in this month
      const newEnrolled = students.filter(s => {
        if (s.admissionMonth === key) return true;
        if (s.admissionDate && s.admissionDate.startsWith(key)) return true;
        return false;
      }).length;

      // Online applications received in this month
      const newApplications = admissions.filter(a => {
        if (a.appliedDate && a.appliedDate.startsWith(key)) return true;
        return false;
      }).length;

      cumulativeEnrolled += newEnrolled;

      return {
        month: label.split(' ')[0],
        fullMonth: label,
        newAdmissions: newEnrolled,
        onlineApplications: newApplications,
        totalEnrolledCumulative: cumulativeEnrolled
      };
    });
  }, [students, admissions]);

  // 3. Compute Pending Payment Status Distribution Data
  const paymentStatusData = useMemo(() => {
    const approvedCount = payments.filter(p => p.status === 'approved').length;
    const pendingCount = payments.filter(p => p.status === 'pending').length;
    const rejectedCount = payments.filter(p => p.status === 'rejected').length;

    const data = [
      { 
        name: 'Approved / Paid', 
        value: approvedCount, 
        amount: totalFeeCollected,
        color: '#10B981', // Emerald
        pct: payments.length > 0 ? Math.round((approvedCount / payments.length) * 100) : 100
      },
      { 
        name: 'Pending Verification', 
        value: pendingCount, 
        amount: totalPendingAmount,
        color: '#F59E0B', // Amber
        pct: payments.length > 0 ? Math.round((pendingCount / payments.length) * 100) : 0
      },
      { 
        name: 'Rejected / Failed', 
        value: rejectedCount, 
        amount: totalRejectedAmount,
        color: '#EF4444', // Red
        pct: payments.length > 0 ? Math.round((rejectedCount / payments.length) * 100) : 0
      }
    ];

    // Filter out zero items if total > 0, otherwise keep approved
    return data;
  }, [payments, totalFeeCollected, totalPendingAmount, totalRejectedAmount]);

  const clearanceRate = useMemo(() => {
    if (payments.length === 0) return 100;
    const approved = payments.filter(p => p.status === 'approved').length;
    return Math.round((approved / payments.length) * 100);
  }, [payments]);

  // Initials generator
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .substring(0, 2)
      .toUpperCase();
  };

  // Custom Recharts Tooltip Formatter
  const CustomRupeeTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-xs space-y-1.5 backdrop-blur-md">
          <p className="font-bold text-slate-200 border-b border-slate-700/80 pb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5 text-slate-300">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
                <span>{entry.name}:</span>
              </span>
              <span className="font-mono font-bold text-white">
                {typeof entry.value === 'number' && entry.name.toLowerCase().includes('fee') || entry.name.toLowerCase().includes('collection') || entry.name.toLowerCase().includes('expense') || entry.name.toLowerCase().includes('surplus')
                  ? `₹${entry.value.toLocaleString('en-IN')}`
                  : entry.value}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Top Header Row with Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800 tracking-tight">Dashboard Overview</h2>
          <p className="text-xs text-slate-500 mt-0.5">Real-time coaching metrics, fee collections, and student management.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button 
            id="admin-db-googlesheets-btn"
            onClick={() => onNavigateTab('googlesheets')}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs transition-colors cursor-pointer"
          >
            <Database className="w-4 h-4" />
            <span>Google Sheets DB</span>
          </button>
          <button 
            id="admin-db-new-admission-btn"
            onClick={() => onNavigateTab('students')}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs sm:text-sm font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Admission</span>
          </button>
          <button 
            id="admin-db-mis-reports-btn"
            onClick={() => onNavigateTab('reports')}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-50 border border-emerald-200 text-emerald-800 hover:bg-emerald-100 rounded-xl text-xs sm:text-sm font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>MIS Reports</span>
          </button>
        </div>
      </div>

      {/* Alert Banners if there are pending items */}
      {(pendingApprovals.length > 0 || pendingAdmissions.length > 0) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {pendingApprovals.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between gap-4 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold shrink-0">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-amber-950 text-xs sm:text-sm">
                    {pendingApprovals.length} Payment{pendingApprovals.length > 1 ? 's' : ''} Awaiting Approval
                  </div>
                  <div className="text-[11px] text-amber-700">
                    Students submitted UPI or Cash payments (₹{totalPendingAmount.toLocaleString('en-IN')} pending).
                  </div>
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('approvals')}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-lg shadow-xs transition cursor-pointer shrink-0"
              >
                Review &rarr;
              </button>
            </div>
          )}

          {pendingAdmissions.length > 0 && (
            <div className="bg-indigo-50 border border-indigo-200 rounded-2xl p-4 flex items-center justify-between gap-4 shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold shrink-0">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <div className="font-bold text-indigo-950 text-xs sm:text-sm">
                    {pendingAdmissions.length} Online Admission Form{pendingAdmissions.length > 1 ? 's' : ''}
                  </div>
                  <div className="text-[11px] text-indigo-700">
                    New students registered from public website.
                  </div>
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('admissions')}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg shadow-xs transition cursor-pointer shrink-0"
              >
                Process &rarr;
              </button>
            </div>
          )}
        </div>
      )}

      {/* KPI Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {/* Total Students */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <p className="text-slate-500 text-xs font-semibold uppercase tracking-wider mb-1">Total Students</p>
            <p className="text-3xl font-bold text-slate-900 font-mono tracking-tight">{students.length}</p>
          </div>
          <div className="mt-2 text-[11px] text-emerald-600 font-medium flex items-center gap-1">
            <span>↑ {activeStudents.length} actively enrolled</span>
          </div>
        </div>

        {/* Pending Payments */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <p className="text-slate-500 text-xs font-semibold uppercase tracking-wider mb-1">Pending Approvals</p>
            <p className="text-3xl font-bold text-orange-600 font-mono tracking-tight">{pendingApprovals.length}</p>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 font-medium">
            {pendingApprovals.length > 0 ? `₹${totalPendingAmount.toLocaleString('en-IN')} awaiting verification` : 'All transactions cleared'}
          </div>
        </div>

        {/* Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <p className="text-slate-500 text-xs font-semibold uppercase tracking-wider mb-1">Revenue (Fee Collections)</p>
            <p className="text-3xl font-bold text-slate-900 font-mono tracking-tight">₹{totalFeeCollected.toLocaleString('en-IN')}</p>
          </div>
          <div className="mt-2 text-[11px] text-emerald-600 font-medium">
            ₹{netSurplus >= 0 ? netSurplus.toLocaleString('en-IN') : '0'} net operating balance
          </div>
        </div>

        {/* Active Batches */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <p className="text-slate-500 text-xs font-semibold uppercase tracking-wider mb-1">Active Batches</p>
            <p className="text-3xl font-bold text-indigo-600 font-mono tracking-tight">{batches.length}</p>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 font-medium font-mono">
            {courses.length} Courses • {educators.length} Mentors
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 📊 RECHARTS ANALYTICS & VISUALIZATIONS SECTION                            */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Chart 1: Monthly Revenue (Bar/Area Chart) - 8 Columns */}
        <div className="lg:col-span-8 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <BarChart3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-sm sm:text-base">Monthly Revenue & Fee Collections</h3>
                  <p className="text-[11px] text-slate-500">Monthly student tuition fee collections vs operational expenses (₹ INR)</p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-lg">
                Session 2026-27
              </span>
            </div>
          </div>

          {/* Revenue Chart Visual */}
          <div className="h-64 sm:h-72 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyRevenueData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorCollections" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#4F46E5" stopOpacity={0.9} />
                    <stop offset="100%" stopColor="#6366F1" stopOpacity={0.6} />
                  </linearGradient>
                  <linearGradient id="colorExpenses" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#F43F5E" stopOpacity={0.8} />
                    <stop offset="100%" stopColor="#FB7185" stopOpacity={0.4} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                <XAxis 
                  dataKey="month" 
                  tick={{ fontSize: 11, fill: '#64748B' }} 
                  axisLine={{ stroke: '#CBD5E1' }}
                  tickLine={false}
                />
                <YAxis 
                  tick={{ fontSize: 11, fill: '#64748B' }} 
                  axisLine={{ stroke: '#CBD5E1' }}
                  tickLine={false}
                  tickFormatter={(val) => `₹${val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}`}
                />
                <Tooltip content={<CustomRupeeTooltip />} />
                <Legend 
                  verticalAlign="top" 
                  align="right"
                  wrapperStyle={{ paddingBottom: '8px', fontSize: '11px', fontWeight: 600 }}
                />
                <Bar 
                  dataKey="collections" 
                  name="Fee Collections" 
                  fill="url(#colorCollections)" 
                  radius={[6, 6, 0, 0]} 
                  maxBarSize={32}
                />
                <Bar 
                  dataKey="expenses" 
                  name="Expenses" 
                  fill="url(#colorExpenses)" 
                  radius={[6, 6, 0, 0]} 
                  maxBarSize={32}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-3 mt-2 border-t border-slate-100 text-center">
            <div className="p-2 rounded-xl bg-indigo-50/70">
              <span className="text-[10px] uppercase font-bold text-indigo-700 block">Total Collections</span>
              <span className="text-xs sm:text-sm font-black font-mono text-indigo-900">₹{totalFeeCollected.toLocaleString('en-IN')}</span>
            </div>
            <div className="p-2 rounded-xl bg-rose-50/70">
              <span className="text-[10px] uppercase font-bold text-rose-700 block">Total Expenses</span>
              <span className="text-xs sm:text-sm font-black font-mono text-rose-900">₹{totalExpenses.toLocaleString('en-IN')}</span>
            </div>
            <div className="p-2 rounded-xl bg-emerald-50/70">
              <span className="text-[10px] uppercase font-bold text-emerald-700 block">Operating Surplus</span>
              <span className="text-xs sm:text-sm font-black font-mono text-emerald-900">₹{netSurplus.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        {/* Chart 2: Pending Payment Status Distribution (Donut Pie Chart) - 4 Columns */}
        <div className="lg:col-span-4 bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
          <div className="flex items-center gap-2 mb-3 pb-3 border-b border-slate-100">
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <PieChartIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Payment Status Distribution</h3>
              <p className="text-[11px] text-slate-500">Approved, Pending & Rejected Fee Logs</p>
            </div>
          </div>

          {/* Donut Chart Visual */}
          <div className="relative h-48 sm:h-52 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={paymentStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={52}
                  outerRadius={78}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {paymentStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="#FFFFFF" strokeWidth={2} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: any, name: any, item: any) => [
                    `${value} receipts (${item.payload.pct}%) • ₹${item.payload.amount.toLocaleString('en-IN')}`,
                    name
                  ]}
                />
              </PieChart>
            </ResponsiveContainer>

            {/* Center Donut Label */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-xl font-black text-slate-800 font-mono">{clearanceRate}%</span>
              <span className="text-[9px] uppercase font-bold text-slate-400">Clearance</span>
            </div>
          </div>

          {/* Status Breakdown Legend Chips */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            {paymentStatusData.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs p-1.5 rounded-lg hover:bg-slate-50 transition">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                  <span className="font-medium text-slate-700 text-[11px]">{item.name}</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <span className="font-bold text-slate-800 text-[11px]">{item.value}</span>
                  <span className="text-[10px] text-slate-400">({item.pct}%)</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Chart 3: New Student Admission Trends (Line / Area Chart) */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-4 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <LineChartIcon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">New Student Admission Trends</h3>
              <p className="text-[11px] text-slate-500">Monthly new student enrollments vs online admission application submissions</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={() => onNavigateTab('admissions')}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer"
            >
              View Admission Queue &rarr;
            </button>
          </div>
        </div>

        <div className="h-60 sm:h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={admissionTrendsData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorAdmissions" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#4F46E5" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#4F46E5" stopOpacity={0.02} />
                </linearGradient>
                <linearGradient id="colorApps" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10B981" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#10B981" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
              <XAxis 
                dataKey="month" 
                tick={{ fontSize: 11, fill: '#64748B' }} 
                axisLine={{ stroke: '#CBD5E1' }}
                tickLine={false}
              />
              <YAxis 
                tick={{ fontSize: 11, fill: '#64748B' }} 
                axisLine={{ stroke: '#CBD5E1' }}
                tickLine={false}
                allowDecimals={false}
              />
              <Tooltip content={<CustomRupeeTooltip />} />
              <Legend 
                verticalAlign="top" 
                align="right"
                wrapperStyle={{ paddingBottom: '8px', fontSize: '11px', fontWeight: 600 }}
              />
              <Area 
                type="monotone" 
                dataKey="newAdmissions" 
                name="Enrolled Students" 
                stroke="#4F46E5" 
                strokeWidth={2.5}
                fillOpacity={1} 
                fill="url(#colorAdmissions)" 
                activeDot={{ r: 6, fill: '#4F46E5', stroke: '#FFFFFF', strokeWidth: 2 }}
              />
              <Area 
                type="monotone" 
                dataKey="onlineApplications" 
                name="Online Applications" 
                stroke="#10B981" 
                strokeWidth={2}
                fillOpacity={1} 
                fill="url(#colorApps)" 
                activeDot={{ r: 5, fill: '#10B981', stroke: '#FFFFFF', strokeWidth: 2 }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Main 12-Column Layout for Recent Activity & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 8-Columns: Recent Fee Collection Table */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-slate-800 text-sm">Recent Fee Collection</h3>
            <button 
              onClick={() => onNavigateTab('fees')}
              className="text-xs text-indigo-600 hover:text-indigo-800 font-semibold cursor-pointer"
            >
              View All History &rarr;
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-50 text-slate-500 text-[11px] uppercase font-bold tracking-wider sticky top-0 border-b border-slate-100">
                <tr>
                  <th className="px-5 py-3">Student Name</th>
                  <th className="px-5 py-3">Months Covered</th>
                  <th className="px-5 py-3">Amount</th>
                  <th className="px-5 py-3">Status</th>
                  <th className="px-5 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentPayments.map((pay) => (
                  <tr key={pay.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-indigo-50 text-indigo-700 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0">
                          {getInitials(pay.studentName)}
                        </div>
                        <div className="flex flex-col">
                          <span className="font-medium text-slate-900">{pay.studentName}</span>
                          <span className="text-[10px] text-slate-400 font-mono">Receipt: {pay.receiptNo}</span>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-slate-600 font-medium text-xs">
                      {pay.month}
                    </td>
                    <td className="px-5 py-3.5 font-mono font-bold text-slate-900">
                      ₹{pay.finalAmountPaid.toLocaleString('en-IN')}
                    </td>
                    <td className="px-5 py-3.5">
                      {pay.status === 'approved' ? (
                        <span className="px-2 py-0.5 bg-green-100 text-green-700 text-[10px] font-bold rounded-full uppercase tracking-wider">
                          Paid
                        </span>
                      ) : pay.status === 'pending' ? (
                        <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 text-[10px] font-bold rounded-full uppercase tracking-wider">
                          Pending
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-red-100 text-red-700 text-[10px] font-bold rounded-full uppercase tracking-wider">
                          Rejected
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      {pay.status === 'pending' ? (
                        <button 
                          onClick={() => onNavigateTab('approvals')}
                          className="text-indigo-600 font-semibold text-xs px-3 py-1 hover:bg-indigo-50 rounded-lg cursor-pointer"
                        >
                          Approve
                        </button>
                      ) : (
                        <button 
                          onClick={() => setSelectedReceiptForPrint(pay)}
                          className="text-slate-500 hover:text-indigo-600 font-semibold text-xs px-3 py-1 hover:bg-slate-50 rounded-lg cursor-pointer inline-flex items-center gap-1"
                        >
                          <Printer className="w-3 h-3" />
                          <span>Receipt</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right 4-Columns: Student App Preview & Quick Actions */}
        <div className="lg:col-span-4 space-y-6">
          {/* Indigo Student App Preview Card */}
          <div className="bg-indigo-700 rounded-2xl p-5 text-white shadow-md relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="font-bold text-base mb-3 flex items-center justify-between">
                <span>Student App Preview</span>
                <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-mono">UPI Enabled</span>
              </h3>

              <div className="bg-white/10 rounded-xl p-4 backdrop-blur-xs border border-white/20 space-y-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-slate-800 shadow-xs shrink-0">
                    <QrCode className="w-6 h-6 text-indigo-700" />
                  </div>
                  <div className="overflow-hidden">
                    <p className="text-[10px] font-bold uppercase tracking-wider opacity-70">Official Center UPI</p>
                    <p className="text-xs font-mono font-bold truncate text-white">{centerInfo.upiId}</p>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-bold">
                    <span className="opacity-80">Payment Gateway</span>
                    <span className="text-emerald-300">Ready</span>
                  </div>
                  <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
                    <div className="w-4/5 h-full bg-emerald-400 rounded-full"></div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button 
                    onClick={() => setActiveTab('student-portal')}
                    className="bg-white hover:bg-slate-100 text-indigo-700 text-[11px] font-bold py-2 rounded-lg text-center transition cursor-pointer shadow-xs"
                  >
                    Open Portal
                  </button>
                  <button 
                    onClick={() => onNavigateTab('fees')}
                    className="bg-indigo-800 hover:bg-indigo-900 text-white text-[11px] font-bold py-2 rounded-lg border border-white/20 text-center transition cursor-pointer"
                  >
                    Collect Fees
                  </button>
                </div>
              </div>
            </div>
            {/* Subtle decorative circle */}
            <div className="absolute -right-8 -bottom-8 w-36 h-36 bg-white/5 rounded-full pointer-events-none"></div>
          </div>

          {/* Quick Actions Grid */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider mb-3">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-2.5">
              <div 
                onClick={() => onNavigateTab('discounts')}
                className="p-3 border border-slate-100 rounded-xl hover:bg-slate-50 hover:border-indigo-200 cursor-pointer flex flex-col items-center gap-1.5 text-center transition"
              >
                <span className="text-lg">📉</span>
                <span className="text-[11px] font-bold text-slate-700 leading-tight">Batch Discounts</span>
              </div>

              <div 
                onClick={() => onNavigateTab('expenses')}
                className="p-3 border border-slate-100 rounded-xl hover:bg-slate-50 hover:border-indigo-200 cursor-pointer flex flex-col items-center gap-1.5 text-center transition"
              >
                <span className="text-lg">💸</span>
                <span className="text-[11px] font-bold text-slate-700 leading-tight">Add Expense</span>
              </div>

              <div 
                onClick={() => onNavigateTab('educators')}
                className="p-3 border border-slate-100 rounded-xl hover:bg-slate-50 hover:border-indigo-200 cursor-pointer flex flex-col items-center gap-1.5 text-center transition"
              >
                <span className="text-lg">🎓</span>
                <span className="text-[11px] font-bold text-slate-700 leading-tight">Educator Directory</span>
              </div>

              <div 
                onClick={() => onNavigateTab('batches')}
                className="p-3 border border-slate-100 rounded-xl hover:bg-slate-50 hover:border-indigo-200 cursor-pointer flex flex-col items-center gap-1.5 text-center transition"
              >
                <span className="text-lg">📚</span>
                <span className="text-[11px] font-bold text-slate-700 leading-tight">Manage Batches</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

