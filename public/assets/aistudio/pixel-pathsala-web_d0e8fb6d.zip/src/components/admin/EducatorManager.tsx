import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { Educator } from '../../types';
import { normalizeImageUrl } from '../../utils/imageHelper';
import { 
  GraduationCap, 
  Plus, 
  Edit3, 
  Trash2, 
  Phone, 
  Mail, 
  Award, 
  DollarSign, 
  Calendar,
  Layers,
  Image,
  Link2,
  CheckCircle,
  AlertCircle,
  Upload,
  User,
  Users
} from 'lucide-react';

export const EducatorManager: React.FC = () => {
  const { educators, batches, addEducator, updateEducator, deleteEducator, updateBatch } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [editingEducatorId, setEditingEducatorId] = useState<string | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('');
  const [qualification, setQualification] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [monthlySalary, setMonthlySalary] = useState(30000);
  const [experienceYears, setExperienceYears] = useState(5);
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  const [assignedBatchIds, setAssignedBatchIds] = useState<string[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Please choose an image smaller than 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result) {
          setPhotoUrl(reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleOpenAdd = () => {
    setEditingEducatorId(null);
    setName('');
    setSubject('');
    setQualification('');
    setPhone('');
    setEmail('');
    setPhotoUrl('');
    setMonthlySalary(30000);
    setExperienceYears(5);
    setStatus('active');
    setAssignedBatchIds([]);
    setShowModal(true);
  };

  const handleOpenEdit = (edu: Educator) => {
    setEditingEducatorId(edu.id);
    setName(edu.name);
    setSubject(edu.subject);
    setQualification(edu.qualification);
    setPhone(edu.phone);
    setEmail(edu.email || '');
    setPhotoUrl(edu.photoUrl || '');
    setMonthlySalary(edu.monthlySalary || 30000);
    setExperienceYears(edu.experienceYears);
    setStatus(edu.status);
    
    // Combine explicit assignedBatchIds and batches where educatorId === edu.id
    const currentBatches = Array.from(new Set([
      ...(edu.assignedBatchIds || []),
      ...batches.filter(b => b.educatorId === edu.id).map(b => b.id)
    ]));
    setAssignedBatchIds(currentBatches);
    setShowModal(true);
  };

  const toggleBatchAssignment = (batchId: string) => {
    setAssignedBatchIds(prev => 
      prev.includes(batchId) ? prev.filter(id => id !== batchId) : [...prev, batchId]
    );
  };

  const handleSaveEducator = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !subject.trim() || !phone.trim()) {
      alert('Please fill mandatory educator fields (Name, Subject, Phone).');
      return;
    }

    const cleanedPhoto = normalizeImageUrl(photoUrl) || photoUrl.trim() || undefined;

    if (editingEducatorId) {
      updateEducator(editingEducatorId, {
        name: name.trim(),
        subject: subject.trim(),
        qualification: qualification.trim(),
        phone: phone.trim(),
        email: email.trim() || undefined,
        photoUrl: cleanedPhoto,
        monthlySalary: Number(monthlySalary),
        experienceYears: Number(experienceYears),
        assignedBatchIds,
        status
      });

      // Also sync batches if updateBatch is available
      if (updateBatch) {
        batches.forEach(b => {
          if (assignedBatchIds.includes(b.id) && b.educatorId !== editingEducatorId) {
            updateBatch(b.id, { educatorId: editingEducatorId });
          }
        });
      }
    } else {
      addEducator({
        name: name.trim(),
        subject: subject.trim(),
        qualification: qualification.trim(),
        phone: phone.trim(),
        email: email.trim() || undefined,
        photoUrl: cleanedPhoto,
        monthlySalary: Number(monthlySalary),
        experienceYears: Number(experienceYears),
        assignedBatchIds,
        status,
        joinDate: new Date().toISOString().split('T')[0]
      });
    }

    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header & Add Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-indigo-600" />
            <span>Faculty & Educator Directory</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Manage teaching staff profiles, profile picture link inputs, subject specializations, qualifications, and payroll structures.
          </p>
        </div>

        <button
          id="btn-add-educator-modal"
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Educator</span>
        </button>
      </div>

      {/* Educators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {educators.map((edu) => {
          const assignedBatches = batches.filter(b => b.educatorId === edu.id);

          return (
            <div
              key={edu.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-4">
                  <div className="flex items-center gap-3">
                    {(() => {
                      const eduPhoto = normalizeImageUrl(edu.photoUrl);
                      return eduPhoto ? (
                        <img
                          src={eduPhoto}
                          alt={edu.name}
                          className="w-14 h-14 rounded-full object-cover shadow-sm border-2 border-indigo-200"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            // Hide image and show fallback style
                            (e.target as HTMLImageElement).onerror = null;
                            (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(edu.name)}&background=4f46e5&color=fff&bold=true`;
                          }}
                        />
                      ) : (
                        <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-600 text-white font-bold text-lg flex items-center justify-center shadow-xs border-2 border-indigo-200">
                          {edu.name.split(' ').slice(0, 2).map(n => n[0]).join('')}
                        </div>
                      );
                    })()}
                    <div>
                      <h3 className="font-bold text-slate-900 text-base">
                        {edu.name}
                      </h3>
                      <div className="text-xs font-semibold text-indigo-600">
                        {edu.subject}
                      </div>
                    </div>
                  </div>

                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    edu.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {edu.status}
                  </span>
                </div>

                <div className="space-y-2.5 bg-slate-50 p-3.5 rounded-2xl border border-slate-100 mb-4 text-xs text-slate-700">
                  <div className="text-slate-600 font-medium">
                    {edu.qualification}
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>Phone: {edu.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Award className="w-3.5 h-3.5 text-amber-500" />
                    <span>Experience: {edu.experienceYears}+ Years</span>
                  </div>
                  {edu.photoUrl && (
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 truncate">
                      <Link2 className="w-3 h-3 text-indigo-500 shrink-0" />
                      <span className="truncate">Photo Link Configured</span>
                    </div>
                  )}

                  {/* Clear Assigned Batches List */}
                  <div className="pt-2 border-t border-slate-200/80">
                    <div className="flex items-center justify-between text-[11px] mb-1.5">
                      <span className="text-slate-500 font-bold flex items-center gap-1">
                        <Users className="w-3 h-3 text-indigo-600" />
                        <span>Batches ({assignedBatches.length}):</span>
                      </span>
                      <span>Salary: <strong className="font-mono text-slate-900">₹{(edu.monthlySalary || 0).toLocaleString('en-IN')}</strong></span>
                    </div>

                    {assignedBatches.length > 0 ? (
                      <div className="flex flex-wrap gap-1 mt-1">
                        {assignedBatches.map(b => (
                          <span
                            key={b.id}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200/80"
                            title={`${b.name} (${b.timing || 'Regular'})`}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full ${b.mode === 'online' ? 'bg-cyan-500' : 'bg-emerald-500'}`} />
                            <span className="truncate max-w-[130px]">{b.name}</span>
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[10px] text-slate-400 italic">No batches assigned yet</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  onClick={() => handleOpenEdit(edu)}
                  className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-xl transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Delete educator ${edu.name}?`)) {
                      deleteEducator(edu.id);
                    }
                  }}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Educator Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Educator Profile
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {editingEducatorId ? 'Edit Educator Record' : 'Add New Educator'}
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEducator} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Dr. Subrata Roy"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm"
                />
              </div>

              {/* Photo Link Input & File Upload with Live Preview */}
              <div className="bg-indigo-50/70 p-4 rounded-2xl border border-indigo-100 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-indigo-950 uppercase tracking-wide flex items-center gap-1.5">
                    <Image className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Educator Profile Photo (Web Link or Device Upload)</span>
                  </label>
                  {photoUrl && (
                    <button
                      type="button"
                      onClick={() => setPhotoUrl('')}
                      className="text-[11px] text-red-600 hover:text-red-700 font-bold cursor-pointer"
                    >
                      Remove Photo
                    </button>
                  )}
                </div>

                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <div className="w-14 h-14 rounded-full overflow-hidden shrink-0 border-2 border-indigo-300 bg-white flex items-center justify-center shadow-xs">
                    {(() => {
                      const previewPhoto = normalizeImageUrl(photoUrl);
                      return previewPhoto ? (
                        <img
                          src={previewPhoto}
                          alt="Preview"
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                          onError={(e) => {
                            (e.target as HTMLImageElement).onerror = null;
                            (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(name || 'Faculty')}&background=4f46e5&color=fff&bold=true`;
                          }}
                        />
                      ) : (
                        <span className="text-[10px] text-indigo-400 font-bold text-center px-1">No Photo</span>
                      );
                    })()}
                  </div>

                  <div className="flex-1 w-full space-y-2">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={photoUrl}
                        onChange={(e) => setPhotoUrl(e.target.value)}
                        placeholder="Paste image URL (Facebook, Google Photos/Drive, Imgur, etc.)..."
                        className="flex-1 px-3 py-2 rounded-xl border border-indigo-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono bg-white"
                      />

                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />

                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="px-3 py-2 bg-white hover:bg-slate-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1 shrink-0"
                        title="Upload directly from device"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload File</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap text-[10px] text-indigo-800 font-medium">
                      <span>✓ Supports Facebook photos</span>
                      <span>•</span>
                      <span>✓ Google Photos & Drive</span>
                      <span>•</span>
                      <span>✓ Direct JPG/PNG web links</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Subject / Domain <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g. Mathematics & Coding"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Contact Phone <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="10-digit number"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Academic Qualification & Degrees <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={qualification}
                  onChange={(e) => setQualification(e.target.value)}
                  placeholder="e.g. M.Sc. Mathematics, B.Ed (CU)"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Monthly Salary (₹)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={monthlySalary}
                    onChange={(e) => setMonthlySalary(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Exp (Years)
                  </label>
                  <input
                    type="number"
                    min={0}
                    value={experienceYears}
                    onChange={(e) => setExperienceYears(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold"
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
              </div>

              {/* Batch Assignment Selector */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Assigned Batches ({assignedBatchIds.length} Selected)</span>
                  </label>
                  <span className="text-[10px] text-slate-500">Click to assign/unassign</span>
                </div>

                {batches.length > 0 ? (
                  <div className="max-h-36 overflow-y-auto p-2 bg-slate-50 rounded-2xl border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {batches.map((b) => {
                      const isAssigned = assignedBatchIds.includes(b.id);
                      return (
                        <button
                          key={b.id}
                          type="button"
                          onClick={() => toggleBatchAssignment(b.id)}
                          className={`p-2 rounded-xl text-left text-xs transition cursor-pointer border flex items-center justify-between gap-2 ${
                            isAssigned
                              ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                              : 'bg-white text-slate-700 border-slate-200 hover:border-indigo-300'
                          }`}
                        >
                          <div className="truncate">
                            <div className="font-bold truncate">{b.name}</div>
                            <div className={`text-[10px] truncate ${isAssigned ? 'text-indigo-100' : 'text-slate-500'}`}>
                              {b.academicClass || 'Class'} • {b.timing || 'Regular'}
                            </div>
                          </div>
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${
                            isAssigned ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {b.mode === 'online' ? 'Online' : 'Offline'}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic p-3 bg-slate-50 rounded-xl border border-slate-200">
                    No batches created yet. You can create batches in the Batches tab.
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="faculty@pixelpathsala.com"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer"
                >
                  {editingEducatorId ? 'Save Changes' : 'Save Educator'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
