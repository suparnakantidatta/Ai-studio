import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdminDashboard } from './AdminDashboard';
import { StudentManager } from './StudentManager';
import { FeeCollectionManager } from './FeeCollectionManager';
import { PaymentApprovalsManager } from './PaymentApprovalsManager';
import { AdmissionProcessor } from './AdmissionProcessor';
import { DiscountManager } from './DiscountManager';
import { CourseManager } from './CourseManager';
import { BatchManager } from './BatchManager';
import { EducatorManager } from './EducatorManager';
import { ExpenseManager } from './ExpenseManager';
import { CenterSettings } from './CenterSettings';
import { ReportsManager } from './ReportsManager';
import { GoogleSheetsSyncManager } from './GoogleSheetsSyncManager';
import { AdminCredentialsManager } from './AdminCredentialsManager';
import { StudyMaterialManager } from './StudyMaterialManager';
import { OnlineExamManager } from './OnlineExamManager';
import { LiveClassManager } from './LiveClassManager';
import { BackupRestoreManager } from './BackupRestoreManager';
import { ApiAndApkHub } from '../api/ApiAndApkHub';
import { 
  LayoutDashboard, 
  CreditCard, 
  Clock, 
  Users, 
  FileText, 
  Percent, 
  BookOpen, 
  Layers, 
  GraduationCap, 
  TrendingDown, 
  Settings,
  Building,
  Smartphone,
  CheckCircle2,
  FileSpreadsheet,
  BarChart3,
  LogOut,
  ShieldCheck,
  UserCheck,
  Database,
  CloudUpload,
  HardDriveDownload,
  KeyRound,
  FolderDown,
  FileQuestion,
  Radio
} from 'lucide-react';

export const AdminLayout: React.FC = () => {
  const { payments, admissions, studyMaterials, exams, liveClasses, centerInfo, setActiveTab, adminUser, logoutAdmin } = useApp();
  const [activeAdminTab, setActiveAdminTab] = useState<string>('dashboard');

  const pendingApprovalsCount = payments.filter(p => p.status === 'pending').length;
  const pendingAdmissionsCount = admissions.filter(a => a.status === 'pending').length;
  const activeLiveCount = liveClasses.filter(c => c.status === 'live').length;
  const postponedClassesCount = liveClasses.filter(c => c.status === 'postponed' || c.isPostponed).length;

  const NAV_GROUPS = [
    {
      group: 'MANAGEMENT',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { 
          id: 'live-classes', 
          label: 'Schedule & Live Classes', 
          icon: Radio, 
          badge: activeLiveCount > 0 ? '🔴 LIVE' : (postponedClassesCount > 0 ? '⚠️ POSTPONED' : (liveClasses.length > 0 ? liveClasses.length : undefined)), 
          badgeColor: activeLiveCount > 0 ? 'bg-rose-600' : (postponedClassesCount > 0 ? 'bg-amber-600' : 'bg-indigo-600') 
        },
        { id: 'students', label: 'Students', icon: Users },
        { 
          id: 'exams', 
          label: 'Online Exams & MCQ Bank', 
          icon: FileQuestion, 
          badge: exams.length > 0 ? exams.length : undefined, 
          badgeColor: 'bg-indigo-600' 
        },
        { 
          id: 'study-materials', 
          label: 'Study Materials', 
          icon: FolderDown, 
          badge: studyMaterials.length > 0 ? studyMaterials.length : undefined, 
          badgeColor: 'bg-indigo-600' 
        },
        { id: 'educators', label: 'Educators', icon: GraduationCap },
        { id: 'courses', label: 'Courses', icon: BookOpen },
        { id: 'batches', label: 'Batches', icon: Layers },
        { 
          id: 'admissions', 
          label: 'Admissions', 
          icon: FileText,
          badge: pendingAdmissionsCount > 0 ? pendingAdmissionsCount : undefined,
          badgeColor: 'bg-indigo-600'
        },
      ]
    },
    {
      group: 'FINANCE & BILLING',
      items: [
        { id: 'fees', label: 'Fee Collection', icon: CreditCard },
        { 
          id: 'approvals', 
          label: 'Payment Approvals', 
          icon: Clock,
          badge: pendingApprovalsCount > 0 ? pendingApprovalsCount : undefined,
          badgeColor: 'bg-amber-500'
        },
        { id: 'discounts', label: 'Discounts', icon: Percent },
        { id: 'expenses', label: 'Center Expenses', icon: TrendingDown },
      ]
    },
    {
      group: 'REPORTS & CLOUD DATABASE',
      items: [
        { 
          id: 'googlesheets', 
          label: 'Google Sheets Database', 
          icon: Database,
          badge: 'CLOUD',
          badgeColor: 'bg-emerald-600'
        },
        { 
          id: 'mobile-apk-api', 
          label: 'Mobile APK & REST API', 
          icon: Smartphone,
          badge: 'APK/API',
          badgeColor: 'bg-emerald-600'
        },
        { 
          id: 'reports', 
          label: 'MIS Excel Exports', 
          icon: FileSpreadsheet,
          badge: 'XLSX',
          badgeColor: 'bg-indigo-600'
        },
      ]
    },
    {
      group: 'SYSTEM SETUP',
      items: [
        { id: 'backup-restore', label: 'Backup & Restore Data', icon: HardDriveDownload, badge: 'OFFLINE', badgeColor: 'bg-emerald-600' },
        { id: 'admin-credentials', label: 'Admin Logins & Security', icon: KeyRound, badge: 'NEW', badgeColor: 'bg-indigo-600' },
        { id: 'settings', label: 'Center & UPI ID', icon: Settings },
      ]
    }
  ];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-4">
      {/* Top Admin Identity & Session Bar */}
      <div className="bg-slate-900 text-white rounded-2xl px-5 py-3.5 border border-slate-800 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-xs border border-indigo-400/30">
            <UserCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-white">{adminUser?.name || 'Director / Center Administrator'}</h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                {adminUser?.role || 'Master Admin'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              Session active &bull; Logged in as <strong className="text-slate-200">{adminUser?.username || 'admin'}</strong>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setActiveTab('student-portal')}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 border border-slate-700"
          >
            <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
            <span>Student Portal</span>
          </button>

          <button
            onClick={() => logoutAdmin()}
            className="px-3 py-1.5 bg-rose-600/90 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 shadow-xs"
            title="Lock & Logout Admin Session"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Desktop & Tablet Layout with Sidebar & Main Panel */}
      <div className="flex flex-col lg:flex-row gap-6 items-start">
        {/* Left Sidebar Navigation */}
        <aside className="w-full lg:w-64 bg-white rounded-2xl border border-slate-200 shadow-sm p-4 shrink-0 flex flex-col justify-between space-y-6">
          <div className="space-y-6">
            {NAV_GROUPS.map((grp) => (
              <div key={grp.group} className="space-y-1">
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-3 mb-2">
                  {grp.group}
                </div>
                {grp.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeAdminTab === item.id;

                  return (
                    <button
                      key={item.id}
                      onClick={() => setActiveAdminTab(item.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-colors cursor-pointer ${
                        isActive
                          ? 'bg-indigo-50 text-indigo-700 font-semibold'
                          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-indigo-600' : 'text-slate-400'}`} />
                        <span>{item.label}</span>
                      </div>
                      {item.badge !== undefined && (
                        <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold text-white ${item.badgeColor}`}>
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Quick Student Portal Card */}
          <div className="p-4 bg-slate-900 rounded-xl text-white text-xs space-y-3 shadow-sm border border-slate-800">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-300">Quick Preview</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            </div>
            <p className="text-slate-400 text-[11px] leading-tight">
              Test Student login via Mobile & Aadhaar with A4 receipts.
            </p>
            <div 
              onClick={() => setActiveTab('student-portal')}
              className="flex items-center gap-2.5 border-t border-slate-800 pt-3 cursor-pointer hover:bg-slate-800/60 p-1.5 rounded-lg transition"
            >
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white shrink-0 shadow-sm">
                <Smartphone className="w-4 h-4" />
              </div>
              <div className="overflow-hidden">
                <p className="font-bold text-white text-xs truncate">Student Portal</p>
                <p className="text-indigo-300 text-[10px] font-mono truncate">{centerInfo.upiId}</p>
              </div>
            </div>
          </div>
        </aside>

        {/* Right Main Content Area */}
        <div className="flex-1 w-full overflow-hidden">
          {activeAdminTab === 'dashboard' && <AdminDashboard onNavigateTab={setActiveAdminTab} />}
          {activeAdminTab === 'live-classes' && <LiveClassManager />}
          {activeAdminTab === 'googlesheets' && <GoogleSheetsSyncManager />}
          {activeAdminTab === 'mobile-apk-api' && <ApiAndApkHub />}
          {activeAdminTab === 'reports' && <ReportsManager />}
          {activeAdminTab === 'exams' && <OnlineExamManager />}
          {activeAdminTab === 'fees' && <FeeCollectionManager />}
          {activeAdminTab === 'approvals' && <PaymentApprovalsManager />}
          {activeAdminTab === 'students' && <StudentManager />}
          {activeAdminTab === 'study-materials' && <StudyMaterialManager />}
          {activeAdminTab === 'admissions' && <AdmissionProcessor />}
          {activeAdminTab === 'discounts' && <DiscountManager />}
          {activeAdminTab === 'courses' && <CourseManager />}
          {activeAdminTab === 'batches' && <BatchManager />}
          {activeAdminTab === 'educators' && <EducatorManager />}
          {activeAdminTab === 'expenses' && <ExpenseManager />}
          {activeAdminTab === 'backup-restore' && <BackupRestoreManager />}
          {activeAdminTab === 'admin-credentials' && <AdminCredentialsManager />}
          {activeAdminTab === 'settings' && <CenterSettings />}
        </div>
      </div>
    </div>
  );
};

