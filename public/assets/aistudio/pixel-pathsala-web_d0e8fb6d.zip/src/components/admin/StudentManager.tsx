import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Student, PaymentMode } from '../../types';
import { getStudentMonthlyBilling, formatMonthKey, calculateTargetDiscount } from '../../utils/feeCalculator';
import { getUpiQrCodeUrl } from '../../utils/qrHelper';
import { 
  getCoursesForClass, 
  getBatchesForCourse, 
  getModesForCourse, 
  getBatchesForCourseAndMode, 
  formatModeLabel,
  getDistinctAcademicClasses,
  getStudentActualClass,
  DeliveryMode 
} from '../../utils/classCourseMatcher';
import { 
  Users, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  CheckCircle, 
  GraduationCap, 
  CreditCard, 
  Phone, 
  BookOpen, 
  Calendar, 
  X, 
  Sparkles, 
  QrCode, 
  Building2, 
  Printer, 
  ArrowRight,
  Eye,
  Radio,
  AlertCircle,
  Clock
} from 'lucide-react';

const MONTH_OPTIONS = [
  { key: '2026-04', label: 'April 2026' },
  { key: '2026-05', label: 'May 2026' },
  { key: '2026-06', label: 'June 2026' },
  { key: '2026-07', label: 'July 2026' },
  { key: '2026-08', label: 'August 2026' },
  { key: '2026-09', label: 'September 2026' },
  { key: '2026-10', label: 'October 2026' },
  { key: '2026-11', label: 'November 2026' },
  { key: '2026-12', label: 'December 2026' },
  { key: '2027-01', label: 'January 2027' },
  { key: '2027-02', label: 'February 2027' },
  { key: '2027-03', label: 'March 2027' }
];

export const StudentManager: React.FC = () => {
  const { 
    students, 
    courses, 
    batches, 
    discounts, 
    payments, 
    centerInfo, 
    addStudent, 
    updateStudent, 
    deleteStudent, 
    collectFee, 
    setSelectedReceiptForPrint 
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'passed_out' | 'dropped'>('all');
  const [batchFilter, setBatchFilter] = useState<string>('all');
  const [modeFilter, setModeFilter] = useState<'all' | 'offline' | 'online' | 'hybrid'>('all');

  // Modal State for Add / Edit
  const [showModal, setShowModal] = useState(false);
  const [editingStudentId, setEditingStudentId] = useState<string | null>(null);

  // Form Fields
  const [name, setName] = useState('');
  const [studentClass, setStudentClass] = useState<string>('Class 10 (Secondary)');
  const [rollNo, setRollNo] = useState('');
  const [mobile, setMobile] = useState('');
  const [aadhaarNo, setAadhaarNo] = useState('');
  const [email, setEmail] = useState('');
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [address, setAddress] = useState('');
  
  // Cascading Selection State: Class -> Course -> Mode -> Batch -> Fee
  const [courseId, setCourseId] = useState(() => {
    const matched = getCoursesForClass(courses, 'Class 10 (Secondary)');
    return matched[0]?.id || courses[0]?.id || '';
  });
  const [selectedMode, setSelectedMode] = useState<string>('offline');
  const [batchId, setBatchId] = useState(() => {
    const matchedCourses = getCoursesForClass(courses, 'Class 10 (Secondary)');
    const initialCourseId = matchedCourses[0]?.id || courses[0]?.id || '';
    const matchedBatches = getBatchesForCourse(batches, initialCourseId);
    return matchedBatches[0]?.id || batches[0]?.id || '';
  });

  const [admissionDate, setAdmissionDate] = useState(new Date().toISOString().split('T')[0]);
  const [admissionMonth, setAdmissionMonth] = useState(() => new Date().toISOString().substring(0, 7));
  const [status, setStatus] = useState<'active' | 'passed_out' | 'dropped'>('active');
  const [customMonthlyFeeOverride, setCustomMonthlyFeeOverride] = useState<string>('');

  // Payment at Admission fields
  const [collectPaymentNow, setCollectPaymentNow] = useState(true);
  const [initialPaymentMode, setInitialPaymentMode] = useState<PaymentMode>('CASH');
  const [initialPaymentRef, setInitialPaymentRef] = useState('');
  const [initialPaymentAmount, setInitialPaymentAmount] = useState<number>(1200);

  // Student Details Inspection Drawer
  const [selectedInspectStudent, setSelectedInspectStudent] = useState<Student | null>(null);

  // Dynamic distinct classes from courses in database
  const distinctClasses = getDistinctAcademicClasses(courses);

  // Dynamic filter courses by selected class
  const availableCourses = getCoursesForClass(courses, studentClass);
  // Dynamic filter modes by selected course
  const availableModes = getModesForCourse(batches, courseId);
  // Dynamic filter batches by selected course and mode
  const availableBatches = getBatchesForCourseAndMode(batches, courseId, selectedMode);

  // Synchronize cascading changes
  const handleClassChange = (newClass: string) => {
    setStudentClass(newClass);
    const matchedCourses = getCoursesForClass(courses, newClass);
    if (matchedCourses.length > 0) {
      const nextCourseId = matchedCourses[0].id;
      setCourseId(nextCourseId);

      const modes = getModesForCourse(batches, nextCourseId);
      const nextMode = modes.includes(selectedMode as DeliveryMode) ? selectedMode : (modes[0] || 'offline');
      setSelectedMode(nextMode);

      const matchedBatches = getBatchesForCourseAndMode(batches, nextCourseId, nextMode);
      const nextBatchId = matchedBatches[0]?.id || '';
      setBatchId(nextBatchId);

      const crs = courses.find(c => c.id === nextCourseId);
      const disc = calculateTargetDiscount({
        studentClass: newClass,
        courseId: nextCourseId,
        batchId: nextBatchId,
        monthKey: admissionMonth || '2026-04',
        baseFee: crs?.monthlyFee || 1200,
        discounts,
        course: crs
      });
      setInitialPaymentAmount(disc.finalFee);
    } else {
      setCourseId('');
      setBatchId('');
      setSelectedMode('offline');
      setInitialPaymentAmount(0);
    }
  };

  const handleCourseChange = (newCourseId: string) => {
    setCourseId(newCourseId);
    if (newCourseId) {
      const modes = getModesForCourse(batches, newCourseId);
      const nextMode = modes.includes(selectedMode as DeliveryMode) ? selectedMode : (modes[0] || 'offline');
      setSelectedMode(nextMode);

      const matchedBatches = getBatchesForCourseAndMode(batches, newCourseId, nextMode);
      const nextBatchId = matchedBatches[0]?.id || '';
      setBatchId(nextBatchId);

      const crs = courses.find(c => c.id === newCourseId);
      const disc = calculateTargetDiscount({
        studentClass,
        courseId: newCourseId,
        batchId: nextBatchId,
        monthKey: admissionMonth || '2026-04',
        baseFee: crs?.monthlyFee || 1200,
        discounts,
        course: crs
      });
      setInitialPaymentAmount(disc.finalFee);
    } else {
      setBatchId('');
      setInitialPaymentAmount(0);
    }
  };

  const handleModeChange = (newMode: string) => {
    setSelectedMode(newMode);
    const matchedBatches = getBatchesForCourseAndMode(batches, courseId, newMode);
    const nextBatchId = matchedBatches[0]?.id || '';
    setBatchId(nextBatchId);

    const crs = courses.find(c => c.id === courseId);
    const disc = calculateTargetDiscount({
      studentClass,
      courseId,
      batchId: nextBatchId,
      monthKey: admissionMonth || '2026-04',
      baseFee: crs?.monthlyFee || 1200,
      discounts,
      course: crs
    });
    setInitialPaymentAmount(disc.finalFee);
  };

  const handleAdmissionDateChange = (newDate: string) => {
    setAdmissionDate(newDate);
    if (newDate) {
      const derivedMonth = newDate.substring(0, 7);
      setAdmissionMonth(derivedMonth);

      const crs = courses.find(c => c.id === courseId);
      const disc = calculateTargetDiscount({
        studentClass,
        courseId,
        batchId,
        monthKey: derivedMonth,
        baseFee: crs?.monthlyFee || 1200,
        discounts,
        course: crs
      });
      setInitialPaymentAmount(disc.finalFee);
    }
  };

  const selectedCourse = courses.find(c => c.id === courseId);
  const defaultFeeSum = selectedCourse?.monthlyFee || 1200;
  const currentEffectiveMonth = admissionDate ? admissionDate.substring(0, 7) : admissionMonth;

  const currentDiscountCalculation = calculateTargetDiscount({
    studentClass,
    courseId,
    batchId,
    studentId: editingStudentId || undefined,
    monthKey: currentEffectiveMonth,
    baseFee: selectedCourse?.monthlyFee || 1200,
    discounts,
    course: selectedCourse
  });

  const handleOpenAdd = () => {
    setEditingStudentId(null);
    setName('');
    const defaultClass = distinctClasses[0] || 'Class 10';
    setStudentClass(defaultClass);
    setRollNo(`PP-${new Date().getFullYear()}-${String(students.length + 1).padStart(3, '0')}`);
    setMobile('');
    setAadhaarNo('');
    setEmail('');
    setGuardianName('');
    setGuardianPhone('');
    setAddress('');
    
    const todayStr = new Date().toISOString().split('T')[0];
    const todayMonth = todayStr.substring(0, 7);
    setAdmissionDate(todayStr);
    setAdmissionMonth(todayMonth);

    const matched = getCoursesForClass(courses, defaultClass);
    if (matched.length > 0) {
      const initialCourseId = matched[0].id;
      setCourseId(initialCourseId);

      const modes = getModesForCourse(batches, initialCourseId);
      const initMode = modes[0] || 'offline';
      setSelectedMode(initMode);

      const matchedBatches = getBatchesForCourseAndMode(batches, initialCourseId, initMode);
      const initBatchId = matchedBatches[0]?.id || '';
      setBatchId(initBatchId);

      const crs = courses.find(c => c.id === initialCourseId);
      const disc = calculateTargetDiscount({
        studentClass: defaultClass,
        courseId: initialCourseId,
        batchId: initBatchId,
        monthKey: todayMonth,
        baseFee: crs?.monthlyFee || 1200,
        discounts,
        course: crs
      });
      setInitialPaymentAmount(disc.finalFee);
    } else {
      setCourseId('');
      setBatchId('');
      setSelectedMode('offline');
      setInitialPaymentAmount(0);
    }

    setStatus('active');
    setCustomMonthlyFeeOverride('');
    setCollectPaymentNow(true);
    setInitialPaymentMode('CASH');
    setInitialPaymentRef('');
    setShowModal(true);
  };

  const handleOpenEdit = (stu: Student) => {
    setEditingStudentId(stu.id);
    setName(stu.name);
    setStudentClass(stu.studentClass || 'Class 10 (Secondary)');
    setRollNo(stu.rollNo);
    setMobile(stu.mobile);
    setAadhaarNo(stu.aadhaarNo);
    setEmail(stu.email || '');
    setGuardianName(stu.guardianName);
    setGuardianPhone(stu.guardianPhone);
    setAddress(stu.address);
    setCourseId(stu.courseId);

    const b = batches.find(batch => batch.id === stu.batchId);
    setSelectedMode(stu.mode || b?.mode || 'offline');
    setBatchId(stu.batchId);

    setAdmissionDate(stu.admissionDate || new Date().toISOString().split('T')[0]);
    setAdmissionMonth(stu.admissionMonth || (stu.admissionDate ? stu.admissionDate.substring(0, 7) : '2026-04'));
    setStatus(stu.status);
    setCustomMonthlyFeeOverride(stu.customMonthlyFeeOverride ? String(stu.customMonthlyFeeOverride) : '');
    setCollectPaymentNow(false);
    setShowModal(true);
  };

  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();

    if (!name.trim() || !mobile.trim() || !aadhaarNo.trim()) {
      alert('Please fill all mandatory fields (Name, Mobile, Aadhaar).');
      return;
    }

    if (!courseId) {
      alert(`No course selected for ${studentClass}. If no courses are found for this class, please create a course for ${studentClass} in the Courses tab first.`);
      return;
    }

    const calculatedMonth = admissionDate ? admissionDate.substring(0, 7) : admissionMonth;

    if (editingStudentId) {
      updateStudent(editingStudentId, {
        name: name.trim(),
        studentClass,
        mode: selectedMode as any,
        rollNo: rollNo.trim(),
        mobile: mobile.trim(),
        aadhaarNo: aadhaarNo.trim(),
        email: email.trim() || undefined,
        guardianName: guardianName.trim(),
        guardianPhone: guardianPhone.trim(),
        address: address.trim(),
        courseId,
        batchId,
        admissionDate,
        admissionMonth: calculatedMonth,
        status,
        customMonthlyFeeOverride: customMonthlyFeeOverride ? Number(customMonthlyFeeOverride) : undefined
      });
      setShowModal(false);
    } else {
      const newStudent = addStudent({
        name: name.trim(),
        studentClass,
        mode: selectedMode as any,
        rollNo: rollNo.trim(),
        mobile: mobile.trim(),
        aadhaarNo: aadhaarNo.trim(),
        email: email.trim() || undefined,
        guardianName: guardianName.trim(),
        guardianPhone: guardianPhone.trim(),
        address: address.trim(),
        courseId,
        batchId,
        admissionDate,
        admissionMonth: calculatedMonth,
        status,
        customMonthlyFeeOverride: customMonthlyFeeOverride ? Number(customMonthlyFeeOverride) : undefined
      });

      // If initial payment collected now:
      if (collectPaymentNow && initialPaymentAmount > 0) {
        const selCourse = courses.find(c => c.id === courseId);
        const selBatch = batches.find(b => b.id === batchId);
        const targetDisc = calculateTargetDiscount({
          studentClass,
          courseId,
          batchId,
          studentId: newStudent.id,
          monthKey: calculatedMonth,
          baseFee: selCourse?.monthlyFee || initialPaymentAmount,
          discounts,
          course: selCourse
        });

        const newPay = collectFee({
          studentId: newStudent.id,
          studentName: newStudent.name,
          studentAadhaar: newStudent.aadhaarNo,
          studentMobile: newStudent.mobile,
          courseTitle: selCourse?.title || 'Enrolled Course',
          batchName: selBatch?.name || 'Batch',
          month: `Admission & ${formatMonthKey(calculatedMonth)}`,
          monthsCovered: [calculatedMonth],
          baseMonthlyFee: selCourse?.monthlyFee || initialPaymentAmount,
          totalBaseFee: selCourse?.monthlyFee || initialPaymentAmount,
          totalDiscount: targetDisc.discountAmount,
          discountBreakdown: targetDisc.notes.length > 0 ? targetDisc.notes.join('; ') : 'Standard Admission',
          finalAmountPaid: initialPaymentAmount,
          remainingDue: Math.max(0, targetDisc.finalFee - initialPaymentAmount),
          paymentMode: initialPaymentMode,
          transactionRef: initialPaymentRef.trim() || 'ADM-INITIAL-RECEIPT',
          status: 'approved',
          paymentDate: admissionDate,
          approvedBy: 'Admin - Desk Admission',
          remarks: targetDisc.notes.length > 0 ? `Admission & 1st month tuition (${targetDisc.notes.join(', ')})` : 'Admission fee + first monthly tuition fee'
        });

        setSelectedReceiptForPrint(newPay);
      }

      setShowModal(false);
    }
  };

  // Filtered student list
  const filteredStudents = students.filter(s => {
    const batch = batches.find(b => b.id === s.batchId);
    const stuMode = s.mode || batch?.mode || 'offline';

    const matchesSearch =
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.rollNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.mobile.includes(searchQuery) ||
      s.aadhaarNo.includes(searchQuery);

    const matchesStatus = statusFilter === 'all' || s.status === statusFilter;
    const matchesBatch = batchFilter === 'all' || s.batchId === batchFilter;
    const matchesMode = modeFilter === 'all' || stuMode === modeFilter;

    return matchesSearch && matchesStatus && matchesBatch && matchesMode;
  });

  return (
    <div className="space-y-6">
      {/* Header & Add Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-600" />
            <span>Student Management & Admissions</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Enroll new students with instant fee payment, manage Active/Passed Out lifecycle, track Aadhaar, learning mode, and batch assignments.
          </p>
        </div>

        <button
          id="btn-add-student-modal"
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Student</span>
        </button>
      </div>

      {/* Filters Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by Name, Roll No, Mobile, Aadhaar..."
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
          {/* Mode Filter */}
          <select
            value={modeFilter}
            onChange={(e) => setModeFilter(e.target.value as any)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
          >
            <option value="all">All Modes</option>
            <option value="offline">Offline Classroom</option>
            <option value="online">Online Live</option>
            <option value="hybrid">Hybrid</option>
          </select>

          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
          >
            <option value="all">All Statuses ({students.length})</option>
            <option value="active">Active Only</option>
            <option value="passed_out">Passed Out Alumni</option>
            <option value="dropped">Dropped / Inactive</option>
          </select>

          {/* Batch filter */}
          <select
            value={batchFilter}
            onChange={(e) => setBatchFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
          >
            <option value="all">All Batches</option>
            {batches.map(b => (
              <option key={b.id} value={b.id}>{b.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Student List Table */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center text-xs font-bold text-slate-700">
          <span>Enrolled Students ({filteredStudents.length} records)</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-slate-100/70 text-slate-600 font-bold border-b border-slate-200">
                <th className="p-3.5">Roll No</th>
                <th className="p-3.5">Student Name</th>
                <th className="p-3.5">Mobile & Aadhaar</th>
                <th className="p-3.5">Mode</th>
                <th className="p-3.5">Enrolled Course / Batch</th>
                <th className="p-3.5">Admission Month</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Fee Dues & Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.map((stu) => {
                const course = courses.find(c => c.id === stu.courseId);
                const batch = batches.find(b => b.id === stu.batchId);
                const billing = getStudentMonthlyBilling(stu, course, discounts, payments);
                const stuMode = stu.mode || batch?.mode || 'offline';

                return (
                  <tr key={stu.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="p-3.5 font-mono font-bold text-indigo-900">
                      {stu.rollNo}
                    </td>
                    <td className="p-3.5">
                      <div className="font-bold text-slate-900">{stu.name}</div>
                      <div className="text-[11px] text-slate-500">Guardian: {stu.guardianName}</div>
                    </td>
                    <td className="p-3.5">
                      <div className="font-mono text-slate-800 font-medium">{stu.mobile}</div>
                      <div className="font-mono text-[11px] text-slate-500">UID: {stu.aadhaarNo}</div>
                    </td>
                    <td className="p-3.5">
                      {stuMode === 'online' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-sky-50 text-sky-700 border border-sky-200">
                          <Radio className="w-3 h-3 text-sky-600 animate-pulse" />
                          <span>Online Live</span>
                        </span>
                      ) : stuMode === 'hybrid' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200">
                          <Sparkles className="w-3 h-3 text-purple-600" />
                          <span>Hybrid</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                          <Building2 className="w-3 h-3 text-indigo-600" />
                          <span>Offline</span>
                        </span>
                      )}
                    </td>
                    <td className="p-3.5 text-xs">
                      <div className="font-semibold text-slate-800 line-clamp-1">{course?.title}</div>
                      <div className="text-slate-500 font-medium">{batch?.name}</div>
                      <div className="mt-1">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-violet-50 text-violet-700 border border-violet-200">
                          <GraduationCap className="w-3 h-3 text-violet-600" />
                          <span>{getStudentActualClass(stu, course, batch)}</span>
                        </span>
                      </div>
                    </td>
                    <td className="p-3.5 font-mono font-medium text-slate-700">
                      {formatMonthKey(stu.admissionMonth)}
                    </td>
                    <td className="p-3.5">
                      <button
                        onClick={() => {
                          const nextStatus = stu.status === 'active' ? 'passed_out' : 'active';
                          updateStudent(stu.id, { status: nextStatus });
                        }}
                        className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold cursor-pointer transition ${
                          stu.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                            : stu.status === 'passed_out'
                            ? 'bg-purple-100 text-purple-800 hover:bg-purple-200'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                        title="Click to toggle status"
                      >
                        {stu.status === 'active' ? <CheckCircle className="w-3 h-3 text-emerald-600" /> : <GraduationCap className="w-3 h-3 text-purple-600" />}
                        <span className="capitalize">{stu.status.replace('_', ' ')}</span>
                      </button>
                    </td>
                    <td className="p-3.5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {/* Due Badge with distinct Green (Fully Paid) and Red (Due) */}
                        {billing.totalDueAmount > 0 ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full font-mono text-xs font-extrabold bg-red-100 text-red-800 border border-red-300 shadow-2xs">
                            <AlertCircle className="w-3.5 h-3.5 text-red-600" />
                            <span>Due: ₹{billing.totalDueAmount.toLocaleString('en-IN')}</span>
                          </span>
                        ) : billing.totalDueAmount < 0 ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full font-mono text-xs font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Advance (-₹{Math.abs(billing.totalDueAmount).toLocaleString('en-IN')})</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full font-mono text-xs font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Fully Paid</span>
                          </span>
                        )}

                        <button
                          onClick={() => setSelectedInspectStudent(stu)}
                          className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition cursor-pointer"
                          title="View complete fee schedule & profile"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => handleOpenEdit(stu)}
                          className="p-1.5 text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                          title="Edit student"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>

                        <button
                          onClick={() => {
                            if (confirm(`Delete student record for ${stu.name}?`)) {
                              deleteStudent(stu.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition cursor-pointer"
                          title="Delete student"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Student Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Student Enrollment Form
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {editingStudentId ? 'Edit Student Details' : 'Add New Student to ERP'}
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveStudent} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Student Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Ananya Das"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Roll Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={rollNo}
                    onChange={(e) => setRollNo(e.target.value)}
                    placeholder="e.g. PP-2026-004"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Mobile Number (Used for Student Login) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={mobile}
                    onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))}
                    placeholder="10-digit mobile"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    AADHAAR Number (Used for Student Login) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={14}
                    value={aadhaarNo}
                    onChange={(e) => setAadhaarNo(e.target.value)}
                    placeholder="12-digit Aadhaar"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Guardian Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={guardianName}
                    onChange={(e) => setGuardianName(e.target.value)}
                    placeholder="Parent / Guardian Name"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Guardian Phone <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={guardianPhone}
                    onChange={(e) => setGuardianPhone(e.target.value.replace(/\D/g, ''))}
                    placeholder="Emergency contact"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Residential Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Address, Locality, Pincode"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              {/* Academic Class & Course Cascading Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1 flex items-center gap-1.5">
                    <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Academic Class Section <span className="text-red-500">*</span></span>
                  </label>
                  <select
                    value={studentClass}
                    onChange={(e) => handleClassChange(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold bg-white"
                  >
                    {distinctClasses.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Enrolled Course (Filtered by Class) <span className="text-red-500">*</span>
                  </label>
                  {availableCourses.length > 0 ? (
                    <select
                      value={courseId}
                      onChange={(e) => handleCourseChange(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold"
                    >
                      {availableCourses.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.title} — ₹{c.monthlyFee}/mo
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div>
                      <select
                        disabled
                        className="w-full px-3.5 py-2 rounded-xl border border-amber-300 bg-amber-50 text-amber-900 text-xs font-medium cursor-not-allowed"
                      >
                        <option value="">No course found for {studentClass}</option>
                      </select>
                      <p className="text-[11px] text-amber-700 font-semibold mt-1">
                        ⚠️ Course not found for {studentClass}. Please add a course for this class in Course Manager.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Delivery Mode & Batch Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Learning Delivery Mode <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={selectedMode}
                    onChange={(e) => handleModeChange(e.target.value)}
                    disabled={availableCourses.length === 0}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium capitalize"
                  >
                    {availableModes.map(m => (
                      <option key={m} value={m}>
                        {formatModeLabel(m)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Assigned Batch (Filtered by Course & Mode)
                  </label>
                  <select
                    value={batchId}
                    onChange={(e) => setBatchId(e.target.value)}
                    disabled={availableCourses.length === 0}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  >
                    {availableBatches.length > 0 ? (
                      availableBatches.map(b => (
                        <option key={b.id} value={b.id}>
                          {b.name} ({b.timing}) • {b.mode || 'offline'}
                        </option>
                      ))
                    ) : (
                      <option value="">No specific batch (Direct Enrollment)</option>
                    )}
                  </select>
                </div>
              </div>

              {/* Date of Admission Calendar & Fee Calculation Month */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Date of Admission <span className="text-red-500">*</span></span>
                  </label>
                  <input
                    type="date"
                    required
                    value={admissionDate}
                    onChange={(e) => handleAdmissionDateChange(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold text-slate-800"
                  />
                  <span className="text-[10px] text-slate-500 mt-0.5 block">
                    Pick admission date
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Billing Start Month
                  </label>
                  <div className="px-3 py-2 rounded-xl border border-indigo-200 bg-indigo-50/50 text-xs font-bold text-indigo-900 flex items-center justify-between">
                    <span>{formatMonthKey(admissionMonth)}</span>
                    <span className="text-[10px] font-normal text-indigo-600">Auto-set</span>
                  </div>
                  <span className="text-[10px] text-indigo-600 mt-0.5 block font-medium">
                    Fees calculated from this month
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Enrollment Status
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold"
                  >
                    <option value="active">Active</option>
                    <option value="passed_out">Passed Out</option>
                    <option value="dropped">Dropped / Inactive</option>
                  </select>
                </div>
              </div>

              {/* Immediate Payment at Admission Section (for new admission) */}
              {!editingStudentId && (
                <div className="mt-4 p-4 bg-indigo-50/70 rounded-2xl border border-indigo-200 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="flex items-center gap-2 text-xs font-bold text-indigo-950 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={collectPaymentNow}
                        onChange={(e) => setCollectPaymentNow(e.target.checked)}
                        className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                      />
                      <span>Collect Initial Admission & 1st Month Fee Right Now</span>
                    </label>

                    {currentDiscountCalculation.discountAmount > 0 && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold border border-emerald-300">
                        <Sparkles className="w-3 h-3 text-emerald-600" />
                        <span>Concession: -₹{currentDiscountCalculation.discountAmount}/mo ({currentDiscountCalculation.notes.join(', ')})</span>
                      </span>
                    )}
                  </div>

                  {/* Fee Calculation Overview */}
                  <div className="p-2.5 bg-white/80 rounded-xl border border-indigo-100 text-xs flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <span className="text-slate-600">
                        Course Base Fee: <strong className="text-slate-900 font-mono">₹{selectedCourse?.monthlyFee || 1200}</strong>
                      </span>
                      {currentDiscountCalculation.discountAmount > 0 && (
                        <span className="text-emerald-700">
                          Discount: <strong className="font-mono font-bold">-₹{currentDiscountCalculation.discountAmount}</strong>
                        </span>
                      )}
                      <span className="text-indigo-900 font-bold">
                        Calculated 1st Month Fee: <strong className="font-mono text-indigo-700 font-black">₹{currentDiscountCalculation.finalFee}</strong>
                      </span>
                    </div>

                    {initialPaymentAmount !== currentDiscountCalculation.finalFee && (
                      <button
                        type="button"
                        onClick={() => setInitialPaymentAmount(currentDiscountCalculation.finalFee)}
                        className="px-2 py-1 bg-indigo-100 hover:bg-indigo-200 text-indigo-800 font-bold rounded-lg text-[10px] cursor-pointer transition"
                      >
                        Reset to Discounted Fee (₹{currentDiscountCalculation.finalFee})
                      </button>
                    )}
                  </div>

                  {collectPaymentNow && (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                          Amount to Collect (₹)
                        </label>
                        <input
                          type="number"
                          value={initialPaymentAmount}
                          onChange={(e) => setInitialPaymentAmount(Number(e.target.value))}
                          className="w-full px-3 py-1.5 bg-white rounded-lg border border-slate-300 text-xs font-mono font-bold text-slate-900"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                          Payment Mode
                        </label>
                        <select
                          value={initialPaymentMode}
                          onChange={(e) => setInitialPaymentMode(e.target.value as PaymentMode)}
                          className="w-full px-3 py-1.5 bg-white rounded-lg border border-slate-300 text-xs font-semibold"
                        >
                          <option value="CASH">Cash at Desk</option>
                          <option value="UPI">UPI (QR 9775708722@apl)</option>
                          <option value="BANK_TRANSFER">Bank NEFT</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                          Ref / Receipt UTR
                        </label>
                        <input
                          type="text"
                          value={initialPaymentRef}
                          onChange={(e) => setInitialPaymentRef(e.target.value)}
                          placeholder="e.g. CSH-ADM-01"
                          className="w-full px-3 py-1.5 bg-white rounded-lg border border-slate-300 text-xs font-mono"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  {editingStudentId ? 'Update Student Record' : 'Save & Enroll Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Student Details Inspection Drawer / Modal */}
      {selectedInspectStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Student Detailed Profile & Ledger
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {selectedInspectStudent.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedInspectStudent(null)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Profile Overview */}
            {(() => {
              const inspectCourse = courses.find(c => c.id === selectedInspectStudent.courseId);
              const inspectBatch = batches.find(b => b.id === selectedInspectStudent.batchId);
              const inspectMode = selectedInspectStudent.mode || inspectBatch?.mode || 'offline';

              return (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 mb-6 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <div>
                    <span className="text-slate-400 block">Roll Number:</span>
                    <strong className="font-mono text-indigo-900">{selectedInspectStudent.rollNo}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Class / Standard:</span>
                    <strong className="font-semibold text-violet-700">{getStudentActualClass(selectedInspectStudent, inspectCourse, inspectBatch)}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Mode:</span>
                    {inspectMode === 'online' ? (
                      <span className="inline-flex items-center gap-1 font-bold text-sky-700">
                        <Radio className="w-3 h-3 text-sky-600 animate-pulse" />
                        <span>Online Live</span>
                      </span>
                    ) : inspectMode === 'hybrid' ? (
                      <span className="inline-flex items-center gap-1 font-bold text-purple-700">
                        <Sparkles className="w-3 h-3 text-purple-600" />
                        <span>Hybrid</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 font-bold text-indigo-700">
                        <Building2 className="w-3 h-3 text-indigo-600" />
                        <span>Offline</span>
                      </span>
                    )}
                  </div>
                  <div>
                    <span className="text-slate-400 block">Aadhaar (UID):</span>
                    <strong className="font-mono text-slate-900">{selectedInspectStudent.aadhaarNo}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Mobile No:</span>
                    <strong className="font-mono text-slate-900">{selectedInspectStudent.mobile}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Admission Month:</span>
                    <strong className="font-mono text-slate-900">{formatMonthKey(selectedInspectStudent.admissionMonth)}</strong>
                  </div>
                </div>
              );
            })()}

            {/* Month-wise schedule */}
            {(() => {
              const crs = courses.find(c => c.id === selectedInspectStudent.courseId);
              const bInfo = getStudentMonthlyBilling(selectedInspectStudent, crs, discounts, payments);

              return (
                <div className="space-y-4">
                  <div className="flex justify-between items-center flex-wrap gap-2">
                    <h4 className="font-bold text-slate-900 text-sm">Month-by-Month Tuition Status</h4>
                    {bInfo.totalDueAmount > 0 ? (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-red-100 text-red-800 border-2 border-red-300 font-mono">
                        <AlertCircle className="w-4 h-4 text-red-600" />
                        <span>Total Due: ₹{bInfo.totalDueAmount.toLocaleString('en-IN')}</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black bg-emerald-100 text-emerald-800 border-2 border-emerald-300 font-mono">
                        <CheckCircle className="w-4 h-4 text-emerald-600" />
                        <span>Fully Paid (₹0 Due)</span>
                      </span>
                    )}
                  </div>

                  <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead className="bg-slate-100 text-slate-600 font-bold">
                        <tr>
                          <th className="p-2.5">Month</th>
                          <th className="p-2.5">Base Fee</th>
                          <th className="p-2.5">Discount</th>
                          <th className="p-2.5">Net Fee</th>
                          <th className="p-2.5">Status</th>
                          <th className="p-2.5 text-right">Receipt</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {bInfo.monthlyStatuses.map(m => (
                          <tr key={m.monthKey}>
                            <td className="p-2.5 font-semibold text-slate-800">{m.monthLabel}</td>
                            <td className="p-2.5 font-mono">₹{m.baseFee}</td>
                            <td className="p-2.5 font-mono text-emerald-600">
                              {m.discountAmount > 0 ? `-₹${m.discountAmount}` : '—'}
                            </td>
                            <td className="p-2.5 font-mono font-bold text-slate-900">₹{m.netFeeDue}</td>
                            <td className="p-2.5">
                              {m.isPaid ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300">
                                  <CheckCircle className="w-3 h-3 text-emerald-600" />
                                  <span>Fully Paid</span>
                                </span>
                              ) : m.isPendingApproval ? (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-amber-100 text-amber-800 border border-amber-300">
                                  <Clock className="w-3 h-3 text-amber-600" />
                                  <span>Pending</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold bg-red-100 text-red-800 border border-red-300">
                                  <AlertCircle className="w-3 h-3 text-red-600" />
                                  <span>Due: ₹{m.netFeeDue}</span>
                                </span>
                              )}
                            </td>
                            <td className="p-2.5 text-right">
                              {m.isPaid && m.paymentId && (
                                <button
                                  onClick={() => {
                                    const p = payments.find(pay => pay.id === m.paymentId);
                                    if (p) setSelectedReceiptForPrint(p);
                                  }}
                                  className="px-2 py-1 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded text-[11px] font-bold cursor-pointer"
                                >
                                  Print A4
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })()}

            <div className="flex justify-end gap-3 pt-5 border-t border-slate-100 mt-6">
              <button
                onClick={() => setSelectedInspectStudent(null)}
                className="px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
