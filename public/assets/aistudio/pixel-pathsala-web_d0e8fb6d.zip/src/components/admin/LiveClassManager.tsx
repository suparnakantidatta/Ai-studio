import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LiveClassSession, ClassRecording, LiveClassStatus, VideoSourceType } from '../../types';
import { getDistinctAcademicClasses, getCoursesForClass, getBatchesForCourse } from '../../utils/classCourseMatcher';
import { cleanMeetingUrl } from '../../utils/imageHelper';
import { ScheduleClassDataTable } from './ScheduleClassDataTable';
import { 
  Video, 
  Radio, 
  Play, 
  Plus, 
  Calendar, 
  Clock, 
  Users, 
  BookOpen, 
  Layers, 
  Link2, 
  ExternalLink, 
  Edit3, 
  Trash2, 
  Search, 
  Filter, 
  CheckCircle2, 
  AlertCircle, 
  Eye, 
  FileText, 
  Sparkles, 
  Copy, 
  Check, 
  X, 
  Film, 
  Youtube, 
  Tv, 
  Share2, 
  GraduationCap,
  PlayCircle
} from 'lucide-react';

export const LiveClassManager: React.FC = () => {
  const { 
    liveClasses, 
    addLiveClass, 
    updateLiveClass, 
    deleteLiveClass, 
    setLiveClassStatus,
    classRecordings,
    addClassRecording,
    updateClassRecording,
    deleteClassRecording,
    courses, 
    batches, 
    educators 
  } = useApp();

  const distinctClasses = getDistinctAcademicClasses(courses);

  const [activeTab, setActiveTab] = useState<'schedule_table' | 'live_sessions' | 'recordings'>('schedule_table');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterClass, setFilterClass] = useState<string>('all');
  const [filterBatchId, setFilterBatchId] = useState<string>('all');
  const [filterCourseId, setFilterCourseId] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Modals state
  const [showLiveModal, setShowLiveModal] = useState(false);
  const [editingLiveSession, setEditingLiveSession] = useState<LiveClassSession | null>(null);

  const [showRecordingModal, setShowRecordingModal] = useState(false);
  const [editingRecording, setEditingRecording] = useState<ClassRecording | null>(null);

  // Video Preview Modal
  const [previewVideo, setPreviewVideo] = useState<{ title: string; url: string; type: VideoSourceType } | null>(null);
  const [copiedSessionId, setCopiedSessionId] = useState<string | null>(null);

  // Form states for Live Session
  const [liveForm, setLiveForm] = useState({
    title: '',
    academicClass: 'All Classes',
    targetClass: 'All Classes',
    subject: '',
    courseId: 'all',
    batchId: 'all',
    educatorName: educators[0]?.name || 'Faculty',
    scheduledDate: new Date().toISOString().split('T')[0],
    startTime: '18:00',
    endTime: '19:30',
    platform: 'google_meet' as 'google_meet' | 'zoom' | 'youtube_live' | 'in_app' | 'other',
    meetingUrl: '',
    meetingPassword: '',
    status: 'scheduled' as LiveClassStatus,
    description: '',
    isRecordingAvailable: false,
    recordingUrl: ''
  });

  // Form states for Class Recording
  const [recForm, setRecForm] = useState({
    title: '',
    academicClass: 'All Classes',
    targetClass: 'All Classes',
    subject: '',
    topic: '',
    chapter: '',
    courseId: 'all',
    batchId: 'all',
    educatorName: educators[0]?.name || 'Faculty',
    recordedDate: new Date().toISOString().split('T')[0],
    durationMinutes: 60,
    videoSourceType: 'youtube' as VideoSourceType,
    videoUrl: '',
    notesPdfUrl: '',
    thumbnailUrl: '',
    description: ''
  });

  // Resolution helpers to resolve educator names cleanly across live sessions and recordings
  const getResolvedEducatorName = (session: LiveClassSession | any): string => {
    if (session.educatorId) {
      const matchedEdu = educators.find(e => e.id === session.educatorId);
      if (matchedEdu) return matchedEdu.name;
    }
    let raw = (session.educatorName || '').trim();
    const eduById = educators.find(e => e.id === raw);
    if (eduById) return eduById.name;
    const eduByName = educators.find(e => e.name.toLowerCase() === raw.toLowerCase());
    if (eduByName) return eduByName.name;

    const isBatchId = raw.startsWith('batch-') || batches.some(b => b.id === raw);
    if (!raw || raw.toLowerCase() === 'all' || raw.toLowerCase() === 'faculty' || isBatchId) {
      const targetBatchId = isBatchId ? raw : session.batchId;
      if (targetBatchId && targetBatchId !== 'all') {
        const batch = batches.find(b => b.id === targetBatchId);
        if (batch && batch.educatorId) {
          const batchEdu = educators.find(e => e.id === batch.educatorId);
          if (batchEdu) return batchEdu.name;
        }
      }
      return educators[0]?.name || 'Senior Faculty';
    }
    return raw;
  };

  const getRecordingEducatorName = (rec: ClassRecording | any): string => {
    let raw = (rec.educatorName || '').trim();
    const eduById = educators.find(e => e.id === raw);
    if (eduById) return eduById.name;
    const eduByName = educators.find(e => e.name.toLowerCase() === raw.toLowerCase());
    if (eduByName) return eduByName.name;
    const isBatchId = raw.startsWith('batch-') || batches.some(b => b.id === raw);
    if (!raw || raw.toLowerCase() === 'all' || raw.toLowerCase() === 'faculty' || isBatchId) {
      const targetBatchId = isBatchId ? raw : rec.batchId;
      if (targetBatchId && targetBatchId !== 'all') {
        const batch = batches.find(b => b.id === targetBatchId);
        if (batch && batch.educatorId) {
          const edu = educators.find(e => e.id === batch.educatorId);
          if (edu) return edu.name;
        }
      }
      return educators[0]?.name || 'Senior Faculty';
    }
    return raw;
  };

  // Cascading helpers for Live Form
  const liveFormMatchedCourses = liveForm.academicClass && liveForm.academicClass !== 'All Classes'
    ? getCoursesForClass(courses, liveForm.academicClass)
    : courses;

  const liveFormMatchedBatches = liveForm.courseId && liveForm.courseId !== 'all'
    ? getBatchesForCourse(batches, liveForm.courseId)
    : (liveForm.academicClass && liveForm.academicClass !== 'All Classes'
        ? batches.filter(b => {
            const c = courses.find(course => course.id === b.courseId);
            return b.academicClass === liveForm.academicClass || (c && c.academicClass === liveForm.academicClass);
          })
        : batches);

  const handleLiveClassChange = (selectedClass: string) => {
    const matchedCourses = selectedClass !== 'All Classes' ? getCoursesForClass(courses, selectedClass) : courses;
    const nextCourseId = matchedCourses.length > 0 ? (matchedCourses.some(c => c.id === liveForm.courseId) ? liveForm.courseId : 'all') : 'all';
    
    const matchedBatches = nextCourseId !== 'all' 
      ? batches.filter(b => b.courseId === nextCourseId) 
      : (selectedClass !== 'All Classes' ? batches.filter(b => b.academicClass === selectedClass) : batches);
    const nextBatchId = matchedBatches.some(b => b.id === liveForm.batchId) ? liveForm.batchId : 'all';

    setLiveForm({
      ...liveForm,
      academicClass: selectedClass,
      targetClass: selectedClass,
      courseId: nextCourseId,
      batchId: nextBatchId
    });
  };

  const handleLiveCourseChange = (selectedCourseId: string) => {
    const matchedBatches = selectedCourseId !== 'all' ? batches.filter(b => b.courseId === selectedCourseId) : batches;
    const nextBatchId = matchedBatches.some(b => b.id === liveForm.batchId) ? liveForm.batchId : 'all';
    
    const c = courses.find(x => x.id === selectedCourseId);
    const nextClass = (c && c.academicClass && liveForm.academicClass === 'All Classes') ? c.academicClass : liveForm.academicClass;

    setLiveForm({
      ...liveForm,
      courseId: selectedCourseId,
      batchId: nextBatchId,
      academicClass: nextClass,
      targetClass: nextClass
    });
  };

  const handleLiveBatchChange = (selectedBatchId: string) => {
    if (selectedBatchId !== 'all') {
      const b = batches.find(x => x.id === selectedBatchId);
      if (b) {
        const c = courses.find(x => x.id === b.courseId);
        setLiveForm({
          ...liveForm,
          batchId: selectedBatchId,
          courseId: b.courseId || liveForm.courseId,
          academicClass: b.academicClass || c?.academicClass || liveForm.academicClass,
          targetClass: b.academicClass || c?.academicClass || liveForm.academicClass
        });
        return;
      }
    }
    setLiveForm({
      ...liveForm,
      batchId: selectedBatchId
    });
  };

  // Cascading helpers for Recording Form
  const recFormMatchedCourses = recForm.academicClass && recForm.academicClass !== 'All Classes'
    ? getCoursesForClass(courses, recForm.academicClass)
    : courses;

  const recFormMatchedBatches = recForm.courseId && recForm.courseId !== 'all'
    ? getBatchesForCourse(batches, recForm.courseId)
    : (recForm.academicClass && recForm.academicClass !== 'All Classes'
        ? batches.filter(b => {
            const c = courses.find(course => course.id === b.courseId);
            return b.academicClass === recForm.academicClass || (c && c.academicClass === recForm.academicClass);
          })
        : batches);

  const handleRecClassChange = (selectedClass: string) => {
    const matchedCourses = selectedClass !== 'All Classes' ? getCoursesForClass(courses, selectedClass) : courses;
    const nextCourseId = matchedCourses.length > 0 ? (matchedCourses.some(c => c.id === recForm.courseId) ? recForm.courseId : 'all') : 'all';
    
    const matchedBatches = nextCourseId !== 'all' 
      ? batches.filter(b => b.courseId === nextCourseId) 
      : (selectedClass !== 'All Classes' ? batches.filter(b => b.academicClass === selectedClass) : batches);
    const nextBatchId = matchedBatches.some(b => b.id === recForm.batchId) ? recForm.batchId : 'all';

    setRecForm({
      ...recForm,
      academicClass: selectedClass,
      targetClass: selectedClass,
      courseId: nextCourseId,
      batchId: nextBatchId
    });
  };

  const handleRecCourseChange = (selectedCourseId: string) => {
    const matchedBatches = selectedCourseId !== 'all' ? batches.filter(b => b.courseId === selectedCourseId) : batches;
    const nextBatchId = matchedBatches.some(b => b.id === recForm.batchId) ? recForm.batchId : 'all';
    
    const c = courses.find(x => x.id === selectedCourseId);
    const nextClass = (c && c.academicClass && recForm.academicClass === 'All Classes') ? c.academicClass : recForm.academicClass;

    setRecForm({
      ...recForm,
      courseId: selectedCourseId,
      batchId: nextBatchId,
      academicClass: nextClass,
      targetClass: nextClass
    });
  };

  const handleRecBatchChange = (selectedBatchId: string) => {
    if (selectedBatchId !== 'all') {
      const b = batches.find(x => x.id === selectedBatchId);
      if (b) {
        const c = courses.find(x => x.id === b.courseId);
        setRecForm({
          ...recForm,
          batchId: selectedBatchId,
          courseId: b.courseId || recForm.courseId,
          academicClass: b.academicClass || c?.academicClass || recForm.academicClass,
          targetClass: b.academicClass || c?.academicClass || recForm.academicClass
        });
        return;
      }
    }
    setRecForm({
      ...recForm,
      batchId: selectedBatchId
    });
  };

  // Open Create/Edit Live Session Modal
  const handleOpenLiveModal = (session?: LiveClassSession) => {
    if (session) {
      setEditingLiveSession(session);
      const targetCls = session.targetClass || session.academicClass || 'All Classes';
      setLiveForm({
        title: session.title,
        academicClass: targetCls,
        targetClass: targetCls,
        subject: session.subject || '',
        courseId: session.courseId,
        batchId: session.batchId,
        educatorName: session.educatorName || educators[0]?.name || 'Faculty',
        scheduledDate: session.scheduledDate,
        startTime: session.startTime,
        endTime: session.endTime,
        platform: session.platform,
        meetingUrl: session.meetingUrl || '',
        meetingPassword: session.meetingPassword || '',
        status: session.status,
        description: session.description || '',
        isRecordingAvailable: !!session.isRecordingAvailable,
        recordingUrl: session.recordingUrl || ''
      });
    } else {
      setEditingLiveSession(null);
      setLiveForm({
        title: '',
        academicClass: 'All Classes',
        targetClass: 'All Classes',
        subject: courses[0]?.category || 'Computer Science',
        courseId: 'all',
        batchId: 'all',
        educatorName: educators[0]?.name || 'Faculty',
        scheduledDate: new Date().toISOString().split('T')[0],
        startTime: '18:00',
        endTime: '19:30',
        platform: 'google_meet',
        meetingUrl: 'https://meet.google.com/new',
        meetingPassword: '',
        status: 'scheduled',
        description: '',
        isRecordingAvailable: false,
        recordingUrl: ''
      });
    }
    setShowLiveModal(true);
  };

  const handleSaveLiveSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (!liveForm.title.trim()) return;

    const cleanedUrl = cleanMeetingUrl(liveForm.meetingUrl) || 'https://meet.google.com/new';

    const payload = {
      ...liveForm,
      meetingUrl: cleanedUrl,
      targetClass: liveForm.academicClass || liveForm.targetClass || 'All Classes',
      academicClass: liveForm.academicClass || liveForm.targetClass || 'All Classes'
    };

    if (editingLiveSession) {
      updateLiveClass(editingLiveSession.id, payload);
    } else {
      addLiveClass(payload);
    }
    setShowLiveModal(false);
  };

  // Open Create/Edit Recording Modal
  const handleOpenRecordingModal = (rec?: ClassRecording) => {
    if (rec) {
      setEditingRecording(rec);
      const targetCls = rec.targetClass || rec.academicClass || 'All Classes';
      setRecForm({
        title: rec.title,
        academicClass: targetCls,
        targetClass: targetCls,
        subject: rec.subject || '',
        topic: rec.topic || '',
        chapter: rec.chapter || '',
        courseId: rec.courseId,
        batchId: rec.batchId,
        educatorName: rec.educatorName || educators[0]?.name || 'Faculty',
        recordedDate: rec.recordedDate,
        durationMinutes: rec.durationMinutes,
        videoSourceType: rec.videoSourceType,
        videoUrl: rec.videoUrl,
        notesPdfUrl: rec.notesPdfUrl || '',
        thumbnailUrl: rec.thumbnailUrl || '',
        description: rec.description || ''
      });
    } else {
      setEditingRecording(null);
      setRecForm({
        title: '',
        academicClass: 'All Classes',
        targetClass: 'All Classes',
        subject: courses[0]?.category || 'Computer Science',
        topic: 'Chapter Concept & Practical Problems',
        chapter: 'Module 1',
        courseId: 'all',
        batchId: 'all',
        educatorName: educators[0]?.name || 'Faculty',
        recordedDate: new Date().toISOString().split('T')[0],
        durationMinutes: 60,
        videoSourceType: 'youtube',
        videoUrl: '',
        notesPdfUrl: '',
        thumbnailUrl: '',
        description: ''
      });
    }
    setShowRecordingModal(true);
  };

  const handleSaveRecording = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recForm.title.trim() || !recForm.videoUrl.trim()) return;

    const payload = {
      ...recForm,
      targetClass: recForm.academicClass || recForm.targetClass || 'All Classes',
      academicClass: recForm.academicClass || recForm.targetClass || 'All Classes'
    };

    if (editingRecording) {
      updateClassRecording(editingRecording.id, payload);
    } else {
      addClassRecording(payload);
    }
    setShowRecordingModal(false);
  };

  // Filtered Live Sessions
  const filteredLiveSessions = liveClasses.filter(s => {
    const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (s.subject && s.subject.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          (s.educatorName && s.educatorName.toLowerCase().includes(searchQuery.toLowerCase()));
    const sessionClass = s.targetClass || s.academicClass || 'All Classes';
    const matchesClass = filterClass === 'all' || sessionClass === 'All Classes' || sessionClass === filterClass;
    const matchesBatch = filterBatchId === 'all' || s.batchId === 'all' || s.batchId === filterBatchId;
    const matchesCourse = filterCourseId === 'all' || s.courseId === 'all' || s.courseId === filterCourseId;
    const matchesStatus = filterStatus === 'all' || s.status === filterStatus;
    return matchesSearch && matchesClass && matchesBatch && matchesCourse && matchesStatus;
  });

  // Filtered Recordings
  const filteredRecordings = classRecordings.filter(r => {
    const matchesSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (r.subject && r.subject.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          (r.topic && r.topic.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          (r.educatorName && r.educatorName.toLowerCase().includes(searchQuery.toLowerCase()));
    const recClass = r.targetClass || r.academicClass || 'All Classes';
    const matchesClass = filterClass === 'all' || recClass === 'All Classes' || recClass === filterClass;
    const matchesBatch = filterBatchId === 'all' || r.batchId === 'all' || r.batchId === filterBatchId;
    const matchesCourse = filterCourseId === 'all' || r.courseId === 'all' || r.courseId === filterCourseId;
    return matchesSearch && matchesClass && matchesBatch && matchesCourse;
  });

  // Helper to copy meeting link
  const handleCopyLink = (url: string, id: string) => {
    if (!url) return;
    navigator.clipboard.writeText(url);
    setCopiedSessionId(id);
    setTimeout(() => setCopiedSessionId(null), 2000);
  };

  // Extract embed URL
  const getEmbedUrl = (url: string, type: VideoSourceType): string => {
    if (!url) return '';
    if (type === 'youtube') {
      const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
      if (match && match[1]) {
        return `https://www.youtube-nocookie.com/embed/${match[1]}?autoplay=1&rel=0`;
      }
    } else if (type === 'drive') {
      // Google drive preview link
      const driveMatch = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
      if (driveMatch && driveMatch[1]) {
        return `https://drive.google.com/file/d/${driveMatch[1]}/preview`;
      }
    } else if (type === 'vimeo') {
      const vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
      if (vimeoMatch && vimeoMatch[1]) {
        return `https://player.vimeo.com/video/${vimeoMatch[1]}?autoplay=1`;
      }
    }
    return url;
  };

  const activeLiveCount = liveClasses.filter(c => c.status === 'live').length;
  const scheduledCount = liveClasses.filter(c => c.status === 'scheduled').length;
  const totalViews = classRecordings.reduce((sum, r) => sum + (r.viewCount || 0), 0);

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-rose-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-rose-500/20">
            <Radio className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-slate-900">Live Classes & Recorded Lectures</h2>
              {activeLiveCount > 0 && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-rose-500 text-white animate-pulse flex items-center gap-1 shadow-xs">
                  <span className="w-2 h-2 rounded-full bg-white"></span>
                  {activeLiveCount} LIVE NOW
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Host interactive live video classes, manage online stream links, and publish recorded video lectures for student batches.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => handleOpenLiveModal()}
            className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-md shadow-rose-600/20 cursor-pointer"
          >
            <Radio className="w-4 h-4" />
            <span>Schedule Live Class</span>
          </button>

          <button
            onClick={() => handleOpenRecordingModal()}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-md shadow-indigo-600/20 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Lecture Recording</span>
          </button>
        </div>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-rose-600 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
            Active Live Streams
          </span>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">
            {activeLiveCount}
          </div>
          <span className="text-[10px] text-slate-400">Broadcasts streaming now</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-600">
            Upcoming Scheduled
          </span>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">
            {scheduledCount}
          </div>
          <span className="text-[10px] text-slate-400">In calendar pipeline</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-violet-600">
            Recorded Lectures
          </span>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">
            {classRecordings.length}
          </div>
          <span className="text-[10px] text-slate-400">Archived video lessons</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-600">
            Student Views
          </span>
          <div className="text-2xl font-black text-emerald-700 font-mono mt-1">
            {totalViews}
          </div>
          <span className="text-[10px] text-slate-400">Total video lecture plays</span>
        </div>
      </div>

      {/* Main Sub-Navigation */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-xl overflow-x-auto w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('schedule_table')}
              className={`px-4 py-2 rounded-lg text-xs font-black transition cursor-pointer flex items-center gap-2 shrink-0 ${
                activeTab === 'schedule_table'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>📅 Schedule & Postpone Data Table ({liveClasses.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('live_sessions')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-2 shrink-0 ${
                activeTab === 'live_sessions'
                  ? 'bg-white text-rose-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>🔴 Live Streams & Cards ({liveClasses.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('recordings')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-2 shrink-0 ${
                activeTab === 'recordings'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              <span>📼 Recorded Lectures ({classRecordings.length})</span>
            </button>
          </div>

          {activeTab !== 'schedule_table' && (
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search title, subject, faculty..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}
        </div>

        {/* Filter Dropdowns (only for live_sessions and recordings tabs) */}
        {activeTab !== 'schedule_table' && (
          <div className="flex flex-wrap items-center gap-2.5 text-xs">
            <div className="flex items-center gap-1.5 text-slate-500 font-medium">
              <Filter className="w-3.5 h-3.5" />
              <span>Filters:</span>
            </div>

            <select
              value={filterClass}
              onChange={(e) => setFilterClass(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none"
            >
              <option value="all">All Academic Classes</option>
              {distinctClasses.map(cls => (
                <option key={cls} value={cls}>{cls}</option>
              ))}
            </select>

            <select
              value={filterCourseId}
              onChange={(e) => setFilterCourseId(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:outline-none"
            >
              <option value="all">All Courses</option>
              {courses.map(c => (
                <option key={c.id} value={c.id}>{c.title}</option>
              ))}
            </select>

            <select
              value={filterBatchId}
              onChange={(e) => setFilterBatchId(e.target.value)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:outline-none"
            >
              <option value="all">All Batches</option>
              {batches.map(b => (
                <option key={b.id} value={b.id}>{b.name} ({b.mode})</option>
              ))}
            </select>

            {activeTab === 'live_sessions' && (
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-700 focus:outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="live">🔴 Live Now</option>
                <option value="scheduled">📅 Scheduled</option>
                <option value="postponed">⚠️ Postponed</option>
                <option value="completed">✅ Completed</option>
                <option value="cancelled">❌ Cancelled</option>
              </select>
            )}

            {(filterClass !== 'all' || filterCourseId !== 'all' || filterBatchId !== 'all' || filterStatus !== 'all' || searchQuery) && (
              <button
                onClick={() => {
                  setFilterClass('all');
                  setFilterCourseId('all');
                  setFilterBatchId('all');
                  setFilterStatus('all');
                  setSearchQuery('');
                }}
                className="text-rose-600 hover:text-rose-700 font-bold ml-auto cursor-pointer"
              >
                Clear Filters
              </button>
            )}
          </div>
        )}
      </div>

      {/* TAB 0: SCHEDULE & POSTPONE DATA TABLE (NEW PRIMARY FEATURE) */}
      {activeTab === 'schedule_table' && (
        <ScheduleClassDataTable />
      )}

      {/* TAB 1: LIVE SESSIONS LIST */}
      {activeTab === 'live_sessions' && (
        <div className="space-y-4">
          {filteredLiveSessions.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-rose-50 text-rose-500 flex items-center justify-center">
                <Radio className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 text-base">No Live Classes Found</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Schedule a live interactive class for your online or classroom batches with Google Meet, Zoom, or In-App streaming links.
              </p>
              <button
                onClick={() => handleOpenLiveModal()}
                className="px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700 transition cursor-pointer"
              >
                Schedule New Live Class
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredLiveSessions.map((session) => {
                const batch = batches.find(b => b.id === session.batchId);
                const course = courses.find(c => c.id === session.courseId);
                const isLive = session.status === 'live';
                const sessionClass = session.targetClass || session.academicClass || 'All Classes';

                return (
                  <div 
                    key={session.id}
                    className={`bg-white rounded-3xl p-5 border transition-all relative overflow-hidden flex flex-col justify-between ${
                      isLive 
                        ? 'border-rose-400 shadow-md shadow-rose-100 ring-2 ring-rose-400/20' 
                        : 'border-slate-200 shadow-xs hover:border-slate-300'
                    }`}
                  >
                    {/* Status Top Strip */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <div className="flex flex-wrap items-center gap-2">
                        {isLive ? (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-black bg-rose-600 text-white animate-pulse flex items-center gap-1.5 shadow-xs">
                            <span className="w-2 h-2 rounded-full bg-white"></span>
                            LIVE NOW
                          </span>
                        ) : session.status === 'scheduled' ? (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-200 flex items-center gap-1">
                            <Clock className="w-3 h-3 text-amber-600" />
                            SCHEDULED
                          </span>
                        ) : session.status === 'completed' ? (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-900 border border-emerald-200 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            COMPLETED
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
                            CANCELLED
                          </span>
                        )}

                        <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                          {session.platform.replace('_', ' ')}
                        </span>

                        {sessionClass && (
                          <span className="px-2 py-0.5 rounded-lg text-[10px] font-extrabold bg-indigo-50 text-indigo-700 border border-indigo-100">
                            {sessionClass}
                          </span>
                        )}
                      </div>

                      {/* Action Menu Buttons */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleOpenLiveModal(session)}
                          className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition cursor-pointer"
                          title="Edit Session"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`Delete live class "${session.title}"?`)) {
                              deleteLiveClass(session.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                          title="Delete Session"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Class Details */}
                    <div className="space-y-2">
                      <h4 className="font-extrabold text-slate-900 text-base leading-snug">
                        {session.title}
                      </h4>
                      <p className="text-xs text-indigo-700 font-semibold flex items-center gap-1.5">
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>{session.subject}</span>
                      </p>

                      {session.description && (
                        <p className="text-xs text-slate-500 line-clamp-2">
                          {session.description}
                        </p>
                      )}

                      {/* Schedule & Batch Meta */}
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-[11px] text-slate-600">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{session.scheduledDate}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{session.startTime} - {session.endTime}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <GraduationCap className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="truncate">{getResolvedEducatorName(session)}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Layers className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span className="font-bold text-slate-800 truncate">
                            {session.batchId === 'all' ? 'All Batches' : (batch?.name || 'Selected Batch')}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Meeting Links & Live Broadcast Toggle */}
                    <div className="mt-4 pt-3 border-t border-slate-100 space-y-2.5">
                      {session.meetingUrl && (
                        <div className="flex items-center justify-between gap-2 p-2 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                          <div className="flex items-center gap-1.5 overflow-hidden">
                            <Link2 className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                            <span className="font-mono text-[11px] text-slate-700 truncate">{session.meetingUrl}</span>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              onClick={() => handleCopyLink(session.meetingUrl!, session.id)}
                              className="p-1 text-slate-500 hover:text-indigo-600 rounded cursor-pointer"
                              title="Copy Student Link"
                            >
                              {copiedSessionId === session.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                            </button>
                            <a
                              href={session.meetingUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="p-1 text-indigo-600 hover:text-indigo-800 rounded"
                              title="Open Meeting Link"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          </div>
                        </div>
                      )}

                      {/* Admin Quick Status Control */}
                      <div className="flex items-center justify-between gap-2">
                        {session.status === 'scheduled' && (
                          <button
                            onClick={() => setLiveClassStatus(session.id, 'live')}
                            className="w-full py-2 px-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                          >
                            <Radio className="w-3.5 h-3.5 animate-pulse" />
                            <span>🔴 Go Live Now (Broadcast)</span>
                          </button>
                        )}

                        {session.status === 'live' && (
                          <div className="flex items-center gap-2 w-full">
                            <a
                              href={session.meetingUrl || '#'}
                              target="_blank"
                              rel="noreferrer"
                              className="flex-1 py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm"
                            >
                              <Tv className="w-3.5 h-3.5" />
                              <span>Enter Host Stream</span>
                            </a>
                            <button
                              onClick={() => setLiveClassStatus(session.id, 'completed')}
                              className="py-2 px-3 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                              title="End and mark completed"
                            >
                              End Class
                            </button>
                          </div>
                        )}

                        {session.status === 'completed' && (
                          <div className="flex items-center justify-between w-full">
                            <button
                              onClick={() => setLiveClassStatus(session.id, 'scheduled')}
                              className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                            >
                              Re-schedule
                            </button>
                            {session.recordingUrl ? (
                              <button
                                onClick={() => setPreviewVideo({ title: session.title, url: session.recordingUrl!, type: 'youtube' })}
                                className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-600 hover:text-rose-800 cursor-pointer"
                              >
                                <PlayCircle className="w-3.5 h-3.5" />
                                <span>Watch Recording</span>
                              </button>
                            ) : (
                              <button
                                onClick={() => handleOpenRecordingModal({
                                  id: '',
                                  title: session.title,
                                  targetClass: session.targetClass || session.academicClass || 'All Classes',
                                  academicClass: session.targetClass || session.academicClass || 'All Classes',
                                  subject: session.subject,
                                  topic: 'Live Session Recording',
                                  courseId: session.courseId,
                                  batchId: session.batchId,
                                  educatorName: session.educatorName,
                                  recordedDate: session.scheduledDate,
                                  durationMinutes: 75,
                                  videoSourceType: 'youtube',
                                  videoUrl: '',
                                  createdAt: ''
                                })}
                                className="text-[11px] font-bold text-slate-500 hover:text-indigo-600 cursor-pointer"
                              >
                                + Link Recording
                              </button>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: CLASS RECORDINGS LIST */}
      {activeTab === 'recordings' && (
        <div className="space-y-4">
          {filteredRecordings.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <Film className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 text-base">No Recorded Lectures Published</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Add YouTube, Google Drive, or Direct Video recordings for students to watch anytime from their Student Portal.
              </p>
              <button
                onClick={() => handleOpenRecordingModal()}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 transition cursor-pointer"
              >
                Upload / Link Lecture Video
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredRecordings.map((rec) => {
                const batch = batches.find(b => b.id === rec.batchId);
                const course = courses.find(c => c.id === rec.courseId);
                const recClass = rec.targetClass || rec.academicClass || 'All Classes';

                return (
                  <div
                    key={rec.id}
                    className="bg-white rounded-3xl border border-slate-200 shadow-xs hover:border-slate-300 transition-all p-5 flex flex-col justify-between"
                  >
                    <div>
                      {/* Video source badge & actions */}
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <div className="flex items-center gap-1.5">
                          <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-indigo-50 text-indigo-700 border border-indigo-100 flex items-center gap-1">
                            {rec.videoSourceType === 'youtube' ? <Youtube className="w-3.5 h-3.5 text-red-600" /> : <Film className="w-3.5 h-3.5 text-indigo-600" />}
                            <span>{rec.videoSourceType}</span>
                          </span>
                          {recClass && (
                            <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-slate-100 text-slate-700">
                              {recClass}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleOpenRecordingModal(rec)}
                            className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg cursor-pointer"
                            title="Edit"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (window.confirm(`Delete recording "${rec.title}"?`)) {
                                deleteClassRecording(rec.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg cursor-pointer"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Title & Topic */}
                      <h4 className="font-extrabold text-slate-900 text-sm leading-snug mb-1">
                        {rec.title}
                      </h4>
                      <p className="text-xs text-indigo-600 font-semibold mb-2">
                        {rec.subject} {rec.chapter ? `• ${rec.chapter}` : ''}
                      </p>

                      {rec.topic && (
                        <p className="text-xs text-slate-500 line-clamp-2 mb-3 bg-slate-50 p-2 rounded-xl">
                          {rec.topic}
                        </p>
                      )}

                      {/* Meta Information */}
                      <div className="space-y-1.5 text-[11px] text-slate-600">
                        <div className="flex justify-between">
                          <span className="text-slate-400">Duration:</span>
                          <span className="font-bold text-slate-800">{rec.durationMinutes} mins</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Educator:</span>
                          <span className="font-bold text-slate-800 truncate">{getRecordingEducatorName(rec)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Target Batch:</span>
                          <span className="font-bold text-slate-800 truncate">
                            {rec.batchId === 'all' ? 'All Batches' : (batch?.name || 'Assigned Batch')}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">Recorded Date:</span>
                          <span className="font-medium text-slate-700">{rec.recordedDate}</span>
                        </div>
                      </div>
                    </div>

                    {/* Footer Actions */}
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                      <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                        <Eye className="w-3 h-3 text-slate-400" />
                        <span>{rec.viewCount || 0} views</span>
                      </span>

                      <button
                        onClick={() => setPreviewVideo({ title: rec.title, url: rec.videoUrl, type: rec.videoSourceType })}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                      >
                        <Play className="w-3 h-3 fill-current" />
                        <span>Preview Video</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* CREATE / EDIT LIVE CLASS MODAL */}
      {showLiveModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-7 shadow-2xl border border-slate-200 animate-fadeIn my-8">
            <div className="flex justify-between items-center pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-rose-50 text-rose-600 rounded-xl">
                  <Radio className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    {editingLiveSession ? 'Edit Live Session Schedule' : 'Schedule New Live Class'}
                  </h3>
                  <p className="text-xs text-slate-500">Configure academic class, course, batch, timing, and meeting links.</p>
                </div>
              </div>
              <button
                onClick={() => setShowLiveModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveLiveSession} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Session Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Python OOPs & Inheritance Live Masterclass"
                  value={liveForm.title}
                  onChange={(e) => setLiveForm({ ...liveForm, title: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              {/* Cascading Academic Class, Course & Batch Selectors */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <GraduationCap className="w-4 h-4 text-rose-600" />
                    <span>Academic Scope & Target Batches</span>
                  </span>
                  <span className="text-[10px] text-slate-500 font-medium">Auto-filters Course & Batch</span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Academic Class Standard <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={liveForm.academicClass || 'All Classes'}
                    onChange={(e) => handleLiveClassChange(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 bg-white focus:ring-2 focus:ring-rose-500 focus:outline-none shadow-xs"
                  >
                    <option value="All Classes">🌟 All Academic Classes (Universal Session)</option>
                    {distinctClasses.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                      Target Course
                    </label>
                    <select
                      value={liveForm.courseId}
                      onChange={(e) => handleLiveCourseChange(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    >
                      <option value="all">All Courses in Selected Class</option>
                      {liveFormMatchedCourses.map(c => (
                        <option key={c.id} value={c.id}>{c.title}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                      Target Batch
                    </label>
                    <select
                      value={liveForm.batchId}
                      onChange={(e) => handleLiveBatchChange(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white focus:ring-2 focus:ring-rose-500 focus:outline-none"
                    >
                      <option value="all">Open to All Batches</option>
                      {liveFormMatchedBatches.map(b => (
                        <option key={b.id} value={b.id}>{b.name} ({b.mode})</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Subject / Topic <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Computer Science (Python)"
                    value={liveForm.subject}
                    onChange={(e) => setLiveForm({ ...liveForm, subject: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Faculty / Educator <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={liveForm.educatorName}
                    onChange={(e) => setLiveForm({ ...liveForm, educatorName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  >
                    {educators.map(edu => (
                      <option key={edu.id} value={edu.name}>{edu.name} ({edu.subject})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Date <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={liveForm.scheduledDate}
                    onChange={(e) => setLiveForm({ ...liveForm, scheduledDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Start Time <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="time"
                    required
                    value={liveForm.startTime}
                    onChange={(e) => setLiveForm({ ...liveForm, startTime: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    End Time <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="time"
                    required
                    value={liveForm.endTime}
                    onChange={(e) => setLiveForm({ ...liveForm, endTime: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Meeting Platform
                  </label>
                  <select
                    value={liveForm.platform}
                    onChange={(e) => setLiveForm({ ...liveForm, platform: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  >
                    <option value="google_meet">Google Meet</option>
                    <option value="zoom">Zoom Video</option>
                    <option value="youtube_live">YouTube Live Stream</option>
                    <option value="in_app">Pixel In-App Studio</option>
                    <option value="other">Custom Web Stream</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Status
                  </label>
                  <select
                    value={liveForm.status}
                    onChange={(e) => setLiveForm({ ...liveForm, status: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none font-bold"
                  >
                    <option value="scheduled">Scheduled</option>
                    <option value="live">🔴 Live Now</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
                    <Link2 className="w-3.5 h-3.5 text-rose-600" />
                    <span>Meeting Link / Stream URL</span>
                    <span className="text-rose-500">*</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setLiveForm({ ...liveForm, meetingUrl: 'https://meet.google.com/new', platform: 'google_meet' })}
                      className="text-[11px] font-bold text-rose-600 hover:text-rose-700 cursor-pointer"
                    >
                      + New Meet Link
                    </button>
                    {liveForm.meetingUrl && (
                      <a
                        href={cleanMeetingUrl(liveForm.meetingUrl)}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5 cursor-pointer"
                      >
                        <span>Test Link</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    placeholder="e.g. meet.google.com/abc-defg-hij or paste any meeting link"
                    value={liveForm.meetingUrl}
                    onChange={(e) => setLiveForm({ ...liveForm, meetingUrl: e.target.value })}
                    onBlur={(e) => {
                      if (e.target.value.trim()) {
                        setLiveForm({ ...liveForm, meetingUrl: cleanMeetingUrl(e.target.value) });
                      }
                    }}
                    className="flex-1 px-3 py-2 border border-slate-300 rounded-xl text-xs font-mono focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (liveForm.meetingUrl) {
                        setLiveForm({ ...liveForm, meetingUrl: cleanMeetingUrl(liveForm.meetingUrl) });
                      }
                    }}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                    title="Auto-format URL"
                  >
                    Format
                  </button>
                </div>
                <p className="text-[10px] text-slate-500">
                  Accepts Google Meet codes (e.g. <code>abc-defg-hij</code>), full Google Meet URLs, Zoom links, YouTube Live, or Jitsi meetings.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Session Description & Learning Goals
                </label>
                <textarea
                  rows={2}
                  placeholder="Key concepts to be covered in this live session..."
                  value={liveForm.description}
                  onChange={(e) => setLiveForm({ ...liveForm, description: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowLiveModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer"
                >
                  {editingLiveSession ? 'Save Changes' : 'Schedule Live Class'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATE / EDIT CLASS RECORDING MODAL */}
      {showRecordingModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-7 shadow-2xl border border-slate-200 animate-fadeIn my-8">
            <div className="flex justify-between items-center pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
                  <Film className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">
                    {editingRecording ? 'Edit Lecture Recording' : 'Publish Lecture Recording'}
                  </h3>
                  <p className="text-xs text-slate-500">Attach video recordings and class notes with target academic standard.</p>
                </div>
              </div>
              <button
                onClick={() => setShowRecordingModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveRecording} className="space-y-4 mt-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Lecture Title <span className="text-indigo-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Python Variables, Loops & Conditional Statements"
                  value={recForm.title}
                  onChange={(e) => setRecForm({ ...recForm, title: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              {/* Cascading Academic Class, Course & Batch for Recording */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <GraduationCap className="w-4 h-4 text-indigo-600" />
                    <span>Academic Scope & Target Batches</span>
                  </span>
                  <span className="text-[10px] text-slate-500 font-medium">Auto-filters Course & Batch</span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Academic Class Standard <span className="text-indigo-500">*</span>
                  </label>
                  <select
                    value={recForm.academicClass || 'All Classes'}
                    onChange={(e) => handleRecClassChange(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none shadow-xs"
                  >
                    <option value="All Classes">🌟 All Academic Classes</option>
                    {distinctClasses.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                      Target Course
                    </label>
                    <select
                      value={recForm.courseId}
                      onChange={(e) => handleRecCourseChange(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    >
                      <option value="all">All Courses in Selected Class</option>
                      {recFormMatchedCourses.map(c => (
                        <option key={c.id} value={c.id}>{c.title}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                      Target Batch
                    </label>
                    <select
                      value={recForm.batchId}
                      onChange={(e) => handleRecBatchChange(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    >
                      <option value="all">All Registered Students</option>
                      {recFormMatchedBatches.map(b => (
                        <option key={b.id} value={b.id}>{b.name} ({b.mode})</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Subject <span className="text-indigo-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Python Programming"
                    value={recForm.subject}
                    onChange={(e) => setRecForm({ ...recForm, subject: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Chapter / Module
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Chapter 3: Functions & Recursion"
                    value={recForm.chapter}
                    onChange={(e) => setRecForm({ ...recForm, chapter: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Educator
                  </label>
                  <select
                    value={recForm.educatorName}
                    onChange={(e) => setRecForm({ ...recForm, educatorName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    {educators.map(edu => (
                      <option key={edu.id} value={edu.name}>{edu.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Recorded Date
                  </label>
                  <input
                    type="date"
                    value={recForm.recordedDate}
                    onChange={(e) => setRecForm({ ...recForm, recordedDate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Video Source Type
                  </label>
                  <select
                    value={recForm.videoSourceType}
                    onChange={(e) => setRecForm({ ...recForm, videoSourceType: e.target.value as any })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none font-bold"
                  >
                    <option value="youtube">YouTube (Unlisted / Public)</option>
                    <option value="drive">Google Drive Video</option>
                    <option value="vimeo">Vimeo Video</option>
                    <option value="mp4_direct">Direct MP4 / HLS Link</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={recForm.durationMinutes}
                    onChange={(e) => setRecForm({ ...recForm, durationMinutes: Number(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Video URL / Share Link <span className="text-indigo-500">*</span>
                </label>
                <input
                  type="url"
                  required
                  placeholder="e.g. https://www.youtube.com/watch?v=xxx or Google Drive share link"
                  value={recForm.videoUrl}
                  onChange={(e) => setRecForm({ ...recForm, videoUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Class Notes / Handout PDF URL (Optional)
                </label>
                <input
                  type="url"
                  placeholder="https://... or Google Drive PDF download link"
                  value={recForm.notesPdfUrl}
                  onChange={(e) => setRecForm({ ...recForm, notesPdfUrl: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Topic Description / Key Timestamps
                </label>
                <textarea
                  rows={2}
                  placeholder="Summary of topics explained in this lecture..."
                  value={recForm.topic}
                  onChange={(e) => setRecForm({ ...recForm, topic: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowRecordingModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer"
                >
                  {editingRecording ? 'Save Changes' : 'Publish Recording'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* VIDEO PREVIEW MODAL */}
      {previewVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-slate-900 text-white rounded-3xl max-w-3xl w-full p-5 sm:p-6 shadow-2xl border border-slate-800 animate-fadeIn my-6">
            <div className="flex justify-between items-center pb-3 border-b border-slate-800 mb-4">
              <div className="flex items-center gap-2">
                <PlayCircle className="w-5 h-5 text-rose-500" />
                <h3 className="font-bold text-sm sm:text-base text-white truncate max-w-lg">
                  {previewVideo.title}
                </h3>
              </div>
              <button
                onClick={() => setPreviewVideo(null)}
                className="text-slate-400 hover:text-white p-1 text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-inner">
              {previewVideo.type === 'mp4_direct' ? (
                <video
                  src={previewVideo.url}
                  controls
                  autoPlay
                  className="w-full h-full object-contain"
                />
              ) : (
                <iframe
                  src={getEmbedUrl(previewVideo.url, previewVideo.type)}
                  title={previewVideo.title}
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              )}
            </div>

            <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400">
              <span>Playback preview for students</span>
              <a
                href={previewVideo.url}
                target="_blank"
                rel="noreferrer"
                className="text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
              >
                <span>Open original source link</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
