import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { PaymentMode, FeePayment, Student, Course, Batch } from '../../types';
import { getStudentMonthlyBilling, formatMonthKey, calculateMonthDiscount, getCurrentMonthKey } from '../../utils/feeCalculator';
import { FeeReminderModal } from './FeeReminderModal';
import { BatchFeeReminderModal } from './BatchFeeReminderModal';
import { 
  CreditCard, 
  Printer, 
  Search, 
  Plus, 
  Trash2, 
  CheckCircle, 
  Clock, 
  XCircle, 
  Calendar, 
  User, 
  Building2, 
  QrCode,
  Sparkles,
  ArrowRight,
  BellRing,
  MessageCircle,
  AlertTriangle,
  Send,
  Mail,
  Zap,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

export const FeeCollectionManager: React.FC = () => {
  const { 
    students, 
    courses, 
    batches, 
    discounts, 
    payments, 
    collectFee, 
    deletePayment, 
    setSelectedReceiptForPrint 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'payments' | 'dues'>('payments');
  const [showCollectModal, setShowCollectModal] = useState(false);
  const [showBatchReminderModal, setShowBatchReminderModal] = useState(false);
  const [selectedStudentId, setSelectedStudentId] = useState<string>(students[0]?.id || '');
  const [selectedMonths, setSelectedMonths] = useState<string[]>([]);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('CASH');
  const [transactionRef, setTransactionRef] = useState('');
  const [remarks, setRemarks] = useState('Collected at center counter');
  const [customDiscountOverride, setCustomDiscountOverride] = useState<number>(0);

  // Real-time Billing Month for calculating dues dynamically
  const currentCalMonth = getCurrentMonthKey();
  const [targetBillingMonth, setTargetBillingMonth] = useState<string>(() => currentCalMonth);

  // Available Billing Months range
  const availableBillingMonths = useMemo(() => {
    return [
      '2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09',
      '2026-10', '2026-11', '2026-12', '2027-01', '2027-02', '2027-03'
    ];
  }, []);

  const handlePrevMonth = () => {
    const idx = availableBillingMonths.indexOf(targetBillingMonth);
    if (idx > 0) {
      setTargetBillingMonth(availableBillingMonths[idx - 1]);
    } else {
      const [y, m] = targetBillingMonth.split('-').map(Number);
      const prevMo = m === 1 ? 12 : m - 1;
      const prevYr = m === 1 ? y - 1 : y;
      setTargetBillingMonth(`${prevYr}-${prevMo < 10 ? '0' + prevMo : prevMo}`);
    }
  };

  const handleNextMonth = () => {
    const idx = availableBillingMonths.indexOf(targetBillingMonth);
    if (idx >= 0 && idx < availableBillingMonths.length - 1) {
      setTargetBillingMonth(availableBillingMonths[idx + 1]);
    } else {
      const [y, m] = targetBillingMonth.split('-').map(Number);
      const nextMo = m === 12 ? 1 : m + 1;
      const nextYr = m === 12 ? y + 1 : y;
      setTargetBillingMonth(`${nextYr}-${nextMo < 10 ? '0' + nextMo : nextMo}`);
    }
  };

  // Search & Filter state for fee ledger
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'approved' | 'pending' | 'rejected'>('all');

  // Fee Reminder Modal State
  const [reminderTarget, setReminderTarget] = useState<{
    student: Student;
    course?: Course;
    batch?: Batch;
    dueAmount: number;
    dueMonths: string[];
  } | null>(null);

  const selectedStudent = students.find(s => s.id === selectedStudentId);
  const selectedCourse = courses.find(c => c.id === selectedStudent?.courseId);
  const selectedBatch = batches.find(b => b.id === selectedStudent?.batchId);

  // Get billing status for selected student in real-time
  const billingInfo = selectedStudent 
    ? getStudentMonthlyBilling(selectedStudent, selectedCourse, discounts, payments, targetBillingMonth)
    : null;

  const unpaidMonths = billingInfo 
    ? billingInfo.monthlyStatuses.filter(m => !m.isPaid && !m.isPendingApproval) 
    : [];

  // Compute dues across all active students in real-time based on targetBillingMonth
  const studentsWithDues = useMemo(() => {
    return students
      .map(student => {
        const course = courses.find(c => c.id === student.courseId);
        const batch = batches.find(b => b.id === student.batchId);
        const billing = getStudentMonthlyBilling(student, course, discounts, payments, targetBillingMonth);
        const dues = billing.monthlyStatuses.filter(m => !m.isPaid && !m.isPendingApproval);
        const totalDueAmount = dues.reduce((acc, m) => acc + m.netFeeDue, 0);

        return {
          student,
          course,
          batch,
          dues,
          totalDueAmount,
          dueMonthLabels: dues.map(m => m.monthLabel)
        };
      })
      .filter(item => item.totalDueAmount > 0);
  }, [students, courses, batches, discounts, payments, targetBillingMonth]);

  const handleOpenCollectModal = (studentId?: string) => {
    const sId = studentId || selectedStudentId || (students[0]?.id || '');
    setSelectedStudentId(sId);
    
    const stu = students.find(s => s.id === sId);
    const crs = courses.find(c => c.id === stu?.courseId);
    const bInfo = stu ? getStudentMonthlyBilling(stu, crs, discounts, payments, targetBillingMonth) : null;
    const dueKeys = bInfo ? bInfo.monthlyStatuses.filter(m => !m.isPaid && !m.isPendingApproval).map(m => m.monthKey) : [];

    // default select first due month or all due months
    setSelectedMonths(dueKeys.slice(0, 1));
    setPaymentMode('CASH');
    setTransactionRef('');
    setCustomDiscountOverride(0);
    setRemarks('Collected at center desk');
    setShowCollectModal(true);
  };

  const handleToggleMonth = (mKey: string) => {
    setSelectedMonths(prev =>
      prev.includes(mKey) ? prev.filter(k => k !== mKey) : [...prev, mKey]
    );
  };

  // Calculate totals for modal
  const baseMonthlyFee = selectedStudent?.customMonthlyFeeOverride ?? (selectedCourse?.monthlyFee ?? 1200);
  const totalBaseFee = baseMonthlyFee * selectedMonths.length;

  let computedAutoDiscount = 0;
  const discountNotes: string[] = [];

  if (selectedStudent) {
    for (const mKey of selectedMonths) {
      const { discountAmount, notes } = calculateMonthDiscount(selectedStudent, mKey, baseMonthlyFee, discounts, selectedCourse);
      computedAutoDiscount += discountAmount;
      if (notes.length) discountNotes.push(...notes);
    }
  }

  const totalDiscount = Math.min(totalBaseFee, computedAutoDiscount + Number(customDiscountOverride || 0));
  const finalAmountToPay = Math.max(0, totalBaseFee - totalDiscount);

  const handleSaveFeePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;
    if (selectedMonths.length === 0) {
      alert('Please select at least one billing month.');
      return;
    }

    const formattedMonths = selectedMonths.map(formatMonthKey).join(', ');

    const newPayment = collectFee({
      studentId: selectedStudent.id,
      studentName: selectedStudent.name,
      studentAadhaar: selectedStudent.aadhaarNo,
      studentMobile: selectedStudent.mobile,
      courseTitle: selectedCourse?.title || 'Enrolled Course',
      batchName: selectedBatch?.name || 'Batch',
      month: formattedMonths,
      monthsCovered: selectedMonths,
      baseMonthlyFee,
      totalBaseFee,
      totalDiscount,
      discountBreakdown: discountNotes.join(', ') + (customDiscountOverride > 0 ? ` + Custom (₹${customDiscountOverride})` : ''),
      finalAmountPaid: finalAmountToPay,
      remainingDue: 0,
      paymentMode,
      transactionRef: transactionRef.trim() || undefined,
      status: 'approved',
      paymentDate: new Date().toISOString().split('T')[0],
      approvedBy: 'Admin - Center Desk',
      remarks: remarks.trim() || undefined
    });

    setShowCollectModal(false);
    // Open A4 print dialog for instant printing
    setSelectedReceiptForPrint(newPayment);
  };

  // Filtered Payments
  const filteredPayments = payments.filter(p => {
    const matchesSearch = 
      p.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.receiptNo.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.studentAadhaar.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.transactionRef && p.transactionRef.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Header & Quick Collect Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-indigo-600" />
            <span>Monthly Fee Collection & Invoicing</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Collect tuition fees month-by-month, apply batch/student concessions, dispatch fee due reminders, and print A4 receipts.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setActiveTab(activeTab === 'dues' ? 'payments' : 'dues')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
              activeTab === 'dues'
                ? 'bg-amber-100 text-amber-900 border border-amber-300 ring-2 ring-amber-400/30'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <BellRing className="w-4 h-4 text-amber-600" />
            <span>Pending Dues Tracker ({studentsWithDues.length})</span>
          </button>

          <button
            id="btn-collect-fee-wizard"
            onClick={() => handleOpenCollectModal()}
            className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Collect Fee & Issue Receipt</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('payments')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'payments'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Payment Transactions ({payments.length})
        </button>
        <button
          onClick={() => setActiveTab('dues')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'dues'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Pending Fees & Reminders ({studentsWithDues.length})</span>
        </button>
      </div>

      {activeTab === 'dues' ? (
        /* Pending Fees & Reminders Tracker */
        <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-4 bg-amber-50/70 border-b border-amber-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <span className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
                <BellRing className="w-4 h-4 text-amber-600" />
                <span>Pending Tuition Fees & Due Reminders Directory</span>
              </span>
              <p className="text-[11px] text-amber-700 mt-0.5">
                Send WhatsApp, SMS, or Email payment reminders directly to students and parents with UPI payment links.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setShowBatchReminderModal(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs transition cursor-pointer"
              >
                <Zap className="w-3.5 h-3.5 fill-current text-amber-300" />
                <span>Automated Batch Reminders (WhatsApp/Email)</span>
              </button>

              <span className="text-xs font-bold bg-amber-200 text-amber-900 px-3 py-1.5 rounded-xl">
                Total Outstanding: ₹{studentsWithDues.reduce((sum, d) => sum + d.totalDueAmount, 0).toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* Real-Time Billing Month Control Bar */}
          <div className="bg-slate-900 text-white p-3.5 px-5 flex flex-wrap items-center justify-between gap-3 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black uppercase tracking-wider text-slate-300">
                    Real-Time Dues Month:
                  </span>
                  <span className="text-xs font-bold text-amber-400 font-mono">
                    {formatMonthKey(targetBillingMonth)}
                  </span>
                  {targetBillingMonth === currentCalMonth ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      Current Month
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                      Custom View
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-slate-400">
                  Dues calculate dynamically in real-time up to the selected month.
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrevMonth}
                className="p-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                title="Previous Month"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span className="hidden sm:inline text-[11px]">Prev</span>
              </button>

              <select
                value={targetBillingMonth}
                onChange={(e) => setTargetBillingMonth(e.target.value)}
                className="bg-slate-800 text-white text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
              >
                {availableBillingMonths.map(m => (
                  <option key={m} value={m}>
                    {formatMonthKey(m)} {m === currentCalMonth ? '• Current Month' : ''}
                  </option>
                ))}
              </select>

              <button
                type="button"
                onClick={handleNextMonth}
                className="p-1.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                title="Next Month"
              >
                <span className="hidden sm:inline text-[11px]">Next</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>

              {targetBillingMonth !== currentCalMonth && (
                <button
                  type="button"
                  onClick={() => setTargetBillingMonth(currentCalMonth)}
                  className="text-xs font-bold text-amber-400 hover:text-amber-300 underline underline-offset-2 ml-1 cursor-pointer"
                >
                  Reset to Current
                </button>
              )}
            </div>
          </div>

          {studentsWithDues.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-100/70 text-slate-600 font-bold border-b border-slate-200">
                    <th className="p-3.5">Roll No</th>
                    <th className="p-3.5">Student Name</th>
                    <th className="p-3.5">Contact Number</th>
                    <th className="p-3.5">Course & Batch</th>
                    <th className="p-3.5">Unpaid Months</th>
                    <th className="p-3.5 text-right">Total Due</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {studentsWithDues.map(({ student, course, batch, totalDueAmount, dueMonthLabels }) => (
                    <tr key={student.id} className="hover:bg-amber-50/30 transition-colors">
                      <td className="p-3.5 font-mono font-bold text-slate-700">
                        {student.rollNo}
                      </td>
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900">{student.name}</div>
                        <div className="text-[11px] text-slate-500 font-mono">Guardian: {student.guardianName || 'Parent'}</div>
                      </td>
                      <td className="p-3.5 font-mono text-slate-700">
                        {student.mobile || '—'}
                      </td>
                      <td className="p-3.5 text-xs text-slate-600">
                        <div className="font-semibold text-slate-800">{course?.title || 'Course'}</div>
                        <div className="text-slate-400 text-[11px]">{batch?.name || 'Batch'}</div>
                      </td>
                      <td className="p-3.5">
                        <div className="flex flex-wrap gap-1">
                          {dueMonthLabels.map((lbl, idx) => (
                            <span key={idx} className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-800 border border-red-200">
                              <AlertTriangle className="w-2.5 h-2.5 text-red-600" />
                              <span>Due: {lbl}</span>
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="p-3.5 text-right">
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full font-mono text-xs font-extrabold bg-red-100 text-red-800 border border-red-300">
                          <AlertTriangle className="w-3 h-3 text-red-600" />
                          <span>Due: ₹{totalDueAmount.toLocaleString('en-IN')}</span>
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => {
                              setReminderTarget({
                                student,
                                course,
                                batch,
                                dueAmount: totalDueAmount,
                                dueMonths: dueMonthLabels
                              });
                            }}
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs transition cursor-pointer"
                            title="Send WhatsApp / SMS / Email reminder"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>Remind Fees Due</span>
                          </button>

                          <button
                            onClick={() => handleOpenCollectModal(student.id)}
                            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-xs transition cursor-pointer"
                            title="Collect Fee Now"
                          >
                            Collect Fee
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500">
              <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <div className="font-bold text-slate-800">No Pending Tuition Fees!</div>
              <p className="text-xs text-slate-500 mt-1">All enrolled students have cleared their dues for current billing cycles.</p>
            </div>
          )}
        </div>
      ) : (
        /* Regular Payments Ledger */
        <div className="space-y-4">
          {/* Search & Filter Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by student, receipt #, Aadhaar..."
                className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <span className="text-xs font-semibold text-slate-500">Filter Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
              >
                <option value="all">All Payments ({payments.length})</option>
                <option value="approved">Approved & Verified</option>
                <option value="pending">Pending Approvals</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>

          {/* Fee Ledger Table */}
          <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center text-xs font-bold text-slate-700">
              <span>Fee Transaction History ({filteredPayments.length} records)</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-100/70 text-slate-600 font-bold border-b border-slate-200">
                    <th className="p-3.5">Receipt No</th>
                    <th className="p-3.5">Student & Aadhaar</th>
                    <th className="p-3.5">Months Covered</th>
                    <th className="p-3.5">Course / Batch</th>
                    <th className="p-3.5 text-right">Amount Paid</th>
                    <th className="p-3.5">Mode & Ref</th>
                    <th className="p-3.5">Date</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">A4 Receipt / Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredPayments.map((pay) => (
                    <tr key={pay.id} className="hover:bg-slate-50/60 transition-colors">
                      <td className="p-3.5 font-mono font-bold text-indigo-900">
                        {pay.receiptNo}
                      </td>
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900">{pay.studentName}</div>
                        <div className="text-[11px] font-mono text-slate-500">Aadhaar: {pay.studentAadhaar || '-'}</div>
                      </td>
                      <td className="p-3.5 font-semibold text-slate-800">
                        {pay.month}
                      </td>
                      <td className="p-3.5 text-xs text-slate-600">
                        <div className="line-clamp-1 font-medium">{pay.courseTitle}</div>
                        <div className="text-slate-400 text-[11px]">{pay.batchName}</div>
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-slate-900 text-sm">
                        ₹{pay.finalAmountPaid.toLocaleString('en-IN')}
                        {pay.totalDiscount > 0 && (
                          <span className="block text-[10px] text-emerald-600 font-normal">
                            Disc: -₹{pay.totalDiscount}
                          </span>
                        )}
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700 font-mono">
                          {pay.paymentMode}
                        </span>
                        {pay.transactionRef && (
                          <span className="block text-[10px] text-slate-500 font-mono mt-0.5 truncate max-w-[120px]" title={pay.transactionRef}>
                            {pay.transactionRef}
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-xs text-slate-600">
                        {pay.paymentDate}
                      </td>
                      <td className="p-3.5">
                        {pay.status === 'approved' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300">
                            <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Fully Paid</span>
                          </span>
                        ) : pay.status === 'pending' ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold bg-amber-100 text-amber-800 border border-amber-300">
                            <Clock className="w-3.5 h-3.5 text-amber-600" />
                            <span>Pending Approval</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold bg-red-100 text-red-800 border border-red-300">
                            <XCircle className="w-3.5 h-3.5 text-red-600" />
                            <span>Rejected / Due</span>
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {pay.status === 'approved' && (
                            <button
                              onClick={() => setSelectedReceiptForPrint(pay)}
                              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs shadow-xs transition cursor-pointer flex items-center gap-1"
                              title="Print A4 Receipt"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>Print A4</span>
                            </button>
                          )}
                          <button
                            onClick={() => {
                              if (confirm(`Are you sure you want to delete payment receipt #${pay.receiptNo}?`)) {
                                deletePayment(pay.id);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                            title="Delete Record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Collect Fee Wizard Modal */}
      {showCollectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Center Counter Collection
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  Collect Monthly Student Fee
                </h3>
              </div>
              <button
                onClick={() => setShowCollectModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveFeePayment} className="space-y-4">
              {/* Student Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Select Student <span className="text-red-500">*</span>
                </label>
                <select
                  value={selectedStudentId}
                  onChange={(e) => {
                    setSelectedStudentId(e.target.value);
                    const stu = students.find(s => s.id === e.target.value);
                    const crs = courses.find(c => c.id === stu?.courseId);
                    const bInfo = stu ? getStudentMonthlyBilling(stu, crs, discounts, payments) : null;
                    const dueKeys = bInfo ? bInfo.monthlyStatuses.filter(m => !m.isPaid && !m.isPendingApproval).map(m => m.monthKey) : [];
                    setSelectedMonths(dueKeys.slice(0, 1));
                  }}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-semibold"
                >
                  {students.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.rollNo}) — {s.mobile} [{s.status}]
                    </option>
                  ))}
                </select>
              </div>

              {/* Student Info Pill */}
              {selectedStudent && (
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-400 block">Course & Batch:</span>
                    <span className="font-bold text-slate-800">{selectedCourse?.title} ({selectedBatch?.name})</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Admission Month:</span>
                    <span className="font-mono font-bold text-indigo-700">{formatMonthKey(selectedStudent.admissionMonth)}</span>
                  </div>
                </div>
              )}

              {/* Multi-month Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
                  Select Months to Collect ({selectedMonths.length} selected) <span className="text-red-500">*</span>
                </label>
                {unpaidMonths.length > 0 ? (
                  <div className="space-y-1.5 max-h-36 overflow-y-auto p-2 bg-slate-50 rounded-xl border border-slate-200">
                    {unpaidMonths.map((m) => (
                      <label key={m.monthKey} className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-200 text-xs cursor-pointer hover:bg-indigo-50/60">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={selectedMonths.includes(m.monthKey)}
                            onChange={() => handleToggleMonth(m.monthKey)}
                            className="rounded text-indigo-600 focus:ring-indigo-500"
                          />
                          <span className="font-bold text-slate-800">{m.monthLabel}</span>
                        </div>
                        <span className="font-mono font-bold text-indigo-900">₹{m.netFeeDue}</span>
                      </label>
                    ))}
                  </div>
                ) : (
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-800">
                    All historical months up to current cycle are already marked as Paid or Pending.
                  </div>
                )}
              </div>

              {/* Amount Breakdown Summary */}
              <div className="bg-indigo-50/80 p-4 rounded-2xl border border-indigo-200 space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Gross Base Tuition ({selectedMonths.length} × ₹{baseMonthlyFee}):</span>
                  <span className="font-mono font-bold text-slate-900">₹{totalBaseFee.toLocaleString('en-IN')}</span>
                </div>
                {computedAutoDiscount > 0 && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Applied Discounts ({discountNotes.join(', ')}):</span>
                    <span className="font-mono font-bold">-₹{computedAutoDiscount.toLocaleString('en-IN')}</span>
                  </div>
                )}

                {/* Additional custom concession input */}
                <div className="flex items-center justify-between pt-1 border-t border-indigo-100">
                  <span className="text-slate-700 font-medium">Additional Custom Concession (₹):</span>
                  <input
                    type="number"
                    min={0}
                    value={customDiscountOverride}
                    onChange={(e) => setCustomDiscountOverride(Number(e.target.value))}
                    className="w-24 px-2 py-1 bg-white border border-slate-300 rounded-lg text-right font-mono font-bold text-xs"
                  />
                </div>

                <div className="flex justify-between pt-2 border-t-2 border-indigo-200 text-sm font-extrabold text-indigo-950">
                  <span>Net Amount to Collect:</span>
                  <span className="font-mono text-base text-indigo-900">₹{finalAmountToPay.toLocaleString('en-IN')}</span>
                </div>
              </div>

              {/* Payment Mode & Reference */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Payment Mode
                  </label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as PaymentMode)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-bold"
                  >
                    <option value="CASH">Cash at Desk</option>
                    <option value="UPI">UPI Transfer</option>
                    <option value="BANK_TRANSFER">Bank NEFT / IMPS</option>
                    <option value="ONLINE_GATEWAY">Online Gateway</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Reference / UTR / Voucher
                  </label>
                  <input
                    type="text"
                    value={transactionRef}
                    onChange={(e) => setTransactionRef(e.target.value)}
                    placeholder="e.g. CSH-091 or UTR No"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Receipt Remarks / Notes
                </label>
                <input
                  type="text"
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="e.g. Cleared April & May fees"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowCollectModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Printer className="w-4 h-4" />
                  <span>Collect & Generate A4 Receipt</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Fee Reminder Modal */}
      {reminderTarget && (
        <FeeReminderModal
          student={reminderTarget.student}
          course={reminderTarget.course}
          batch={reminderTarget.batch}
          dueAmount={reminderTarget.dueAmount}
          dueMonths={reminderTarget.dueMonths}
          onClose={() => setReminderTarget(null)}
        />
      )}

      {/* Automated Batch Fee Reminder Modal */}
      {showBatchReminderModal && (
        <BatchFeeReminderModal
          items={studentsWithDues}
          onClose={() => setShowBatchReminderModal(false)}
        />
      )}
    </div>
  );
};
