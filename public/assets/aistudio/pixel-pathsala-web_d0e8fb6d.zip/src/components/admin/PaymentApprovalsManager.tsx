import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { FeePayment } from '../../types';
import { 
  CheckCircle, 
  XCircle, 
  Clock, 
  Printer, 
  User, 
  CreditCard, 
  Calendar, 
  AlertCircle, 
  Filter, 
  Sparkles,
  QrCode,
  Building2
} from 'lucide-react';

export const PaymentApprovalsManager: React.FC = () => {
  const { payments, approvePayment, rejectPayment, setSelectedReceiptForPrint } = useApp();

  const [rejectionPaymentId, setRejectionPaymentId] = useState<string | null>(null);
  const [rejectReasonInput, setRejectReasonInput] = useState('');
  const [filterMode, setFilterMode] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');

  const pendingPayments = payments.filter(p => p.status === 'pending');
  
  const displayedPayments = payments.filter(p => {
    if (filterMode === 'all') return true;
    return p.status === filterMode;
  });

  const handleOpenRejectModal = (paymentId: string) => {
    setRejectionPaymentId(paymentId);
    setRejectReasonInput('Invalid UPI UTR Number / Cash not received at center');
  };

  const handleConfirmReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectionPaymentId) return;
    rejectPayment(rejectionPaymentId, rejectReasonInput.trim() || 'Payment verification failed');
    setRejectionPaymentId(null);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-500" />
              <span>Student Payment Verification & Approvals</span>
            </h2>
            {pendingPayments.length > 0 && (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800 animate-pulse">
                {pendingPayments.length} Pending
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Review UPI QR transactions and Cash-at-center requests submitted by students from the Student Portal.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl border border-slate-200 text-xs">
          <button
            onClick={() => setFilterMode('pending')}
            className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
              filterMode === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pending ({pendingPayments.length})
          </button>
          <button
            onClick={() => setFilterMode('approved')}
            className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
              filterMode === 'approved' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Approved
          </button>
          <button
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
              filterMode === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All History
          </button>
        </div>
      </div>

      {/* Payment Requests Grid / List */}
      <div className="space-y-4">
        {displayedPayments.length > 0 ? (
          displayedPayments.map((pay) => (
            <div
              key={pay.id}
              className={`bg-white rounded-3xl border p-6 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-6 transition ${
                pay.status === 'pending'
                  ? 'border-amber-300 bg-amber-50/20 ring-1 ring-amber-200'
                  : pay.status === 'approved'
                  ? 'border-slate-200'
                  : 'border-red-200 bg-red-50/10 opacity-75'
              }`}
            >
              {/* Left Details */}
              <div className="space-y-2 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                    pay.status === 'pending'
                      ? 'bg-amber-100 text-amber-800'
                      : pay.status === 'approved'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {pay.status}
                  </span>

                  <span className="font-mono text-xs font-bold text-slate-500">
                    ID: {pay.receiptNo}
                  </span>

                  <span className="text-xs text-slate-400">•</span>
                  <span className="text-xs text-slate-500">Date: {pay.paymentDate}</span>
                </div>

                <div className="flex items-center gap-3">
                  <h3 className="text-lg font-bold text-slate-900">
                    {pay.studentName}
                  </h3>
                  <span className="text-xs font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    Aadhaar: {pay.studentAadhaar}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-slate-600">
                  <div>
                    <span className="text-slate-400">Course / Batch: </span>
                    <strong className="text-slate-800">{pay.courseTitle}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Months: </span>
                    <strong className="text-indigo-900">{pay.month}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Mode: </span>
                    <strong className="text-slate-800 font-mono">{pay.paymentMode}</strong>
                    {pay.transactionRef && <span className="font-mono text-[11px] text-slate-500 ml-1">({pay.transactionRef})</span>}
                  </div>
                </div>

                {pay.remarks && (
                  <p className="text-xs text-slate-500 italic bg-slate-50 p-2 rounded-xl border border-slate-100">
                    Note: &quot;{pay.remarks}&quot;
                  </p>
                )}

                {pay.rejectionReason && (
                  <p className="text-xs text-red-600 font-medium">
                    Rejection Reason: {pay.rejectionReason}
                  </p>
                )}
              </div>

              {/* Right Side Amount & Actions */}
              <div className="flex md:flex-col items-center md:items-end justify-between w-full md:w-auto gap-4 border-t md:border-t-0 pt-4 md:pt-0 border-slate-100">
                <div className="text-left md:text-right">
                  <div className="text-xs text-slate-400 font-medium">Payment Amount</div>
                  <div className="text-2xl font-black text-indigo-950 font-mono">
                    ₹{pay.finalAmountPaid.toLocaleString('en-IN')}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  {pay.status === 'pending' && (
                    <>
                      <button
                        onClick={() => approvePayment(pay.id)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md transition cursor-pointer flex items-center gap-1.5"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>Approve & Issue Receipt</span>
                      </button>

                      <button
                        onClick={() => handleOpenRejectModal(pay.id)}
                        className="px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 font-bold rounded-xl text-xs transition cursor-pointer flex items-center gap-1"
                      >
                        <XCircle className="w-4 h-4" />
                        <span>Reject</span>
                      </button>
                    </>
                  )}

                  {pay.status === 'approved' && (
                    <button
                      onClick={() => setSelectedReceiptForPrint(pay)}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md transition cursor-pointer flex items-center gap-1.5"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Print A4 Receipt</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center text-slate-400">
            <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-3 opacity-60" />
            <h3 className="font-bold text-slate-700 text-base">No {filterMode} payment requests</h3>
            <p className="text-xs text-slate-400 mt-1">All student-submitted fees have been cleared.</p>
          </div>
        )}
      </div>

      {/* Reject Modal */}
      {rejectionPaymentId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-fadeIn">
            <h3 className="text-lg font-bold text-slate-900 mb-1">
              Reject Student Fee Submission
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Please enter the reason for rejection. This will be shown to the student in their portal.
            </p>

            <form onSubmit={handleConfirmReject} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Rejection Reason <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={3}
                  required
                  value={rejectReasonInput}
                  onChange={(e) => setRejectReasonInput(e.target.value)}
                  placeholder="e.g. UTR number was invalid or cash was not received."
                  className="w-full p-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRejectionPaymentId(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
