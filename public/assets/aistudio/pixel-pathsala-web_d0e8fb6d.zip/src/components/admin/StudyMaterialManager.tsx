import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { StudyMaterial } from '../../types';
import { 
  FolderDown, 
  Upload, 
  FileText, 
  FileCode, 
  FileArchive, 
  Link2, 
  Trash2, 
  Download, 
  Search, 
  Filter, 
  Plus, 
  CheckCircle, 
  BookOpen, 
  Users, 
  Calendar, 
  ExternalLink,
  Layers,
  Sparkles,
  Eye,
  AlertCircle
} from 'lucide-react';

export const StudyMaterialManager: React.FC = () => {
  const { 
    studyMaterials, 
    addStudyMaterial, 
    deleteStudyMaterial, 
    downloadStudyMaterial,
    batches, 
    courses, 
    educators,
    showToast 
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBatchFilter, setSelectedBatchFilter] = useState('all');
  const [selectedCourseFilter, setSelectedCourseFilter] = useState('all');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [materialToDelete, setMaterialToDelete] = useState<StudyMaterial | null>(null);

  // Form State
  const [uploadMode, setUploadMode] = useState<'file' | 'link'>('file');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [targetCourseId, setTargetCourseId] = useState(courses[0]?.id || 'course-1');
  const [targetBatchId, setTargetBatchId] = useState('all');
  const [subject, setSubject] = useState('');
  const [uploadedBy, setUploadedBy] = useState('Admin - Faculty Desk');
  
  // File state
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileDataUrl, setFileDataUrl] = useState('');
  const [fileName, setFileName] = useState('');
  const [fileSize, setFileSize] = useState('');
  const [fileType, setFileType] = useState<StudyMaterial['fileType']>('pdf');
  const [externalUrl, setExternalUrl] = useState('');
  const [isProcessingFile, setIsProcessingFile] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const availableBatchesForCourse = batches.filter(b => targetCourseId === 'all' || b.courseId === targetCourseId);

  // Calculate file sizes helper
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit (max 12MB for base64 storage)
    if (file.size > 12 * 1024 * 1024) {
      alert('File size exceeds 12 MB limit. For larger videos or presentations, please use the "Web / Google Drive Link" option.');
      return;
    }

    setSelectedFile(file);
    setFileName(file.name);
    setFileSize(formatFileSize(file.size));

    // Auto-detect file type
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (ext === 'pdf') setFileType('pdf');
    else if (['doc', 'docx', 'odt', 'txt', 'rtf'].includes(ext || '')) setFileType('doc');
    else if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext || '')) setFileType('zip');
    else if (['png', 'jpg', 'jpeg', 'webp', 'svg'].includes(ext || '')) setFileType('image');
    else if (['mp4', 'mkv', 'webm', 'mov'].includes(ext || '')) setFileType('video');
    else setFileType('other');

    if (!title) {
      setTitle(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '));
    }

    setIsProcessingFile(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      setFileDataUrl(event.target?.result as string);
      setIsProcessingFile(false);
    };
    reader.onerror = () => {
      alert('Error reading local file.');
      setIsProcessingFile(false);
    };
    reader.readAsDataURL(file);
  };

  const handleOpenUploadModal = () => {
    setTitle('');
    setDescription('');
    setSubject('');
    setSelectedFile(null);
    setFileDataUrl('');
    setFileName('');
    setFileSize('');
    setExternalUrl('');
    setUploadMode('file');
    setTargetCourseId(courses[0]?.id || 'all');
    setTargetBatchId('all');
    setShowUploadModal(true);
  };

  const handleSubmitUpload = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim()) {
      alert('Please enter a title for the study material.');
      return;
    }

    let finalFileUrl = '';
    let finalFileName = '';
    let finalFileType = fileType;
    let finalFileSize = fileSize || '1.0 MB';

    if (uploadMode === 'file') {
      if (!fileDataUrl) {
        alert('Please choose a file to upload or switch to Link mode.');
        return;
      }
      finalFileUrl = fileDataUrl;
      finalFileName = fileName || `${title.replace(/[^a-zA-Z0-9]/g, '_')}.${fileType}`;
    } else {
      if (!externalUrl.trim()) {
        alert('Please enter the URL for Google Drive, YouTube, or web resource.');
        return;
      }
      finalFileUrl = externalUrl.trim();
      finalFileName = title.trim();
      finalFileType = 'link';
      finalFileSize = 'Cloud Web Resource';
    }

    addStudyMaterial({
      title: title.trim(),
      description: description.trim() || undefined,
      batchId: targetBatchId,
      courseId: targetCourseId,
      subject: subject.trim() || undefined,
      fileType: finalFileType,
      fileUrl: finalFileUrl,
      fileName: finalFileName,
      fileSize: finalFileSize,
      uploadedBy: uploadedBy.trim() || 'Center Faculty'
    });

    setShowUploadModal(false);
  };

  // Filtered materials
  const filteredMaterials = studyMaterials.filter((mat) => {
    const matchesSearch = 
      mat.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (mat.subject && mat.subject.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (mat.description && mat.description.toLowerCase().includes(searchQuery.toLowerCase())) ||
      mat.fileName.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesBatch = selectedBatchFilter === 'all' || mat.batchId === 'all' || mat.batchId === selectedBatchFilter;
    const matchesCourse = selectedCourseFilter === 'all' || mat.courseId === 'all' || mat.courseId === selectedCourseFilter;

    return matchesSearch && matchesBatch && matchesCourse;
  });

  const getFileTypeIcon = (type: StudyMaterial['fileType']) => {
    switch (type) {
      case 'pdf':
        return <FileText className="w-5 h-5 text-red-600" />;
      case 'doc':
        return <FileText className="w-5 h-5 text-blue-600" />;
      case 'zip':
        return <FileArchive className="w-5 h-5 text-amber-600" />;
      case 'link':
        return <Link2 className="w-5 h-5 text-emerald-600" />;
      case 'video':
        return <Eye className="w-5 h-5 text-purple-600" />;
      default:
        return <FileCode className="w-5 h-5 text-indigo-600" />;
    }
  };

  const getFileTypeBadgeColor = (type: StudyMaterial['fileType']) => {
    switch (type) {
      case 'pdf':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'doc':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'zip':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'link':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      default:
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
    }
  };

  const totalDownloads = studyMaterials.reduce((acc, m) => acc + (m.downloadCount || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header & Metrics */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                <FolderDown className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900">
                  Batch Study Materials & Handouts
                </h1>
                <p className="text-xs text-slate-500 mt-0.5">
                  Upload syllabus notes, PDF handouts, and lab assignments batch-wise for enrolled students to download.
                </p>
              </div>
            </div>
          </div>

          <button
            id="btn-upload-study-material"
            onClick={handleOpenUploadModal}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl text-xs sm:text-sm shadow-md transition cursor-pointer flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>Upload New Material</span>
          </button>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-100">
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
            <span className="text-[11px] text-slate-500 font-medium">Total Files & Notes</span>
            <div className="text-xl font-extrabold text-slate-900 font-mono mt-0.5">
              {studyMaterials.length}
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
            <span className="text-[11px] text-slate-500 font-medium">Target Batches</span>
            <div className="text-xl font-extrabold text-indigo-600 font-mono mt-0.5">
              {batches.length} Batches
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
            <span className="text-[11px] text-slate-500 font-medium">Student Downloads</span>
            <div className="text-xl font-extrabold text-emerald-600 font-mono mt-0.5">
              {totalDownloads}
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100">
            <span className="text-[11px] text-slate-500 font-medium">Sync Status</span>
            <div className="text-xs font-bold text-emerald-700 flex items-center gap-1 mt-1">
              <CheckCircle className="w-3.5 h-3.5" />
              <span>Available in Student Portal</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row gap-3 justify-between items-center">
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by title, subject, filename..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Course filter */}
          <div className="flex items-center gap-1 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs">
            <BookOpen className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedCourseFilter}
              onChange={(e) => setSelectedCourseFilter(e.target.value)}
              className="bg-transparent font-medium text-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="all">All Courses</option>
              {courses.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.title}
                </option>
              ))}
            </select>
          </div>

          {/* Batch filter */}
          <div className="flex items-center gap-1 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs">
            <Users className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={selectedBatchFilter}
              onChange={(e) => setSelectedBatchFilter(e.target.value)}
              className="bg-transparent font-medium text-slate-700 focus:outline-none cursor-pointer"
            >
              <option value="all">All Batches</option>
              {batches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Materials List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredMaterials.length > 0 ? (
          filteredMaterials.map((material) => {
            const course = courses.find(c => c.id === material.courseId);
            const batch = batches.find(b => b.id === material.batchId);

            return (
              <div
                key={material.id}
                className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:shadow-md transition group"
              >
                <div>
                  {/* Top Tags */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 rounded-2xl bg-slate-100 flex items-center justify-center">
                        {getFileTypeIcon(material.fileType)}
                      </div>
                      <div>
                        <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider border ${getFileTypeBadgeColor(material.fileType)}`}>
                          {material.fileType}
                        </span>
                        {material.fileSize && (
                          <span className="text-[11px] text-slate-400 ml-2 font-mono">
                            {material.fileSize}
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => setMaterialToDelete(material)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition cursor-pointer"
                      title="Delete study material"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Title & Subject */}
                  <h3 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2">
                    {material.title}
                  </h3>

                  {material.subject && (
                    <span className="inline-block text-[11px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md mt-1.5">
                      {material.subject}
                    </span>
                  )}

                  {material.description && (
                    <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                      {material.description}
                    </p>
                  )}

                  {/* Batch & Course targets */}
                  <div className="mt-4 pt-3 border-t border-slate-100 space-y-1 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-600">
                      <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-semibold text-slate-800">
                        Batch: {batch ? batch.name : 'All Batches in Course'}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                      <BookOpen className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">
                        {course ? course.title : 'All Courses'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Footer and Download Action */}
                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div className="text-[11px] text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    <span>{material.uploadedDate}</span>
                    {material.downloadCount !== undefined && material.downloadCount > 0 && (
                      <span className="font-mono text-emerald-600 font-semibold ml-1">
                        • {material.downloadCount} dl
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => downloadStudyMaterial(material)}
                    className="px-3.5 py-1.5 bg-indigo-50 hover:bg-indigo-600 text-indigo-700 hover:text-white font-bold rounded-xl text-xs transition cursor-pointer flex items-center gap-1.5 shadow-xs"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download / Test</span>
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="col-span-full bg-white rounded-3xl border border-slate-200 p-12 text-center text-slate-400">
            <FolderDown className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="font-bold text-slate-700 text-base">No Study Materials Found</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              {searchQuery || selectedBatchFilter !== 'all' 
                ? 'No materials match your current filter criteria. Try clearing the filters.' 
                : 'Click "Upload New Material" above to upload PDF handouts and batch study guides for students.'}
            </p>
          </div>
        )}
      </div>

      {/* Upload Material Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Resource Management
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  Upload Batch Study Material
                </h3>
              </div>
              <button
                onClick={() => setShowUploadModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitUpload} className="space-y-4">
              {/* Upload Mode Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">
                  Upload Format:
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setUploadMode('file')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-2.5 cursor-pointer transition ${
                      uploadMode === 'file'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-950 font-bold'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    <Upload className="w-4 h-4 text-indigo-600" />
                    <div>
                      <div className="text-xs">Direct File Upload</div>
                      <div className="text-[10px] text-slate-500 font-normal">PDF, DOCX, ZIP, PPT</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUploadMode('link')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-2.5 cursor-pointer transition ${
                      uploadMode === 'link'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-950 font-bold'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    <Link2 className="w-4 h-4 text-emerald-600" />
                    <div>
                      <div className="text-xs">Web / Drive Link</div>
                      <div className="text-[10px] text-slate-500 font-normal">Google Drive, Video, Docs</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* Title & Subject */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Material Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Chapter 4 - Functions Notes"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-medium bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Subject / Topic
                  </label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g. Python 3.12, Physics, DBMS"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm bg-white"
                  />
                </div>
              </div>

              {/* Target Course and Batch Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Target Course <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={targetCourseId}
                    onChange={(e) => {
                      setTargetCourseId(e.target.value);
                      setTargetBatchId('all');
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-medium bg-white"
                  >
                    <option value="all">All Courses</option>
                    {courses.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.title}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Target Batch <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={targetBatchId}
                    onChange={(e) => setTargetBatchId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-medium bg-white"
                  >
                    <option value="all">All Batches (General Course Material)</option>
                    {availableBatchesForCourse.map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name} ({b.timing})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* File Upload Zone */}
              {uploadMode === 'file' ? (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Choose File <span className="text-red-500">*</span>
                  </label>
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-indigo-200 hover:border-indigo-500 rounded-2xl p-6 text-center cursor-pointer transition bg-indigo-50/20 hover:bg-indigo-50/50"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      className="hidden"
                      onChange={handleFileSelect}
                      accept=".pdf,.doc,.docx,.ppt,.pptx,.zip,.rar,.txt,.png,.jpg,.jpeg"
                    />

                    {selectedFile ? (
                      <div className="flex items-center justify-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold">
                          {getFileTypeIcon(fileType)}
                        </div>
                        <div className="text-left">
                          <div className="text-xs font-bold text-slate-900">{fileName}</div>
                          <div className="text-[11px] text-slate-500 font-mono">{fileSize} • Ready to save</div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <Upload className="w-8 h-8 text-indigo-500 mx-auto mb-1" />
                        <div className="text-xs font-bold text-slate-800">
                          Click to select PDF, Word Document, or ZIP notes
                        </div>
                        <p className="text-[11px] text-slate-400">
                          Supports PDF, DOCX, ZIP up to 12 MB
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Google Drive or Resource Web Link <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <Link2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="url"
                      required
                      value={externalUrl}
                      onChange={(e) => setExternalUrl(e.target.value)}
                      placeholder="https://drive.google.com/file/d/..."
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-mono bg-white"
                    />
                  </div>
                </div>
              )}

              {/* Description & Uploaded By */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Brief Description / Instructions
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="e.g. Read sections 4.1 to 4.5 before attending Wednesday's practical session."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Uploaded By (Faculty / Admin Name)
                </label>
                <input
                  type="text"
                  value={uploadedBy}
                  onChange={(e) => setUploadedBy(e.target.value)}
                  placeholder="e.g. Dr. Debasish Roy"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs bg-white"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isProcessingFile}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Upload className="w-4 h-4" />
                  <span>Upload & Publish to Batch</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {materialToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-slate-200">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-red-100 flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Delete Study Material?</h3>
                <span className="text-xs text-slate-500">{materialToDelete.fileName}</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              Are you sure you want to remove <strong className="text-slate-900 font-bold">&quot;{materialToDelete.title}&quot;</strong> from the batch repository? Students will no longer be able to download this file.
            </p>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setMaterialToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteStudyMaterial(materialToDelete.id);
                  setMaterialToDelete(null);
                }}
                className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-md flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Confirm Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
