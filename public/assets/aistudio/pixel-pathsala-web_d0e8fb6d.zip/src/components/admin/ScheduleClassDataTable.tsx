import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { LiveClassSession, LiveClassStatus, Batch, Course } from '../../types';
import { getDistinctAcademicClasses, getCoursesForClass, getBatchesForCourse } from '../../utils/classCourseMatcher';
import { cleanMeetingUrl } from '../../utils/imageHelper';
import {
  Calendar,
  Clock,
  Radio,
  Layers,
  BookOpen,
  Users,
  Edit3,
  Trash2,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Bell,
  Send,
  Plus,
  Sparkles,
  RefreshCw,
  ExternalLink,
  Copy,
  Check,
  Printer,
  Download,
  X,
  Building2,
  Video,
  PauseCircle,
  PlayCircle,
  GraduationCap
} from 'lucide-react';

const POSTPONE_REASON_PRESETS = [
  'Faculty on Emergency Medical Leave',
  'Center Official Holiday / Public Festival',
  'Technical / High-Speed Internet Maintenance',
  'Rescheduled on Batch Students Special Request',
  'Severe Weather / Road Inaccessibility Alert',
  'Exam Preparation / Study Break Reschedule',
  'Faculty Attending Academic Conference',
  'Other / Custom Administrative Reason'
];

export const ScheduleClassDataTable: React.FC = () => {
  const {
    liveClasses,
    addLiveClass,
    updateLiveClass,
    deleteLiveClass,
    postponeLiveClass,
    autoGenerateBatchSchedules,
    sendStudentNotification,
    setLiveClassStatus,
    courses,
    batches,
    educators,
    notifications
  } = useApp();

  const distinctClasses = getDistinctAcademicClasses(courses);

  // Filter & Search states
  const [searchQuery, setSearchQuery] = useState('');
  const [filterClass, setFilterClass] = useState<string>('all');
  const [filterCourseId, setFilterCourseId] = useState<string>('all');
  const [filterBatchId, setFilterBatchId] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterDateRange, setFilterDateRange] = useState<'all' | 'today' | 'tomorrow' | 'upcoming' | 'postponed'>('all');

  // Modals state
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [editingSession, setEditingSession] = useState<LiveClassSession | null>(null);

  const [showPostponeModal, setShowPostponeModal] = useState(false);
  const [targetPostponeSession, setTargetPostponeSession] = useState<LiveClassSession | null>(null);

  const [showAutoModal, setShowAutoModal] = useState(false);
  const [showNotifyModal, setShowNotifyModal] = useState(false);
  const [targetNotifySession, setTargetNotifySession] = useState<LiveClassSession | null>(null);

  const [copiedLinkSessionId, setCopiedLinkSessionId] = useState<string | null>(null);

  // Manual Schedule Form state
  const [formTitle, setFormTitle] = useState('');
  const [formAcademicClass, setFormAcademicClass] = useState('All Classes');
  const [formCourseId, setFormCourseId] = useState('all');
  const [formBatchId, setFormBatchId] = useState('all');
  const [formSubject, setFormSubject] = useState('');
  const [formEducatorName, setFormEducatorName] = useState(educators[0]?.name || 'Faculty');
  const [formScheduledDate, setFormScheduledDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [formStartTime, setFormStartTime] = useState('05:00 PM');
  const [formEndTime, setFormEndTime] = useState('06:30 PM');
  const [formPlatform, setFormPlatform] = useState<'google_meet' | 'zoom' | 'in_app' | 'custom'>('google_meet');
  const [formMeetingUrl, setFormMeetingUrl] = useState('https://meet.google.com/new');
  const [formRoomNumber, setFormRoomNumber] = useState('Classroom 101');
  const [formMode, setFormMode] = useState<'offline' | 'online' | 'hybrid'>('online');
  const [formDescription, setFormDescription] = useState('');
  const [formNotifyStudents, setFormNotifyStudents] = useState(true);

  // Postpone Form state
  const [postponeDate, setPostponeDate] = useState('');
  const [postponeStartTime, setPostponeStartTime] = useState('');
  const [postponeEndTime, setPostponeEndTime] = useState('');
  const [postponeReasonPreset, setPostponeReasonPreset] = useState(POSTPONE_REASON_PRESETS[0]);
  const [customPostponeReason, setCustomPostponeReason] = useState('');
  const [postponeNotifyStudents, setPostponeNotifyStudents] = useState(true);
  const [isDateTbd, setIsDateTbd] = useState(false);

  // Auto-Generate Form state
  const [autoCourseId, setAutoCourseId] = useState('all');
  const [autoBatchId, setAutoBatchId] = useState('all');
  const [autoRangePreset, setAutoRangePreset] = useState<'7days' | '14days' | '30days' | 'custom'>('7days');
  const [autoStartDate, setAutoStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [autoEndDate, setAutoEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().split('T')[0];
  });
  const [autoNotifyToggle, setAutoNotifyToggle] = useState(true);

  // Custom Direct Notification Form state
  const [customNotifTitle, setCustomNotifTitle] = useState('');
  const [customNotifMessage, setCustomNotifMessage] = useState('');

  // Resolution helper for Educator Name
  const getResolvedEducator = (session: LiveClassSession): string => {
    if (session.educatorId) {
      const match = educators.find(e => e.id === session.educatorId);
      if (match) return match.name;
    }
    if (session.educatorName && session.educatorName !== 'Faculty' && session.educatorName !== 'all') {
      return session.educatorName;
    }
    if (session.batchId && session.batchId !== 'all') {
      const b = batches.find(x => x.id === session.batchId);
      if (b && b.educatorId) {
        const match = educators.find(e => e.id === b.educatorId);
        if (match) return match.name;
      }
    }
    return educators[0]?.name || 'Senior Faculty';
  };

  // Cascading helpers for Schedule Form
  const matchedCourses = useMemo(() => {
    if (formAcademicClass && formAcademicClass !== 'All Classes') {
      return getCoursesForClass(courses, formAcademicClass);
    }
    return courses;
  }, [courses, formAcademicClass]);

  const matchedBatches = useMemo(() => {
    if (formCourseId && formCourseId !== 'all') {
      return getBatchesForCourse(batches, formCourseId);
    }
    if (formAcademicClass && formAcademicClass !== 'All Classes') {
      return batches.filter(b => {
        const c = courses.find(course => course.id === b.courseId);
        return b.academicClass === formAcademicClass || (c && c.academicClass === formAcademicClass);
      });
    }
    return batches;
  }, [batches, courses, formCourseId, formAcademicClass]);

  // Handlers for cascading dropdowns in modal
  const handleAcademicClassChange = (selectedClass: string) => {
    setFormAcademicClass(selectedClass);
    const mCourses = selectedClass !== 'All Classes' ? getCoursesForClass(courses, selectedClass) : courses;
    const nextCourseId = mCourses.length > 0 ? (mCourses.some(c => c.id === formCourseId) ? formCourseId : 'all') : 'all';
    setFormCourseId(nextCourseId);
    const mBatches = nextCourseId !== 'all' ? batches.filter(b => b.courseId === nextCourseId) : batches;
    setFormBatchId(mBatches.some(b => b.id === formBatchId) ? formBatchId : 'all');
  };

  const handleCourseChange = (selectedCourseId: string) => {
    setFormCourseId(selectedCourseId);
    const c = courses.find(x => x.id === selectedCourseId);
    if (c && c.academicClass && formAcademicClass === 'All Classes') {
      setFormAcademicClass(c.academicClass);
    }
    const mBatches = selectedCourseId !== 'all' ? batches.filter(b => b.courseId === selectedCourseId) : batches;
    setFormBatchId(mBatches.some(b => b.id === formBatchId) ? formBatchId : 'all');
  };

  const handleBatchChange = (selectedBatchId: string) => {
    setFormBatchId(selectedBatchId);
    if (selectedBatchId !== 'all') {
      const b = batches.find(x => x.id === selectedBatchId);
      if (b) {
        setFormCourseId(b.courseId);
        if (b.academicClass) setFormAcademicClass(b.academicClass);
        if (b.roomNumber) setFormRoomNumber(b.roomNumber);
        if (b.mode) setFormMode(b.mode === 'online' ? 'online' : 'offline');
        // Pre-fill timing from batch timing
        if (b.timing && b.timing.includes('-')) {
          const parts = b.timing.split('-').map(s => s.trim());
          if (parts[0]) setFormStartTime(parts[0]);
          if (parts[1]) setFormEndTime(parts[1]);
        }
        if (b.educatorId) {
          const edu = educators.find(e => e.id === b.educatorId);
          if (edu) setFormEducatorName(edu.name);
        }
      }
    }
  };

  // Open Create / Edit Schedule Modal
  const handleOpenScheduleModal = (session?: LiveClassSession) => {
    if (session) {
      setEditingSession(session);
      setFormTitle(session.title);
      setFormAcademicClass(session.academicClass || session.targetClass || 'All Classes');
      setFormCourseId(session.courseId || 'all');
      setFormBatchId(session.batchId || 'all');
      setFormSubject(session.subject || '');
      setFormEducatorName(session.educatorName || educators[0]?.name || 'Faculty');
      setFormScheduledDate(session.scheduledDate);
      setFormStartTime(session.startTime);
      setFormEndTime(session.endTime);
      setFormPlatform(session.platform as any || 'google_meet');
      setFormMeetingUrl(session.meetingUrl || '');
      setFormRoomNumber(session.roomNumber || 'Classroom 101');
      setFormMode(session.mode || 'online');
      setFormDescription(session.description || '');
      setFormNotifyStudents(false); // don't spam if editing existing
    } else {
      setEditingSession(null);
      setFormTitle('');
      setFormAcademicClass('All Classes');
      setFormCourseId('all');
      setFormBatchId('all');
      setFormSubject(courses[0]?.category || 'Computer Science');
      setFormEducatorName(educators[0]?.name || 'Faculty');
      const today = new Date().toISOString().split('T')[0];
      setFormScheduledDate(today);
      setFormStartTime('05:00 PM');
      setFormEndTime('06:30 PM');
      setFormPlatform('google_meet');
      setFormMeetingUrl('https://meet.google.com/new');
      setFormRoomNumber('Classroom 101');
      setFormMode('online');
      setFormDescription('');
      setFormNotifyStudents(true);
    }
    setShowScheduleModal(true);
  };

  // Save Schedule Handler (Manual)
  const handleSaveSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) {
      alert('Please enter a class title or topic.');
      return;
    }

    const cleanedUrl = cleanMeetingUrl(formMeetingUrl) || (formMode === 'online' ? 'https://meet.google.com/new' : '');

    const payload = {
      title: formTitle.trim(),
      academicClass: formAcademicClass,
      targetClass: formAcademicClass,
      subject: formSubject.trim() || 'General Subject',
      courseId: formCourseId,
      batchId: formBatchId,
      educatorName: formEducatorName,
      scheduledDate: formScheduledDate,
      startTime: formStartTime,
      endTime: formEndTime,
      status: (editingSession?.status || 'scheduled') as LiveClassStatus,
      platform: formPlatform,
      meetingUrl: cleanedUrl,
      roomNumber: formRoomNumber,
      mode: formMode,
      description: formDescription.trim(),
      isRecordingAvailable: editingSession?.isRecordingAvailable || false,
      recordingUrl: editingSession?.recordingUrl || ''
    };

    if (editingSession) {
      updateLiveClass(editingSession.id, payload);
    } else {
      addLiveClass(payload, formNotifyStudents);
    }

    setShowScheduleModal(false);
  };

  // Open Postpone Modal
  const handleOpenPostponeModal = (session: LiveClassSession) => {
    setTargetPostponeSession(session);
    // calculate a suggested tomorrow date
    const d = new Date(session.scheduledDate || new Date());
    d.setDate(d.getDate() + 1);
    const tomorrowStr = d.toISOString().split('T')[0];

    setPostponeDate(session.rescheduledDate || tomorrowStr);
    setPostponeStartTime(session.rescheduledStartTime || session.startTime);
    setPostponeEndTime(session.rescheduledEndTime || session.endTime);
    setPostponeReasonPreset(POSTPONE_REASON_PRESETS[0]);
    setCustomPostponeReason(session.postponedReason || '');
    setPostponeNotifyStudents(true);
    setIsDateTbd(false);
    setShowPostponeModal(true);
  };

  // Confirm Postpone Handler
  const handleConfirmPostpone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetPostponeSession) return;

    const finalReason = customPostponeReason.trim()
      ? customPostponeReason.trim()
      : postponeReasonPreset;

    postponeLiveClass(targetPostponeSession.id, {
      postponedReason: finalReason,
      rescheduledDate: isDateTbd ? undefined : postponeDate,
      rescheduledStartTime: isDateTbd ? undefined : postponeStartTime,
      rescheduledEndTime: isDateTbd ? undefined : postponeEndTime,
      notifyStudents: postponeNotifyStudents
    });

    setShowPostponeModal(false);
    setTargetPostponeSession(null);
  };

  // Resume / Restore Postponed Class to Scheduled
  const handleResumeClass = (session: LiveClassSession) => {
    if (confirm(`Resume class "${session.title}" back to Scheduled status?`)) {
      updateLiveClass(session.id, {
        status: 'scheduled',
        isPostponed: false
      });
    }
  };

  // Auto-Generate Presets
  const handleAutoRangePresetChange = (preset: '7days' | '14days' | '30days' | 'custom') => {
    setAutoRangePreset(preset);
    const start = new Date();
    const startStr = start.toISOString().split('T')[0];
    setAutoStartDate(startStr);

    if (preset === '7days') {
      const end = new Date();
      end.setDate(end.getDate() + 7);
      setAutoEndDate(end.toISOString().split('T')[0]);
    } else if (preset === '14days') {
      const end = new Date();
      end.setDate(end.getDate() + 14);
      setAutoEndDate(end.toISOString().split('T')[0]);
    } else if (preset === '30days') {
      const end = new Date();
      end.setDate(end.getDate() + 30);
      setAutoEndDate(end.toISOString().split('T')[0]);
    }
  };

  // Run Auto-Generation
  const handleRunAutoGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    const res = autoGenerateBatchSchedules({
      courseId: autoCourseId,
      batchId: autoBatchId,
      startDate: autoStartDate,
      endDate: autoEndDate,
      autoNotify: autoNotifyToggle
    });
    alert(res.message);
    if (res.generatedCount > 0) {
      setShowAutoModal(false);
    }
  };

  // Open Direct Notification Modal
  const handleOpenNotifyModal = (session: LiveClassSession) => {
    setTargetNotifySession(session);
    const batch = batches.find(b => b.id === session.batchId);
    setCustomNotifTitle(`🔔 Class Update: ${session.title}`);
    setCustomNotifMessage(
      `Reminder for students of ${batch?.name || 'Batch'}: Session on "${session.subject}" is scheduled for ${session.scheduledDate} at ${session.startTime} - ${session.endTime}. Please be on time!`
    );
    setShowNotifyModal(true);
  };

  const handleSendCustomNotification = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetNotifySession || !customNotifTitle.trim()) return;

    sendStudentNotification({
      title: customNotifTitle.trim(),
      message: customNotifMessage.trim(),
      type: 'general',
      courseId: targetNotifySession.courseId,
      batchId: targetNotifySession.batchId,
      studentId: 'all',
      classSessionId: targetNotifySession.id,
      classTitle: targetNotifySession.title,
      scheduledDate: targetNotifySession.scheduledDate,
      timeSlot: `${targetNotifySession.startTime} - ${targetNotifySession.endTime}`,
      reason: 'Administrative alert from faculty'
    });

    // Mark session as notified
    updateLiveClass(targetNotifySession.id, {
      notificationSent: true,
      notificationSentAt: new Date().toISOString()
    });

    setShowNotifyModal(false);
    setTargetNotifySession(null);
  };

  // Helper to copy meeting link
  const handleCopyLink = (url: string, id: string) => {
    if (!url) return;
    navigator.clipboard.writeText(url);
    setCopiedLinkSessionId(id);
    setTimeout(() => setCopiedLinkSessionId(null), 2000);
  };

  // Filtered Sessions
  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrowDate = new Date();
  tomorrowDate.setDate(tomorrowDate.getDate() + 1);
  const tomorrowStr = tomorrowDate.toISOString().split('T')[0];

  const filteredSessions = useMemo(() => {
    return liveClasses.filter(s => {
      // Search
      const q = searchQuery.toLowerCase();
      const matchesSearch =
        s.title.toLowerCase().includes(q) ||
        (s.subject && s.subject.toLowerCase().includes(q)) ||
        (s.educatorName && s.educatorName.toLowerCase().includes(q)) ||
        (s.roomNumber && s.roomNumber.toLowerCase().includes(q)) ||
        (s.postponedReason && s.postponedReason.toLowerCase().includes(q));

      // Academic Class
      const cls = s.academicClass || s.targetClass || 'All Classes';
      const matchesClass = filterClass === 'all' || cls === 'All Classes' || cls === filterClass;

      // Course
      const matchesCourse = filterCourseId === 'all' || s.courseId === 'all' || s.courseId === filterCourseId;

      // Batch
      const matchesBatch = filterBatchId === 'all' || s.batchId === 'all' || s.batchId === filterBatchId;

      // Status
      const matchesStatus = filterStatus === 'all' || s.status === filterStatus;

      // Date Range
      let matchesDate = true;
      if (filterDateRange === 'today') {
        matchesDate = s.scheduledDate === todayStr || s.rescheduledDate === todayStr;
      } else if (filterDateRange === 'tomorrow') {
        matchesDate = s.scheduledDate === tomorrowStr || s.rescheduledDate === tomorrowStr;
      } else if (filterDateRange === 'upcoming') {
        matchesDate = s.scheduledDate >= todayStr && s.status !== 'completed' && s.status !== 'cancelled';
      } else if (filterDateRange === 'postponed') {
        matchesDate = s.status === 'postponed' || !!s.isPostponed;
      }

      return matchesSearch && matchesClass && matchesCourse && matchesBatch && matchesStatus && matchesDate;
    });
  }, [liveClasses, searchQuery, filterClass, filterCourseId, filterBatchId, filterStatus, filterDateRange, todayStr, tomorrowStr]);

  // Statistics
  const scheduledCount = liveClasses.filter(s => s.status === 'scheduled').length;
  const postponedCount = liveClasses.filter(s => s.status === 'postponed' || s.isPostponed).length;
  const liveCount = liveClasses.filter(s => s.status === 'live').length;
  const todayClassesCount = liveClasses.filter(s => s.scheduledDate === todayStr || s.rescheduledDate === todayStr).length;
  const batchesCoveredCount = new Set(liveClasses.map(s => s.batchId).filter(b => b && b !== 'all')).size;
  const notificationsCount = notifications.length;

  return (
    <div className="space-y-6">
      {/* Top Banner & Primary Actions */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-[11px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-indigo-400" />
              Course Batch Timetable & Live Scheduler
            </span>
            {postponedCount > 0 && (
              <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wide bg-amber-500/20 text-amber-300 border border-amber-400/40 flex items-center gap-1 animate-pulse">
                <AlertTriangle className="w-3 h-3 text-amber-400" />
                {postponedCount} Postponed Notice{postponedCount > 1 ? 's' : ''}
              </span>
            )}
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Class Schedule & Postpone Management Data Table
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            Assign live & classroom sessions to course batches, manage automatic timetable syncs, postpone sessions with instant student login alerts, and edit or delete records manually anytime.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
          {/* Automatic Generation Button */}
          <button
            onClick={() => setShowAutoModal(true)}
            className="px-4 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-2xl text-xs font-black shadow-lg shadow-emerald-900/20 transition transform hover:scale-105 flex items-center gap-2 cursor-pointer border border-emerald-400/30 shrink-0"
            title="Auto-generate multiple class sessions matching batch schedule days & timings"
          >
            <Sparkles className="w-4 h-4 text-emerald-200 animate-spin" style={{ animationDuration: '4s' }} />
            <span>⚡ Auto-Generate from Batch Schedule</span>
          </button>

          {/* Manual Schedule Button */}
          <button
            onClick={() => handleOpenScheduleModal()}
            className="px-4 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-xs font-black shadow-lg shadow-indigo-900/20 transition transform hover:scale-105 flex items-center gap-2 cursor-pointer border border-indigo-400/30 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>➕ Schedule Class (Manual)</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-300 transition">
          <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 flex items-center gap-1">
            <Calendar className="w-3 h-3" />
            Scheduled
          </span>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">
            {scheduledCount}
          </div>
          <span className="text-[10px] text-slate-400">Upcoming in queue</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-amber-300 transition">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            Postponed
          </span>
          <div className="text-2xl font-black text-amber-600 font-mono mt-1">
            {postponedCount}
          </div>
          <span className="text-[10px] text-slate-400">Rescheduled alerts</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-rose-300 transition">
          <span className="text-[10px] font-bold uppercase tracking-wider text-rose-600 flex items-center gap-1">
            <Radio className="w-3 h-3 animate-pulse" />
            Live Now
          </span>
          <div className="text-2xl font-black text-rose-600 font-mono mt-1">
            {liveCount}
          </div>
          <span className="text-[10px] text-slate-400">Broadcasting live</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-emerald-300 transition">
          <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            Today's Classes
          </span>
          <div className="text-2xl font-black text-emerald-700 font-mono mt-1">
            {todayClassesCount}
          </div>
          <span className="text-[10px] text-slate-400">On today's roster</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-violet-300 transition">
          <span className="text-[10px] font-bold uppercase tracking-wider text-violet-600 flex items-center gap-1">
            <Layers className="w-3 h-3" />
            Batches Covered
          </span>
          <div className="text-2xl font-black text-violet-700 font-mono mt-1">
            {batchesCoveredCount}
          </div>
          <span className="text-[10px] text-slate-400">Active assigned batches</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs hover:border-sky-300 transition">
          <span className="text-[10px] font-bold uppercase tracking-wider text-sky-600 flex items-center gap-1">
            <Bell className="w-3 h-3" />
            Student Alerts
          </span>
          <div className="text-2xl font-black text-sky-700 font-mono mt-1">
            {notificationsCount}
          </div>
          <span className="text-[10px] text-slate-400">Broadcast notices sent</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by topic, batch, educator, reason..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Date Range Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto p-1 bg-slate-100 rounded-2xl shrink-0">
            {[
              { id: 'all', label: 'All Dates' },
              { id: 'today', label: "Today's Classes" },
              { id: 'tomorrow', label: 'Tomorrow' },
              { id: 'upcoming', label: 'Upcoming Only' },
              { id: 'postponed', label: '⚠️ Postponed Only' }
            ].map(pill => (
              <button
                key={pill.id}
                onClick={() => setFilterDateRange(pill.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
                  filterDateRange === pill.id
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {pill.label}
              </button>
            ))}
          </div>
        </div>

        {/* Dropdown Filters */}
        <div className="flex flex-wrap items-center gap-2.5 pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-1.5 text-slate-500 font-bold shrink-0">
            <Filter className="w-3.5 h-3.5 text-indigo-500" />
            <span>Filter:</span>
          </div>

          {/* Academic Class */}
          <select
            value={filterClass}
            onChange={(e) => setFilterClass(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Academic Classes</option>
            {distinctClasses.map(cls => (
              <option key={cls} value={cls}>{cls}</option>
            ))}
          </select>

          {/* Course */}
          <select
            value={filterCourseId}
            onChange={(e) => setFilterCourseId(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 max-w-[200px] truncate"
          >
            <option value="all">All Courses</option>
            {courses.map(c => (
              <option key={c.id} value={c.id}>{c.title}</option>
            ))}
          </select>

          {/* Batch */}
          <select
            value={filterBatchId}
            onChange={(e) => setFilterBatchId(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 max-w-[220px] truncate"
          >
            <option value="all">All Batches</option>
            {batches.map(b => (
              <option key={b.id} value={b.id}>
                {b.name} ({b.scheduleDays?.join(', ')} @ {b.timing})
              </option>
            ))}
          </select>

          {/* Status */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Statuses</option>
            <option value="scheduled">🟡 Scheduled</option>
            <option value="postponed">🟠 Postponed</option>
            <option value="live">🔴 Live Now</option>
            <option value="completed">🟢 Completed</option>
            <option value="cancelled">⚪ Cancelled</option>
          </select>

          {/* Clear Filters Button */}
          {(filterClass !== 'all' || filterCourseId !== 'all' || filterBatchId !== 'all' || filterStatus !== 'all' || filterDateRange !== 'all' || searchQuery) && (
            <button
              onClick={() => {
                setFilterClass('all');
                setFilterCourseId('all');
                setFilterBatchId('all');
                setFilterStatus('all');
                setFilterDateRange('all');
                setSearchQuery('');
              }}
              className="text-xs font-bold text-rose-600 hover:text-rose-700 ml-auto cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* DATA TABLE */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        {filteredSessions.length === 0 ? (
          <div className="p-12 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-indigo-50 text-indigo-500 flex items-center justify-center">
              <Calendar className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-slate-800 text-base">No Classes Found</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                No scheduled or postponed classes match your current filter query. You can auto-generate sessions from your course batches or schedule a class manually.
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setShowAutoModal(true)}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-600/20"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Auto-Generate from Batch</span>
              </button>
              <button
                onClick={() => handleOpenScheduleModal()}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/20"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Schedule Class Manually</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 min-w-[200px]">Class Title & Subject</th>
                  <th className="py-3.5 px-4 min-w-[200px]">Course & Assigned Batch</th>
                  <th className="py-3.5 px-4 min-w-[170px]">Scheduled Date & Timing</th>
                  <th className="py-3.5 px-4">Faculty</th>
                  <th className="py-3.5 px-4 min-w-[140px]">Venue / Platform</th>
                  <th className="py-3.5 px-4">Student Alert</th>
                  <th className="py-3.5 px-4 text-right min-w-[160px]">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredSessions.map((session) => {
                  const batch = batches.find(b => b.id === session.batchId);
                  const course = courses.find(c => c.id === session.courseId);
                  const isPostponed = session.status === 'postponed' || !!session.isPostponed;
                  const isLive = session.status === 'live';
                  const isCompleted = session.status === 'completed';
                  const isCancelled = session.status === 'cancelled';
                  const facultyName = getResolvedEducator(session);

                  return (
                    <tr
                      key={session.id}
                      className={`hover:bg-slate-50/80 transition ${
                        isPostponed ? 'bg-amber-50/30' : isLive ? 'bg-rose-50/30' : ''
                      }`}
                    >
                      {/* 1. Status Column */}
                      <td className="py-3.5 px-4 align-top">
                        {isPostponed && (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wide bg-amber-500 text-white shadow-xs">
                              <AlertTriangle className="w-3 h-3" />
                              POSTPONED
                            </span>
                            {session.postponedReason && (
                              <p className="text-[10px] font-semibold text-amber-800 line-clamp-1 max-w-[120px]" title={session.postponedReason}>
                                {session.postponedReason}
                              </p>
                            )}
                          </div>
                        )}
                        {isLive && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wide bg-rose-600 text-white animate-pulse shadow-xs">
                            <span className="w-2 h-2 rounded-full bg-white"></span>
                            LIVE NOW
                          </span>
                        )}
                        {!isPostponed && !isLive && session.status === 'scheduled' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide bg-blue-50 text-blue-700 border border-blue-200">
                            <Clock className="w-3 h-3 text-blue-500" />
                            SCHEDULED
                          </span>
                        )}
                        {isCompleted && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                            COMPLETED
                          </span>
                        )}
                        {isCancelled && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide bg-slate-100 text-slate-500">
                            CANCELLED
                          </span>
                        )}
                      </td>

                      {/* 2. Class Title & Subject */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="space-y-1">
                          <h4 className="font-extrabold text-slate-900 text-sm leading-snug">
                            {session.title}
                          </h4>
                          <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
                            <span className="font-semibold text-indigo-600">
                              {session.subject}
                            </span>
                            <span>•</span>
                            <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 text-[10px] font-medium">
                              {session.academicClass || session.targetClass || 'All Classes'}
                            </span>
                          </div>
                          {session.description && (
                            <p className="text-[11px] text-slate-500 line-clamp-1">
                              {session.description}
                            </p>
                          )}
                        </div>
                      </td>

                      {/* 3. Course & Assigned Batch */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="space-y-1">
                          <div className="font-bold text-slate-800 flex items-center gap-1">
                            <BookOpen className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                            <span className="truncate max-w-[180px]">{course?.title || 'Open Course'}</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-[11px] text-slate-600">
                            <Layers className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span className="font-semibold text-slate-700">
                              {session.batchId === 'all' ? 'All Batches (Open Session)' : (batch?.name || 'Assigned Batch')}
                            </span>
                          </div>
                          {batch?.scheduleDays && batch.scheduleDays.length > 0 && (
                            <div className="flex items-center gap-1 text-[10px] text-slate-400">
                              <span className="font-mono bg-slate-100 px-1.5 py-0.5 rounded text-slate-600 font-bold">
                                {batch.scheduleDays.join(', ')}
                              </span>
                              <span>•</span>
                              <span>{batch.timing}</span>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* 4. Scheduled Date & Timing */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="space-y-1.5">
                          {isPostponed ? (
                            <div className="p-2 bg-amber-100/70 rounded-xl border border-amber-300 text-amber-950 space-y-1">
                              <div className="text-[10px] line-through text-slate-500">
                                Original: {session.originalDate || session.scheduledDate} ({session.originalStartTime || session.startTime})
                              </div>
                              <div className="font-extrabold text-[11px] text-amber-900 flex items-center gap-1">
                                <span>👉 Rescheduled:</span>
                                <span>{session.rescheduledDate || 'Date TBD'}</span>
                              </div>
                              {session.rescheduledStartTime && (
                                <div className="text-[10px] font-bold text-amber-800">
                                  Time: {session.rescheduledStartTime} - {session.rescheduledEndTime || ''}
                                </div>
                              )}
                            </div>
                          ) : (
                            <div>
                              <div className="font-extrabold text-slate-900 flex items-center gap-1">
                                <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                                <span>{session.scheduledDate}</span>
                              </div>
                              <div className="text-[11px] font-semibold text-slate-600 flex items-center gap-1 mt-0.5">
                                <Clock className="w-3 h-3 text-slate-400" />
                                <span>{session.startTime} - {session.endTime}</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* 5. Faculty */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 font-bold flex items-center justify-center text-[10px] shrink-0">
                            {facultyName.charAt(0)}
                          </div>
                          <span className="font-bold text-slate-800 line-clamp-1 max-w-[110px]" title={facultyName}>
                            {facultyName}
                          </span>
                        </div>
                      </td>

                      {/* 6. Venue / Platform */}
                      <td className="py-3.5 px-4 align-top">
                        <div className="space-y-1">
                          <span className="inline-block px-2 py-0.5 rounded-md text-[10px] font-extrabold uppercase bg-slate-100 text-slate-700">
                            {session.platform?.replace('_', ' ') || 'Google Meet'}
                          </span>
                          {session.roomNumber && (
                            <p className="text-[10px] text-slate-500 flex items-center gap-1">
                              <Building2 className="w-3 h-3 text-slate-400" />
                              <span>{session.roomNumber}</span>
                            </p>
                          )}
                          {session.meetingUrl && (
                            <div className="flex items-center gap-1.5 pt-0.5">
                              <a
                                href={session.meetingUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5"
                              >
                                <span>Join URL</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                              <button
                                onClick={() => handleCopyLink(session.meetingUrl!, session.id)}
                                className="text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                                title="Copy Meeting Link"
                              >
                                {copiedLinkSessionId === session.id ? (
                                  <Check className="w-3 h-3 text-emerald-500" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </button>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* 7. Student Alert */}
                      <td className="py-3.5 px-4 align-top">
                        {session.notificationSent ? (
                          <div className="space-y-1">
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                              Sent to Batch
                            </span>
                            <button
                              onClick={() => handleOpenNotifyModal(session)}
                              className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold block cursor-pointer"
                            >
                              Re-send Alert
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleOpenNotifyModal(session)}
                            className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-[10px] font-bold transition flex items-center gap-1 cursor-pointer"
                          >
                            <Send className="w-3 h-3" />
                            <span>Notify Batch</span>
                          </button>
                        )}
                      </td>

                      {/* 8. Actions */}
                      <td className="py-3.5 px-4 align-top text-right">
                        <div className="flex items-center justify-end gap-1.5 flex-wrap">
                          {/* Postpone button */}
                          {!isPostponed ? (
                            <button
                              onClick={() => handleOpenPostponeModal(session)}
                              className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg transition cursor-pointer border border-amber-200"
                              title="Postpone Class & Notify Students"
                            >
                              <PauseCircle className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              onClick={() => handleResumeClass(session)}
                              className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg transition cursor-pointer border border-emerald-200"
                              title="Resume / Unpostpone to Scheduled"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Quick Go Live toggle */}
                          {session.status !== 'live' ? (
                            <button
                              onClick={() => setLiveClassStatus(session.id, 'live')}
                              className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg transition cursor-pointer border border-rose-200"
                              title="Start Live Stream Now"
                            >
                              <PlayCircle className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              onClick={() => setLiveClassStatus(session.id, 'completed')}
                              className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg transition cursor-pointer border border-emerald-200"
                              title="Mark Completed"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Edit button */}
                          <button
                            onClick={() => handleOpenScheduleModal(session)}
                            className="p-1.5 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 rounded-lg transition cursor-pointer"
                            title="Edit Class Details"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete button */}
                          <button
                            onClick={() => {
                              if (confirm(`Are you sure you want to delete class "${session.title}"?`)) {
                                deleteLiveClass(session.id);
                              }
                            }}
                            className="p-1.5 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-700 rounded-lg transition cursor-pointer"
                            title="Delete Class"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Table Footer info */}
        <div className="p-4 bg-slate-50/80 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-slate-500 font-medium">
          <span>
            Showing <strong>{filteredSessions.length}</strong> of <strong>{liveClasses.length}</strong> total schedule entries
          </span>
          <div className="flex items-center gap-2">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span>Real-time persistence active</span>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 1. AUTO-GENERATE MODAL (From Course Batch Schedule)       */}
      {/* ========================================================= */}
      {showAutoModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">
                    ⚡ Auto-Generate from Course Batch Schedule
                  </h3>
                  <p className="text-xs text-slate-500">
                    Automatically create scheduled sessions matching your batch timetable days & timings.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowAutoModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRunAutoGenerate} className="space-y-4 text-xs">
              {/* Select Course */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  1. Select Target Course
                </label>
                <select
                  value={autoCourseId}
                  onChange={(e) => {
                    setAutoCourseId(e.target.value);
                    setAutoBatchId('all');
                  }}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="all">All Courses (All Active Batches)</option>
                  {courses.map(c => (
                    <option key={c.id} value={c.id}>{c.title}</option>
                  ))}
                </select>
              </div>

              {/* Select Batch */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  2. Select Target Batch
                </label>
                <select
                  value={autoBatchId}
                  onChange={(e) => setAutoBatchId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="all">All Active Batches in Selection</option>
                  {(autoCourseId === 'all' ? batches : batches.filter(b => b.courseId === autoCourseId)).map(b => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.scheduleDays?.join(', ')} @ {b.timing})
                    </option>
                  ))}
                </select>
              </div>

              {/* Batch Timetable Info Preview */}
              {autoBatchId !== 'all' && (() => {
                const b = batches.find(x => x.id === autoBatchId);
                const c = courses.find(x => x.id === b?.courseId);
                const edu = educators.find(x => x.id === b?.educatorId);
                if (!b) return null;
                return (
                  <div className="p-3.5 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-950 space-y-1 text-xs">
                    <span className="font-black text-emerald-900 block">
                      📌 Selected Batch Schedule Specs:
                    </span>
                    <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                      <div>
                        <span className="text-emerald-700">Days: </span>
                        <strong>{b.scheduleDays?.join(', ') || 'N/A'}</strong>
                      </div>
                      <div>
                        <span className="text-emerald-700">Timing: </span>
                        <strong>{b.timing}</strong>
                      </div>
                      <div>
                        <span className="text-emerald-700">Faculty: </span>
                        <strong>{edu?.name || 'Assigned Faculty'}</strong>
                      </div>
                      <div>
                        <span className="text-emerald-700">Venue / Room: </span>
                        <strong>{b.roomNumber || 'Classroom 101'}</strong>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Date Range Presets */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  3. Select Date Window
                </label>
                <div className="flex items-center gap-2 mb-2">
                  {[
                    { id: '7days', label: 'Next 7 Days (1 Week)' },
                    { id: '14days', label: 'Next 14 Days (2 Weeks)' },
                    { id: '30days', label: 'Next 30 Days (1 Month)' }
                  ].map(p => (
                    <button
                      type="button"
                      key={p.id}
                      onClick={() => handleAutoRangePresetChange(p.id as any)}
                      className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer text-xs ${
                        autoRangePreset === p.id
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-slate-500 font-semibold block mb-0.5">Start Date:</span>
                    <input
                      type="date"
                      value={autoStartDate}
                      onChange={(e) => {
                        setAutoStartDate(e.target.value);
                        setAutoRangePreset('custom');
                      }}
                      className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 font-semibold block mb-0.5">End Date:</span>
                    <input
                      type="date"
                      value={autoEndDate}
                      onChange={(e) => {
                        setAutoEndDate(e.target.value);
                        setAutoRangePreset('custom');
                      }}
                      className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* Auto-notify toggle */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-800 block">
                    📢 Send Notification to Enrolled Students
                  </span>
                  <p className="text-[11px] text-slate-500">
                    Immediately send schedule alerts to student login portal for this batch.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={autoNotifyToggle}
                  onChange={(e) => setAutoNotifyToggle(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded cursor-pointer"
                />
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAutoModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-extrabold shadow-lg shadow-emerald-600/20 transition cursor-pointer flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>⚡ Generate Batch Schedule Now</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. POSTPONE CLASS MODAL                                   */}
      {/* ========================================================= */}
      {showPostponeModal && targetPostponeSession && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-lg shadow-amber-500/20">
                  <PauseCircle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">
                    Postpone Class Session
                  </h3>
                  <p className="text-xs text-slate-500">
                    Reschedule this class and broadcast an alert to student logins.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowPostponeModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Current Session Summary */}
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
              <div className="font-extrabold text-slate-900">{targetPostponeSession.title}</div>
              <div className="text-slate-600 flex items-center gap-2 text-[11px]">
                <span>Original Date: <strong>{targetPostponeSession.scheduledDate}</strong></span>
                <span>•</span>
                <span>Timing: <strong>{targetPostponeSession.startTime} - {targetPostponeSession.endTime}</strong></span>
              </div>
              <div className="text-slate-500 text-[11px]">
                Faculty: {getResolvedEducator(targetPostponeSession)}
              </div>
            </div>

            <form onSubmit={handleConfirmPostpone} className="space-y-4 text-xs">
              {/* Reason Preset */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  1. Reason for Postponement
                </label>
                <select
                  value={postponeReasonPreset}
                  onChange={(e) => setPostponeReasonPreset(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-amber-500 focus:outline-none"
                >
                  {POSTPONE_REASON_PRESETS.map(r => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

              {/* Custom Reason Details */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Custom Notes / Explanation (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Rescheduled due to festival holiday; session shifted to Friday"
                  value={customPostponeReason}
                  onChange={(e) => setCustomPostponeReason(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>

              {/* Reschedule Date Option */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-700 font-bold">
                    2. New Rescheduled Date & Time
                  </label>
                  <label className="flex items-center gap-1.5 text-[11px] text-amber-700 font-bold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isDateTbd}
                      onChange={(e) => setIsDateTbd(e.target.checked)}
                      className="rounded text-amber-600 cursor-pointer"
                    />
                    <span>Date To Be Announced (TBD)</span>
                  </label>
                </div>

                {!isDateTbd && (
                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-1">
                      <span className="text-[10px] text-slate-400 block mb-0.5">New Date:</span>
                      <input
                        type="date"
                        required={!isDateTbd}
                        value={postponeDate}
                        onChange={(e) => setPostponeDate(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">Start Time:</span>
                      <input
                        type="text"
                        placeholder="05:00 PM"
                        value={postponeStartTime}
                        onChange={(e) => setPostponeStartTime(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-xs focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">End Time:</span>
                      <input
                        type="text"
                        placeholder="06:30 PM"
                        value={postponeEndTime}
                        onChange={(e) => setPostponeEndTime(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-xs focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Notify Students Checkbox */}
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-center justify-between">
                <div>
                  <span className="font-extrabold text-amber-950 block">
                    🔔 Send Postpone Notice to Student Login
                  </span>
                  <p className="text-[11px] text-amber-800">
                    Immediately displays an alert toast & banner when students of this batch log in.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={postponeNotifyStudents}
                  onChange={(e) => setPostponeNotifyStudents(e.target.checked)}
                  className="w-4 h-4 text-amber-600 rounded cursor-pointer"
                />
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowPostponeModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-extrabold shadow-lg shadow-amber-600/20 transition cursor-pointer flex items-center gap-1.5"
                >
                  <AlertTriangle className="w-4 h-4" />
                  <span>Confirm Postponement & Notify</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 3. MANUAL SCHEDULE / EDIT CLASS MODAL                     */}
      {/* ========================================================= */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-600/20">
                  <Calendar className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">
                    {editingSession ? 'Edit Class Schedule' : 'Schedule New Class (Manual)'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Assign to course batch, specify timing, venue, meeting links, and student notifications.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowScheduleModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSchedule} className="space-y-4 text-xs">
              {/* Title */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Class Title / Lecture Topic *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Dynamic Programming & Pointer Arithmetic in C++"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              {/* Academic Class & Subject */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Academic Class
                  </label>
                  <select
                    value={formAcademicClass}
                    onChange={(e) => handleAcademicClassChange(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="All Classes">All Classes</option>
                    {distinctClasses.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Subject / Stream
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Computer Science, Physics, Mathematics"
                    value={formSubject}
                    onChange={(e) => setFormSubject(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Course & Batch Assignment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Course Assignment
                  </label>
                  <select
                    value={formCourseId}
                    onChange={(e) => handleCourseChange(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="all">All Courses (Open Masterclass)</option>
                    {matchedCourses.map(c => (
                      <option key={c.id} value={c.id}>{c.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Batch Assignment *
                  </label>
                  <select
                    value={formBatchId}
                    onChange={(e) => handleBatchChange(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="all">Assign in All Batches</option>
                    {matchedBatches.map(b => (
                      <option key={b.id} value={b.id}>
                        {b.name} ({b.scheduleDays?.join(', ')} @ {b.timing})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Date, Timing, Educator */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Scheduled Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={formScheduledDate}
                    onChange={(e) => setFormScheduledDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Start Time
                  </label>
                  <input
                    type="text"
                    placeholder="05:00 PM"
                    value={formStartTime}
                    onChange={(e) => setFormStartTime(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    End Time
                  </label>
                  <input
                    type="text"
                    placeholder="06:30 PM"
                    value={formEndTime}
                    onChange={(e) => setFormEndTime(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Educator, Mode, Platform */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Faculty / Educator
                  </label>
                  <select
                    value={formEducatorName}
                    onChange={(e) => setFormEducatorName(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    {educators.map(edu => (
                      <option key={edu.id} value={edu.name}>{edu.name} ({edu.designation || 'Faculty'})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Class Mode
                  </label>
                  <select
                    value={formMode}
                    onChange={(e) => setFormMode(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="offline">Offline Classroom</option>
                    <option value="online">Online Live Stream</option>
                    <option value="hybrid">Hybrid (Both)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Platform / Room
                  </label>
                  <select
                    value={formPlatform}
                    onChange={(e) => setFormPlatform(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  >
                    <option value="google_meet">Google Meet</option>
                    <option value="zoom">Zoom</option>
                    <option value="in_app">In-App Live Class</option>
                    <option value="custom">Offline Classroom / Venue</option>
                  </select>
                </div>
              </div>

              {/* Meeting Link & Room Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Meeting URL / Stream Link
                  </label>
                  <input
                    type="url"
                    placeholder="https://meet.google.com/xxx-yyyy-zzz"
                    value={formMeetingUrl}
                    onChange={(e) => setFormMeetingUrl(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Room No / Physical Venue
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Lab-1 (Pixel Lab), Room 102"
                    value={formRoomNumber}
                    onChange={(e) => setFormRoomNumber(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Syllabus / Lecture Notes Description
                </label>
                <textarea
                  rows={2}
                  placeholder="Key concepts to be covered in this lecture..."
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              {/* Notify Checkbox */}
              {!editingSession && (
                <div className="p-3 bg-indigo-50/80 rounded-2xl border border-indigo-200 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-indigo-950 block">
                      📢 Send Notification to Batch Students on Save
                    </span>
                    <p className="text-[11px] text-indigo-800">
                      Creates instant alert in student portal and notification drawer.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={formNotifyStudents}
                    onChange={(e) => setFormNotifyStudents(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 rounded cursor-pointer"
                  />
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowScheduleModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-extrabold shadow-lg shadow-indigo-600/20 transition cursor-pointer flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingSession ? 'Update Class Schedule' : 'Save & Schedule Class'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 4. SEND CUSTOM NOTIFICATION MODAL                         */}
      {/* ========================================================= */}
      {showNotifyModal && targetNotifySession && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-lg shadow-indigo-600/20">
                  <Send className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">
                    Send Student Alert
                  </h3>
                  <p className="text-xs text-slate-500">
                    Broadcast an announcement to students enrolled in this batch.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowNotifyModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSendCustomNotification} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Notification Title
                </label>
                <input
                  type="text"
                  required
                  value={customNotifTitle}
                  onChange={(e) => setCustomNotifTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Message Body
                </label>
                <textarea
                  rows={3}
                  required
                  value={customNotifMessage}
                  onChange={(e) => setCustomNotifMessage(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="p-3 bg-indigo-50 rounded-2xl border border-indigo-200 text-indigo-950 text-[11px]">
                Target: <strong>{targetNotifySession.batchId === 'all' ? 'All Students in All Batches' : batches.find(b => b.id === targetNotifySession.batchId)?.name || 'Batch'}</strong>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNotifyModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-extrabold shadow-lg shadow-indigo-600/20 transition cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Notification Alert Now</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
