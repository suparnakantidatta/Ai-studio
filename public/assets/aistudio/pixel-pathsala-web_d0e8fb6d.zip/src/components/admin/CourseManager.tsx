import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Course } from '../../types';
import { BookOpen, Plus, Edit3, Trash2, Tag, Eye, EyeOff, Sparkles, CheckCircle, GraduationCap } from 'lucide-react';

export const CourseManager: React.FC = () => {
  const { courses, addCourse, updateCourse, deleteCourse, batches, students } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [editingCourseId, setEditingCourseId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [code, setCode] = useState('');
  const [academicClass, setAcademicClass] = useState('Class 10');
  const [description, setDescription] = useState('');
  const [monthlyFee, setMonthlyFee] = useState(1200);
  const [syllabusInput, setSyllabusInput] = useState('Physics & Chemistry\nMathematics Foundations\nPeriodic Mock Tests\nBoard Exam Question Bank');
  const [highlightsInput, setHighlightsInput] = useState('Class Strength: 25 Max\nDaily Doubt Counters\nWeekly Chapter Tests');
  const [showOnWebsite, setShowOnWebsite] = useState(true);

  const handleOpenAdd = () => {
    setEditingCourseId(null);
    setTitle('');
    setCode(`CRS-${Math.floor(Math.random() * 800) + 100}`);
    setAcademicClass('Class 10');
    setDescription('');
    setMonthlyFee(1200);
    setSyllabusInput('Physics & Chemistry\nMathematics Foundations\nPeriodic Mock Tests\nBoard Exam Question Bank');
    setHighlightsInput('Class Strength: 25 Max\nDaily Doubt Counters\nWeekly Chapter Tests');
    setShowOnWebsite(true);
    setShowModal(true);
  };

  const handleOpenEdit = (c: Course) => {
    setEditingCourseId(c.id);
    setTitle(c.title);
    setCode(c.code);
    setAcademicClass(c.academicClass || 'Class 10');
    setDescription(c.description);
    setMonthlyFee(c.monthlyFee);
    setSyllabusInput(c.syllabusPoints.join('\n'));
    setHighlightsInput((c.highlights || []).join('\n'));
    setShowOnWebsite(c.showOnWebsite);
    setShowModal(true);
  };

  const handleSaveCourse = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !code.trim() || !academicClass.trim()) {
      alert('Please fill course title, academic class, and code.');
      return;
    }

    const syllabusPoints = syllabusInput.split('\n').map(s => s.trim()).filter(Boolean);
    const highlights = highlightsInput.split('\n').map(s => s.trim()).filter(Boolean);

    if (editingCourseId) {
      updateCourse(editingCourseId, {
        title: title.trim(),
        code: code.trim(),
        academicClass: academicClass.trim(),
        description: description.trim(),
        monthlyFee: Number(monthlyFee),
        syllabusPoints,
        highlights,
        showOnWebsite
      });
    } else {
      addCourse({
        title: title.trim(),
        code: code.trim(),
        academicClass: academicClass.trim(),
        description: description.trim(),
        monthlyFee: Number(monthlyFee),
        syllabusPoints,
        highlights,
        showOnWebsite
      });
    }

    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header & Add Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            <span>Course & Class Curriculum Management</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Create courses with Academic Class specifications, set standard monthly fees (0 registration fee), and manage website visibility.
          </p>
        </div>

        <button
          id="btn-add-course-modal"
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Course</span>
        </button>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => {
          const enrolledCount = students.filter(s => s.courseId === course.id).length;
          const courseBatchesCount = batches.filter(b => b.courseId === course.id).length;

          return (
            <div
              key={course.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex flex-wrap gap-1.5 items-center">
                    <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-600 text-white shadow-xs">
                      {course.academicClass || 'General Class'}
                    </span>
                  </div>
                  <span className="font-mono text-xs text-slate-400 font-semibold">
                    {course.code}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-base mb-1.5 line-clamp-1">
                  {course.title}
                </h3>
                <p className="text-xs text-slate-600 line-clamp-2 mb-4">
                  {course.description}
                </p>

                {/* Stats */}
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-100 mb-4 text-xs">
                  <div>
                    <span className="text-slate-400 block">Monthly Fee:</span>
                    <strong className="font-mono text-indigo-900 text-sm font-bold">₹{course.monthlyFee}/mo</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Registration Fee:</span>
                    <span className="text-emerald-700 font-bold">₹0 (Free)</span>
                  </div>
                  <div className="pt-2 border-t border-slate-200 col-span-2">
                    <span className="text-slate-400 block">Class & Enrolled:</span>
                    <strong className="text-slate-800">{course.academicClass} &bull; {enrolledCount} Students ({courseBatchesCount} Batches)</strong>
                  </div>
                </div>

                {/* Website visibility */}
                <div className="flex items-center gap-2 text-xs font-medium text-slate-600">
                  {course.showOnWebsite ? (
                    <span className="inline-flex items-center gap-1 text-emerald-700 font-bold">
                      <Eye className="w-3.5 h-3.5" />
                      <span>Visible on Public Website</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-slate-400">
                      <EyeOff className="w-3.5 h-3.5" />
                      <span>Hidden from Website</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100 mt-4">
                <button
                  onClick={() => handleOpenEdit(course)}
                  className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-xl transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
                <button
                  onClick={() => {
                    if (confirm(`Delete course "${course.title}"?`)) {
                      deleteCourse(course.id);
                    }
                  }}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Course Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Course & Class Setup
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {editingCourseId ? 'Edit Course' : 'Create New Course'}
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveCourse} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Course Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Class 10 Board Excellence"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Code <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="CRS-101"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-mono"
                  />
                </div>
              </div>

              {/* Class Section Selection / Input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1 flex items-center gap-1.5">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Academic Class Section <span className="text-red-500">*</span></span>
                </label>
                <input
                  type="text"
                  required
                  value={academicClass}
                  onChange={(e) => setAcademicClass(e.target.value)}
                  placeholder="e.g. Class 8, Class 9, Class 10, Class 11, Class 12, BCA"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-semibold text-indigo-900"
                />
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {['Class 8', 'Class 9', 'Class 10', 'Class 11 Science', 'Class 12 Science', 'BCA / Coding'].map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setAcademicClass(c)}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 rounded text-[10px] font-medium text-slate-600 transition cursor-pointer"
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Course Description
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Overview of syllabus, goals, target students..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs resize-none"
                />
              </div>

              {/* Monthly Fee Input */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-900 uppercase tracking-wide mb-1">
                      Monthly Tuition Fee (₹) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      min={0}
                      required
                      value={monthlyFee}
                      onChange={(e) => setMonthlyFee(Number(e.target.value))}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-mono font-bold text-indigo-900"
                    />
                  </div>

                  <div className="flex flex-col justify-center text-xs text-slate-600">
                    <span className="font-bold text-emerald-700 flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" />
                      ₹0 Registration & ₹0 Admission Fee
                    </span>
                    <span className="text-[11px] text-slate-500 mt-0.5">
                      Collected per month transparently from admission day onwards.
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Syllabus Topics (One per line)
                </label>
                <textarea
                  rows={3}
                  value={syllabusInput}
                  onChange={(e) => setSyllabusInput(e.target.value)}
                  placeholder="Enter syllabus topics line by line..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Highlights & Features (One per line)
                </label>
                <textarea
                  rows={2}
                  value={highlightsInput}
                  onChange={(e) => setHighlightsInput(e.target.value)}
                  placeholder="e.g. Daily Doubt Counters..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <label className="flex items-center gap-2 text-xs font-bold text-slate-800 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={showOnWebsite}
                  onChange={(e) => setShowOnWebsite(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                />
                <span>Show Course on Public Website Catalog</span>
              </label>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer"
                >
                  {editingCourseId ? 'Save Changes' : 'Create Course'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
