import React, { useState, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  HardDriveDownload, 
  UploadCloud, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle, 
  FileJson, 
  ShieldCheck, 
  Database, 
  Clock, 
  Layers, 
  Users, 
  CreditCard, 
  BookOpen, 
  FileQuestion, 
  FolderDown, 
  TrendingDown, 
  Building, 
  Lock,
  Download,
  FileCheck,
  Sparkles,
  Info,
  ArrowRight
} from 'lucide-react';
import { FullDatabaseBackup } from '../../types';

export const BackupRestoreManager: React.FC = () => {
  const { 
    centerInfo, 
    students, 
    admissions, 
    payments, 
    courses, 
    batches, 
    educators, 
    expenses, 
    discounts, 
    adminAccounts, 
    studyMaterials, 
    questions, 
    exams, 
    examSubmissions, 
    downloadFullBackup, 
    restoreFullBackup, 
    resetToDefaultData, 
    showToast 
  } = useApp();

  const [uploadedBackup, setUploadedBackup] = useState<FullDatabaseBackup | null>(null);
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [uploadedFileSize, setUploadedFileSize] = useState<string>('');
  const [parseError, setParseError] = useState<string | null>(null);
  const [isRestoring, setIsRestoring] = useState<boolean>(false);
  const [keepCurrentAdmin, setKeepCurrentAdmin] = useState<boolean>(true);
  const [restoreSuccess, setRestoreSuccess] = useState<{ message: string; counts: any } | null>(null);
  const [lastBackupDownloaded, setLastBackupDownloaded] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const totalCurrentRecords = 
    students.length + 
    admissions.length + 
    payments.length + 
    courses.length + 
    batches.length + 
    educators.length + 
    expenses.length + 
    discounts.length + 
    adminAccounts.length + 
    studyMaterials.length + 
    questions.length + 
    exams.length + 
    examSubmissions.length;

  const handleDownload = () => {
    const res = downloadFullBackup();
    if (res.success) {
      const nowFormatted = new Date().toLocaleTimeString('en-IN', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit',
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });
      setLastBackupDownloaded(nowFormatted);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setParseError(null);
    setRestoreSuccess(null);
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    setUploadedFileSize(`${(file.size / 1024).toFixed(1)} KB`);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const json = JSON.parse(text);

        // Basic verification
        if (!json || typeof json !== 'object') {
          throw new Error('Invalid JSON file format.');
        }

        // Verify if it contains some data collections or tables
        const hasKnownFields = 
          Array.isArray(json.students) || 
          Array.isArray(json.payments) || 
          Array.isArray(json.courses) || 
          Array.isArray(json.batches) || 
          json.centerInfo;

        if (!hasKnownFields) {
          throw new Error('The selected JSON file does not appear to be a valid Pixel Pathsala database backup.');
        }

        setUploadedBackup(json);
      } catch (err: any) {
        setParseError(err.message || 'Failed to read backup file.');
        setUploadedBackup(null);
      }
    };
    reader.readAsText(file);
  };

  const handleExecuteRestore = async () => {
    if (!uploadedBackup) return;
    
    setIsRestoring(true);
    setParseError(null);
    try {
      const res = await restoreFullBackup(uploadedBackup, { keepCurrentAdmin });
      if (res.success) {
        setRestoreSuccess({
          message: res.message,
          counts: res.counts
        });
        setUploadedBackup(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
      } else {
        setParseError(res.message || 'Failed to restore backup.');
      }
    } catch (err: any) {
      setParseError(err.message || 'Unexpected error during restore.');
    } finally {
      setIsRestoring(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-bold shadow-xs">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
                <span>Database Backup & Restore Hub</span>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  OFFLINE + CLOUD SAFE
                </span>
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Export 100% complete offline snapshots of your center database in JSON format, and restore any previous backup safely.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-xs font-bold text-slate-900">{totalCurrentRecords} Active Records</div>
            <div className="text-[11px] text-slate-500 font-mono">12 Integrated Tables</div>
          </div>
          <button
            type="button"
            onClick={handleDownload}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-sm cursor-pointer shrink-0"
          >
            <HardDriveDownload className="w-4 h-4" />
            <span>Download Backup Now</span>
          </button>
        </div>
      </div>

      {/* Success Banner if Restored */}
      {restoreSuccess && (
        <div className="p-5 bg-emerald-50 border-2 border-emerald-300 rounded-3xl text-emerald-950 space-y-3 animate-fadeIn shadow-xs">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-500 flex items-center justify-center text-white shrink-0 mt-0.5">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h4 className="font-extrabold text-sm text-emerald-900">Database Restored Successfully!</h4>
              <p className="text-xs text-emerald-800 mt-0.5">{restoreSuccess.message}</p>
              {restoreSuccess.counts && (
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 mt-3 text-[11px] font-mono font-semibold">
                  <div className="bg-white/80 p-2 rounded-lg border border-emerald-200">
                    <span className="text-slate-500 block text-[9px] uppercase font-sans">Students</span>
                    <span className="text-emerald-900 font-bold">{restoreSuccess.counts.students}</span>
                  </div>
                  <div className="bg-white/80 p-2 rounded-lg border border-emerald-200">
                    <span className="text-slate-500 block text-[9px] uppercase font-sans">Admissions</span>
                    <span className="text-emerald-900 font-bold">{restoreSuccess.counts.admissions}</span>
                  </div>
                  <div className="bg-white/80 p-2 rounded-lg border border-emerald-200">
                    <span className="text-slate-500 block text-[9px] uppercase font-sans">Fee Receipts</span>
                    <span className="text-emerald-900 font-bold">{restoreSuccess.counts.payments}</span>
                  </div>
                  <div className="bg-white/80 p-2 rounded-lg border border-emerald-200">
                    <span className="text-slate-500 block text-[9px] uppercase font-sans">Courses & Batches</span>
                    <span className="text-emerald-900 font-bold">{restoreSuccess.counts.courses + restoreSuccess.counts.batches}</span>
                  </div>
                  <div className="bg-white/80 p-2 rounded-lg border border-emerald-200">
                    <span className="text-slate-500 block text-[9px] uppercase font-sans">Exams & MCQs</span>
                    <span className="text-emerald-900 font-bold">{restoreSuccess.counts.exams + restoreSuccess.counts.questions}</span>
                  </div>
                  <div className="bg-white/80 p-2 rounded-lg border border-emerald-200">
                    <span className="text-slate-500 block text-[9px] uppercase font-sans">Study Notes</span>
                    <span className="text-emerald-900 font-bold">{restoreSuccess.counts.studyMaterials}</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main Grid: Backup on Left (5 cols) & Restore on Right (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Export & Snapshot Card */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileJson className="w-4 h-4 text-indigo-600" />
                <span>Export Full Backup</span>
              </h3>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 font-mono">
                JSON v2.0
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Creates a complete, portable JSON snapshot containing all students, fee collections, exam banks, admissions, faculty, and institute settings.
            </p>

            {/* Current Snapshot Breakdown */}
            <div className="space-y-2">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                Current Snapshot Summary:
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                  <span className="text-slate-600 flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Students</span>
                  </span>
                  <span className="font-bold text-slate-900">{students.length}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                  <span className="text-slate-600 flex items-center gap-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Fee Receipts</span>
                  </span>
                  <span className="font-bold text-slate-900">{payments.length}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                  <span className="text-slate-600 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                    <span>Courses</span>
                  </span>
                  <span className="font-bold text-slate-900">{courses.length}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                  <span className="text-slate-600 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-amber-600" />
                    <span>Batches</span>
                  </span>
                  <span className="font-bold text-slate-900">{batches.length}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                  <span className="text-slate-600 flex items-center gap-1.5">
                    <FileQuestion className="w-3.5 h-3.5 text-purple-600" />
                    <span>Exams & MCQs</span>
                  </span>
                  <span className="font-bold text-slate-900">{exams.length + questions.length}</span>
                </div>
                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                  <span className="text-slate-600 flex items-center gap-1.5">
                    <FolderDown className="w-3.5 h-3.5 text-teal-600" />
                    <span>Study Materials</span>
                  </span>
                  <span className="font-bold text-slate-900">{studyMaterials.length}</span>
                </div>
              </div>
            </div>

            {lastBackupDownloaded && (
              <div className="p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-[11px] text-indigo-900 flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <span>Last backup downloaded: <strong>{lastBackupDownloaded}</strong></span>
              </div>
            )}

            <button
              type="button"
              onClick={handleDownload}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download Complete Backup (.json)</span>
            </button>
          </div>

          {/* Quick Safety Note */}
          <div className="p-4 bg-slate-900 text-white rounded-3xl border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-indigo-300">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Zero Vendor Lock-In Guarantee</span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">
              Your data is stored in open, human-readable standard JSON. You can keep periodic backup files on your computer, external drive, or cloud storage for disaster recovery.
            </p>
          </div>
        </div>

        {/* Right: Restore from Backup File Card (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <UploadCloud className="w-4 h-4 text-emerald-600" />
                <span>Restore Database from Backup</span>
              </h3>
              <span className="text-xs text-slate-500">
                Accepts <code className="text-indigo-600 font-bold">.json</code>
              </span>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Select a previously downloaded Pixel Pathsala backup JSON file. You will be able to inspect its contents and summary before confirming the restoration.
            </p>

            {/* File Upload Zone */}
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={`p-6 border-2 border-dashed rounded-2xl text-center cursor-pointer transition ${
                uploadedBackup 
                  ? 'border-emerald-400 bg-emerald-50/40' 
                  : 'border-slate-300 hover:border-indigo-400 bg-slate-50/60 hover:bg-indigo-50/20'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleFileChange}
                className="hidden"
              />
              
              {uploadedBackup ? (
                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-xs">
                    <FileCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-emerald-950">{uploadedFileName}</div>
                    <div className="text-[11px] text-emerald-700 font-mono mt-0.5">{uploadedFileSize} &bull; Valid Backup Verified</div>
                  </div>
                  <span className="inline-block text-[10px] font-bold text-emerald-800 underline">
                    Click to choose a different file
                  </span>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto border border-indigo-100">
                    <UploadCloud className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-800">
                      Click to Browse or Drag &amp; Drop Backup File
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      Select your downloaded <code className="text-indigo-600">.json</code> file
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Parse Error Box */}
            {parseError && (
              <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-900 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">Restore Validation Error</div>
                  <div className="text-[11px] text-rose-700 mt-0.5">{parseError}</div>
                </div>
              </div>
            )}

            {/* Inspection Preview Table when File Loaded */}
            {uploadedBackup && (
              <div className="space-y-4 p-4 bg-slate-50 rounded-2xl border border-slate-200 animate-fadeIn">
                <div className="flex items-center justify-between pb-2 border-b border-slate-200 text-xs">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Backup Contents Inspection</span>
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">
                    {uploadedBackup.exportedAt ? new Date(uploadedBackup.exportedAt).toLocaleString('en-IN') : 'Snapshot Date N/A'}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-semibold uppercase">Students</div>
                    <div className="text-sm font-extrabold text-slate-900">
                      {(uploadedBackup.students || []).length}
                    </div>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-semibold uppercase">Admissions</div>
                    <div className="text-sm font-extrabold text-slate-900">
                      {(uploadedBackup.admissions || []).length}
                    </div>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-semibold uppercase">Fee Receipts</div>
                    <div className="text-sm font-extrabold text-slate-900">
                      {(uploadedBackup.payments || []).length}
                    </div>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-semibold uppercase">Courses &amp; Batches</div>
                    <div className="text-sm font-extrabold text-slate-900">
                      {(uploadedBackup.courses || []).length + (uploadedBackup.batches || []).length}
                    </div>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-semibold uppercase">Exams &amp; Questions</div>
                    <div className="text-sm font-extrabold text-slate-900">
                      {(uploadedBackup.exams || []).length + (uploadedBackup.questions || []).length}
                    </div>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <div className="text-[10px] text-slate-500 font-semibold uppercase">Study Materials</div>
                    <div className="text-sm font-extrabold text-slate-900">
                      {(uploadedBackup.studyMaterials || []).length}
                    </div>
                  </div>
                </div>

                {/* Restore Options */}
                <div className="pt-2 space-y-2 text-xs">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={keepCurrentAdmin}
                      onChange={(e) => setKeepCurrentAdmin(e.target.checked)}
                      className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                    />
                    <span className="text-slate-700 font-medium">
                      Keep current admin login credentials (prevent accidental logout)
                    </span>
                  </label>
                </div>

                {/* Confirmation Button */}
                <div className="pt-2">
                  <button
                    type="button"
                    disabled={isRestoring}
                    onClick={handleExecuteRestore}
                    className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-md transition cursor-pointer disabled:opacity-50"
                  >
                    {isRestoring ? (
                      <>
                        <RotateCcw className="w-4 h-4 animate-spin" />
                        <span>Restoring All Database Records...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Confirm &amp; Restore Complete Database</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Reset Factory / Demo Data Option */}
          <div className="bg-white rounded-3xl border border-rose-200 p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h4 className="text-xs font-bold text-rose-900 flex items-center gap-1.5">
                <RotateCcw className="w-3.5 h-3.5 text-rose-600" />
                <span>Reset to Demonstration Seed Records</span>
              </h4>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Resets the database back to standard sample courses, batches, and demo students.
              </p>
            </div>

            <button
              type="button"
              onClick={resetToDefaultData}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 transition cursor-pointer shrink-0"
            >
              Reset to Defaults
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
