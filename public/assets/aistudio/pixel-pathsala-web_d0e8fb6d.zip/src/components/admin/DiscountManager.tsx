import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Discount } from '../../types';
import { googleSheetsBackendApi } from '../../services/googleSheetsBackendApi';
import { 
  Percent, 
  Plus, 
  Trash2, 
  Edit3, 
  Users, 
  User, 
  Calendar,
  BookOpen,
  Building2,
  GraduationCap,
  Layers,
  Sparkles,
  ArrowRight,
  AlertCircle,
  FileSpreadsheet,
  RefreshCw,
  Database,
  Check
} from 'lucide-react';
import { 
  getDistinctAcademicClasses, 
  getCoursesForClass, 
  getBatchesForCourse,
  formatModeLabel
} from '../../utils/classCourseMatcher';

const MONTH_OPTIONS = [
  { key: '2026-04', label: 'April 2026' },
  { key: '2026-05', label: 'May 2026' },
  { key: '2026-06', label: 'June 2026' },
  { key: '2026-07', label: 'July 2026' },
  { key: '2026-08', label: 'August 2026' },
  { key: '2026-09', label: 'September 2026' },
  { key: '2026-10', label: 'October 2026' },
  { key: '2026-11', label: 'November 2026' },
  { key: '2026-12', label: 'December 2026' },
  { key: '2027-01', label: 'January 2027' },
  { key: '2027-02', label: 'February 2027' },
  { key: '2027-03', label: 'March 2027' }
];

export const DiscountManager: React.FC = () => {
  const { 
    discounts, 
    addDiscount, 
    updateDiscount, 
    deleteDiscount, 
    batches, 
    students, 
    courses, 
    centerInfo, 
    saveAllToDatabase, 
    showToast 
  } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [editingDiscountId, setEditingDiscountId] = useState<string | null>(null);
  const [isEnsuringTables, setIsEnsuringTables] = useState(false);
  const [isSavingAll, setIsSavingAll] = useState(false);

  const distinctClasses = getDistinctAcademicClasses(courses);

  // Form State
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'flat' | 'percentage'>('flat');
  const [value, setValue] = useState<number>(200);
  const [scope, setScope] = useState<'all' | 'class' | 'course' | 'batch' | 'student'>('batch');
  
  // Cascading Hierarchy States: Class -> Course -> Batch -> Student
  const [academicClass, setAcademicClass] = useState<string>(distinctClasses[0] || 'Class 10');
  const [courseId, setCourseId] = useState<string>(() => {
    const matched = getCoursesForClass(courses, distinctClasses[0] || 'Class 10');
    return matched[0]?.id || courses[0]?.id || '';
  });
  const [batchId, setBatchId] = useState<string>(() => {
    const defaultCourse = getCoursesForClass(courses, distinctClasses[0] || 'Class 10')[0]?.id || courses[0]?.id || '';
    const matchedB = getBatchesForCourse(batches, defaultCourse);
    return matchedB[0]?.id || batches[0]?.id || '';
  });
  const [studentId, setStudentId] = useState<string>(students[0]?.id || '');
  
  const [applicableMonthsType, setApplicableMonthsType] = useState<'all_months' | 'selected_months'>('all_months');
  const [selectedMonths, setSelectedMonths] = useState<string[]>(['2026-04']);
  const [reason, setReason] = useState('');
  const [active, setActive] = useState(true);

  // Dynamically filtered options based on current selection
  const classMatchedCourses = getCoursesForClass(courses, academicClass);
  const courseMatchedBatches = getBatchesForCourse(batches, courseId);
  const filteredStudents = batchId 
    ? students.filter(s => s.batchId === batchId)
    : courseId 
    ? students.filter(s => s.courseId === courseId)
    : students;

  // Cascading handlers
  const handleClassChange = (newClass: string) => {
    setAcademicClass(newClass);
    const matchedC = getCoursesForClass(courses, newClass);
    if (matchedC.length > 0) {
      const newCourseId = matchedC[0].id;
      setCourseId(newCourseId);
      const matchedB = getBatchesForCourse(batches, newCourseId);
      if (matchedB.length > 0) {
        setBatchId(matchedB[0].id);
        const matchedS = students.filter(s => s.batchId === matchedB[0].id);
        if (matchedS.length > 0) {
          setStudentId(matchedS[0].id);
        }
      } else {
        setBatchId('');
      }
    } else {
      setCourseId('');
      setBatchId('');
    }
  };

  const handleCourseChange = (newCourseId: string) => {
    setCourseId(newCourseId);
    const matchedB = getBatchesForCourse(batches, newCourseId);
    if (matchedB.length > 0) {
      setBatchId(matchedB[0].id);
      const matchedS = students.filter(s => s.batchId === matchedB[0].id);
      if (matchedS.length > 0) {
        setStudentId(matchedS[0].id);
      }
    } else {
      setBatchId('');
    }
  };

  const handleBatchChange = (newBatchId: string) => {
    setBatchId(newBatchId);
    const matchedS = students.filter(s => s.batchId === newBatchId);
    if (matchedS.length > 0) {
      setStudentId(matchedS[0].id);
    }
  };

  const handleOpenAdd = () => {
    setEditingDiscountId(null);
    setTitle('');
    setType('flat');
    setValue(200);
    setScope('batch');
    
    const defaultClass = distinctClasses[0] || 'Class 10';
    setAcademicClass(defaultClass);
    
    const matchedC = getCoursesForClass(courses, defaultClass);
    const defaultCourseId = matchedC[0]?.id || courses[0]?.id || '';
    setCourseId(defaultCourseId);
    
    const matchedB = getBatchesForCourse(batches, defaultCourseId);
    const defaultBatchId = matchedB[0]?.id || batches[0]?.id || '';
    setBatchId(defaultBatchId);
    
    const matchedS = defaultBatchId ? students.filter(s => s.batchId === defaultBatchId) : students;
    setStudentId(matchedS[0]?.id || students[0]?.id || '');
    
    setApplicableMonthsType('all_months');
    setSelectedMonths(['2026-04']);
    setReason('');
    setActive(true);
    setShowModal(true);
  };

  const handleOpenEdit = (disc: Discount) => {
    setEditingDiscountId(disc.id);
    setTitle(disc.title);
    setType(disc.type);
    setValue(disc.value);
    setScope(disc.scope || 'all');

    let targetClass = disc.academicClass || '';
    let targetCourseId = disc.courseId || '';
    let targetBatchId = disc.batchId || '';
    let targetStudentId = disc.studentId || '';

    if (disc.batchId) {
      const b = batches.find(x => x.id === disc.batchId);
      if (b) {
        targetBatchId = b.id;
        targetCourseId = b.courseId;
        const c = courses.find(x => x.id === b.courseId);
        targetClass = disc.academicClass || b.academicClass || c?.academicClass || distinctClasses[0] || 'Class 10';
      }
    } else if (disc.courseId) {
      const c = courses.find(x => x.id === disc.courseId);
      if (c) {
        targetCourseId = c.id;
        targetClass = disc.academicClass || c.academicClass || distinctClasses[0] || 'Class 10';
        const matchedB = getBatchesForCourse(batches, c.id);
        targetBatchId = matchedB[0]?.id || '';
      }
    } else if (disc.studentId) {
      const s = students.find(x => x.id === disc.studentId);
      if (s) {
        targetStudentId = s.id;
        targetBatchId = s.batchId;
        targetCourseId = s.courseId;
        const c = courses.find(x => x.id === s.courseId);
        targetClass = s.studentClass || c?.academicClass || distinctClasses[0] || 'Class 10';
      }
    }

    if (!targetClass) targetClass = distinctClasses[0] || 'Class 10';
    if (!targetCourseId) {
      const matchedC = getCoursesForClass(courses, targetClass);
      targetCourseId = matchedC[0]?.id || courses[0]?.id || '';
    }
    if (!targetBatchId) {
      const matchedB = getBatchesForCourse(batches, targetCourseId);
      targetBatchId = matchedB[0]?.id || batches[0]?.id || '';
    }
    if (!targetStudentId) {
      targetStudentId = students[0]?.id || '';
    }

    setAcademicClass(targetClass);
    setCourseId(targetCourseId);
    setBatchId(targetBatchId);
    setStudentId(targetStudentId);
    setApplicableMonthsType(disc.applicableMonthsType);
    setSelectedMonths(disc.selectedMonths || ['2026-04']);
    setReason(disc.reason || '');
    setActive(disc.active !== false);
    setShowModal(true);
  };

  const handleToggleMonth = (mKey: string) => {
    setSelectedMonths(prev =>
      prev.includes(mKey) ? prev.filter(k => k !== mKey) : [...prev, mKey]
    );
  };

  const handleEnsureDataTable = async () => {
    setIsEnsuringTables(true);
    try {
      const res = await googleSheetsBackendApi.ensureTables(centerInfo.googleSheetId);
      if (res.success) {
        await saveAllToDatabase({ discounts });
        showToast(res.message || 'Data table "Discounts" created and verified in Google Sheet!', 'success');
      } else {
        showToast(res.error || 'Failed to auto-create tables in Google Sheet.', 'error');
      }
    } catch (err: any) {
      showToast(err.message || 'Auto-creation of data tables failed.', 'error');
    } finally {
      setIsEnsuringTables(false);
    }
  };

  const handleSaveAllDiscounts = async () => {
    setIsSavingAll(true);
    try {
      const res = await saveAllToDatabase({ discounts });
      showToast(res?.message || 'All discounts saved to ERP database and synchronized!', 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save discounts to database.', 'error');
    } finally {
      setIsSavingAll(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || value <= 0) {
      alert('Please provide a valid discount title and positive value.');
      return;
    }

    const isAllOption = scope === 'all' || 
      (scope === 'class' && (academicClass === 'all' || !academicClass)) ||
      (scope === 'course' && (courseId === 'all' || !courseId)) ||
      (scope === 'batch' && (batchId === 'all' || !batchId)) ||
      (scope === 'student' && (studentId === 'all' || !studentId));

    const effectiveScope = isAllOption ? 'all' : scope;

    if (!isAllOption && scope === 'course' && !courseId) {
      alert('Please select a valid course for course-wide discount or select "All Courses".');
      return;
    }

    if (!isAllOption && scope === 'batch' && !batchId) {
      alert('Please select a valid target batch or select "All Batches".');
      return;
    }

    if (!isAllOption && scope === 'student' && !studentId) {
      alert('Please select a valid student or select "All Students".');
      return;
    }

    if (applicableMonthsType === 'selected_months' && selectedMonths.length === 0) {
      alert('Please select at least one applicable month.');
      return;
    }

    const payload: Omit<Discount, 'id' | 'createdAt'> = {
      title: title.trim(),
      type,
      value: Number(value),
      scope: effectiveScope,
      academicClass: !isAllOption && (scope === 'class' || scope === 'course' || scope === 'batch') ? academicClass : undefined,
      courseId: !isAllOption && (scope === 'course' || scope === 'batch') ? courseId : undefined,
      batchId: !isAllOption && scope === 'batch' ? batchId : undefined,
      studentId: !isAllOption && scope === 'student' ? studentId : undefined,
      applicableMonthsType,
      selectedMonths: applicableMonthsType === 'selected_months' ? selectedMonths : undefined,
      reason: reason.trim() || undefined,
      active
    };

    if (editingDiscountId) {
      updateDiscount(editingDiscountId, payload);
    } else {
      addDiscount(payload);
    }

    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header & Action Buttons */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <Percent className="w-5 h-5 text-indigo-600" />
            <span>Discount & Scholarship Management</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Configure concessions center-wide, per academic class, per course, per batch, or for individual students. Applied automatically on monthly student billing.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={handleEnsureDataTable}
            disabled={isEnsuringTables}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold rounded-xl text-xs shadow-2xs transition cursor-pointer disabled:opacity-50"
            title="Create missing data tables (including Discounts) in Google Sheet automatically"
          >
            {isEnsuringTables ? (
              <RefreshCw className="w-4 h-4 animate-spin text-emerald-600" />
            ) : (
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            )}
            <span>{isEnsuringTables ? 'Creating in Sheet...' : 'Auto-Create Table in Sheet'}</span>
          </button>

          <button
            type="button"
            onClick={handleSaveAllDiscounts}
            disabled={isSavingAll}
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 font-bold rounded-xl text-xs shadow-2xs transition cursor-pointer disabled:opacity-50"
            title="Save all discount rules to ERP Database"
          >
            {isSavingAll ? (
              <RefreshCw className="w-4 h-4 animate-spin text-slate-600" />
            ) : (
              <Database className="w-4 h-4 text-slate-600" />
            )}
            <span>{isSavingAll ? 'Saving to DB...' : 'Save to Database'}</span>
          </button>

          <button
            id="btn-add-discount"
            onClick={handleOpenAdd}
            className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Discount Rule</span>
          </button>
        </div>
      </div>

      {/* Discounts List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {discounts.map((disc) => {
          const targetCourse = courses.find(c => c.id === disc.courseId);
          const targetBatch = batches.find(b => b.id === disc.batchId);
          const targetStudent = students.find(s => s.id === disc.studentId);
          const targetBatchCourse = targetBatch ? courses.find(c => c.id === targetBatch.courseId) : null;

          return (
            <div
              key={disc.id}
              className={`bg-white rounded-3xl border p-6 shadow-xs flex flex-col justify-between transition ${
                disc.active ? 'border-slate-200 hover:border-indigo-300' : 'border-slate-200 opacity-60 bg-slate-50'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                      disc.scope === 'all'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : disc.scope === 'class'
                        ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                        : disc.scope === 'course'
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : disc.scope === 'batch'
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : 'bg-purple-50 text-purple-700 border border-purple-200'
                    }`}>
                      {disc.scope === 'all' 
                        ? 'Center-wide' 
                        : disc.scope === 'class'
                        ? 'Class-wide'
                        : disc.scope === 'course' 
                        ? 'Course-wide' 
                        : disc.scope === 'batch' 
                        ? 'Batch-wide' 
                        : 'Single Student'}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700 font-mono">
                      {disc.type === 'flat' ? `₹${disc.value} Flat Off` : `${disc.value}% Off`}
                    </span>
                  </div>

                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    disc.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {disc.active ? 'Active' : 'Disabled'}
                  </span>
                </div>

                <h3 className="font-bold text-slate-900 text-base mb-1">
                  {disc.title}
                </h3>

                {disc.reason && (
                  <p className="text-xs text-slate-500 italic mb-3">
                    &quot;{disc.reason}&quot;
                  </p>
                )}

                {/* Target Information */}
                <div className="bg-slate-50 rounded-2xl p-3 border border-slate-100 space-y-1.5 text-xs text-slate-700 mb-4">
                  <div className="flex items-center gap-1.5 font-medium">
                    {disc.scope === 'all' ? (
                      <>
                        <Building2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                        <span>Target: <strong>All Students Center-wide</strong></span>
                      </>
                    ) : disc.scope === 'class' ? (
                      <>
                        <GraduationCap className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        <span>Target: <strong>{disc.academicClass || 'Selected Class'}</strong> (All Courses)</span>
                      </>
                    ) : disc.scope === 'course' ? (
                      <>
                        <BookOpen className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <span>Target: <strong>{targetCourse?.title || 'Course Students'}</strong> ({targetCourse?.academicClass || disc.academicClass})</span>
                      </>
                    ) : disc.scope === 'batch' ? (
                      <>
                        <Users className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        <span>
                          Target Batch: <strong>{targetBatch?.name || 'Batch Students'}</strong>
                          {targetBatchCourse && <span className="text-slate-500"> ({targetBatchCourse.title})</span>}
                        </span>
                      </>
                    ) : (
                      <>
                        <User className="w-3.5 h-3.5 text-purple-600 shrink-0" />
                        <span>Target: <strong>{targetStudent?.name || 'Specified Student'}</strong> ({targetStudent?.rollNo})</span>
                      </>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 text-slate-500">
                    <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>
                      {disc.applicableMonthsType === 'all_months' 
                        ? 'Applied to: All Billing Months' 
                        : `Applied to: ${disc.selectedMonths?.join(', ') || 'Selected Months'}`}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-slate-100">
                <div>
                  {disc.scope !== 'all' ? (
                    <button
                      onClick={() => {
                        updateDiscount(disc.id, { 
                          scope: 'all', 
                          academicClass: undefined, 
                          courseId: undefined, 
                          batchId: undefined, 
                          studentId: undefined 
                        });
                        showToast(`Discount "${disc.title}" assigned to ALL options center-wide and saved to database!`, 'success');
                      }}
                      title="Assign this discount rule to ALL options (All Classes, Courses, Batches & Students center-wide)"
                      className="px-3 py-1.5 text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition cursor-pointer text-xs font-bold flex items-center gap-1.5 border border-emerald-200 shadow-2xs"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Assign in All Option</span>
                    </button>
                  ) : (
                    <span className="px-3 py-1 text-emerald-800 bg-emerald-100 rounded-xl text-[11px] font-extrabold flex items-center gap-1.5 border border-emerald-300">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Assigned in All Options</span>
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleOpenEdit(disc)}
                    className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-xl transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Delete discount rule "${disc.title}"?`)) {
                        deleteDiscount(disc.id);
                      }
                    }}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn my-6">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Discount Rule Configuration
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {editingDiscountId ? 'Edit Discount Rule' : 'Create New Discount Rule'}
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Discount Title <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Class 10 Inaugural Concession or Merit Scholarship"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-medium"
                />
              </div>

              {/* Scope & Type */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                      Applicable Scope
                    </label>
                    <button
                      type="button"
                      onClick={() => setScope('all')}
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md transition flex items-center gap-1 cursor-pointer ${
                        scope === 'all' 
                          ? 'bg-emerald-600 text-white shadow-2xs' 
                          : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                      }`}
                      title="Set scope to Center-wide (Assign in All Option)"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>Assign in All Option</span>
                    </button>
                  </div>
                  <select
                    value={scope}
                    onChange={(e) => setScope(e.target.value as any)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold bg-white"
                  >
                    <option value="all">🌟 Center-wide (All Students, Batches & Courses) [ASSIGN IN ALL OPTION]</option>
                    <option value="class">All Students & Courses in a Class</option>
                    <option value="course">All Students in a Course</option>
                    <option value="batch">All Students in a Batch</option>
                    <option value="student">Single Specific Student</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Discount Type
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as 'flat' | 'percentage')}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold bg-white"
                  >
                    <option value="flat">Flat Amount (₹ Off / mo)</option>
                    <option value="percentage">Percentage (% Off / mo)</option>
                  </select>
                </div>
              </div>

              {/* Cascading Target Hierarchy: Class -> Course -> Batch */}
              {scope !== 'all' && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-700 flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5" />
                      Target Selection ({scope.toUpperCase()})
                    </span>
                    <button
                      type="button"
                      onClick={() => setScope('all')}
                      className="text-[10px] text-emerald-700 hover:text-emerald-900 font-bold flex items-center gap-1 cursor-pointer bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200"
                    >
                      <Sparkles className="w-3 h-3 text-emerald-600" />
                      <span>Switch to Assign in All Option</span>
                    </button>
                  </div>

                  {/* Step 1: Academic Class Selection */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                        Select Academic Class <span className="text-red-500">*</span>
                      </span>
                      <span className="text-[10px] text-indigo-600 font-semibold bg-indigo-50 px-2 py-0.5 rounded-md">
                        Step 1
                      </span>
                    </label>
                    <select
                      value={academicClass}
                      onChange={(e) => handleClassChange(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold bg-white"
                    >
                      <option value="all">🌟 All Academic Classes (Center-wide)</option>
                      {distinctClasses.map((cls) => (
                        <option key={cls} value={cls}>
                          {cls}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Step 2: Course Selection (Populated dynamically from selected class) */}
                  {(scope === 'course' || scope === 'batch' || scope === 'student') && (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <BookOpen className="w-3.5 h-3.5 text-amber-600" />
                          {scope === 'course' ? 'Target Course' : 'Select Course'} <span className="text-red-500">*</span>
                        </span>
                        <span className="text-[10px] text-amber-700 font-semibold bg-amber-50 px-2 py-0.5 rounded-md">
                          Step 2 (from {academicClass === 'all' ? 'All Classes' : academicClass})
                        </span>
                      </label>
                      {classMatchedCourses.length > 0 || academicClass === 'all' ? (
                        <select
                          value={courseId}
                          onChange={(e) => handleCourseChange(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium bg-white"
                        >
                          <option value="all">🌟 All Courses (Assign to All Courses)</option>
                          {(academicClass === 'all' ? courses : classMatchedCourses).map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.title} (Fee: ₹{c.monthlyFee}/mo &bull; {c.academicClass})
                            </option>
                          ))}
                        </select>
                      ) : (
                        <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-800 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                          <span>No courses found under {academicClass}. Please select another class.</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Step 3: Batch Selection (Populated dynamically from selected course) */}
                  {(scope === 'batch' || scope === 'student') && (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-blue-600" />
                          {scope === 'batch' ? 'Target Batch' : 'Filter by Batch'} <span className="text-red-500">*</span>
                        </span>
                        <span className="text-[10px] text-blue-700 font-semibold bg-blue-50 px-2 py-0.5 rounded-md">
                          Step 3 (from Selected Course)
                        </span>
                      </label>
                      {courseMatchedBatches.length > 0 || courseId === 'all' ? (
                        <select
                          value={batchId}
                          onChange={(e) => handleBatchChange(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium bg-white"
                        >
                          <option value="all">🌟 All Batches (Assign to All Batches)</option>
                          {(courseId === 'all' ? batches : courseMatchedBatches).map((b) => (
                            <option key={b.id} value={b.id}>
                              {b.name} ({b.timing} &bull; {formatModeLabel(b.mode || 'offline')})
                            </option>
                          ))}
                        </select>
                      ) : (
                        <div className="p-2.5 bg-blue-50 rounded-xl border border-blue-200 text-xs text-blue-800 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-blue-600 shrink-0" />
                          <span>No active batches configured for this course. Please create a batch in Batch Manager.</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Step 4: Specific Student Selection */}
                  {scope === 'student' && (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                        <span className="flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-purple-600" />
                          Select Target Student <span className="text-red-500">*</span>
                        </span>
                        <span className="text-[10px] text-purple-700 font-semibold bg-purple-50 px-2 py-0.5 rounded-md">
                          Target Student
                        </span>
                      </label>
                      {filteredStudents.length > 0 || batchId === 'all' || courseId === 'all' ? (
                        <select
                          value={studentId}
                          onChange={(e) => setStudentId(e.target.value)}
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium bg-white"
                        >
                          <option value="all">🌟 All Students (Assign to All Students)</option>
                          {(batchId === 'all' ? students : filteredStudents).map((s) => (
                            <option key={s.id} value={s.id}>
                              {s.name} (Roll: {s.rollNo || s.id} &bull; {s.mobile})
                            </option>
                          ))}
                        </select>
                      ) : (
                        <div className="p-2.5 bg-purple-50 rounded-xl border border-purple-200 text-xs text-purple-800 flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-purple-600 shrink-0" />
                          <span>No enrolled students found matching current filter.</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Discount Value */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Discount Value {type === 'flat' ? '(in Rupees ₹)' : '(in Percentage %)'} <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  min={1}
                  required
                  value={value}
                  onChange={(e) => setValue(Number(e.target.value))}
                  placeholder={type === 'flat' ? 'e.g. 200' : 'e.g. 20'}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono font-bold"
                />
              </div>

              {/* Applicable Months: All Months vs Selected Months */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Month Applicability:
                </label>
                <div className="grid grid-cols-2 gap-3 mb-2">
                  <button
                    type="button"
                    onClick={() => setApplicableMonthsType('all_months')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                      applicableMonthsType === 'all_months'
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    All Months
                  </button>
                  <button
                    type="button"
                    onClick={() => setApplicableMonthsType('selected_months')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition cursor-pointer ${
                      applicableMonthsType === 'selected_months'
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Selected Months
                  </button>
                </div>

                {applicableMonthsType === 'selected_months' && (
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 max-h-32 overflow-y-auto grid grid-cols-2 gap-1.5">
                    {MONTH_OPTIONS.map((m) => (
                      <label key={m.key} className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedMonths.includes(m.key)}
                          onChange={() => handleToggleMonth(m.key)}
                          className="rounded text-indigo-600 focus:ring-indigo-500"
                        />
                        <span>{m.label}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* Reason / Remarks */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Reason / Concession Note
                </label>
                <input
                  type="text"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="e.g. Sibling discount, Class 10 Early-bird special concession"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              {/* Active Toggle */}
              <label className="flex items-center gap-2 text-xs font-bold text-slate-800 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={active}
                  onChange={(e) => setActive(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                />
                <span>Active (Enable discount in billing calculations)</span>
              </label>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer"
                >
                  {editingDiscountId ? 'Save Changes' : 'Create Discount'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

