import React, { useState } from 'react';
import { Student, Course, Batch, CenterInfo } from '../../types';
import { useApp } from '../../context/AppContext';
import { 
  FeeReminderPayload, 
  buildFeeReminderMessage, 
  sendStudentWhatsAppReminder, 
  sendStudentEmailReminder,
  buildBatchFeeReminderDigest 
} from '../../services/feeReminderService';
import { 
  BellRing, 
  MessageCircle, 
  Mail, 
  Copy, 
  Check, 
  X, 
  Send, 
  CheckCircle, 
  Clock, 
  ExternalLink,
  Sparkles,
  AlertTriangle,
  Play,
  Users
} from 'lucide-react';

interface BatchFeeReminderModalProps {
  items: {
    student: Student;
    course?: Course;
    batch?: Batch;
    totalDueAmount: number;
    dueMonthLabels: string[];
  }[];
  onClose: () => void;
}

export const BatchFeeReminderModal: React.FC<BatchFeeReminderModalProps> = ({ items, onClose }) => {
  const { centerInfo, showToast } = useApp();
  const [templateType, setTemplateType] = useState<'friendly' | 'standard' | 'urgent'>('standard');
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>(items.map(i => i.student.id));
  const [dispatchStatus, setDispatchStatus] = useState<Record<string, 'sent' | 'pending'>>({});
  const [copiedDigest, setCopiedDigest] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const selectedItems = items.filter(i => selectedStudentIds.includes(i.student.id));
  const totalSelectedDue = selectedItems.reduce((acc, curr) => acc + curr.totalDueAmount, 0);

  const toggleSelectAll = () => {
    if (selectedStudentIds.length === items.length) {
      setSelectedStudentIds([]);
    } else {
      setSelectedStudentIds(items.map(i => i.student.id));
    }
  };

  const toggleStudent = (id: string) => {
    setSelectedStudentIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleSendSingleWhatsApp = (item: typeof items[0]) => {
    const payload: FeeReminderPayload = {
      student: item.student,
      course: item.course,
      batch: item.batch,
      dueAmount: item.totalDueAmount,
      dueMonths: item.dueMonthLabels,
      templateType
    };
    sendStudentWhatsAppReminder(payload, centerInfo);
    setDispatchStatus(prev => ({ ...prev, [item.student.id]: 'sent' }));
    showToast(`WhatsApp reminder dispatched for ${item.student.name}!`);
  };

  const handleSendSingleEmail = (item: typeof items[0]) => {
    const payload: FeeReminderPayload = {
      student: item.student,
      course: item.course,
      batch: item.batch,
      dueAmount: item.totalDueAmount,
      dueMonths: item.dueMonthLabels,
      templateType
    };
    sendStudentEmailReminder(payload, centerInfo);
    setDispatchStatus(prev => ({ ...prev, [item.student.id]: 'sent' }));
    showToast(`Email reminder launched for ${item.student.name}!`);
  };

  const handleCopyDigest = () => {
    const payloads: FeeReminderPayload[] = selectedItems.map(i => ({
      student: i.student,
      course: i.course,
      batch: i.batch,
      dueAmount: i.totalDueAmount,
      dueMonths: i.dueMonthLabels,
      templateType
    }));
    const digest = buildBatchFeeReminderDigest(payloads, centerInfo);
    navigator.clipboard.writeText(digest);
    setCopiedDigest(true);
    showToast('Batch fee reminder digest copied to clipboard!');
    setTimeout(() => setCopiedDigest(false), 2500);
  };

  // Launch sequential reminder sender (automated interactive queue)
  const currentItem = selectedItems[currentIndex];

  const handleNextInQueue = (channel: 'whatsapp' | 'email') => {
    if (!currentItem) return;
    if (channel === 'whatsapp') {
      handleSendSingleWhatsApp(currentItem);
    } else {
      handleSendSingleEmail(currentItem);
    }
    if (currentIndex < selectedItems.length - 1) {
      setCurrentIndex(prev => prev + 1);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1.5">
            <BellRing className="w-4 h-4 animate-bounce" />
            <span>Admin ERP Automated Service</span>
          </div>

          <h2 className="text-xl font-black tracking-tight text-white flex items-center gap-2">
            <span>Automated Batch Fee Reminders Trigger</span>
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Trigger automated, personalized payment reminder messages via WhatsApp and Email for students with outstanding dues.
          </p>

          <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800 text-center">
            <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 block">Total Due Students</span>
              <span className="text-sm font-bold text-white">{items.length}</span>
            </div>
            <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 block">Selected Queue</span>
              <span className="text-sm font-bold text-amber-400">{selectedItems.length}</span>
            </div>
            <div className="bg-slate-800/80 p-2 rounded-xl border border-slate-700">
              <span className="text-[10px] text-slate-400 block">Total Outstanding</span>
              <span className="text-sm font-bold text-emerald-400">₹{totalSelectedDue.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          {/* Template Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1.5">
              Select Message Notice Tone & Template
            </label>
            <div className="grid grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => setTemplateType('friendly')}
                className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer text-left ${
                  templateType === 'friendly'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-900 ring-2 ring-emerald-400/30'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Friendly Tone</span>
                </div>
                <span className="text-[10px] text-slate-500 font-normal block mt-0.5">Gentle reminder for upcoming cycle</span>
              </button>

              <button
                type="button"
                onClick={() => setTemplateType('standard')}
                className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer text-left ${
                  templateType === 'standard'
                    ? 'bg-indigo-50 border-indigo-500 text-indigo-900 ring-2 ring-indigo-400/30'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <BellRing className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Standard Due</span>
                </div>
                <span className="text-[10px] text-slate-500 font-normal block mt-0.5">Formal notice with UPI & breakdown</span>
              </button>

              <button
                type="button"
                onClick={() => setTemplateType('urgent')}
                className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer text-left ${
                  templateType === 'urgent'
                    ? 'bg-red-50 border-red-500 text-red-900 ring-2 ring-red-400/30'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
                  <span>Urgent Overdue</span>
                </div>
                <span className="text-[10px] text-slate-500 font-normal block mt-0.5">High priority overdue alert</span>
              </button>
            </div>
          </div>

          {/* Sequential Quick Dispatch Queue */}
          {selectedItems.length > 0 && currentItem && (
            <div className="p-4 bg-indigo-50/80 rounded-2xl border border-indigo-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-indigo-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Play className="w-3.5 h-3.5 text-indigo-600 fill-current" />
                  <span>Next in Dispatch Queue ({currentIndex + 1} of {selectedItems.length})</span>
                </span>
                <span className="text-xs font-mono font-bold text-red-600">
                  Due: ₹{currentItem.totalDueAmount.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="bg-white p-3 rounded-xl border border-indigo-100 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-900 text-sm block">{currentItem.student.name}</span>
                  <span className="text-slate-500 text-[11px] font-mono">
                    Roll: {currentItem.student.rollNo} • Mobile: {currentItem.student.mobile}
                  </span>
                  <span className="block text-[11px] text-slate-600 mt-0.5">
                    Unpaid: {currentItem.dueMonthLabels.join(', ')}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleNextInQueue('whatsapp')}
                    className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5 fill-current" />
                    <span>Send WhatsApp & Next</span>
                  </button>

                  <button
                    onClick={() => handleNextInQueue('email')}
                    className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl text-xs shadow-xs cursor-pointer"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    <span>Send Email & Next</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Student Selection List */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                Target Students with Dues ({selectedItems.length}/{items.length} Selected)
              </span>
              <button
                type="button"
                onClick={toggleSelectAll}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 cursor-pointer"
              >
                {selectedStudentIds.length === items.length ? 'Deselect All' : 'Select All'}
              </button>
            </div>

            <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden max-h-48 overflow-y-auto">
              {items.map((item) => {
                const isSelected = selectedStudentIds.includes(item.student.id);
                const status = dispatchStatus[item.student.id];

                return (
                  <div 
                    key={item.student.id} 
                    className={`p-3 flex items-center justify-between text-xs transition-colors ${
                      isSelected ? 'bg-white hover:bg-slate-50' : 'bg-slate-50 opacity-60'
                    }`}
                  >
                    <label className="flex items-center gap-3 cursor-pointer flex-1">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleStudent(item.student.id)}
                        className="rounded text-indigo-600 focus:ring-indigo-500"
                      />
                      <div>
                        <div className="font-bold text-slate-900 flex items-center gap-2">
                          <span>{item.student.name}</span>
                          <span className="font-mono text-[10px] text-slate-500 font-normal">({item.student.rollNo})</span>
                          {status === 'sent' && (
                            <span className="px-1.5 py-0.2 bg-emerald-100 text-emerald-800 font-bold text-[9px] rounded-full flex items-center gap-0.5">
                              <Check className="w-2.5 h-2.5" /> Dispatched
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {item.student.mobile} &bull; {item.course?.title}
                        </div>
                      </div>
                    </label>

                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-red-600 text-xs">
                        ₹{item.totalDueAmount.toLocaleString('en-IN')}
                      </span>

                      <button
                        type="button"
                        onClick={() => handleSendSingleWhatsApp(item)}
                        className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white transition cursor-pointer"
                        title="Send WhatsApp"
                      >
                        <MessageCircle className="w-3.5 h-3.5 fill-current" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSendSingleEmail(item)}
                        className="p-1.5 rounded-lg bg-purple-50 text-purple-700 hover:bg-purple-600 hover:text-white transition cursor-pointer"
                        title="Send Email"
                      >
                        <Mail className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleCopyDigest}
            className="flex items-center gap-1.5 px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
          >
            {copiedDigest ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            <span>{copiedDigest ? 'Digest Copied!' : 'Copy Batch Notice Summary'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
