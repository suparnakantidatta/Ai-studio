import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Expense, ExpenseCategory, PaymentMode } from '../../types';
import { 
  TrendingDown, 
  Plus, 
  Edit3, 
  Trash2, 
  DollarSign, 
  Calendar, 
  Tag, 
  PieChart, 
  Receipt,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';

const CATEGORIES: ExpenseCategory[] = [
  'Educator Salary',
  'Center Rent',
  'Electricity & Utilities',
  'Study Material & Printing',
  'Software, Hosting & SMS',
  'Marketing & Banners',
  'Stationery & Assets',
  'Maintenance & Cleaning',
  'Refreshments',
  'Miscellaneous'
];

export const ExpenseManager: React.FC = () => {
  const { expenses, payments, addExpense, updateExpense, deleteExpense } = useApp();

  const [showModal, setShowModal] = useState(false);
  const [editingExpenseId, setEditingExpenseId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>(CATEGORIES[0]);
  const [amount, setAmount] = useState<number>(5000);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('UPI');
  const [paidTo, setPaidTo] = useState('');
  const [receiptNo, setReceiptNo] = useState('');
  const [notes, setNotes] = useState('');

  // Financial Stats
  const totalApprovedFeeIncome = payments
    .filter(p => p.status === 'approved')
    .reduce((sum, p) => sum + p.finalAmountPaid, 0);

  const totalCenterExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const netBalance = totalApprovedFeeIncome - totalCenterExpenses;

  const handleOpenAdd = () => {
    setEditingExpenseId(null);
    setTitle('');
    setCategory(CATEGORIES[0]);
    setAmount(5000);
    setDate(new Date().toISOString().split('T')[0]);
    setPaymentMode('UPI');
    setPaidTo('');
    setReceiptNo('');
    setNotes('');
    setShowModal(true);
  };

  const handleOpenEdit = (exp: Expense) => {
    setEditingExpenseId(exp.id);
    setTitle(exp.title);
    setCategory(exp.category);
    setAmount(exp.amount);
    setDate(exp.date);
    setPaymentMode(exp.paymentMode);
    setPaidTo(exp.paidTo || '');
    setReceiptNo(exp.receiptNo || '');
    setNotes(exp.notes || '');
    setShowModal(true);
  };

  const handleSaveExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || amount <= 0) {
      alert('Please fill expense title and valid amount.');
      return;
    }

    if (editingExpenseId) {
      updateExpense(editingExpenseId, {
        title: title.trim(),
        category,
        amount: Number(amount),
        date,
        paymentMode,
        paidTo: paidTo.trim() || 'Vendor',
        receiptNo: receiptNo.trim() || undefined,
        notes: notes.trim() || undefined
      });
    } else {
      addExpense({
        title: title.trim(),
        category,
        amount: Number(amount),
        date,
        paymentMode,
        paidTo: paidTo.trim() || 'Vendor',
        receiptNo: receiptNo.trim() || undefined,
        notes: notes.trim() || undefined
      });
    }

    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header & Add Button */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <TrendingDown className="w-5 h-5 text-red-500" />
            <span>Center Expenses & Ledger</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Track all center operational costs, faculty salaries, facility rent, printing, and hardware expenses.
          </p>
        </div>

        <button
          id="btn-add-expense-modal"
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Center Expense</span>
        </button>
      </div>

      {/* Financial Health Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-emerald-700 font-bold mb-1">
            <span>Total Fee Collections</span>
            <ArrowUpRight className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono">
            ₹{totalApprovedFeeIncome.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Approved student fees</span>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-xs text-red-700 font-bold mb-1">
            <span>Total Center Expenses</span>
            <ArrowDownRight className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-black text-red-600 font-mono">
            ₹{totalCenterExpenses.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">{expenses.length} expense vouchers</span>
        </div>

        <div className={`p-5 rounded-3xl border shadow-xs ${
          netBalance >= 0 ? 'bg-indigo-50 border-indigo-200' : 'bg-red-50 border-red-200'
        }`}>
          <div className="flex items-center justify-between text-xs font-bold text-indigo-900 mb-1">
            <span>Net Operating Balance</span>
            <span className="font-mono">{netBalance >= 0 ? 'Surplus' : 'Deficit'}</span>
          </div>
          <div className="text-2xl font-black font-mono text-indigo-950">
            ₹{netBalance.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">Income minus operational expenses</span>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center text-xs font-bold text-slate-700">
          <span>Expense Vouchers ({expenses.length} records)</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-slate-100/70 text-slate-600 font-bold border-b border-slate-200">
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Expense Title</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5">Paid To</th>
                <th className="p-3.5 text-right">Amount</th>
                <th className="p-3.5">Mode & Ref</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {expenses.map((exp) => (
                <tr key={exp.id} className="hover:bg-slate-50/60 transition-colors">
                  <td className="p-3.5 font-mono text-slate-600 text-xs">
                    {exp.date}
                  </td>
                  <td className="p-3.5">
                    <div className="font-bold text-slate-900">{exp.title}</div>
                    {exp.notes && <div className="text-[11px] text-slate-400 italic">{exp.notes}</div>}
                  </td>
                  <td className="p-3.5">
                    <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-slate-100 text-slate-700">
                      {exp.category}
                    </span>
                  </td>
                  <td className="p-3.5 text-slate-800 font-medium">
                    {exp.paidTo || '—'}
                  </td>
                  <td className="p-3.5 text-right font-mono font-bold text-red-600 text-sm">
                    -₹{exp.amount.toLocaleString('en-IN')}
                  </td>
                  <td className="p-3.5">
                    <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700 font-mono">
                      {exp.paymentMode}
                    </span>
                    {exp.receiptNo && (
                      <span className="block text-[10px] text-slate-500 font-mono mt-0.5">
                        {exp.receiptNo}
                      </span>
                    )}
                  </td>
                  <td className="p-3.5 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => handleOpenEdit(exp)}
                        className="p-1.5 text-slate-600 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                        title="Edit expense"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Delete expense "${exp.title}"?`)) {
                            deleteExpense(exp.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition cursor-pointer"
                        title="Delete expense"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Expense Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-red-600 uppercase tracking-wider">
                  Expense Voucher
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {editingExpenseId ? 'Edit Expense Voucher' : 'Record Center Expense'}
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveExpense} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Expense Title / Purpose <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Broadband Internet & Fiber connection bill"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs sm:text-sm"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Category <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-medium"
                  >
                    {CATEGORIES.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Amount (₹) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    min={1}
                    required
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Expense Date <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Payment Mode
                  </label>
                  <select
                    value={paymentMode}
                    onChange={(e) => setPaymentMode(e.target.value as PaymentMode)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-bold"
                  >
                    <option value="UPI">UPI</option>
                    <option value="CASH">Cash</option>
                    <option value="BANK_TRANSFER">Bank NEFT / IMPS</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Paid To / Vendor
                  </label>
                  <input
                    type="text"
                    value={paidTo}
                    onChange={(e) => setPaidTo(e.target.value)}
                    placeholder="e.g. Airtel Fiber / Subhas Das"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Bill / Voucher Ref #
                  </label>
                  <input
                    type="text"
                    value={receiptNo}
                    onChange={(e) => setReceiptNo(e.target.value)}
                    placeholder="e.g. INV-2026-90"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Additional Notes
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Optional memo..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-xs"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer"
                >
                  {editingExpenseId ? 'Save Changes' : 'Record Expense'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
