import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdmissionApplication, PaymentMode } from '../../types';
import { calculateTargetDiscount, formatMonthKey } from '../../utils/feeCalculator';
import { MonthCalendarPicker } from '../common/MonthCalendarPicker';
import { 
  FileText, 
  CheckCircle, 
  XCircle, 
  Clock, 
  UserCheck, 
  Building2, 
  QrCode, 
  Calendar, 
  BookOpen, 
  Phone, 
  Sparkles,
  ArrowRight,
  Trash2,
  AlertTriangle,
  Receipt,
  CreditCard,
  Printer
} from 'lucide-react';

export const AdmissionProcessor: React.FC = () => {
  const { 
    admissions, 
    courses, 
    batches, 
    discounts,
    approveAdmission, 
    rejectAdmission, 
    deleteAdmission,
    setSelectedReceiptForPrint 
  } = useApp();

  const [selectedApp, setSelectedApp] = useState<AdmissionApplication | null>(null);
  const [appToDelete, setAppToDelete] = useState<AdmissionApplication | null>(null);
  const [assignedRollNo, setAssignedRollNo] = useState('');
  const [assignedBatchId, setAssignedBatchId] = useState('');
  const [admissionMonth, setAdmissionMonth] = useState(() => new Date().toISOString().substring(0, 7));
  const [filterStatus, setFilterStatus] = useState<'pending' | 'approved' | 'rejected' | 'all'>('pending');

  // Fee collection state for approval
  const [collectFeeNow, setCollectFeeNow] = useState(true);
  const [feeAmount, setFeeAmount] = useState(1500);
  const [feeMode, setFeeMode] = useState<PaymentMode>('UPI');
  const [feeRef, setFeeRef] = useState('');
  const [feeDate, setFeeDate] = useState(new Date().toISOString().split('T')[0]);

  const pendingApps = admissions.filter(a => a.status === 'pending');
  const displayedApps = admissions.filter(a => {
    if (filterStatus === 'all') return true;
    return a.status === filterStatus;
  });

  const handleOpenProcessModal = (app: AdmissionApplication) => {
    setSelectedApp(app);
    setAssignedRollNo(`PP-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 800) + 100)}`);
    const matchingBatches = batches.filter(b => b.courseId === app.targetCourseId);
    const initialBatchId = app.preferredBatchId || (matchingBatches[0]?.id || batches[0]?.id || '');
    setAssignedBatchId(initialBatchId);
    
    // Dynamic month detection: from student application date or current date
    const appMonth = (app.appliedDate && /^\d{4}-\d{2}/.test(app.appliedDate))
      ? app.appliedDate.substring(0, 7)
      : `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
    const defaultMonth = appMonth;
    setAdmissionMonth(defaultMonth);

    const course = courses.find(c => c.id === app.targetCourseId);
    const disc = calculateTargetDiscount({
      studentClass: app.studentClass,
      courseId: app.targetCourseId,
      batchId: initialBatchId,
      monthKey: defaultMonth,
      baseFee: course?.monthlyFee || 1200,
      discounts,
      course
    });

    setCollectFeeNow(true);
    setFeeAmount(app.initialPaymentAmount !== undefined ? app.initialPaymentAmount : disc.finalFee);
    setFeeMode(app.initialPaymentMode || 'UPI');
    setFeeRef(app.initialPaymentRef || (app.initialPaymentMode === 'CASH' ? 'CASH-COUNTER' : `ADM-${app.applicationNo}-PAID`));
    setFeeDate(new Date().toISOString().split('T')[0]);
  };

  const selectedCourse = courses.find(c => c.id === selectedApp?.targetCourseId);
  const selectedDiscountCalculation = calculateTargetDiscount({
    studentClass: selectedApp?.studentClass,
    courseId: selectedApp?.targetCourseId,
    batchId: assignedBatchId,
    monthKey: admissionMonth,
    baseFee: selectedCourse?.monthlyFee || 1200,
    discounts,
    course: selectedCourse
  });

  const handleMonthChange = (newMonth: string) => {
    setAdmissionMonth(newMonth);
    if (selectedApp && selectedCourse) {
      const disc = calculateTargetDiscount({
        studentClass: selectedApp.studentClass,
        courseId: selectedApp.targetCourseId,
        batchId: assignedBatchId,
        monthKey: newMonth,
        baseFee: selectedCourse.monthlyFee || 1200,
        discounts,
        course: selectedCourse
      });
      // If fee was matching current discount final fee, update to new month's discounted fee
      if (feeAmount === selectedDiscountCalculation.finalFee) {
        setFeeAmount(disc.finalFee);
      }
    }
  };

  const handleConfirmEnrollment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApp) return;

    const res = approveAdmission(
      selectedApp.id, 
      assignedBatchId, 
      assignedRollNo.trim(), 
      admissionMonth,
      {
        isPaid: collectFeeNow,
        amount: Number(feeAmount),
        paymentMode: feeMode,
        transactionRef: feeRef.trim() || 'ONLINE-ADM-PAY',
        paymentDate: feeDate,
        totalDiscount: selectedDiscountCalculation.discountAmount,
        discountBreakdown: selectedDiscountCalculation.notes.length > 0 ? selectedDiscountCalculation.notes.join('; ') : undefined,
        totalBaseFee: selectedCourse?.monthlyFee || Number(feeAmount),
        remarks: selectedDiscountCalculation.notes.length > 0 
          ? `Admission & tuition for ${formatMonthKey(admissionMonth)} (${selectedDiscountCalculation.notes.join(', ')}) (App #${selectedApp.applicationNo})`
          : `Admission Fee & tuition for ${formatMonthKey(admissionMonth)} (Application #${selectedApp.applicationNo})`
      }
    );

    if (res?.payment) {
      setSelectedReceiptForPrint(res.payment);
    }

    setSelectedApp(null);
  };

  const handleReject = (appId: string) => {
    const reason = prompt('Please enter the reason for rejecting this admission application:');
    if (reason) {
      rejectAdmission(appId, reason);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-600" />
              <span>Online Website Admission Applications</span>
            </h2>
            {pendingApps.length > 0 && (
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800">
                {pendingApps.length} New
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Review incoming student admission requests from the website, verify UPI/cash payments, and onboard into active batches.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl border border-slate-200 text-xs">
          <button
            onClick={() => setFilterStatus('pending')}
            className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
              filterStatus === 'pending' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pending Review ({pendingApps.length})
          </button>
          <button
            onClick={() => setFilterStatus('approved')}
            className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
              filterStatus === 'approved' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Enrolled
          </button>
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded-xl font-bold transition cursor-pointer ${
              filterStatus === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Applications
          </button>
        </div>
      </div>

      {/* Applications List */}
      <div className="space-y-4">
        {displayedApps.length > 0 ? (
          displayedApps.map((app) => {
            const course = courses.find(c => c.id === app.targetCourseId);
            const batch = batches.find(b => b.id === app.preferredBatchId);

            return (
              <div
                key={app.id}
                className={`bg-white rounded-3xl border p-6 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-6 transition ${
                  app.status === 'pending'
                    ? 'border-indigo-200 bg-indigo-50/20'
                    : app.status === 'approved'
                    ? 'border-slate-200'
                    : 'border-red-200 opacity-60'
                }`}
              >
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                      app.status === 'pending'
                        ? 'bg-indigo-100 text-indigo-800'
                        : app.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {app.status}
                    </span>

                    <span className="font-mono text-xs font-bold text-indigo-900">
                      App #: {app.applicationNo}
                    </span>

                    <span className="text-xs text-slate-400">•</span>
                    <span className="text-xs text-slate-500">Submitted: {app.appliedDate}</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-3">
                    <h3 className="text-lg font-bold text-slate-900">
                      {app.studentName}
                    </h3>
                    <span className="text-xs font-bold text-violet-700 bg-violet-50 border border-violet-200 px-2 py-0.5 rounded-full">
                      {app.studentClass || 'Class 10 (Secondary)'}
                    </span>
                    <span className="text-xs font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                      Aadhaar: {app.aadhaarNo}
                    </span>
                    <span className="text-xs font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                      Mobile: {app.mobile}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-slate-600">
                    <div>
                      <span className="text-slate-400">Selected Course: </span>
                      <strong className="text-indigo-950">{course?.title}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400">Guardian: </span>
                      <strong className="text-slate-800">{app.guardianName} ({app.guardianPhone})</strong>
                    </div>
                    <div>
                      <span className="text-slate-400">Payment Option: </span>
                      <strong className="text-slate-800 uppercase font-mono">
                        {app.initialPaymentMode || 'None'} ({app.initialPaymentStatus})
                      </strong>
                    </div>
                  </div>

                  {app.appliedDiscountAmount !== undefined && app.appliedDiscountAmount > 0 && (
                    <div className="flex items-center gap-1.5 text-xs text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>
                        Concession: <strong className="font-mono font-bold">-₹{app.appliedDiscountAmount}</strong> {app.appliedDiscountNotes ? `(${app.appliedDiscountNotes})` : ''} • Base Fee: ₹{app.baseFee || course?.monthlyFee}
                      </span>
                    </div>
                  )}

                  {app.initialPaymentRef && (
                    <div className="text-xs font-mono text-slate-500">
                      Payment Ref / UTR: <strong className="text-indigo-700">{app.initialPaymentRef}</strong>
                    </div>
                  )}

                  {app.remarks && (
                    <p className="text-xs text-slate-500 italic">
                      Applicant Note: &quot;{app.remarks}&quot;
                    </p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
                  {app.status === 'pending' && (
                    <>
                      <button
                        onClick={() => handleOpenProcessModal(app)}
                        className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md transition cursor-pointer flex items-center gap-1.5"
                      >
                        <UserCheck className="w-4 h-4" />
                        <span>Process & Enroll</span>
                      </button>

                      <button
                        onClick={() => handleReject(app.id)}
                        className="px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
                      >
                        Reject
                      </button>
                    </>
                  )}

                  {/* Delete Application Button */}
                  <button
                    onClick={() => setAppToDelete(app)}
                    title="Permanently Delete Application"
                    className="p-2.5 bg-red-50 hover:bg-red-100 text-red-600 hover:text-red-700 rounded-xl text-xs transition cursor-pointer border border-red-200 flex items-center gap-1"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span className="hidden sm:inline font-bold">Delete</span>
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center text-slate-400">
            <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto mb-3 opacity-60" />
            <h3 className="font-bold text-slate-700 text-base">No {filterStatus} applications</h3>
            <p className="text-xs text-slate-400 mt-1">All online admission forms are processed.</p>
          </div>
        )}
      </div>

      {/* Delete Confirmation Modal */}
      {appToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 shadow-2xl border border-slate-200">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-red-100 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Delete Admission Application?</h3>
                <span className="text-xs text-slate-500 font-mono">App #{appToDelete.applicationNo}</span>
              </div>
            </div>

            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              Are you sure you want to permanently delete the admission application for <strong className="text-slate-900 font-bold">{appToDelete.studentName}</strong> ({appToDelete.mobile})? This action will remove it from the database and cannot be undone.
            </p>

            <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setAppToDelete(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  deleteAdmission(appToDelete.id);
                  setAppToDelete(null);
                }}
                className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-md flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Confirm Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Process & Enroll Modal */}
      {selectedApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Admission Onboarding
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  Enroll {selectedApp.studentName}
                </h3>
              </div>
              <button
                onClick={() => setSelectedApp(null)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleConfirmEnrollment} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Assign Roll Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={assignedRollNo}
                  onChange={(e) => setAssignedRollNo(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Assign Final Batch <span className="text-red-500">*</span>
                </label>
                <select
                  value={assignedBatchId}
                  onChange={(e) => setAssignedBatchId(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-medium"
                >
                  {batches.map(b => (
                    <option key={b.id} value={b.id}>
                      {b.name} ({b.timing})
                    </option>
                  ))}
                </select>
              </div>

              {/* Dynamic Admission Billing Month with Calendar Picker */}
              <MonthCalendarPicker
                value={admissionMonth}
                onChange={handleMonthChange}
                label="Admission Billing Month"
                required
                helperText="Monthly fees will be billed starting from this month"
                applicationMonth={selectedApp?.appliedDate ? selectedApp.appliedDate.substring(0, 7) : undefined}
                id="admission-billing-month-picker"
              />

              {/* Initial Fee Collection & Payment Section */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={collectFeeNow}
                      onChange={(e) => setCollectFeeNow(e.target.checked)}
                      className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
                    />
                    <div className="flex items-center gap-1.5 font-bold text-xs sm:text-sm text-slate-900">
                      <Receipt className="w-4 h-4 text-indigo-600" />
                      <span>Record & Approve Admission Fee Payment</span>
                    </div>
                  </label>

                  {selectedDiscountCalculation.discountAmount > 0 && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold border border-emerald-300">
                      <Sparkles className="w-3 h-3 text-emerald-600" />
                      <span>Concession: -₹{selectedDiscountCalculation.discountAmount} ({selectedDiscountCalculation.notes.join(', ')})</span>
                    </span>
                  )}
                </div>

                {/* Fee Calculation Overview Banner */}
                <div className="p-2.5 bg-white rounded-xl border border-slate-200 text-xs flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <span className="text-slate-600">
                      Course Base Fee: <strong className="text-slate-900 font-mono">₹{selectedCourse?.monthlyFee || 1200}</strong>
                    </span>
                    {selectedDiscountCalculation.discountAmount > 0 && (
                      <span className="text-emerald-700">
                        Discount: <strong className="font-mono font-bold">-₹{selectedDiscountCalculation.discountAmount}</strong>
                      </span>
                    )}
                    <span className="text-indigo-900 font-bold">
                      Net 1st Month Fee: <strong className="font-mono text-indigo-700 font-black">₹{selectedDiscountCalculation.finalFee}</strong>
                    </span>
                  </div>

                  {feeAmount !== selectedDiscountCalculation.finalFee && (
                    <button
                      type="button"
                      onClick={() => setFeeAmount(selectedDiscountCalculation.finalFee)}
                      className="px-2 py-1 bg-indigo-100 hover:bg-indigo-200 text-indigo-800 font-bold rounded-lg text-[10px] cursor-pointer transition"
                    >
                      Set to Discounted Fee (₹{selectedDiscountCalculation.finalFee})
                    </button>
                  )}
                </div>

                {collectFeeNow && (
                  <div className="space-y-3 pt-2 border-t border-slate-200/80">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                          Amount Received (₹) <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="number"
                          required={collectFeeNow}
                          min="1"
                          value={feeAmount}
                          onChange={(e) => setFeeAmount(Number(e.target.value))}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono font-bold"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                          Payment Mode
                        </label>
                        <select
                          value={feeMode}
                          onChange={(e) => setFeeMode(e.target.value as PaymentMode)}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-medium"
                        >
                          <option value="UPI">UPI (GooglePay / PhonePe / Paytm)</option>
                          <option value="CASH">Cash at Desk Counter</option>
                          <option value="ONLINE_GATEWAY">Online Payment Gateway</option>
                          <option value="BANK_TRANSFER">Direct Bank Transfer / NEFT</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                          Transaction Ref / UTR / Cash Note
                        </label>
                        <input
                          type="text"
                          value={feeRef}
                          onChange={(e) => setFeeRef(e.target.value)}
                          placeholder="e.g. UPI-1234567890 or CASH-RECEPTION"
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-600 uppercase mb-1">
                          Payment Date
                        </label>
                        <input
                          type="date"
                          value={feeDate}
                          onChange={(e) => setFeeDate(e.target.value)}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-[11px] text-emerald-700 font-medium bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-200">
                      <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                      <span>An official approved A4 fee receipt will be automatically generated and added to Fee Transactions and Google Sheets.</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedApp(null)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>Confirm Enrollment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
