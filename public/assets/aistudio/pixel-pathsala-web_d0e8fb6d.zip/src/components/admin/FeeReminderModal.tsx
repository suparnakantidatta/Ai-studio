import React, { useState } from 'react';
import { Student, Course, Batch } from '../../types';
import { useApp } from '../../context/AppContext';
import { 
  FeeReminderPayload, 
  buildFeeReminderMessage, 
  sendStudentWhatsAppReminder, 
  sendStudentEmailReminder 
} from '../../services/feeReminderService';
import { 
  BellRing, 
  MessageCircle, 
  MessageSquare, 
  Mail, 
  Copy, 
  Check, 
  X, 
  Send, 
  QrCode, 
  AlertCircle,
  Sparkles,
  AlertTriangle,
  ExternalLink
} from 'lucide-react';

interface FeeReminderModalProps {
  student: Student;
  course?: Course;
  batch?: Batch;
  dueAmount: number;
  dueMonths: string[];
  onClose: () => void;
}

export const FeeReminderModal: React.FC<FeeReminderModalProps> = ({
  student,
  course,
  batch,
  dueAmount,
  dueMonths,
  onClose
}) => {
  const { centerInfo, showToast } = useApp();
  const [selectedChannel, setSelectedChannel] = useState<'whatsapp' | 'sms' | 'email'>('whatsapp');
  const [templateType, setTemplateType] = useState<'friendly' | 'standard' | 'urgent'>('standard');
  const [customAmount, setCustomAmount] = useState<number>(dueAmount);
  const [copied, setCopied] = useState<boolean>(false);

  const cleanPhone = (student.mobile || '').replace(/[^0-9]/g, '');
  const formattedPhone = cleanPhone.startsWith('91') ? cleanPhone : `91${cleanPhone}`;

  const payload: FeeReminderPayload = {
    student,
    course,
    batch,
    dueAmount: customAmount,
    dueMonths,
    templateType
  };

  const { subject, message: reminderMessage } = buildFeeReminderMessage(payload, centerInfo);

  const handleCopy = () => {
    navigator.clipboard.writeText(reminderMessage);
    setCopied(true);
    showToast('Reminder message copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSendWhatsApp = () => {
    sendStudentWhatsAppReminder(payload, centerInfo);
    showToast(`WhatsApp reminder dispatched for ${student.name}!`);
    onClose();
  };

  const handleSendSMS = () => {
    const encoded = encodeURIComponent(reminderMessage);
    const url = `sms:${student.mobile}?body=${encoded}`;
    window.location.href = url;
    showToast(`SMS application opened for ${student.name}!`);
    onClose();
  };

  const handleSendEmail = () => {
    sendStudentEmailReminder(payload, centerInfo);
    showToast(`Email reminder dispatched for ${student.name}!`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <BellRing className="w-4 h-4 animate-bounce" />
            <span>Automated Fee Due Reminder</span>
          </div>

          <h2 className="text-xl font-black tracking-tight text-white">
            Send Fee Notification
          </h2>
          <p className="text-xs text-slate-300 mt-1">
            Dispatch personalized fee reminders via WhatsApp, SMS, or Email to parents and students.
          </p>

          {/* Student mini tag */}
          <div className="flex flex-wrap items-center gap-2 mt-4 text-xs bg-slate-800/80 p-3 rounded-2xl border border-slate-700">
            <span className="font-bold text-white">{student.name}</span>
            <span className="text-slate-400">•</span>
            <span className="font-mono text-indigo-300">Roll: {student.rollNo}</span>
            <span className="text-slate-400">•</span>
            <span className="font-mono text-emerald-400">Due: ₹{customAmount.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          {/* Template Tone Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Notice Template Tone
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setTemplateType('friendly')}
                className={`p-2 rounded-xl border text-xs font-bold transition cursor-pointer text-center ${
                  templateType === 'friendly'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-400/30'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                Friendly
              </button>
              <button
                type="button"
                onClick={() => setTemplateType('standard')}
                className={`p-2 rounded-xl border text-xs font-bold transition cursor-pointer text-center ${
                  templateType === 'standard'
                    ? 'bg-indigo-50 border-indigo-500 text-indigo-800 ring-2 ring-indigo-400/30'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                Standard
              </button>
              <button
                type="button"
                onClick={() => setTemplateType('urgent')}
                className={`p-2 rounded-xl border text-xs font-bold transition cursor-pointer text-center ${
                  templateType === 'urgent'
                    ? 'bg-red-50 border-red-500 text-red-800 ring-2 ring-red-400/30'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                Urgent
              </button>
            </div>
          </div>

          {/* Channel Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              Select Notification Channel
            </label>
            <div className="grid grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => setSelectedChannel('whatsapp')}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-bold transition-all cursor-pointer ${
                  selectedChannel === 'whatsapp'
                    ? 'bg-emerald-50 border-emerald-500 text-emerald-800 ring-2 ring-emerald-400/30'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <MessageCircle className="w-5 h-5 text-emerald-600 mb-1" />
                <span>WhatsApp</span>
                <span className="text-[10px] text-slate-500 font-normal mt-0.5">{student.mobile || 'No Mobile'}</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedChannel('sms')}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-bold transition-all cursor-pointer ${
                  selectedChannel === 'sms'
                    ? 'bg-blue-50 border-blue-500 text-blue-800 ring-2 ring-blue-400/30'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <MessageSquare className="w-5 h-5 text-blue-600 mb-1" />
                <span>Direct SMS</span>
                <span className="text-[10px] text-slate-500 font-normal mt-0.5">Cellular</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedChannel('email')}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl border text-xs font-bold transition-all cursor-pointer ${
                  selectedChannel === 'email'
                    ? 'bg-purple-50 border-purple-500 text-purple-800 ring-2 ring-purple-400/30'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Mail className="w-5 h-5 text-purple-600 mb-1" />
                <span>Email</span>
                <span className="text-[10px] text-slate-500 font-normal mt-0.5 truncate max-w-[100px]">{student.email || 'Center Default'}</span>
              </button>
            </div>
          </div>

          {/* Amount Adjustment */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Due Amount (₹)
              </label>
              <input
                type="number"
                value={customAmount}
                onChange={(e) => setCustomAmount(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Recipient Contact
              </label>
              <div className="px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl text-xs font-mono text-slate-800 flex items-center justify-between">
                <span>{student.mobile}</span>
                <span className="text-[10px] text-slate-500">{student.guardianName || 'Parent'}</span>
              </div>
            </div>
          </div>

          {/* Live Message Preview */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700">
                Message Preview
              </label>
              <button
                type="button"
                onClick={handleCopy}
                className="flex items-center gap-1 text-xs font-semibold text-indigo-600 hover:text-indigo-800 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Text'}</span>
              </button>
            </div>
            <textarea
              readOnly
              rows={7}
              value={reminderMessage}
              className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-mono text-slate-800 leading-relaxed resize-none focus:outline-hidden select-all"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-end gap-2.5 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
            >
              Cancel
            </button>

            {selectedChannel === 'whatsapp' && (
              <button
                type="button"
                onClick={handleSendWhatsApp}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>Dispatch via WhatsApp</span>
              </button>
            )}

            {selectedChannel === 'sms' && (
              <button
                type="button"
                onClick={handleSendSMS}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Open SMS Composer</span>
              </button>
            )}

            {selectedChannel === 'email' && (
              <button
                type="button"
                onClick={handleSendEmail}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer"
              >
                <Mail className="w-4 h-4" />
                <span>Send Email Reminder</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
