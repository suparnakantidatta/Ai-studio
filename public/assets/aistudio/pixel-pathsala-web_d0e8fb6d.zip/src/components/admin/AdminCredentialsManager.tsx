import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { AdminAccount } from '../../types';
import { 
  KeyRound, 
  ShieldCheck, 
  Plus, 
  Edit3, 
  Trash2, 
  Eye, 
  EyeOff, 
  Lock, 
  User, 
  Mail, 
  Phone, 
  Save, 
  X, 
  CheckCircle2, 
  AlertCircle,
  Database,
  CloudUpload,
  RefreshCw
} from 'lucide-react';

export const AdminCredentialsManager: React.FC = () => {
  const { 
    adminAccounts, 
    addAdminAccount, 
    updateAdminAccount, 
    deleteAdminAccount, 
    updateAdminPassword,
    syncToGoogleSheets,
    isSyncingSheets,
    adminUser
  } = useApp();

  const [showPasswordMap, setShowPasswordMap] = useState<{ [id: string]: boolean }>({});
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form states for adding / editing
  const [formData, setFormData] = useState<Omit<AdminAccount, 'id' | 'updatedAt'>>({
    username: '',
    password: '',
    name: '',
    role: 'Administrator',
    email: '',
    phone: '',
    securityPin: '1234',
    status: 'active'
  });

  // Quick Change Master Password modal
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');

  const togglePasswordVisibility = (id: string) => {
    setShowPasswordMap(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleStartAdd = () => {
    setFormData({
      username: '',
      password: '',
      name: '',
      role: 'Staff Administrator',
      email: '',
      phone: '',
      securityPin: '1234',
      status: 'active'
    });
    setEditingId(null);
    setIsAddingNew(true);
  };

  const handleStartEdit = (account: AdminAccount) => {
    setFormData({
      username: account.username,
      password: account.password,
      name: account.name,
      role: account.role,
      email: account.email,
      phone: account.phone,
      securityPin: account.securityPin,
      status: account.status
    });
    setEditingId(account.id);
    setIsAddingNew(false);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.username || !formData.password || !formData.name) {
      alert('Please fill in required fields (Username, Password, Name).');
      return;
    }

    if (editingId) {
      updateAdminAccount(editingId, formData);
      setEditingId(null);
    } else {
      addAdminAccount(formData);
      setIsAddingNew(false);
    }
  };

  const handlePasswordChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');
    setPasswordSuccess('');

    if (newPass !== confirmPass) {
      setPasswordError('New passwords do not match.');
      return;
    }

    const res = updateAdminPassword(currentPass, newPass);
    if (res.success) {
      setPasswordSuccess('Password updated successfully!');
      setCurrentPass('');
      setNewPass('');
      setConfirmPass('');
      setTimeout(() => {
        setIsChangingPassword(false);
        setPasswordSuccess('');
      }, 1500);
    } else {
      setPasswordError(res.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header & Quick Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase tracking-wider">
            <KeyRound className="w-4 h-4" />
            <span>Database Table: Admin_Credentials</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">
            Admin Access & Credentials Directory
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage administrative accounts, access roles, passwords, and security credentials stored in your Google Sheets database.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => syncToGoogleSheets()}
            disabled={isSyncingSheets}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-300 rounded-xl text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
            title="Sync Admin Credentials Table to Google Sheets"
          >
            <CloudUpload className={`w-3.5 h-3.5 ${isSyncingSheets ? 'animate-spin' : ''}`} />
            <span>{isSyncingSheets ? 'Syncing...' : 'Sync to Sheets'}</span>
          </button>

          <button
            onClick={() => setIsChangingPassword(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold transition-all cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-slate-600" />
            <span>Change My Password</span>
          </button>

          <button
            onClick={handleStartAdd}
            className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Admin User</span>
          </button>
        </div>
      </div>

      {/* Add / Edit Form Modal / Box */}
      {(isAddingNew || editingId) && (
        <div className="bg-gradient-to-br from-indigo-50/70 to-slate-50 border-2 border-indigo-200 rounded-2xl p-6 shadow-md animate-in fade-in duration-150">
          <div className="flex items-center justify-between mb-4 pb-3 border-b border-indigo-100">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>{editingId ? 'Edit Admin Login Credentials' : 'Create New Administrative Account'}</span>
            </h3>
            <button
              onClick={() => {
                setIsAddingNew(false);
                setEditingId(null);
              }}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <form onSubmit={handleSaveForm} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Name / Title *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Director Suparna Kanti Datta"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Username *
                </label>
                <input
                  type="text"
                  required
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  placeholder="e.g. admin or director"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Password *
                </label>
                <input
                  type="text"
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="e.g. admin123"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Role Title *
                </label>
                <select
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                >
                  <option value="Master Administrator">Master Administrator</option>
                  <option value="Center Director">Center Director</option>
                  <option value="Academic Coordinator">Academic Coordinator</option>
                  <option value="Accounts & Billing Manager">Accounts & Billing Manager</option>
                  <option value="Staff Administrator">Staff Administrator</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Official Email
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="e.g. admin@pixelpathsala.com"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Mobile / Helpline
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="e.g. +91 9775708722"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Security PIN
                </label>
                <input
                  type="text"
                  maxLength={6}
                  value={formData.securityPin}
                  onChange={(e) => setFormData({ ...formData, securityPin: e.target.value })}
                  placeholder="e.g. 7722"
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Account Status
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as 'active' | 'inactive' })}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                >
                  <option value="active">Active (Access Allowed)</option>
                  <option value="inactive">Inactive (Access Suspended)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  setIsAddingNew(false);
                  setEditingId(null);
                }}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{editingId ? 'Save Credential Updates' : 'Create Admin Account'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Admin Credentials Database Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-700">
            <Database className="w-3.5 h-3.5 text-indigo-600" />
            <span>Registered Admin Accounts ({adminAccounts.length})</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono">
            Synced with Google Sheets Tab: Admin_Credentials
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/70 text-slate-600 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Account ID</th>
                <th className="py-3 px-4">Admin Name</th>
                <th className="py-3 px-4">Username</th>
                <th className="py-3 px-4">Password</th>
                <th className="py-3 px-4">Role Title</th>
                <th className="py-3 px-4">Contact Info</th>
                <th className="py-3 px-4">PIN</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {adminAccounts.map((account) => {
                const isRevealed = showPasswordMap[account.id];
                const isCurrent = adminUser?.username.toLowerCase() === account.username.toLowerCase();

                return (
                  <tr 
                    key={account.id}
                    className={`hover:bg-slate-50/80 transition-colors ${
                      isCurrent ? 'bg-indigo-50/40' : ''
                    }`}
                  >
                    <td className="py-3 px-4 font-mono font-bold text-slate-700">
                      {account.id}
                      {isCurrent && (
                        <span className="ml-1.5 px-1.5 py-0.2 rounded text-[9px] font-bold bg-indigo-100 text-indigo-700 border border-indigo-200">
                          You
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{account.name}</div>
                      <div className="text-[11px] text-slate-500 font-mono">Last modified: {account.updatedAt || '—'}</div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.8 rounded-lg bg-slate-100 border border-slate-200 font-mono font-bold text-slate-800">
                        {account.username}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono bg-slate-100 px-2 py-0.8 rounded border border-slate-200 text-slate-700 select-all">
                          {isRevealed ? account.password : '••••••••'}
                        </span>
                        <button
                          type="button"
                          onClick={() => togglePasswordVisibility(account.id)}
                          className="p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                          title={isRevealed ? 'Hide Password' : 'Show Password'}
                        >
                          {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-indigo-500" />}
                        </button>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.8 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-100 font-semibold text-[11px]">
                        {account.role}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-700">{account.email || '—'}</div>
                      <div className="text-[11px] text-slate-500 font-mono">{account.phone || '—'}</div>
                    </td>
                    <td className="py-3 px-4 font-mono font-semibold text-slate-600">
                      {account.securityPin || '—'}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        account.status === 'active'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${account.status === 'active' ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
                        {account.status === 'active' ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleStartEdit(account)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 transition cursor-pointer"
                          title="Edit Credentials"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        {adminAccounts.length > 1 && (
                          <button
                            onClick={() => {
                              if (confirm(`Are you sure you want to delete admin account "${account.username}"?`)) {
                                deleteAdminAccount(account.id);
                              }
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                            title="Delete Account"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Change Password Modal */}
      {isChangingPassword && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 animate-in fade-in duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Lock className="w-4 h-4 text-indigo-600" />
                <span>Update Master Admin Password</span>
              </h3>
              <button
                onClick={() => {
                  setIsChangingPassword(false);
                  setPasswordError('');
                  setPasswordSuccess('');
                }}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handlePasswordChangeSubmit} className="space-y-3.5 mt-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Current Password *
                </label>
                <input
                  type="password"
                  required
                  value={currentPass}
                  onChange={(e) => setCurrentPass(e.target.value)}
                  placeholder="Enter current password"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  New Password *
                </label>
                <input
                  type="password"
                  required
                  minLength={4}
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  placeholder="At least 4 characters"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Confirm New Password *
                </label>
                <input
                  type="password"
                  required
                  minLength={4}
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                  placeholder="Re-enter new password"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              {passwordError && (
                <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                  <span>{passwordError}</span>
                </div>
              )}

              {passwordSuccess && (
                <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  <span>{passwordSuccess}</span>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsChangingPassword(false)}
                  className="px-3.5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
                >
                  Save New Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
