import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { Batch, Student } from '../../types';
import { getStudentMonthlyBilling, formatMonthKey, getCurrentMonthKey } from '../../utils/feeCalculator';
import { 
  exportBatchStudentDetailsToExcel,
  exportBatchWiseDuesAndPaymentsToExcel,
  exportFinancialYearMISReportToExcel,
  FYFinancialMonthRow
} from '../../utils/excelExporter';
import { 
  FileSpreadsheet, 
  Download, 
  Users, 
  CreditCard, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Layers, 
  Calendar, 
  Filter, 
  CheckCircle2, 
  AlertCircle, 
  Printer, 
  Building2,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  BarChart3,
  Percent,
  Search
} from 'lucide-react';

export const ReportsManager: React.FC = () => {
  const { 
    students, 
    batches, 
    courses, 
    educators, 
    discounts, 
    payments, 
    expenses, 
    centerInfo,
    setSelectedReceiptForPrint 
  } = useApp();

  // Active Report Tab: 'batch-students' | 'batch-dues' | 'fy-finance'
  const [activeReportTab, setActiveReportTab] = useState<'batch-students' | 'batch-dues' | 'fy-finance'>('batch-students');

  // Filters for Batch-wise Student Report
  const [selectedBatchIdForStudents, setSelectedBatchIdForStudents] = useState<string>('all');
  const [studentStatusFilter, setStudentStatusFilter] = useState<'all' | 'active' | 'passed_out'>('all');
  const [studentSearchQuery, setStudentSearchQuery] = useState('');

  // Filters for Batch-wise Dues Report
  const currentCalMonth = getCurrentMonthKey();
  const [selectedBatchIdForDues, setSelectedBatchIdForDues] = useState<string>('all');
  const [dueStatusFilter, setDueStatusFilter] = useState<'all' | 'has_dues' | 'cleared'>('all');
  const [duesBillingMonth, setDuesBillingMonth] = useState<string>(() => currentCalMonth);

  // Filters for FY Financial Report
  const [selectedFY, setSelectedFY] = useState<string>('2026-27');

  // Pre-calculate billing map for all students in real-time
  const studentBillingMap = useMemo(() => {
    const map: Record<string, ReturnType<typeof getStudentMonthlyBilling>> = {};
    students.forEach(st => {
      const course = courses.find(c => c.id === st.courseId);
      map[st.id] = getStudentMonthlyBilling(st, course, discounts, payments, duesBillingMonth);
    });
    return map;
  }, [students, courses, discounts, payments, duesBillingMonth]);

  // -------------------------------------------------------------
  // REPORT 1: BATCH-WISE STUDENT DIRECTORY
  // -------------------------------------------------------------
  const filteredStudents = useMemo(() => {
    return students.filter(st => {
      const matchBatch = selectedBatchIdForStudents === 'all' || st.batchId === selectedBatchIdForStudents;
      const matchStatus = studentStatusFilter === 'all' || st.status === studentStatusFilter;
      const matchQuery = !studentSearchQuery.trim() || 
        st.name.toLowerCase().includes(studentSearchQuery.toLowerCase()) ||
        st.rollNo.toLowerCase().includes(studentSearchQuery.toLowerCase()) ||
        st.mobile.includes(studentSearchQuery);
      return matchBatch && matchStatus && matchQuery;
    });
  }, [students, selectedBatchIdForStudents, studentStatusFilter, studentSearchQuery]);

  const activeBatchObj = batches.find(b => b.id === selectedBatchIdForStudents) || null;

  const handleExportStudentsExcel = () => {
    exportBatchStudentDetailsToExcel({
      batch: activeBatchObj,
      students: filteredStudents,
      courses,
      educators,
      centerInfo
    });
  };

  // -------------------------------------------------------------
  // REPORT 2: BATCH-WISE DUES & PAYMENTS
  // -------------------------------------------------------------
  const filteredDuesStudents = useMemo(() => {
    return students.filter(st => {
      const matchBatch = selectedBatchIdForDues === 'all' || st.batchId === selectedBatchIdForDues;
      const billing = studentBillingMap[st.id];
      if (!billing) return matchBatch;

      let matchDue = true;
      if (dueStatusFilter === 'has_dues') {
        matchDue = billing.totalDueAmount > 0;
      } else if (dueStatusFilter === 'cleared') {
        matchDue = billing.totalDueAmount === 0;
      }

      return matchBatch && matchDue;
    });
  }, [students, selectedBatchIdForDues, dueStatusFilter, studentBillingMap]);

  const duesSummaryMetrics = useMemo(() => {
    let totalPayable = 0;
    let totalPaid = 0;
    let totalPending = 0;
    let totalDues = 0;

    filteredDuesStudents.forEach(st => {
      const b = studentBillingMap[st.id];
      if (b) {
        totalPayable += b.totalPayableSinceAdmission;
        totalPaid += b.totalPaid;
        totalPending += b.totalPendingApproval;
        totalDues += b.totalDueAmount;
      }
    });

    const recoveryRate = totalPayable > 0 ? (totalPaid / totalPayable) * 100 : 100;

    return {
      totalPayable,
      totalPaid,
      totalPending,
      totalDues,
      recoveryRate
    };
  }, [filteredDuesStudents, studentBillingMap]);

  const activeDuesBatchObj = batches.find(b => b.id === selectedBatchIdForDues) || null;

  const handleExportDuesExcel = () => {
    exportBatchWiseDuesAndPaymentsToExcel({
      batch: activeDuesBatchObj,
      batches,
      students: filteredDuesStudents,
      courses,
      billingMap: studentBillingMap,
      centerInfo
    });
  };

  // -------------------------------------------------------------
  // REPORT 3: FY-WISE FINANCIAL STATEMENT (INCOME / EXPENDITURE / BALANCE)
  // -------------------------------------------------------------
  // Indian Financial Year: April to March (e.g. FY 2026-27 is 2026-04 to 2027-03)
  const fyMonths = useMemo(() => {
    const [startYearStr, endYearShort] = selectedFY.split('-');
    const startYear = parseInt(startYearStr, 10);
    const endYear = startYear + 1;

    const list = [
      { key: `${startYear}-04`, name: `April ${startYear}` },
      { key: `${startYear}-05`, name: `May ${startYear}` },
      { key: `${startYear}-06`, name: `June ${startYear}` },
      { key: `${startYear}-07`, name: `July ${startYear}` },
      { key: `${startYear}-08`, name: `August ${startYear}` },
      { key: `${startYear}-09`, name: `September ${startYear}` },
      { key: `${startYear}-10`, name: `October ${startYear}` },
      { key: `${startYear}-11`, name: `November ${startYear}` },
      { key: `${startYear}-12`, name: `December ${startYear}` },
      { key: `${endYear}-01`, name: `January ${endYear}` },
      { key: `${endYear}-02`, name: `February ${endYear}` },
      { key: `${endYear}-03`, name: `March ${endYear}` },
    ];

    return list;
  }, [selectedFY]);

  const fyMonthlyFinancials: FYFinancialMonthRow[] = useMemo(() => {
    let runningBalance = 0;

    return fyMonths.map(m => {
      // Approved Fee collections in this month
      const monthApprovedPayments = payments.filter(p => {
        if (p.status !== 'approved') return false;
        // Check either paymentDate or month covered
        return p.paymentDate.startsWith(m.key) || p.month.includes(m.name.split(' ')[0]);
      });

      const grossIncome = monthApprovedPayments.reduce((sum, p) => sum + p.finalAmountPaid, 0);

      // Expenses in this month
      const monthExpenses = expenses.filter(e => e.date.startsWith(m.key));
      const grossExpenditure = monthExpenses.reduce((sum, e) => sum + e.amount, 0);

      const netSurplus = grossIncome - grossExpenditure;
      runningBalance += netSurplus;

      const categoryBreakdown: Record<string, number> = {};
      monthExpenses.forEach(e => {
        categoryBreakdown[e.category] = (categoryBreakdown[e.category] || 0) + e.amount;
      });

      return {
        monthKey: m.key,
        monthName: m.name,
        grossIncome,
        approvedReceiptsCount: monthApprovedPayments.length,
        grossExpenditure,
        expenseVouchersCount: monthExpenses.length,
        netSurplus,
        cumulativeBalance: runningBalance,
        categoryBreakdown
      };
    });
  }, [fyMonths, payments, expenses]);

  const fyTotalIncome = fyMonthlyFinancials.reduce((sum, m) => sum + m.grossIncome, 0);
  const fyTotalExpenditure = fyMonthlyFinancials.reduce((sum, m) => sum + m.grossExpenditure, 0);
  const fyNetSurplus = fyTotalIncome - fyTotalExpenditure;
  const fyOperatingMargin = fyTotalIncome > 0 ? ((fyNetSurplus / fyTotalIncome) * 100) : 0;

  // Filter expenses and payments strictly for this FY
  const fyExpenses = useMemo(() => {
    const keys = fyMonths.map(m => m.key);
    return expenses.filter(e => keys.some(k => e.date.startsWith(k)));
  }, [expenses, fyMonths]);

  const fyPayments = useMemo(() => {
    const keys = fyMonths.map(m => m.key);
    return payments.filter(p => keys.some(k => p.paymentDate.startsWith(k)));
  }, [payments, fyMonths]);

  const handleExportFYExcel = () => {
    exportFinancialYearMISReportToExcel({
      fyLabel: selectedFY,
      monthsData: fyMonthlyFinancials,
      expenses: fyExpenses,
      payments: fyPayments,
      centerInfo
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                Reports & MIS Management System
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Generate and export official multi-sheet Excel (.xlsx) workbooks for batches, fees, and financial statements.
              </p>
            </div>
          </div>
        </div>

        {/* Global Quick Info Pill */}
        <div className="flex items-center gap-2 bg-slate-50 px-3.5 py-1.5 rounded-xl border border-slate-200 text-xs">
          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
          <span className="text-slate-600 font-medium">Real-time Data Sync</span>
          <span className="text-slate-300">•</span>
          <span className="font-mono text-indigo-700 font-bold">{students.length} Students</span>
        </div>
      </div>

      {/* Main Report Navigation Tabs (Professional Polish Pill Style) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-2 shadow-xs flex items-center gap-2 overflow-x-auto">
        <button
          onClick={() => setActiveReportTab('batch-students')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            activeReportTab === 'batch-students'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>1. Batch-wise Student Directory</span>
        </button>

        <button
          onClick={() => setActiveReportTab('batch-dues')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            activeReportTab === 'batch-dues'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <CreditCard className="w-4 h-4" />
          <span>2. Batch-wise Due & Payment Ledger</span>
        </button>

        <button
          onClick={() => setActiveReportTab('fy-finance')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            activeReportTab === 'fy-finance'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>3. FY Financial Statement (Income & Expense)</span>
        </button>
      </div>

      {/* ============================================================= */}
      {/* TAB 1: BATCH-WISE STUDENT DIRECTORY */}
      {/* ============================================================= */}
      {activeReportTab === 'batch-students' && (
        <div className="space-y-6">
          {/* Controls Bar & Filters */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Select Target Batch
                </label>
                <select
                  value={selectedBatchIdForStudents}
                  onChange={(e) => setSelectedBatchIdForStudents(e.target.value)}
                  className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  <option value="all">All Batches (Institute Wide)</option>
                  {batches.map(b => (
                    <option key={b.id} value={b.id}>{b.name} ({b.timing})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Enrollment Status
                </label>
                <select
                  value={studentStatusFilter}
                  onChange={(e) => setStudentStatusFilter(e.target.value as any)}
                  className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  <option value="all">All Statuses</option>
                  <option value="active">Active Enrolled Only</option>
                  <option value="passed_out">Passed Out / Alumni</option>
                </select>
              </div>

              <div className="flex-1 min-w-[180px]">
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Search Student
                </label>
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={studentSearchQuery}
                    onChange={(e) => setStudentSearchQuery(e.target.value)}
                    placeholder="Search by name, roll, mobile..."
                    className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>

            {/* Excel Download Button */}
            <button
              onClick={handleExportStudentsExcel}
              className="w-full md:w-auto flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-sm transition-colors cursor-pointer shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Export Excel Workbook (.xlsx)</span>
            </button>
          </div>

          {/* Quick Metrics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Total Filtered Students</span>
              <p className="text-2xl font-bold text-slate-900 font-mono mt-1">{filteredStudents.length}</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">Active Students</span>
              <p className="text-2xl font-bold text-emerald-700 font-mono mt-1">
                {filteredStudents.filter(s => s.status === 'active').length}
              </p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Target Course / Batch</span>
              <p className="text-sm font-bold text-indigo-900 truncate mt-1">
                {activeBatchObj ? activeBatchObj.name : 'All Center Batches'}
              </p>
            </div>
          </div>

          {/* Tabular View */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center text-xs font-bold text-slate-700">
              <span>Student Roster ({filteredStudents.length} Records)</span>
              <span className="text-slate-400 text-[11px]">Formatted for A4 / Excel Export</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-100/70 text-slate-600 font-bold border-b border-slate-200 text-[11px] uppercase tracking-wider">
                  <tr>
                    <th className="p-3.5">Roll No</th>
                    <th className="p-3.5">Student Name</th>
                    <th className="p-3.5">Batch</th>
                    <th className="p-3.5">Course</th>
                    <th className="p-3.5">Mobile</th>
                    <th className="p-3.5">Aadhaar</th>
                    <th className="p-3.5">Guardian & Phone</th>
                    <th className="p-3.5">Admission Month</th>
                    <th className="p-3.5 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredStudents.map((st) => {
                    const batch = batches.find(b => b.id === st.batchId);
                    const course = courses.find(c => c.id === st.courseId);
                    return (
                      <tr key={st.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-indigo-900 text-xs">
                          {st.rollNo}
                        </td>
                        <td className="p-3.5 font-bold text-slate-900">
                          {st.name}
                        </td>
                        <td className="p-3.5 text-slate-600 font-medium text-xs">
                          {batch?.name || '—'}
                        </td>
                        <td className="p-3.5 text-slate-600 text-xs">
                          {course?.title || '—'}
                        </td>
                        <td className="p-3.5 font-mono text-slate-700 text-xs">
                          {st.mobile}
                        </td>
                        <td className="p-3.5 font-mono text-slate-500 text-xs">
                          {st.aadhaarNo}
                        </td>
                        <td className="p-3.5 text-xs text-slate-600">
                          <div>{st.guardianName}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{st.guardianPhone}</div>
                        </td>
                        <td className="p-3.5 text-xs text-slate-700 font-mono">
                          {formatMonthKey(st.admissionMonth)}
                        </td>
                        <td className="p-3.5 text-right">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            st.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                          }`}>
                            {st.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================= */}
      {/* TAB 2: BATCH-WISE DUES AND PAYMENT LEDGER */}
      {/* ============================================================= */}
      {activeReportTab === 'batch-dues' && (
        <div className="space-y-6">
          {/* Filter Bar */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Select Batch
                </label>
                <select
                  value={selectedBatchIdForDues}
                  onChange={(e) => setSelectedBatchIdForDues(e.target.value)}
                  className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  <option value="all">All Batches (Consolidated)</option>
                  {batches.map(b => (
                    <option key={b.id} value={b.id}>{b.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Due Status Filter
                </label>
                <select
                  value={dueStatusFilter}
                  onChange={(e) => setDueStatusFilter(e.target.value as any)}
                  className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  <option value="all">All Students (Paid + Unpaid)</option>
                  <option value="has_dues">Only Students with Outstanding Dues</option>
                  <option value="cleared">Only Fully Cleared (0 Due)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Calculate Dues Up To Month
                </label>
                <select
                  value={duesBillingMonth}
                  onChange={(e) => setDuesBillingMonth(e.target.value)}
                  className="px-3.5 py-2 rounded-xl border border-indigo-300 text-xs font-bold text-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-indigo-50/50"
                >
                  {['2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09', '2026-10', '2026-11', '2026-12', '2027-01', '2027-02', '2027-03'].map(m => (
                    <option key={m} value={m}>
                      {formatMonthKey(m)} {m === currentCalMonth ? '(Current)' : ''}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Excel Download Button */}
            <button
              onClick={handleExportDuesExcel}
              className="w-full md:w-auto flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-sm transition-colors cursor-pointer shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Export Batch Dues Excel (.xlsx)</span>
            </button>
          </div>

          {/* Dues KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Gross Billed Fees</span>
              <p className="text-2xl font-bold text-slate-900 font-mono mt-1">
                ₹{duesSummaryMetrics.totalPayable.toLocaleString('en-IN')}
              </p>
              <span className="text-[10px] text-slate-400 mt-1 block">Since admission months</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider">Total Realized Fees</span>
              <p className="text-2xl font-bold text-emerald-700 font-mono mt-1">
                ₹{duesSummaryMetrics.totalPaid.toLocaleString('en-IN')}
              </p>
              <span className="text-[10px] text-emerald-600 mt-1 block">
                {duesSummaryMetrics.recoveryRate.toFixed(1)}% Recovery Rate
              </span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider">Pending Student Approvals</span>
              <p className="text-2xl font-bold text-amber-600 font-mono mt-1">
                ₹{duesSummaryMetrics.totalPending.toLocaleString('en-IN')}
              </p>
              <span className="text-[10px] text-slate-400 mt-1 block">UPI & Cash in queue</span>
            </div>

            <div className={`p-5 rounded-2xl border shadow-xs ${
              duesSummaryMetrics.totalDues > 0 ? 'bg-red-50/70 border-red-200' : 'bg-emerald-50/70 border-emerald-200'
            }`}>
              <span className="text-[10px] font-bold uppercase tracking-wider text-red-700">Total Outstanding Dues</span>
              <p className="text-2xl font-bold text-red-600 font-mono mt-1">
                ₹{duesSummaryMetrics.totalDues.toLocaleString('en-IN')}
              </p>
              <span className="text-[10px] text-slate-500 mt-1 block">Unpaid monthly installments</span>
            </div>
          </div>

          {/* Dues Table */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center text-xs font-bold text-slate-700">
              <span>Student Due Breakdown ({filteredDuesStudents.length} Students)</span>
              <span className="text-slate-400 text-[11px]">Official Center UPI: {centerInfo.upiId}</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-100/70 text-slate-600 font-bold border-b border-slate-200 text-[11px] uppercase tracking-wider">
                  <tr>
                    <th className="p-3.5">Roll No</th>
                    <th className="p-3.5">Student Name</th>
                    <th className="p-3.5">Batch</th>
                    <th className="p-3.5 text-right">Total Billed</th>
                    <th className="p-3.5 text-right">Total Paid</th>
                    <th className="p-3.5 text-right">Pending Review</th>
                    <th className="p-3.5 text-right">Net Due Amount</th>
                    <th className="p-3.5">Unpaid Months</th>
                    <th className="p-3.5 text-right">Clearance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredDuesStudents.map((st) => {
                    const billing = studentBillingMap[st.id] || {
                      totalPayableSinceAdmission: 0,
                      totalPaid: 0,
                      totalPendingApproval: 0,
                      totalDueAmount: 0,
                      monthlyStatuses: []
                    };
                    const batch = batches.find(b => b.id === st.batchId);
                    const unpaidList = billing.monthlyStatuses
                      .filter(m => !m.isPaid)
                      .map(m => m.monthLabel);

                    return (
                      <tr key={st.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-indigo-900 text-xs">
                          {st.rollNo}
                        </td>
                        <td className="p-3.5 font-bold text-slate-900">
                          {st.name}
                        </td>
                        <td className="p-3.5 text-slate-600 font-medium text-xs">
                          {batch?.name || '—'}
                        </td>
                        <td className="p-3.5 text-right font-mono font-semibold text-slate-800">
                          ₹{billing.totalPayableSinceAdmission.toLocaleString('en-IN')}
                        </td>
                        <td className="p-3.5 text-right font-mono font-bold text-emerald-700">
                          ₹{billing.totalPaid.toLocaleString('en-IN')}
                        </td>
                        <td className="p-3.5 text-right font-mono text-amber-600">
                          {billing.totalPendingApproval > 0 ? `₹${billing.totalPendingApproval.toLocaleString('en-IN')}` : '—'}
                        </td>
                        <td className="p-3.5 text-right font-mono font-bold text-red-600 text-sm">
                          {billing.totalDueAmount > 0 ? `₹${billing.totalDueAmount.toLocaleString('en-IN')}` : '₹0'}
                        </td>
                        <td className="p-3.5 text-xs">
                          {unpaidList.length > 0 ? (
                            <span className="text-red-700 font-medium">
                              {unpaidList.join(', ')}
                            </span>
                          ) : (
                            <span className="text-emerald-700 font-bold">All Paid</span>
                          )}
                        </td>
                        <td className="p-3.5 text-right">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            billing.totalDueAmount === 0 
                              ? 'bg-emerald-100 text-emerald-800' 
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {billing.totalDueAmount === 0 ? 'CLEARED' : 'PENDING'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================= */}
      {/* TAB 3: FY-WISE FINANCIAL STATEMENT (INCOME / EXPENDITURE / BALANCE) */}
      {/* ============================================================= */}
      {activeReportTab === 'fy-finance' && (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">
                  Select Financial Year (FY)
                </label>
                <select
                  value={selectedFY}
                  onChange={(e) => setSelectedFY(e.target.value)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm font-mono font-bold text-indigo-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  <option value="2026-27">FY 2026-27 (Apr 2026 - Mar 2027)</option>
                  <option value="2025-26">FY 2025-26 (Apr 2025 - Mar 2026)</option>
                  <option value="2024-25">FY 2024-25 (Apr 2024 - Mar 2025)</option>
                </select>
              </div>
            </div>

            {/* Excel Download Button */}
            <button
              onClick={handleExportFYExcel}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-sm transition-colors cursor-pointer shrink-0"
            >
              <Download className="w-4 h-4" />
              <span>Export FY Balance Sheet Excel (.xlsx)</span>
            </button>
          </div>

          {/* FY Financial Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-xs text-emerald-700 font-bold mb-1">
                <span>Total Realized Income</span>
                <ArrowUpRight className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-black text-slate-900 font-mono">
                ₹{fyTotalIncome.toLocaleString('en-IN')}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Approved student fees</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-xs text-red-700 font-bold mb-1">
                <span>Total FY Expenses</span>
                <ArrowDownRight className="w-4 h-4 text-red-600" />
              </div>
              <div className="text-2xl font-black text-red-600 font-mono">
                ₹{fyTotalExpenditure.toLocaleString('en-IN')}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">{fyExpenses.length} operational vouchers</span>
            </div>

            <div className={`p-5 rounded-2xl border shadow-xs ${
              fyNetSurplus >= 0 ? 'bg-indigo-50 border-indigo-200' : 'bg-red-50 border-red-200'
            }`}>
              <div className="flex items-center justify-between text-xs font-bold text-indigo-900 mb-1">
                <span>Net Financial Surplus</span>
                <span className="font-mono">{fyNetSurplus >= 0 ? 'Surplus' : 'Deficit'}</span>
              </div>
              <div className="text-2xl font-black font-mono text-indigo-950">
                ₹{fyNetSurplus.toLocaleString('en-IN')}
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">Income minus expenditure</span>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between text-xs text-slate-500 font-bold mb-1">
                <span>Operating Margin</span>
                <Percent className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-2xl font-black text-indigo-600 font-mono">
                {fyOperatingMargin.toFixed(1)}%
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Financial health ratio</span>
            </div>
          </div>

          {/* Month-by-Month Statement */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center text-xs font-bold text-slate-700">
              <span>Financial Year {selectedFY} &bull; Monthly Income, Expenditure & Cumulative Balance</span>
              <span className="text-slate-400 text-[11px]">Audit Ready Ledger</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-100/70 text-slate-600 font-bold border-b border-slate-200 text-[11px] uppercase tracking-wider">
                  <tr>
                    <th className="p-3.5">Month</th>
                    <th className="p-3.5 text-right">Fee Collections (₹)</th>
                    <th className="p-3.5 text-center">Receipts (#)</th>
                    <th className="p-3.5 text-right">Center Expenses (₹)</th>
                    <th className="p-3.5 text-center">Vouchers (#)</th>
                    <th className="p-3.5 text-right">Monthly Net (₹)</th>
                    <th className="p-3.5 text-right">Cumulative Balance (₹)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {fyMonthlyFinancials.map((m) => (
                    <tr key={m.monthKey} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3.5 font-bold text-slate-900">
                        {m.monthName}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-emerald-700">
                        ₹{m.grossIncome.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-center font-mono text-xs text-slate-500">
                        {m.approvedReceiptsCount}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-red-600">
                        ₹{m.grossExpenditure.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3.5 text-center font-mono text-xs text-slate-500">
                        {m.expenseVouchersCount}
                      </td>
                      <td className={`p-3.5 text-right font-mono font-bold ${
                        m.netSurplus >= 0 ? 'text-indigo-900' : 'text-red-600'
                      }`}>
                        {m.netSurplus >= 0 ? `+₹${m.netSurplus.toLocaleString('en-IN')}` : `-₹${Math.abs(m.netSurplus).toLocaleString('en-IN')}`}
                      </td>
                      <td className={`p-3.5 text-right font-mono font-bold ${
                        m.cumulativeBalance >= 0 ? 'text-slate-900' : 'text-red-600'
                      }`}>
                        ₹{m.cumulativeBalance.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  ))}
                  {/* Total Row */}
                  <tr className="bg-slate-50 font-bold border-t-2 border-slate-300">
                    <td className="p-3.5 text-slate-900 uppercase">
                      FY {selectedFY} TOTAL
                    </td>
                    <td className="p-3.5 text-right font-mono text-emerald-800 font-black">
                      ₹{fyTotalIncome.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3.5 text-center font-mono text-slate-600">
                      {fyMonthlyFinancials.reduce((s, m) => s + m.approvedReceiptsCount, 0)}
                    </td>
                    <td className="p-3.5 text-right font-mono text-red-700 font-black">
                      ₹{fyTotalExpenditure.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3.5 text-center font-mono text-slate-600">
                      {fyMonthlyFinancials.reduce((s, m) => s + m.expenseVouchersCount, 0)}
                    </td>
                    <td className="p-3.5 text-right font-mono font-black text-indigo-950">
                      ₹{fyNetSurplus.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3.5 text-right font-mono font-black text-indigo-950">
                      ₹{fyNetSurplus.toLocaleString('en-IN')}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
