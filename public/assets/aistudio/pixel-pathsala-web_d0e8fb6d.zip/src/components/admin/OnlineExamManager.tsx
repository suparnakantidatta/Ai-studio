import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { ExamQuestion, OnlineExam } from '../../types';
import { ACADEMIC_CLASSES } from '../../utils/imageHelper';
import { 
  FileQuestion, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  Plus, 
  Trash2, 
  Edit3, 
  Eye, 
  Search, 
  Filter, 
  Award, 
  BookOpen, 
  GraduationCap, 
  Layers, 
  Code2, 
  HelpCircle, 
  Check, 
  Sparkles, 
  AlertCircle,
  ToggleLeft,
  ToggleRight,
  TrendingUp,
  BarChart3,
  UserCheck
} from 'lucide-react';

export const OnlineExamManager: React.FC = () => {
  const { 
    exams, 
    addExam, 
    updateExam, 
    deleteExam, 
    toggleExamPublish, 
    setExamStatus, 
    questions, 
    addQuestion, 
    updateQuestion, 
    deleteQuestion, 
    bulkAddQuestions,
    courses, 
    batches, 
    students,
    examSubmissions,
    deleteExamSubmission
  } = useApp();

  // Top sub-tab in exam manager: 'exams' | 'questions' | 'submissions'
  const [activeSection, setActiveSection] = useState<'exams' | 'questions' | 'submissions'>('exams');

  // Filters
  const [selectedCourseFilter, setSelectedCourseFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Exam Modal State
  const [showExamModal, setShowExamModal] = useState(false);
  const [editingExamId, setEditingExamId] = useState<string | null>(null);
  const [examTitle, setExamTitle] = useState('');
  const [examCode, setExamCode] = useState('');
  const [examCourseId, setExamCourseId] = useState(courses[0]?.id || '');
  const [examBatchId, setExamBatchId] = useState('all');
  const [examClass, setExamClass] = useState('Class 10 (Secondary)');
  const [examSubject, setExamSubject] = useState('Computer Applications');
  const [examDuration, setExamDuration] = useState(30); // minutes
  const [examTotalMarks, setExamTotalMarks] = useState(25);
  const [examPassingMarks, setExamPassingMarks] = useState(10);
  const [examScheduleDate, setExamScheduleDate] = useState(new Date().toISOString().split('T')[0]);
  const [examStartTime, setExamStartTime] = useState('10:00 AM');
  const [examEndTime, setExamEndTime] = useState('08:00 PM');
  const [examInstructions, setExamInstructions] = useState('Read each question carefully. No negative marking for wrong answers. Submit within the allotted time.');
  const [selectedQuestionIds, setSelectedQuestionIds] = useState<string[]>([]);
  const [isPublished, setIsPublished] = useState(true);

  // Question Modal State
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [editingQuestionId, setEditingQuestionId] = useState<string | null>(null);
  const [qCourseId, setQCourseId] = useState(courses[0]?.id || '');
  const [qSubject, setQSubject] = useState('Programming & Problem Solving');
  const [qTopic, setQTopic] = useState('Core Concepts');
  const [qDifficulty, setQDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');
  const [qText, setQText] = useState('');
  const [qCodeSnippet, setQCodeSnippet] = useState('');
  const [qOptions, setQOptions] = useState<string[]>(['', '', '', '']);
  const [qCorrectIndex, setQCorrectIndex] = useState(0);
  const [qMarks, setQMarks] = useState(2);
  const [qExplanation, setQExplanation] = useState('');

  // Detailed submission view modal
  const [viewSubmissionId, setViewSubmissionId] = useState<string | null>(null);

  // Filtered Questions
  const filteredQuestions = useMemo(() => {
    return questions.filter(q => {
      const matchCourse = selectedCourseFilter === 'all' || q.courseId === selectedCourseFilter || q.courseId === 'all';
      const matchSearch = searchQuery.trim() === '' || 
        q.questionText.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
        q.subject.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCourse && matchSearch;
    });
  }, [questions, selectedCourseFilter, searchQuery]);

  // Filtered Exams
  const filteredExams = useMemo(() => {
    return exams.filter(e => {
      const matchCourse = selectedCourseFilter === 'all' || e.courseId === selectedCourseFilter || e.courseId === 'all';
      const matchSearch = searchQuery.trim() === '' || 
        e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.examCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.subject.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCourse && matchSearch;
    });
  }, [exams, selectedCourseFilter, searchQuery]);

  // Handle open add exam
  const handleOpenAddExam = () => {
    setEditingExamId(null);
    setExamTitle('');
    const randomCode = `EXAM-${Math.floor(100 + Math.random() * 900)}`;
    setExamCode(randomCode);
    const defaultCourseId = courses[0]?.id || '';
    setExamCourseId(defaultCourseId);
    setExamBatchId('all');
    setExamClass('Class 10 (Secondary)');
    setExamSubject('Computer Science / Coding');
    setExamDuration(30);
    setExamTotalMarks(20);
    setExamPassingMarks(8);
    setExamScheduleDate(new Date().toISOString().split('T')[0]);
    setExamStartTime('09:00 AM');
    setExamEndTime('09:00 PM');
    setExamInstructions('Read each question carefully. You may navigate between questions. Click Submit Exam when finished.');
    
    // Auto-select questions matching the course
    const courseQuestions = questions.filter(q => q.courseId === defaultCourseId || q.courseId === 'all');
    setSelectedQuestionIds(courseQuestions.slice(0, 10).map(q => q.id));
    setIsPublished(true);
    setShowExamModal(true);
  };

  // Handle open edit exam
  const handleOpenEditExam = (exam: OnlineExam) => {
    setEditingExamId(exam.id);
    setExamTitle(exam.title);
    setExamCode(exam.examCode);
    setExamCourseId(exam.courseId);
    setExamBatchId(exam.batchId);
    setExamClass(exam.academicClass || 'Class 10 (Secondary)');
    setExamSubject(exam.subject);
    setExamDuration(exam.durationMinutes);
    setExamTotalMarks(exam.totalMarks);
    setExamPassingMarks(exam.passingMarks);
    setExamScheduleDate(exam.scheduledDate);
    setExamStartTime(exam.startTime);
    setExamEndTime(exam.endTime);
    setExamInstructions(exam.instructions || '');
    setSelectedQuestionIds(exam.questionIds);
    setIsPublished(exam.isPublished);
    setShowExamModal(true);
  };

  // Save exam
  const handleSaveExam = (e: React.FormEvent) => {
    e.preventDefault();
    if (!examTitle.trim() || selectedQuestionIds.length === 0) {
      alert('Please enter an exam title and select at least one question.');
      return;
    }

    const payload = {
      title: examTitle.trim(),
      examCode: examCode.trim(),
      courseId: examCourseId,
      batchId: examBatchId,
      academicClass: examClass,
      subject: examSubject.trim(),
      durationMinutes: Number(examDuration),
      totalMarks: Number(examTotalMarks),
      passingMarks: Number(examPassingMarks),
      scheduledDate: examScheduleDate,
      startTime: examStartTime.trim(),
      endTime: examEndTime.trim(),
      instructions: examInstructions.trim(),
      questionIds: selectedQuestionIds,
      isPublished,
      status: 'active' as const
    };

    if (editingExamId) {
      updateExam(editingExamId, payload);
    } else {
      addExam(payload);
    }

    setShowExamModal(false);
  };

  // Handle open add question
  const handleOpenAddQuestion = () => {
    setEditingQuestionId(null);
    setQCourseId(courses[0]?.id || 'all');
    setQSubject('Programming & Logic');
    setQTopic('Fundamentals');
    setQDifficulty('medium');
    setQText('');
    setQCodeSnippet('');
    setQOptions(['', '', '', '']);
    setQCorrectIndex(0);
    setQMarks(2);
    setQExplanation('');
    setShowQuestionModal(true);
  };

  // Handle open edit question
  const handleOpenEditQuestion = (q: ExamQuestion) => {
    setEditingQuestionId(q.id);
    setQCourseId(q.courseId);
    setQSubject(q.subject);
    setQTopic(q.topic);
    setQDifficulty(q.difficulty);
    setQText(q.questionText);
    setQCodeSnippet(q.codeSnippet || '');
    setQOptions(q.options);
    setQCorrectIndex(q.correctOptionIndex);
    setQMarks(q.marks);
    setQExplanation(q.explanation || '');
    setShowQuestionModal(true);
  };

  // Save question
  const handleSaveQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!qText.trim() || qOptions.some(opt => !opt.trim())) {
      alert('Please fill the question text and all 4 options.');
      return;
    }

    const payload = {
      courseId: qCourseId,
      subject: qSubject.trim(),
      topic: qTopic.trim(),
      difficulty: qDifficulty,
      questionText: qText.trim(),
      codeSnippet: qCodeSnippet.trim() || undefined,
      options: qOptions.map(o => o.trim()),
      correctOptionIndex: qCorrectIndex,
      marks: Number(qMarks),
      explanation: qExplanation.trim() || undefined
    };

    if (editingQuestionId) {
      updateQuestion(editingQuestionId, payload);
    } else {
      addQuestion(payload);
    }

    setShowQuestionModal(false);
  };

  // Toggle question in exam builder
  const handleToggleQuestionSelection = (qid: string) => {
    setSelectedQuestionIds(prev => 
      prev.includes(qid) ? prev.filter(id => id !== qid) : [...prev, qid]
    );
  };

  // Auto calculate total marks for exam based on selected questions
  const calculatedExamMarks = useMemo(() => {
    return selectedQuestionIds.reduce((sum, qid) => {
      const q = questions.find(item => item.id === qid);
      return sum + (q ? q.marks : 2);
    }, 0);
  }, [selectedQuestionIds, questions]);

  const selectedSubmission = examSubmissions.find(s => s.id === viewSubmissionId);
  const selectedSubmissionExam = selectedSubmission ? exams.find(e => e.id === selectedSubmission.examId) : null;
  const selectedSubmissionStudent = selectedSubmission ? students.find(s => s.id === selectedSubmission.studentId) : null;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <FileQuestion className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-xl font-black text-slate-900">
                Online Exams & Course-Wise Question Bank
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Schedule course-specific online MCQ tests, author questions with code snippets, and review student scorecards.
              </p>
            </div>
          </div>
        </div>

        {/* Action buttons based on active tab */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {activeSection === 'exams' && (
            <button
              id="btn-schedule-exam"
              onClick={handleOpenAddExam}
              className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Schedule New Exam</span>
            </button>
          )}

          {activeSection === 'questions' && (
            <button
              id="btn-add-question"
              onClick={handleOpenAddQuestion}
              className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add MCQ Question</span>
            </button>
          )}
        </div>
      </div>

      {/* Nav Sub-Tabs */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-200 pb-3">
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl">
          <button
            onClick={() => setActiveSection('exams')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSection === 'exams'
                ? 'bg-white text-indigo-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Scheduled Exams ({exams.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('questions')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSection === 'questions'
                ? 'bg-white text-indigo-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Question Bank ({questions.length})</span>
          </button>

          <button
            onClick={() => setActiveSection('submissions')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              activeSection === 'submissions'
                ? 'bg-white text-indigo-600 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>Student Submissions ({examSubmissions.length})</span>
          </button>
        </div>

        {/* Course Filter Dropdown & Search */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-56">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, subject..."
              className="w-full pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <select
            value={selectedCourseFilter}
            onChange={(e) => setSelectedCourseFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-slate-200 bg-white text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="all">All Courses</option>
            {courses.map(c => (
              <option key={c.id} value={c.id}>{c.title}</option>
            ))}
          </select>
        </div>
      </div>

      {/* SECTION 1: SCHEDULED EXAMS */}
      {activeSection === 'exams' && (
        <div className="space-y-4">
          {filteredExams.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
              <FileQuestion className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="font-bold text-slate-700">No scheduled exams found</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Create and schedule a new course-wise online test with questions from the bank.
              </p>
              <button
                onClick={handleOpenAddExam}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                + Schedule First Exam
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredExams.map((exam) => {
                const course = courses.find(c => c.id === exam.courseId);
                const batch = batches.find(b => b.id === exam.batchId);
                const submissionCount = examSubmissions.filter(s => s.examId === exam.id).length;

                return (
                  <div
                    key={exam.id}
                    className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition flex flex-col justify-between"
                  >
                    <div>
                      {/* Top Badges */}
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 truncate max-w-[180px]">
                          {course?.title || 'All Courses'}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => toggleExamPublish(exam.id)}
                            title={exam.isPublished ? 'Published to Students' : 'Draft / Unpublished'}
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer transition ${
                              exam.isPublished
                                ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                            }`}
                          >
                            {exam.isPublished ? 'Published' : 'Draft'}
                          </button>
                          
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            exam.status === 'active' ? 'bg-blue-100 text-blue-800' : 'bg-amber-100 text-amber-800'
                          }`}>
                            {exam.status}
                          </span>
                        </div>
                      </div>

                      {/* Exam Title & Subject */}
                      <h3 className="font-extrabold text-slate-900 text-base mb-1">
                        {exam.title}
                      </h3>
                      <div className="flex items-center gap-2 text-xs text-indigo-600 font-medium mb-3">
                        <span>Code: <strong className="font-mono text-slate-800">{exam.examCode}</strong></span>
                        <span>•</span>
                        <span>{exam.subject}</span>
                      </div>

                      {/* Details Box */}
                      <div className="space-y-2 bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-xs text-slate-700 mb-4">
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-slate-500">
                            <GraduationCap className="w-3.5 h-3.5 text-indigo-500" />
                            <span>Target:</span>
                          </span>
                          <span className="font-bold text-slate-800">
                            {exam.academicClass || 'All Standards'}
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-slate-500">
                            <Clock className="w-3.5 h-3.5 text-indigo-500" />
                            <span>Duration:</span>
                          </span>
                          <span className="font-bold text-slate-800 font-mono">
                            {exam.durationMinutes} Minutes
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-slate-500">
                            <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                            <span>Date & Window:</span>
                          </span>
                          <span className="font-semibold text-slate-800 text-[11px]">
                            {exam.scheduledDate} ({exam.startTime})
                          </span>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                          <span className="text-slate-500">Questions & Marks:</span>
                          <span className="font-bold text-indigo-900 font-mono">
                            {exam.questionIds.length} Qs • {exam.totalMarks} Marks (Pass: {exam.passingMarks})
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom stats and action buttons */}
                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
                        <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{submissionCount} Submissions</span>
                      </span>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleOpenEditExam(exam)}
                          className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Delete exam "${exam.title}"?`)) {
                              deleteExam(exam.id);
                            }
                          }}
                          className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer text-xs font-semibold flex items-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: COURSE-WISE QUESTION BANK */}
      {activeSection === 'questions' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500 px-1">
            <span>Showing <strong>{filteredQuestions.length}</strong> questions in question bank</span>
            <span className="text-slate-400">Questions are categorized by Course and Subject</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredQuestions.map((q, idx) => {
              const course = courses.find(c => c.id === q.courseId);

              return (
                <div
                  key={q.id}
                  className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs hover:border-indigo-300 transition space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold text-xs font-mono">
                        {idx + 1}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                        {course?.title || 'General / All'}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        q.difficulty === 'easy' ? 'bg-emerald-50 text-emerald-700' :
                        q.difficulty === 'hard' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'
                      }`}>
                        {q.difficulty}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold font-mono text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md">
                        {q.marks} Marks
                      </span>
                      <button
                        onClick={() => handleOpenEditQuestion(q)}
                        className="p-1 text-slate-400 hover:text-indigo-600 transition cursor-pointer"
                        title="Edit question"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('Delete this question from question bank?')) {
                            deleteQuestion(q.id);
                          }
                        }}
                        className="p-1 text-slate-400 hover:text-rose-600 transition cursor-pointer"
                        title="Delete question"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Question Text */}
                  <h4 className="font-bold text-slate-900 text-sm leading-snug">
                    {q.questionText}
                  </h4>

                  {/* Code snippet preview if present */}
                  {q.codeSnippet && (
                    <div className="bg-slate-900 text-slate-200 p-3 rounded-xl font-mono text-xs overflow-x-auto border border-slate-800">
                      <pre>{q.codeSnippet}</pre>
                    </div>
                  )}

                  {/* 4 Options Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {q.options.map((opt, oIdx) => {
                      const isCorrect = oIdx === q.correctOptionIndex;
                      const optLabel = String.fromCharCode(65 + oIdx);

                      return (
                        <div
                          key={oIdx}
                          className={`p-2.5 rounded-xl border text-xs flex items-start gap-2 ${
                            isCorrect
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-semibold'
                              : 'bg-slate-50 border-slate-200 text-slate-700'
                          }`}
                        >
                          <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 ${
                            isCorrect ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                          }`}>
                            {optLabel}
                          </span>
                          <span className="leading-tight">{opt}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Explanation if present */}
                  {q.explanation && (
                    <div className="text-[11px] text-slate-500 bg-amber-50/50 p-2.5 rounded-xl border border-amber-200/60 flex items-start gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                      <span><strong>Key:</strong> {q.explanation}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SECTION 3: STUDENT SUBMISSIONS & SCORECARDS */}
      {activeSection === 'submissions' && (
        <div className="space-y-4">
          {examSubmissions.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
              <Award className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="font-bold text-slate-700">No test attempts submitted yet</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                When students take published exams through their portal, their scores, percentage, and detailed answers will appear here.
              </p>
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-700">
                  <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                    <tr>
                      <th className="px-5 py-3">Student Name & Roll</th>
                      <th className="px-4 py-3">Exam Title</th>
                      <th className="px-4 py-3">Date & Time</th>
                      <th className="px-4 py-3 text-center">Score / Total</th>
                      <th className="px-4 py-3 text-center">Percentage</th>
                      <th className="px-4 py-3 text-center">Result</th>
                      <th className="px-5 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {examSubmissions.map((sub) => {
                      const exam = exams.find(e => e.id === sub.examId);
                      const student = students.find(s => s.id === sub.studentId);

                      return (
                        <tr key={sub.id} className="hover:bg-slate-50/80 transition">
                          <td className="px-5 py-3.5">
                            <div className="font-bold text-slate-900">{sub.studentName}</div>
                            <div className="text-[11px] text-slate-400 font-mono">Roll: {sub.studentRollNo || student?.rollNo}</div>
                          </td>
                          <td className="px-4 py-3.5">
                            <div className="font-semibold text-slate-800">{sub.examTitle}</div>
                            <div className="text-[10px] text-indigo-600 font-mono">{exam?.examCode}</div>
                          </td>
                          <td className="px-4 py-3.5 text-slate-500 text-[11px]">
                            <div>{sub.submittedAt.split('T')[0]}</div>
                            <div className="text-[10px] text-slate-400">Duration: {Math.floor(sub.timeSpentSeconds / 60)}m {sub.timeSpentSeconds % 60}s</div>
                          </td>
                          <td className="px-4 py-3.5 text-center font-mono font-bold text-slate-900">
                            {sub.score} / {sub.totalMarks}
                          </td>
                          <td className="px-4 py-3.5 text-center font-bold">
                            <span className={`px-2 py-0.5 rounded-full text-[11px] font-mono ${
                              sub.percentage >= 75 ? 'bg-emerald-100 text-emerald-800' :
                              sub.percentage >= 40 ? 'bg-blue-100 text-blue-800' : 'bg-rose-100 text-rose-800'
                            }`}>
                              {sub.percentage}%
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-center">
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase ${
                              sub.passed ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' : 'bg-rose-100 text-rose-800 border border-rose-200'
                            }`}>
                              {sub.passed ? 'Passed ✓' : 'Failed ✕'}
                            </span>
                          </td>
                          <td className="px-5 py-3.5 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => setViewSubmissionId(sub.id)}
                                className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-xs transition cursor-pointer flex items-center gap-1"
                              >
                                <Eye className="w-3.5 h-3.5" />
                                <span>Review</span>
                              </button>
                              <button
                                onClick={() => {
                                  if (confirm('Delete this student submission attempt?')) {
                                    deleteExamSubmission(sub.id);
                                  }
                                }}
                                className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                title="Delete submission"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SCHEDULE / EDIT EXAM MODAL */}
      {showExamModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto animate-fadeIn">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Test Scheduler & Exam Engine
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {editingExamId ? 'Edit Scheduled Exam' : 'Schedule New Online Test'}
                </h3>
              </div>
              <button
                onClick={() => setShowExamModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveExam} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Exam Title <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={examTitle}
                    onChange={(e) => setExamTitle(e.target.value)}
                    placeholder="e.g. Python Core & OOP Term Test"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Exam Code / Ref <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={examCode}
                    onChange={(e) => setExamCode(e.target.value)}
                    placeholder="e.g. EXAM-PY-101"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                  />
                </div>
              </div>

              {/* Course & Class Selection */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Course Target <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={examCourseId}
                    onChange={(e) => {
                      const cid = e.target.value;
                      setExamCourseId(cid);
                      // suggest auto questions for this course
                      const qMatch = questions.filter(q => q.courseId === cid || q.courseId === 'all');
                      if (qMatch.length > 0) {
                        setSelectedQuestionIds(qMatch.map(q => q.id));
                      }
                    }}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold bg-white"
                  >
                    {courses.map(c => (
                      <option key={c.id} value={c.id}>{c.title} ({c.academicClass})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Academic Class / Standard
                  </label>
                  <select
                    value={examClass}
                    onChange={(e) => setExamClass(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold bg-white"
                  >
                    {ACADEMIC_CLASSES.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Subject Name
                  </label>
                  <input
                    type="text"
                    required
                    value={examSubject}
                    onChange={(e) => setExamSubject(e.target.value)}
                    placeholder="e.g. C Programming"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Duration (Minutes)
                  </label>
                  <input
                    type="number"
                    min={5}
                    max={180}
                    value={examDuration}
                    onChange={(e) => setExamDuration(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Passing Marks
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={examPassingMarks}
                    onChange={(e) => setExamPassingMarks(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Scheduled Date
                  </label>
                  <input
                    type="date"
                    required
                    value={examScheduleDate}
                    onChange={(e) => setExamScheduleDate(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Start Window
                  </label>
                  <input
                    type="text"
                    value={examStartTime}
                    onChange={(e) => setExamStartTime(e.target.value)}
                    placeholder="09:00 AM"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    End Window
                  </label>
                  <input
                    type="text"
                    value={examEndTime}
                    onChange={(e) => setExamEndTime(e.target.value)}
                    placeholder="09:00 PM"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>
              </div>

              {/* Question Selection for Exam */}
              <div className="pt-2">
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center gap-1">
                    <span>Select Questions from Bank ({selectedQuestionIds.length} Selected)</span>
                    <span className="text-indigo-600 font-mono">[{calculatedExamMarks} Total Marks]</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      const allIds = questions.map(q => q.id);
                      setSelectedQuestionIds(selectedQuestionIds.length === allIds.length ? [] : allIds);
                    }}
                    className="text-xs font-bold text-indigo-600 hover:underline cursor-pointer"
                  >
                    {selectedQuestionIds.length === questions.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="max-h-48 overflow-y-auto border border-slate-200 rounded-2xl p-3 space-y-2 bg-slate-50">
                  {questions.map((q) => {
                    const isChecked = selectedQuestionIds.includes(q.id);
                    return (
                      <label
                        key={q.id}
                        className={`flex items-start gap-2.5 p-2 rounded-xl border text-xs cursor-pointer transition ${
                          isChecked
                            ? 'bg-indigo-50 border-indigo-300 text-indigo-950 font-medium'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleQuestionSelection(q.id)}
                          className="rounded text-indigo-600 mt-0.5 w-4 h-4"
                        />
                        <div className="flex-1">
                          <p className="line-clamp-2">{q.questionText}</p>
                          <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                            <span>{q.subject}</span>
                            <span>•</span>
                            <span className="font-mono text-indigo-600 font-bold">{q.marks} Marks</span>
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Exam Instructions
                </label>
                <textarea
                  rows={2}
                  value={examInstructions}
                  onChange={(e) => setExamInstructions(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <label className="flex items-center gap-2 text-xs font-bold text-slate-800 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={isPublished}
                  onChange={(e) => setIsPublished(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                />
                <span>Publish to Student Portal Immediately</span>
              </label>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowExamModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer"
                >
                  {editingExamId ? 'Save Changes' : 'Create & Schedule Exam'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CREATE / EDIT QUESTION MODAL */}
      {showQuestionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto animate-fadeIn">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Course Question Authoring
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  {editingQuestionId ? 'Edit MCQ Question' : 'Add New MCQ Question'}
                </h3>
              </div>
              <button
                onClick={() => setShowQuestionModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveQuestion} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Course Map <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={qCourseId}
                    onChange={(e) => setQCourseId(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold bg-white"
                  >
                    <option value="all">All / Common</option>
                    {courses.map(c => (
                      <option key={c.id} value={c.id}>{c.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Subject / Module
                  </label>
                  <input
                    type="text"
                    required
                    value={qSubject}
                    onChange={(e) => setQSubject(e.target.value)}
                    placeholder="e.g. Python Basics"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Difficulty Level
                  </label>
                  <select
                    value={qDifficulty}
                    onChange={(e) => setQDifficulty(e.target.value as any)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-semibold bg-white"
                  >
                    <option value="easy">Easy</option>
                    <option value="medium">Medium</option>
                    <option value="hard">Hard / Advanced</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Question Text <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={2}
                  required
                  value={qText}
                  onChange={(e) => setQText(e.target.value)}
                  placeholder="e.g. What is the output of the following C program snippet?"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1 flex items-center justify-between">
                  <span>Code Snippet (Optional)</span>
                  <span className="text-[10px] text-slate-400 font-mono">Supports C, Python, SQL, JS</span>
                </label>
                <textarea
                  rows={3}
                  value={qCodeSnippet}
                  onChange={(e) => setQCodeSnippet(e.target.value)}
                  placeholder="int a = 10;\nprintf('%d', a++);"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-800 bg-slate-900 text-emerald-400 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* 4 Options Input with Correct Radio */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                  4 Options & Correct Answer Radio <span className="text-red-500">*</span>
                </label>

                {qOptions.map((opt, idx) => {
                  const optLabel = String.fromCharCode(65 + idx);
                  const isCorrect = qCorrectIndex === idx;

                  return (
                    <div
                      key={idx}
                      className={`flex items-center gap-2.5 p-2 rounded-xl border transition ${
                        isCorrect ? 'bg-emerald-50 border-emerald-300' : 'bg-white border-slate-200'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => setQCorrectIndex(idx)}
                        className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs shrink-0 cursor-pointer transition ${
                          isCorrect ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                        }`}
                        title="Click to set as correct answer"
                      >
                        {optLabel}
                      </button>

                      <input
                        type="text"
                        required
                        value={opt}
                        onChange={(e) => {
                          const newOpts = [...qOptions];
                          newOpts[idx] = e.target.value;
                          setQOptions(newOpts);
                        }}
                        placeholder={`Option ${optLabel} text...`}
                        className="w-full px-3 py-1.5 rounded-lg border border-slate-200 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />

                      <button
                        type="button"
                        onClick={() => setQCorrectIndex(idx)}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold cursor-pointer transition shrink-0 ${
                          isCorrect
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {isCorrect ? 'Correct ✓' : 'Mark Correct'}
                      </button>
                    </div>
                  );
                })}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Question Marks
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={qMarks}
                    onChange={(e) => setQMarks(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                    Topic / Tag
                  </label>
                  <input
                    type="text"
                    value={qTopic}
                    onChange={(e) => setQTopic(e.target.value)}
                    placeholder="e.g. Loops & Memory"
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Explanation / Solution Note (Shown during review)
                </label>
                <textarea
                  rows={2}
                  value={qExplanation}
                  onChange={(e) => setQExplanation(e.target.value)}
                  placeholder="Explain why the chosen option is correct..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowQuestionModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer"
                >
                  {editingQuestionId ? 'Save Question' : 'Add to Question Bank'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* REVIEW STUDENT SUBMISSION SCORECARD MODAL */}
      {selectedSubmission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto animate-fadeIn space-y-6">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Student Examination Scorecard
                </span>
                <h3 className="text-2xl font-black text-slate-900 mt-0.5">
                  {selectedSubmission.studentName}
                </h3>
                <p className="text-xs text-slate-500">
                  Exam: <strong>{selectedSubmission.examTitle}</strong> • Submitted: {new Date(selectedSubmission.submittedAt).toLocaleString('en-IN')}
                </p>
              </div>
              <button
                onClick={() => setViewSubmissionId(null)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Scorecard Hero Banner */}
            <div className={`p-6 rounded-2xl border text-center flex flex-col sm:flex-row items-center justify-around gap-4 ${
              selectedSubmission.passed
                ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                : 'bg-rose-50 border-rose-200 text-rose-950'
            }`}>
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-600">Marks Scored</div>
                <div className="text-4xl font-black font-mono mt-1">
                  {selectedSubmission.score} <span className="text-lg font-normal text-slate-500">/ {selectedSubmission.totalMarks}</span>
                </div>
              </div>

              <div className="h-10 w-[1px] bg-slate-300 hidden sm:block"></div>

              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-600">Percentage</div>
                <div className="text-4xl font-black font-mono mt-1 text-indigo-600">
                  {selectedSubmission.percentage}%
                </div>
              </div>

              <div className="h-10 w-[1px] bg-slate-300 hidden sm:block"></div>

              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-600">Exam Outcome</div>
                <div className={`text-xl font-black mt-1 uppercase ${selectedSubmission.passed ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {selectedSubmission.passed ? '✓ PASSED' : '✕ FAILED'}
                </div>
              </div>
            </div>

            {/* Question by question analysis */}
            <div className="space-y-4 pt-2">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileQuestion className="w-4 h-4 text-indigo-600" />
                <span>Question Responses & Correct Keys</span>
              </h4>

              <div className="space-y-3">
                {selectedSubmission.questionBreakdown.map((item, idx) => {
                  const q = questions.find(question => question.id === item.questionId);
                  if (!q) return null;

                  const isCorrect = item.isCorrect;
                  const studentChoice = item.selectedOptionIndex !== null ? String.fromCharCode(65 + item.selectedOptionIndex) : 'Not Answered';
                  const correctChoice = String.fromCharCode(65 + item.correctOptionIndex);

                  return (
                    <div
                      key={item.questionId}
                      className={`p-4 rounded-2xl border space-y-2.5 ${
                        isCorrect
                          ? 'bg-emerald-50/40 border-emerald-200'
                          : 'bg-rose-50/40 border-rose-200'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs ${
                            isCorrect ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
                          }`}>
                            {idx + 1}
                          </span>
                          <h5 className="font-bold text-slate-900 text-xs sm:text-sm">
                            {q.questionText}
                          </h5>
                        </div>

                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                          isCorrect ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {isCorrect ? `+${item.marks} Marks` : '0 Marks'}
                        </span>
                      </div>

                      {q.codeSnippet && (
                        <div className="bg-slate-900 text-slate-200 p-2.5 rounded-xl font-mono text-xs overflow-x-auto">
                          <pre>{q.codeSnippet}</pre>
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div className={`p-2 rounded-xl border flex items-center justify-between ${
                          isCorrect ? 'bg-emerald-100/70 border-emerald-300 text-emerald-900 font-bold' : 'bg-rose-100/70 border-rose-300 text-rose-900 font-semibold'
                        }`}>
                          <span>Student's Choice:</span>
                          <span>Option {studentChoice}</span>
                        </div>

                        <div className="p-2 rounded-xl border bg-emerald-100/70 border-emerald-300 text-emerald-900 font-bold flex items-center justify-between">
                          <span>Correct Answer Key:</span>
                          <span>Option {correctChoice} ({q.options[item.correctOptionIndex]})</span>
                        </div>
                      </div>

                      {q.explanation && (
                        <div className="text-[11px] text-slate-600 bg-white/80 p-2.5 rounded-xl border border-slate-200">
                          <strong>Explanation:</strong> {q.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-100">
              <button
                onClick={() => setViewSubmissionId(null)}
                className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                Close Scorecard
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
