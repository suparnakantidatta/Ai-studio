import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { LiveClassSession, ClassRecording, VideoSourceType } from '../../types';
import { getStudentActualClass, isRecordingForStudent } from '../../utils/classCourseMatcher';
import { 
  Radio, 
  Play, 
  Calendar, 
  Clock, 
  Users, 
  BookOpen, 
  Layers, 
  ExternalLink, 
  Search, 
  Filter, 
  FileText, 
  Sparkles, 
  CheckCircle2, 
  PlayCircle, 
  Film, 
  Youtube, 
  GraduationCap, 
  Download, 
  Eye, 
  Tv,
  Share2,
  Copy,
  Check,
  Video,
  AlertTriangle,
  Building2,
  LogOut
} from 'lucide-react';

export const StudentLiveClassPortal: React.FC = () => {
  const { 
    currentStudent, 
    logoutStudent,
    setActiveTab,
    liveClasses, 
    classRecordings, 
    incrementRecordingViews, 
    courses, 
    batches,
    educators = []
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'live' | 'recordings'>('live');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [activeVideo, setActiveVideo] = useState<ClassRecording | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Resolution helper to resolve educator names cleanly
  const getResolvedEducatorName = (session: LiveClassSession | any): string => {
    if (session.educatorId) {
      const matchedEdu = educators.find(e => e.id === session.educatorId);
      if (matchedEdu) return matchedEdu.name;
    }
    let raw = (session.educatorName || '').trim();
    const eduById = educators.find(e => e.id === raw);
    if (eduById) return eduById.name;
    const eduByName = educators.find(e => e.name.toLowerCase() === raw.toLowerCase());
    if (eduByName) return eduByName.name;

    const isBatchId = raw.startsWith('batch-') || batches.some(b => b.id === raw);
    if (!raw || raw.toLowerCase() === 'all' || raw.toLowerCase() === 'faculty' || isBatchId) {
      const targetBatchId = isBatchId ? raw : session.batchId;
      if (targetBatchId && targetBatchId !== 'all') {
        const batch = batches.find(b => b.id === targetBatchId);
        if (batch && batch.educatorId) {
          const batchEdu = educators.find(e => e.id === batch.educatorId);
          if (batchEdu) return batchEdu.name;
        }
      }
      return educators[0]?.name || 'Senior Faculty';
    }
    return raw;
  };

  const getRecordingEducatorName = (rec: ClassRecording | any): string => {
    let raw = (rec.educatorName || '').trim();
    const eduById = educators.find(e => e.id === raw);
    if (eduById) return eduById.name;
    const eduByName = educators.find(e => e.name.toLowerCase() === raw.toLowerCase());
    if (eduByName) return eduByName.name;
    const isBatchId = raw.startsWith('batch-') || batches.some(b => b.id === raw);
    if (!raw || raw.toLowerCase() === 'all' || raw.toLowerCase() === 'faculty' || isBatchId) {
      const targetBatchId = isBatchId ? raw : rec.batchId;
      if (targetBatchId && targetBatchId !== 'all') {
        const batch = batches.find(b => b.id === targetBatchId);
        if (batch && batch.educatorId) {
          const edu = educators.find(e => e.id === batch.educatorId);
          if (edu) return edu.name;
        }
      }
      return educators[0]?.name || 'Senior Faculty';
    }
    return raw;
  };

  if (!currentStudent) return null;

  const studentBatch = batches.find(b => b.id === currentStudent.batchId);
  const studentCourse = courses.find(c => c.id === currentStudent.courseId);
  const studentActualClass = getStudentActualClass(currentStudent, studentCourse, studentBatch);

  // Filter live classes for this student's batch, course or matching academic class
  const studentLiveClasses = liveClasses.filter(c => {
    const matchesBatch = c.batchId === 'all' || c.batchId === currentStudent.batchId;
    const matchesCourse = !c.courseId || c.courseId === 'all' || c.courseId === currentStudent.courseId;
    const matchesClass = !c.academicClass || c.academicClass === 'all' || c.academicClass.toLowerCase().includes(studentActualClass.toLowerCase());
    return (matchesBatch && matchesCourse) || (c.batchId === currentStudent.batchId) || (matchesCourse && matchesClass);
  });

  const activeLiveSessions = studentLiveClasses.filter(c => c.status === 'live');
  const upcomingLiveSessions = studentLiveClasses.filter(c => c.status === 'scheduled');
  const postponedLiveSessions = studentLiveClasses.filter(c => c.status === 'postponed' || !!c.isPostponed);
  const pastLiveSessions = studentLiveClasses.filter(c => c.status === 'completed');

  // Filter recordings for this student's admission class, course, or batch
  const studentRecordings = classRecordings.filter(r => 
    isRecordingForStudent(r, currentStudent, courses, batches)
  );

  // Extract unique subjects for filter
  const allSubjects = Array.from(new Set(studentRecordings.map(r => r.subject)));

  const filteredRecordings = studentRecordings.filter(r => {
    const matchesSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          r.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (r.topic && r.topic.toLowerCase().includes(searchQuery.toLowerCase())) ||
                          r.educatorName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSubject = selectedSubject === 'all' || r.subject === selectedSubject;
    return matchesSearch && matchesSubject;
  });

  // Play video handler
  const handlePlayVideo = (rec: ClassRecording) => {
    setActiveVideo(rec);
    incrementRecordingViews(rec.id);
  };

  // Helper to get embeddable iframe URL
  const getEmbedUrl = (url: string, type: VideoSourceType): string => {
    if (!url) return '';
    if (type === 'youtube') {
      const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
      if (match && match[1]) {
        return `https://www.youtube-nocookie.com/embed/${match[1]}?autoplay=1&rel=0`;
      }
    } else if (type === 'drive') {
      const driveMatch = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
      if (driveMatch && driveMatch[1]) {
        return `https://drive.google.com/file/d/${driveMatch[1]}/preview`;
      }
    } else if (type === 'vimeo') {
      const vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
      if (vimeoMatch && vimeoMatch[1]) {
        return `https://player.vimeo.com/video/${vimeoMatch[1]}?autoplay=1`;
      }
    }
    return url;
  };

  const handleCopyMeetingLink = (link: string) => {
    navigator.clipboard.writeText(link);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Student Enrolled Batch Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black tracking-wider uppercase bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping"></span>
              Live Learning Hub
            </span>
            <span className="text-xs text-slate-300">
              Batch: <strong className="text-white">{studentBatch?.name || 'Assigned Batch'}</strong>
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Online Classroom & Video Archive
          </h2>
          <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
            Attend real-time live interactive classes with your faculty, or re-watch lecture recordings and download study notes anytime.
          </p>
        </div>

        {/* Action Buttons: Quick Tabs Pill & Sign Out */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center gap-2 bg-white/10 p-1 rounded-2xl shrink-0 backdrop-blur-xs border border-white/10">
            <button
              onClick={() => setActiveSubTab('live')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 ${
                activeSubTab === 'live'
                  ? 'bg-white text-slate-900 shadow-md'
                  : 'text-slate-200 hover:text-white'
              }`}
            >
              <Radio className={`w-3.5 h-3.5 ${activeLiveSessions.length > 0 ? 'text-rose-500 animate-pulse' : ''}`} />
              <span>Live Sessions</span>
              {activeLiveSessions.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
              )}
            </button>

            <button
              onClick={() => setActiveSubTab('recordings')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-2 ${
                activeSubTab === 'recordings'
                  ? 'bg-white text-slate-900 shadow-md'
                  : 'text-slate-200 hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5 text-indigo-500" />
              <span>Recorded Lectures ({studentRecordings.length})</span>
            </button>
          </div>

          <button
            id="student-live-portal-signout-btn"
            onClick={() => {
              logoutStudent();
              setActiveTab('website');
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-600/80 hover:bg-rose-600 text-white font-bold rounded-xl text-xs transition cursor-pointer border border-rose-400/40 shadow-xs"
            title="Sign Out from Student Portal"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* 🔴 PROMINENT "LIVE NOW" BROADCAST CARD (IF ACTIVE) */}
      {activeLiveSessions.length > 0 && (
        <div className="space-y-4">
          {activeLiveSessions.map((session) => (
            <div 
              key={session.id}
              className="bg-gradient-to-r from-rose-600 via-rose-700 to-indigo-700 rounded-3xl p-6 text-white shadow-xl shadow-rose-900/20 border-2 border-rose-400 relative overflow-hidden"
            >
              <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="space-y-2 max-w-xl">
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-xs font-black bg-white text-rose-700 animate-pulse flex items-center gap-1.5 shadow-md">
                      <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
                      CLASS IS LIVE RIGHT NOW
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-white/20 text-white backdrop-blur-xs">
                      {session.platform.replace('_', ' ').toUpperCase()}
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-white leading-tight">
                    {session.title}
                  </h3>

                  <p className="text-xs text-rose-100 flex items-center gap-2">
                    <BookOpen className="w-4 h-4" />
                    <span>{session.subject}</span>
                    <span>•</span>
                    <GraduationCap className="w-4 h-4" />
                    <span>Faculty: <strong>{getResolvedEducatorName(session)}</strong></span>
                  </p>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-rose-100 pt-1">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      <span>{session.startTime} - {session.endTime}</span>
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Layers className="w-3.5 h-3.5" />
                      <span>{session.batchId === 'all' ? 'All Batches' : (studentBatch?.name || 'Assigned Batch')}</span>
                    </span>
                  </div>
                </div>

                {/* Join Button */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 w-full md:w-auto shrink-0">
                  <a
                    href={session.meetingUrl || '#'}
                    target="_blank"
                    rel="noreferrer"
                    className="px-6 py-3.5 bg-white hover:bg-slate-100 text-rose-700 font-extrabold rounded-2xl text-sm shadow-xl transition transform hover:scale-105 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Tv className="w-5 h-5 text-rose-600 animate-bounce" />
                    <span>🔴 Join Live Class Now</span>
                  </a>

                  {session.meetingUrl && (
                    <button
                      onClick={() => handleCopyMeetingLink(session.meetingUrl!)}
                      className="px-3.5 py-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer backdrop-blur-xs"
                      title="Copy Link"
                    >
                      {copiedLink ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                      <span>{copiedLink ? 'Copied' : 'Copy'}</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SUB TAB 1: LIVE & UPCOMING CLASSES */}
      {activeSubTab === 'live' && (
        <div className="space-y-6">
          {/* Batch Timetable Box */}
          {studentBatch && (
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-indigo-50 text-indigo-700 border border-indigo-200">
                    Official Timetable
                  </span>
                  <span className="text-xs font-bold text-slate-800">
                    {studentBatch.name}
                  </span>
                </div>
                <h4 className="text-sm font-extrabold text-slate-900">
                  Weekly Class Days: <span className="text-indigo-600">{studentBatch.scheduleDays?.join(', ') || 'Regular Days'}</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Standard Timing: <strong>{studentBatch.timing}</strong> • Room: <strong>{studentBatch.roomNumber || 'Classroom 101'}</strong> • Mode: <span className="capitalize">{studentBatch.mode || 'Offline'}</span>
                </p>
              </div>

              <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 bg-slate-50 p-2.5 rounded-2xl border border-slate-100">
                <Building2 className="w-4 h-4 text-slate-400" />
                <span>Classroom Attendance & Live Sync Active</span>
              </div>
            </div>
          )}

          {/* ⚠️ POSTPONED CLASSES NOTICES (IF ANY) */}
          {postponedLiveSessions.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-amber-900 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 animate-bounce" />
                  <span>⚠️ Important: Postponed Classes Notice ({postponedLiveSessions.length})</span>
                </h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {postponedLiveSessions.map((session) => (
                  <div
                    key={session.id}
                    className="bg-amber-50/80 rounded-3xl p-5 border-2 border-amber-300 shadow-md space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500 text-white flex items-center gap-1.5 shadow-xs">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        POSTPONED BY FACULTY
                      </span>
                      <span className="text-[11px] font-mono text-slate-500 line-through">
                        Was: {session.originalDate || session.scheduledDate}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-black text-amber-950 text-base leading-snug">
                        {session.title}
                      </h4>
                      <p className="text-xs font-bold text-amber-800 mt-0.5">
                        {session.subject}
                      </p>
                    </div>

                    {/* Faculty Reason */}
                    {session.postponedReason && (
                      <div className="p-3 bg-white/90 rounded-2xl border border-amber-200 text-xs text-amber-950">
                        <span className="font-extrabold text-amber-900 block text-[11px]">Reason from Center:</span>
                        <p className="mt-0.5 font-medium">{session.postponedReason}</p>
                      </div>
                    )}

                    {/* Rescheduled Date Box */}
                    <div className="p-3 bg-amber-200/50 rounded-2xl border border-amber-300 text-xs text-amber-950 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-black uppercase tracking-wide text-amber-900 block">
                          👉 New Rescheduled Time:
                        </span>
                        <span className="font-extrabold text-sm text-amber-950">
                          {session.rescheduledDate || 'Date To Be Announced'}
                        </span>
                        {session.rescheduledStartTime && (
                          <span className="block text-[11px] text-amber-900 font-semibold">
                            Time: {session.rescheduledStartTime} - {session.rescheduledEndTime || ''}
                          </span>
                        )}
                      </div>
                      <Clock className="w-6 h-6 text-amber-700/60" />
                    </div>

                    <div className="text-[11px] text-slate-600 flex items-center justify-between pt-1 border-t border-amber-200">
                      <span>Faculty: <strong>{getResolvedEducatorName(session)}</strong></span>
                      <span className="text-[10px] text-amber-800 font-bold">Please check back before new session</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Upcoming Schedule */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-indigo-600" />
                <span>Upcoming Scheduled Live Classes ({upcomingLiveSessions.length})</span>
              </h3>
            </div>

            {upcomingLiveSessions.length === 0 ? (
              <div className="bg-white p-8 rounded-3xl border border-slate-200 text-center space-y-2">
                <Radio className="w-8 h-8 mx-auto text-slate-300" />
                <h4 className="font-bold text-slate-700 text-sm">No Live Classes Scheduled Right Now</h4>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Your educators will schedule live interactive sessions here. Check back before class timing.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {upcomingLiveSessions.map((session) => (
                  <div 
                    key={session.id}
                    className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs hover:border-indigo-300 transition flex flex-col justify-between"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-50 text-amber-800 border border-amber-200 flex items-center gap-1">
                          <Clock className="w-3 h-3 text-amber-600" />
                          SCHEDULED
                        </span>
                        <span className="text-[11px] font-mono font-bold text-slate-500">
                          {session.scheduledDate}
                        </span>
                      </div>

                      <h4 className="font-extrabold text-slate-900 text-base leading-snug">
                        {session.title}
                      </h4>

                      <p className="text-xs text-indigo-600 font-semibold flex items-center gap-1.5">
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>{session.subject}</span>
                      </p>

                      {session.description && (
                        <p className="text-xs text-slate-500 line-clamp-2">
                          {session.description}
                        </p>
                      )}

                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-[11px] text-slate-600">
                        <div>
                          <span className="text-slate-400 block">Class Timing:</span>
                          <span className="font-bold text-slate-800">{session.startTime} - {session.endTime}</span>
                        </div>
                        <div>
                          <span className="text-slate-400 block">Faculty:</span>
                          <span className="font-bold text-slate-800 truncate">{getResolvedEducatorName(session)}</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[11px] font-medium text-slate-500">
                        Platform: <strong className="text-slate-800">{session.platform.replace('_', ' ')}</strong>
                      </span>

                      <a
                        href={session.meetingUrl || '#'}
                        target="_blank"
                        rel="noreferrer"
                        className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-xs transition flex items-center gap-1.5"
                      >
                        <span>Meeting Link</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recently Completed Sessions */}
          {pastLiveSessions.length > 0 && (
            <div>
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2 mb-4">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Recently Concluded Live Sessions</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {pastLiveSessions.map((session) => (
                  <div 
                    key={session.id}
                    className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex items-center justify-between gap-4"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          COMPLETED
                        </span>
                        <span className="text-[10px] text-slate-400">{session.scheduledDate}</span>
                      </div>
                      <h4 className="font-bold text-slate-800 text-sm">{session.title}</h4>
                      <p className="text-xs text-slate-500">{session.subject} • {session.educatorName}</p>
                    </div>

                    {session.recordingUrl ? (
                      <button
                        onClick={() => handlePlayVideo({
                          id: session.id,
                          title: session.title,
                          subject: session.subject,
                          courseId: session.courseId,
                          batchId: session.batchId,
                          educatorName: session.educatorName,
                          recordedDate: session.scheduledDate,
                          durationMinutes: 75,
                          videoSourceType: 'youtube',
                          videoUrl: session.recordingUrl,
                          createdAt: ''
                        })}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shrink-0 cursor-pointer"
                      >
                        <PlayCircle className="w-3.5 h-3.5" />
                        <span>Watch Video</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => setActiveSubTab('recordings')}
                        className="text-xs text-indigo-600 font-bold hover:underline shrink-0 cursor-pointer"
                      >
                        View Recordings →
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUB TAB 2: RECORDED LECTURES ARCHIVE */}
      {activeSubTab === 'recordings' && (
        <div className="space-y-6">
          {/* Search & Subject Filters */}
          <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                placeholder="Search lecture title, chapter, or topic..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={selectedSubject}
                onChange={(e) => setSelectedSubject(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none"
              >
                <option value="all">All Subjects</option>
                {allSubjects.map(sub => (
                  <option key={sub} value={sub}>{sub}</option>
                ))}
              </select>
            </div>
          </div>

          {filteredRecordings.length === 0 ? (
            <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
              <Film className="w-10 h-10 mx-auto text-slate-300" />
              <h4 className="font-bold text-slate-800 text-base">No Recorded Lectures Found</h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Recorded class videos for your enrolled batch will appear here once uploaded by the center faculty.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredRecordings.map((rec) => (
                <div
                  key={rec.id}
                  className="bg-white rounded-3xl border border-slate-200 shadow-xs hover:shadow-md hover:border-indigo-300 transition-all flex flex-col justify-between overflow-hidden group"
                >
                  <div>
                    {/* Video Visual Card Preview Header */}
                    <div 
                      onClick={() => handlePlayVideo(rec)}
                      className="relative aspect-video bg-gradient-to-tr from-slate-900 to-indigo-950 flex items-center justify-center cursor-pointer overflow-hidden"
                    >
                      <div className="w-12 h-12 rounded-full bg-rose-600 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition transform">
                        <Play className="w-5 h-5 fill-current ml-0.5" />
                      </div>

                      <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 bg-black/80 text-white text-[10px] font-bold rounded-md backdrop-blur-xs">
                        {rec.durationMinutes} mins
                      </span>

                      <span className="absolute top-2.5 left-2.5 px-2 py-0.5 bg-indigo-600/90 text-white text-[10px] font-bold rounded-md backdrop-blur-xs flex items-center gap-1">
                        {rec.videoSourceType === 'youtube' ? <Youtube className="w-3 h-3" /> : <Film className="w-3 h-3" />}
                        <span>{rec.videoSourceType.toUpperCase()}</span>
                      </span>
                    </div>

                    {/* Content Details */}
                    <div className="p-4 space-y-2">
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span className="font-semibold text-indigo-600">{rec.subject}</span>
                        <span>{rec.recordedDate}</span>
                      </div>

                      <h4 
                        onClick={() => handlePlayVideo(rec)}
                        className="font-extrabold text-slate-900 text-sm leading-snug hover:text-indigo-600 cursor-pointer transition line-clamp-2"
                      >
                        {rec.title}
                      </h4>

                      {rec.chapter && (
                        <p className="text-[11px] font-medium text-slate-500">
                          {rec.chapter}
                        </p>
                      )}

                      {rec.topic && (
                        <p className="text-xs text-slate-500 line-clamp-2 bg-slate-50 p-2 rounded-xl">
                          {rec.topic}
                        </p>
                      )}

                      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                        <span className="flex items-center gap-1">
                          <GraduationCap className="w-3.5 h-3.5 text-slate-400" />
                          <span className="font-semibold text-slate-700">{getRecordingEducatorName(rec)}</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <Eye className="w-3.5 h-3.5 text-slate-400" />
                          <span>{rec.viewCount || 0} views</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Bar */}
                  <div className="p-4 pt-0 flex items-center justify-between gap-2">
                    {rec.notesPdfUrl ? (
                      <a
                        href={rec.notesPdfUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
                      >
                        <Download className="w-3.5 h-3.5 text-indigo-600" />
                        <span>Notes PDF</span>
                      </a>
                    ) : (
                      <span className="text-[10px] text-slate-400">Class Lecture</span>
                    )}

                    <button
                      onClick={() => handlePlayVideo(rec)}
                      className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs cursor-pointer ml-auto"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Watch</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIDEO PLAYER THEATER MODAL */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-3 sm:p-6 overflow-y-auto">
          <div className="bg-slate-900 text-white rounded-3xl max-w-4xl w-full p-4 sm:p-6 shadow-2xl border border-slate-800 animate-fadeIn my-auto space-y-4">
            
            {/* Header */}
            <div className="flex justify-between items-start pb-2 border-b border-slate-800">
              <div className="space-y-1 max-w-2xl">
                <span className="px-2 py-0.5 bg-rose-500/20 text-rose-300 text-[10px] font-bold rounded-md uppercase tracking-wider">
                  {activeVideo.subject} {activeVideo.chapter ? `• ${activeVideo.chapter}` : ''}
                </span>
                <h3 className="text-base sm:text-lg font-black text-white leading-tight">
                  {activeVideo.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveVideo(null)}
                className="text-slate-400 hover:text-white p-1 text-xl font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Video Player Frame */}
            <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-black border border-slate-800 shadow-2xl">
              {activeVideo.videoSourceType === 'mp4_direct' ? (
                <video
                  src={activeVideo.videoUrl}
                  controls
                  autoPlay
                  className="w-full h-full object-contain"
                />
              ) : (
                <iframe
                  src={getEmbedUrl(activeVideo.videoUrl, activeVideo.videoSourceType)}
                  title={activeVideo.title}
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              )}
            </div>

            {/* Video Meta and Handout Download */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pt-2 text-xs">
              <div className="space-y-1">
                <p className="text-slate-300">
                  Faculty: <strong className="text-white">{activeVideo.educatorName}</strong> • Recorded Date: <span className="text-slate-400">{activeVideo.recordedDate}</span>
                </p>
                {activeVideo.topic && (
                  <p className="text-slate-400 text-[11px] leading-relaxed max-w-xl">
                    {activeVideo.topic}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-2">
                {activeVideo.notesPdfUrl && (
                  <a
                    href={activeVideo.notesPdfUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition flex items-center gap-1.5 shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Notes PDF</span>
                  </a>
                )}

                <a
                  href={activeVideo.videoUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl transition flex items-center gap-1"
                  title="Open Source Video"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
