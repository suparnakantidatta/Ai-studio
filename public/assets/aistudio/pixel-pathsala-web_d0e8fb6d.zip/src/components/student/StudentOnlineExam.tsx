import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { OnlineExam, ExamQuestion, ExamSubmission } from '../../types';
import confetti from 'canvas-confetti';
import { 
  FileQuestion, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Award, 
  BookOpen, 
  ChevronRight, 
  ChevronLeft, 
  Play, 
  RotateCcw, 
  Check, 
  HelpCircle, 
  Sparkles, 
  Flag, 
  Eye, 
  FileText,
  Calendar,
  XCircle,
  Timer,
  Send
} from 'lucide-react';

export const StudentOnlineExam: React.FC = () => {
  const { 
    currentStudent, 
    exams, 
    questions, 
    examSubmissions, 
    submitExamAnswers, 
    courses, 
    batches 
  } = useApp();

  // Active sub-tab: 'available' | 'taking' | 'history'
  const [activeTab, setActiveTab] = useState<'available' | 'taking' | 'history'>('available');

  // Currently taking exam state
  const [takingExam, setTakingExam] = useState<OnlineExam | null>(null);
  const [currentQIndex, setCurrentQIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, number>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<string[]>([]);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(0);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [examStartedAt, setExamStartedAt] = useState<number>(Date.now());

  // Completed submission review modal/card
  const [activeReviewSubmission, setActiveReviewSubmission] = useState<ExamSubmission | null>(null);

  // Student course and batch
  const studentCourse = courses.find(c => c.id === currentStudent?.courseId);
  const studentBatch = batches.find(b => b.id === currentStudent?.batchId);

  // Filter exams available for student (course matches, or course is 'all', and is published)
  const availableExams = useMemo(() => {
    if (!currentStudent) return [];
    return exams.filter(e => {
      if (!e.isPublished) return false;
      const matchCourse = !e.courseId || e.courseId === 'all' || e.courseId === currentStudent.courseId;
      const matchBatch = !e.batchId || e.batchId === 'all' || e.batchId === currentStudent.batchId;
      return matchCourse && matchBatch;
    });
  }, [exams, currentStudent]);

  // Student's submissions history
  const studentSubmissions = useMemo(() => {
    if (!currentStudent) return [];
    return examSubmissions.filter(s => s.studentId === currentStudent.id);
  }, [examSubmissions, currentStudent]);

  // Questions for the exam being taken
  const takingExamQuestions = useMemo(() => {
    if (!takingExam) return [];
    return takingExam.questionIds
      .map(id => questions.find(q => q.id === id))
      .filter((q): q is ExamQuestion => q !== undefined);
  }, [takingExam, questions]);

  // Timer effect during exam
  useEffect(() => {
    if (activeTab !== 'taking' || !takingExam || secondsRemaining <= 0) return;

    const timer = setInterval(() => {
      setSecondsRemaining(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleAutoSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activeTab, takingExam, secondsRemaining]);

  // Start exam handler
  const handleStartExam = (exam: OnlineExam) => {
    if (!confirm(`Are you ready to start "${exam.title}"? The timer will start immediately (${exam.durationMinutes} minutes).`)) {
      return;
    }

    setTakingExam(exam);
    setCurrentQIndex(0);
    setSelectedAnswers({});
    setFlaggedQuestions([]);
    setSecondsRemaining(exam.durationMinutes * 60);
    setExamStartedAt(Date.now());
    setActiveTab('taking');
  };

  // Auto-submit when time is up
  const handleAutoSubmit = () => {
    alert('Time has expired! Submitting your exam responses now.');
    handleSubmitExam();
  };

  // Submit exam handler
  const handleSubmitExam = () => {
    if (!currentStudent || !takingExam) return;

    setIsSubmitting(true);
    const timeSpent = Math.floor((Date.now() - examStartedAt) / 1000);

    const submission = submitExamAnswers(
      takingExam.id,
      currentStudent.id,
      selectedAnswers,
      timeSpent
    );

    if (submission.passed) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    }

    setTakingExam(null);
    setActiveReviewSubmission(submission);
    setActiveTab('available');
    setIsSubmitting(false);
  };

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  const handleToggleFlag = (questionId: string) => {
    setFlaggedQuestions(prev =>
      prev.includes(questionId) ? prev.filter(id => id !== questionId) : [...prev, questionId]
    );
  };

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remSecs = secs % 60;
    return `${String(mins).padStart(2, '0')}:${String(remSecs).padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Header Banner if not currently taking exam */}
      {activeTab !== 'taking' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2.5 bg-indigo-50 text-indigo-600 rounded-2xl">
                <Award className="w-6 h-6" />
              </span>
              <div>
                <h2 className="text-2xl font-black text-slate-900">
                  Online Exams & Course Assessment Portal
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Attempt scheduled online MCQ tests, timed practical quizzes, and review your performance scorecards.
                </p>
              </div>
            </div>
          </div>

          {/* Sub Navigation Tabs */}
          <div className="flex items-center gap-2 bg-slate-100 p-1.5 rounded-2xl">
            <button
              onClick={() => setActiveTab('available')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'available'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileQuestion className="w-4 h-4" />
              <span>Available Tests ({availableExams.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'history'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>My Test Attempts ({studentSubmissions.length})</span>
            </button>
          </div>
        </div>
      )}

      {/* VIEW 1: AVAILABLE EXAMS LIST */}
      {activeTab === 'available' && (
        <div className="space-y-6">
          {availableExams.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
              <FileQuestion className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="font-bold text-slate-700">No scheduled tests right now</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Your educators will schedule course-wise tests and online assessments for your batch soon.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {availableExams.map((exam) => {
                const isCompleted = studentSubmissions.some(s => s.examId === exam.id);
                const lastAttempt = studentSubmissions.find(s => s.examId === exam.id);
                const examCourse = courses.find(c => c.id === exam.courseId);

                return (
                  <div
                    key={exam.id}
                    className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition flex flex-col justify-between"
                  >
                    <div>
                      {/* Course badge & status */}
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-100 truncate max-w-[170px]">
                          {examCourse?.title || 'Academic Assessment'}
                        </span>
                        {isCompleted ? (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>Submitted</span>
                          </span>
                        ) : (
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 animate-pulse">
                            Live Ready
                          </span>
                        )}
                      </div>

                      <h3 className="font-extrabold text-slate-900 text-base mb-1">
                        {exam.title}
                      </h3>
                      <p className="text-xs text-slate-500 font-medium mb-3">
                        Subject: <strong className="text-slate-800">{exam.subject}</strong> • Code: <span className="font-mono text-indigo-600">{exam.examCode}</span>
                      </p>

                      {/* Info grid */}
                      <div className="space-y-2 bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-xs text-slate-700 mb-4">
                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-slate-500">
                            <Clock className="w-3.5 h-3.5 text-indigo-500" />
                            <span>Duration:</span>
                          </span>
                          <span className="font-bold text-slate-800 font-mono">
                            {exam.durationMinutes} Minutes
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="flex items-center gap-1.5 text-slate-500">
                            <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                            <span>Schedule:</span>
                          </span>
                          <span className="font-semibold text-slate-800">
                            {exam.scheduledDate} ({exam.startTime})
                          </span>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-[11px]">
                          <span className="text-slate-500">Total Marks:</span>
                          <span className="font-bold text-indigo-900 font-mono">
                            {exam.questionIds.length} Qs • {exam.totalMarks} Marks (Pass: {exam.passingMarks})
                          </span>
                        </div>
                      </div>

                      {isCompleted && lastAttempt && (
                        <div className="mb-4 p-3 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-950 flex items-center justify-between text-xs font-semibold">
                          <span>Your Score:</span>
                          <span className="font-black font-mono text-sm text-emerald-700">
                            {lastAttempt.score} / {lastAttempt.totalMarks} ({lastAttempt.percentage}%)
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Action buttons */}
                    <div className="pt-3 border-t border-slate-100">
                      {isCompleted && lastAttempt ? (
                        <div className="grid grid-cols-2 gap-2">
                          <button
                            onClick={() => setActiveReviewSubmission(lastAttempt)}
                            className="py-2.5 px-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Scorecard</span>
                          </button>
                          <button
                            onClick={() => handleStartExam(exam)}
                            className="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>Re-Take</span>
                          </button>
                        </div>
                      ) : (
                        <button
                          id={`btn-start-exam-${exam.id}`}
                          onClick={() => handleStartExam(exam)}
                          className="w-full py-3 px-4 bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white font-bold rounded-2xl shadow-md transition cursor-pointer text-xs sm:text-sm flex items-center justify-center gap-2"
                        >
                          <Play className="w-4 h-4 fill-current" />
                          <span>Start Online Exam</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: ACTIVE EXAM TAKING INTERFACE */}
      {activeTab === 'taking' && takingExam && (
        <div className="space-y-6 animate-fadeIn">
          {/* Active Exam Sticky Banner */}
          <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-6 border border-slate-800 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 sticky top-4 z-40">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500 text-slate-950">
                  Exam in Progress
                </span>
                <span className="text-xs text-slate-400 font-mono">Code: {takingExam.examCode}</span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white mt-1">
                {takingExam.title}
              </h2>
            </div>

            {/* Timer Display */}
            <div className="flex items-center gap-4 w-full md:w-auto justify-between md:justify-end">
              <div className={`flex items-center gap-2 px-4 py-2 rounded-2xl border font-mono font-bold text-base sm:text-lg ${
                secondsRemaining < 300 
                  ? 'bg-rose-500/20 border-rose-500/40 text-rose-400 animate-pulse' 
                  : 'bg-indigo-500/20 border-indigo-500/40 text-cyan-300'
              }`}>
                <Timer className="w-5 h-5" />
                <span>{formatTime(secondsRemaining)}</span>
              </div>

              <button
                onClick={() => {
                  const answeredCount = Object.keys(selectedAnswers).length;
                  const totalCount = takingExamQuestions.length;
                  if (confirm(`Are you sure you want to submit your exam now? You have answered ${answeredCount} of ${totalCount} questions.`)) {
                    handleSubmitExam();
                  }
                }}
                disabled={isSubmitting}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-2xl shadow-lg transition cursor-pointer text-xs sm:text-sm flex items-center gap-1.5"
              >
                <Send className="w-4 h-4" />
                <span>Submit Exam</span>
              </button>
            </div>
          </div>

          {/* Exam Body: Left Question & Right Navigator */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Main Question Pane (8 cols) */}
            <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
              {takingExamQuestions[currentQIndex] ? (() => {
                const currentQ = takingExamQuestions[currentQIndex];
                const selectedOption = selectedAnswers[currentQ.id];
                const isFlagged = flaggedQuestions.includes(currentQ.id);

                return (
                  <div className="space-y-6">
                    {/* Question Header */}
                    <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <span className="w-8 h-8 rounded-xl bg-indigo-600 text-white font-bold text-sm flex items-center justify-center font-mono shadow-xs">
                          {currentQIndex + 1}
                        </span>
                        <div>
                          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                            Question {currentQIndex + 1} of {takingExamQuestions.length}
                          </span>
                          <div className="text-xs font-semibold text-indigo-600">
                            {currentQ.subject} &bull; {currentQ.marks} Marks
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => handleToggleFlag(currentQ.id)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition cursor-pointer border ${
                          isFlagged
                            ? 'bg-amber-50 text-amber-700 border-amber-300'
                            : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <Flag className={`w-3.5 h-3.5 ${isFlagged ? 'fill-current text-amber-500' : ''}`} />
                        <span>{isFlagged ? 'Flagged for Review' : 'Mark for Review'}</span>
                      </button>
                    </div>

                    {/* Question Text */}
                    <div className="text-base sm:text-lg font-bold text-slate-900 leading-relaxed">
                      {currentQ.questionText}
                    </div>

                    {/* Code Snippet Box if available */}
                    {currentQ.codeSnippet && (
                      <div className="bg-slate-900 text-slate-100 p-4 rounded-2xl font-mono text-xs overflow-x-auto border border-slate-800 shadow-inner">
                        <pre>{currentQ.codeSnippet}</pre>
                      </div>
                    )}

                    {/* Options List */}
                    <div className="space-y-3 pt-2">
                      {currentQ.options.map((optText, optIdx) => {
                        const optLetter = String.fromCharCode(65 + optIdx);
                        const isSelected = selectedOption === optIdx;

                        return (
                          <button
                            key={optIdx}
                            type="button"
                            onClick={() => handleSelectOption(currentQ.id, optIdx)}
                            className={`w-full text-left p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                              isSelected
                                ? 'bg-indigo-50/80 border-indigo-600 ring-2 ring-indigo-500/20 shadow-xs'
                                : 'bg-slate-50/50 hover:bg-slate-100 border-slate-200 text-slate-800'
                            }`}
                          >
                            <span className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 transition ${
                              isSelected
                                ? 'bg-indigo-600 text-white shadow-xs'
                                : 'bg-slate-200 text-slate-700'
                            }`}>
                              {optLetter}
                            </span>
                            <span className="text-sm font-medium pt-0.5 leading-relaxed">
                              {optText}
                            </span>
                          </button>
                        );
                      })}
                    </div>

                    {/* Clear selection */}
                    {selectedOption !== undefined && (
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={() => {
                            const copy = { ...selectedAnswers };
                            delete copy[currentQ.id];
                            setSelectedAnswers(copy);
                          }}
                          className="text-xs text-slate-400 hover:text-slate-600 underline cursor-pointer"
                        >
                          Clear Choice
                        </button>
                      </div>
                    )}

                    {/* Bottom Question Nav buttons */}
                    <div className="flex items-center justify-between pt-6 border-t border-slate-100">
                      <button
                        type="button"
                        disabled={currentQIndex === 0}
                        onClick={() => setCurrentQIndex(prev => prev - 1)}
                        className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
                          currentQIndex === 0
                            ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        <ChevronLeft className="w-4 h-4" />
                        <span>Previous Question</span>
                      </button>

                      {currentQIndex < takingExamQuestions.length - 1 ? (
                        <button
                          type="button"
                          onClick={() => setCurrentQIndex(prev => prev + 1)}
                          className="flex items-center gap-1.5 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-xs"
                        >
                          <span>Next Question</span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm('Submit all your exam responses now?')) {
                              handleSubmitExam();
                            }
                          }}
                          className="flex items-center gap-1.5 px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-xs"
                        >
                          <span>Review & Finish</span>
                          <Check className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })() : null}
            </div>

            {/* Right Question Palette / Navigator (4 cols) */}
            <div className="lg:col-span-4 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-6">
              <div>
                <h3 className="font-bold text-sm text-slate-900">Question Navigator</h3>
                <p className="text-xs text-slate-500 mt-0.5">Jump directly to any question</p>
              </div>

              {/* Status Legend */}
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 rounded-md bg-indigo-600"></span>
                  <span>Answered</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 rounded-md bg-amber-500"></span>
                  <span>Flagged</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 rounded-md bg-slate-200"></span>
                  <span>Unanswered</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 rounded-md border-2 border-indigo-600 bg-white"></span>
                  <span>Current</span>
                </div>
              </div>

              {/* Number buttons grid */}
              <div className="grid grid-cols-5 gap-2">
                {takingExamQuestions.map((q, idx) => {
                  const isCurrent = idx === currentQIndex;
                  const isAnswered = selectedAnswers[q.id] !== undefined;
                  const isFlagged = flaggedQuestions.includes(q.id);

                  let bgStyle = 'bg-slate-100 text-slate-700 hover:bg-slate-200';
                  if (isAnswered) bgStyle = 'bg-indigo-600 text-white font-bold';
                  if (isFlagged) bgStyle = 'bg-amber-500 text-white font-bold';

                  return (
                    <button
                      key={q.id}
                      onClick={() => setCurrentQIndex(idx)}
                      className={`h-10 rounded-xl flex items-center justify-center font-mono text-xs transition cursor-pointer ${bgStyle} ${
                        isCurrent ? 'ring-2 ring-indigo-600 ring-offset-2 font-black' : ''
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>

              {/* Summary Stats */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Answered:</span>
                  <span className="font-bold text-indigo-700 font-mono">
                    {Object.keys(selectedAnswers).length} / {takingExamQuestions.length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Flagged for Review:</span>
                  <span className="font-bold text-amber-700 font-mono">
                    {flaggedQuestions.length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Unanswered:</span>
                  <span className="font-bold text-slate-700 font-mono">
                    {takingExamQuestions.length - Object.keys(selectedAnswers).length}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: PAST SUBMISSIONS HISTORY */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          {studentSubmissions.length === 0 ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
              <Award className="w-12 h-12 text-slate-300 mx-auto" />
              <h3 className="font-bold text-slate-700">No test attempts completed yet</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Take an available test to view your scores, rank, and detailed question-by-question analysis here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {studentSubmissions.map((sub) => {
                return (
                  <div
                    key={sub.id}
                    className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition flex flex-col justify-between space-y-4"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold ${
                          sub.passed ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {sub.passed ? 'Passed ✓' : 'Failed ✕'}
                        </span>
                        <span className="text-xs text-slate-400">
                          {new Date(sub.submittedAt).toLocaleDateString('en-IN')}
                        </span>
                      </div>

                      <h3 className="font-bold text-slate-900 text-base">
                        {sub.examTitle}
                      </h3>

                      <div className="grid grid-cols-3 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-100 text-center my-3">
                        <div>
                          <div className="text-[10px] text-slate-500">Marks</div>
                          <div className="font-bold font-mono text-sm text-slate-900 mt-0.5">
                            {sub.score}/{sub.totalMarks}
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500">Percentage</div>
                          <div className="font-bold font-mono text-sm text-indigo-600 mt-0.5">
                            {sub.percentage}%
                          </div>
                        </div>
                        <div>
                          <div className="text-[10px] text-slate-500">Time Taken</div>
                          <div className="font-bold font-mono text-xs text-slate-700 mt-1">
                            {Math.floor(sub.timeSpentSeconds / 60)}m {sub.timeSpentSeconds % 60}s
                          </div>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveReviewSubmission(sub)}
                      className="w-full py-2.5 px-4 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Review Scorecard & Explanations</span>
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* DETAILED SCORECARD MODAL */}
      {activeReviewSubmission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto animate-fadeIn space-y-6">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Test Performance Scorecard
                </span>
                <h3 className="text-2xl font-black text-slate-900 mt-0.5">
                  {activeReviewSubmission.examTitle}
                </h3>
                <p className="text-xs text-slate-500">
                  Student: <strong>{activeReviewSubmission.studentName}</strong> • Submitted: {new Date(activeReviewSubmission.submittedAt).toLocaleString('en-IN')}
                </p>
              </div>
              <button
                onClick={() => setActiveReviewSubmission(null)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Scorecard Hero Banner */}
            <div className={`p-6 rounded-2xl border text-center flex flex-col sm:flex-row items-center justify-around gap-4 ${
              activeReviewSubmission.passed
                ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                : 'bg-rose-50 border-rose-200 text-rose-950'
            }`}>
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-600">Marks Scored</div>
                <div className="text-4xl font-black font-mono mt-1">
                  {activeReviewSubmission.score} <span className="text-lg font-normal text-slate-500">/ {activeReviewSubmission.totalMarks}</span>
                </div>
              </div>

              <div className="h-10 w-[1px] bg-slate-300 hidden sm:block"></div>

              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-600">Percentage</div>
                <div className="text-4xl font-black font-mono mt-1 text-indigo-600">
                  {activeReviewSubmission.percentage}%
                </div>
              </div>

              <div className="h-10 w-[1px] bg-slate-300 hidden sm:block"></div>

              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-slate-600">Result</div>
                <div className={`text-xl font-black mt-1 uppercase ${activeReviewSubmission.passed ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {activeReviewSubmission.passed ? '✓ PASSED' : '✕ FAILED'}
                </div>
              </div>
            </div>

            {/* Detailed Question Review */}
            <div className="space-y-4 pt-2">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileQuestion className="w-4 h-4 text-indigo-600" />
                <span>Question Responses & Solution Key</span>
              </h4>

              <div className="space-y-3">
                {activeReviewSubmission.questionBreakdown.map((item, idx) => {
                  const q = questions.find(question => question.id === item.questionId);
                  if (!q) return null;

                  const isCorrect = item.isCorrect;
                  const studentChoice = item.selectedOptionIndex !== null ? String.fromCharCode(65 + item.selectedOptionIndex) : 'Not Answered';
                  const correctChoice = String.fromCharCode(65 + item.correctOptionIndex);

                  return (
                    <div
                      key={item.questionId}
                      className={`p-4 rounded-2xl border space-y-2.5 ${
                        isCorrect
                          ? 'bg-emerald-50/40 border-emerald-200'
                          : 'bg-rose-50/40 border-rose-200'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs ${
                            isCorrect ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
                          }`}>
                            {idx + 1}
                          </span>
                          <h5 className="font-bold text-slate-900 text-xs sm:text-sm">
                            {q.questionText}
                          </h5>
                        </div>

                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold font-mono ${
                          isCorrect ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {isCorrect ? `+${item.marks} Marks` : '0 Marks'}
                        </span>
                      </div>

                      {q.codeSnippet && (
                        <div className="bg-slate-900 text-slate-200 p-2.5 rounded-xl font-mono text-xs overflow-x-auto">
                          <pre>{q.codeSnippet}</pre>
                        </div>
                      )}

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div className={`p-2 rounded-xl border flex items-center justify-between ${
                          isCorrect ? 'bg-emerald-100/70 border-emerald-300 text-emerald-900 font-bold' : 'bg-rose-100/70 border-rose-300 text-rose-900 font-semibold'
                        }`}>
                          <span>Your Choice:</span>
                          <span>Option {studentChoice}</span>
                        </div>

                        <div className="p-2 rounded-xl border bg-emerald-100/70 border-emerald-300 text-emerald-900 font-bold flex items-center justify-between">
                          <span>Correct Answer:</span>
                          <span>Option {correctChoice} ({q.options[item.correctOptionIndex]})</span>
                        </div>
                      </div>

                      {q.explanation && (
                        <div className="text-[11px] text-slate-600 bg-white/80 p-2.5 rounded-xl border border-slate-200">
                          <strong>Explanation:</strong> {q.explanation}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-slate-100">
              <button
                onClick={() => setActiveReviewSubmission(null)}
                className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs cursor-pointer"
              >
                Close Review
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
