import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { PaymentMode, StudentMonthDueStatus, AdmissionApplication, StudentNotification, ClassRecording, VideoSourceType } from '../../types';
import { getStudentMonthlyBilling, formatMonthKey } from '../../utils/feeCalculator';
import { getStudentActualClass, isRecordingForStudent, isMaterialForStudent } from '../../utils/classCourseMatcher';
import { getUpiQrCodeUrl, getUpiDeepLink } from '../../utils/qrHelper';
import { getDirectApkDownloadUrl } from '../../utils/apkHelper';
import { AdmissionReceiptModal } from '../common/AdmissionReceiptModal';
import { Playzone } from '../playzone/Playzone';
import { StudentOnlineExam } from './StudentOnlineExam';
import { StudentLiveClassPortal } from './StudentLiveClassPortal';
import { 
  User, 
  Lock, 
  LogOut, 
  CreditCard, 
  Printer, 
  QrCode, 
  Building2, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  XCircle, 
  Copy, 
  Check, 
  Sparkles, 
  BookOpen, 
  Calendar, 
  Phone, 
  MapPin, 
  Receipt, 
  ShieldCheck,
  Send,
  Smartphone,
  ExternalLink,
  FolderDown,
  Download,
  FileArchive,
  FileCode,
  FileText,
  Link2,
  Eye,
  Layers,
  Code2,
  GraduationCap,
  FileQuestion,
  LayoutDashboard,
  Radio,
  Tv,
  Bell,
  AlertTriangle,
  X,
  Play,
  PlayCircle,
  Film,
  Search,
  Filter,
  Video
} from 'lucide-react';

export const StudentPortal: React.FC = () => {
  const { 
    currentStudent, 
    loginStudent, 
    logoutStudent, 
    students,
    courses, 
    batches, 
    discounts, 
    payments, 
    studyMaterials,
    downloadStudyMaterial,
    liveClasses,
    classRecordings,
    incrementRecordingViews,
    notifications,
    markNotificationAsRead,
    clearAllStudentNotifications,
    centerInfo, 
    submitStudentFeePayment, 
    setSelectedReceiptForPrint,
    setActiveTab,
    educators = []
  } = useApp();

  // Login form state
  const [mobileInput, setMobileInput] = useState('');
  const [aadhaarInput, setAadhaarInput] = useState('');
  const [loginError, setLoginError] = useState('');

  // Pending admission status state
  const [pendingApplication, setPendingApplication] = useState<AdmissionApplication | null>(null);
  const [receiptModalApp, setReceiptModalApp] = useState<AdmissionApplication | null>(null);

  // Active tab within student portal: 'billing' | 'live' | 'recordings' | 'study-material' | 'notices' | 'codezone' | 'exams'
  const [studentActiveTab, setStudentActiveTab] = useState<'billing' | 'live' | 'recordings' | 'study-material' | 'notices' | 'codezone' | 'exams'>('billing');
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [noticeFilterType, setNoticeFilterType] = useState<'all' | 'postponed' | 'scheduled'>('all');

  // Study material search & filters
  const [materialSearchQuery, setMaterialSearchQuery] = useState('');
  const [materialSelectedSubject, setMaterialSelectedSubject] = useState<string>('all');
  const [materialTypeFilter, setMaterialTypeFilter] = useState<string>('all');

  // Recorded classes search, filter & active playback
  const [recordingSearchQuery, setRecordingSearchQuery] = useState('');
  const [recordingSelectedSubject, setRecordingSelectedSubject] = useState<string>('all');
  const [activeRecordingVideo, setActiveRecordingVideo] = useState<ClassRecording | null>(null);

  // Payment Form modal state
  const [showPayModal, setShowPayModal] = useState(false);
  const [selectedMonthsToPay, setSelectedMonthsToPay] = useState<string[]>([]);
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('UPI');
  const [transactionRef, setTransactionRef] = useState('');
  const [studentRemarks, setStudentRemarks] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    const res = await loginStudent(mobileInput, aadhaarInput);
    if (res.isPendingAdmission && res.application) {
      setPendingApplication(res.application);
      setLoginError('');
    } else if (!res.success) {
      setLoginError(res.message);
    }
  };

  // If viewing Pending Admission Status
  if (pendingApplication) {
    const appliedCourse = courses.find(c => c.id === pendingApplication.targetCourseId);
    const appliedBatch = batches.find(b => b.id === pendingApplication.preferredBatchId);

    return (
      <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 py-12 animate-fadeIn">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
          
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 sm:p-8 text-white">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    Admission Tracker & Desk Verification
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
                  Application Under Process
                </h2>
                <p className="text-xs text-slate-300 mt-1">
                  Applicant: <strong>{pendingApplication.studentName}</strong> • Ref: <span className="font-mono text-amber-300">{pendingApplication.applicationNo}</span>
                </p>
              </div>

              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs font-extrabold uppercase tracking-wide shrink-0">
                <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
                <span>Pending Approval</span>
              </div>
            </div>
          </div>

          {/* Under Process Notice Message - EXACT USER REQUIREMENT */}
          <div className="p-6 sm:p-8 space-y-6">
            <div className="p-5 bg-amber-50 rounded-2xl border-2 border-amber-300 text-amber-950 space-y-2">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-black text-sm sm:text-base text-amber-900">
                    Your application is under process, Please contact you educator or visit center with payment receipt
                  </h3>
                  <p className="text-xs text-amber-800 mt-1 leading-relaxed">
                    We have received your admission application for <strong>{appliedCourse?.title || 'Academic Course'}</strong>. Please download or print your official provisional payment receipt and present it at {centerInfo.name} center desk or contact your educator.
                  </p>
                </div>
              </div>
            </div>

            {/* Application Overview Details */}
            <div className="bg-slate-50 rounded-2xl p-5 sm:p-6 border border-slate-200">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-4 pb-2 border-b border-slate-200 flex items-center justify-between">
                <span>Application Summary & Status</span>
                <span className="font-mono text-indigo-700 font-bold">{pendingApplication.applicationNo}</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Applicant Name:</span>
                    <span className="font-bold text-slate-900">{pendingApplication.studentName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Academic Class:</span>
                    <span className="font-bold text-indigo-700">{pendingApplication.studentClass || appliedCourse?.academicClass || appliedBatch?.academicClass || 'Class 12'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Registered Mobile:</span>
                    <span className="font-mono text-slate-800">{pendingApplication.mobile}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">AADHAAR Number:</span>
                    <span className="font-mono text-slate-800">XXXX-XXXX-{pendingApplication.aadhaarNo.slice(-4)}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Selected Course:</span>
                    <span className="font-bold text-slate-800 text-right">{appliedCourse?.title || 'Course'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Preferred Batch:</span>
                    <span className="font-semibold text-slate-700 text-right">
                      {appliedBatch ? `${appliedBatch.name} (${appliedBatch.timing})` : 'Under Allocation'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Payment Option:</span>
                    <span className="font-semibold text-slate-800">
                      {pendingApplication.initialPaymentMode === 'UPI' ? 'UPI Advance Payment' : 'Cash at Center Desk'}
                    </span>
                  </div>
                  {pendingApplication.initialPaymentRef && (
                    <div className="flex justify-between">
                      <span className="text-slate-500">UPI / Ref UTR:</span>
                      <span className="font-mono font-bold text-indigo-700">{pendingApplication.initialPaymentRef}</span>
                    </div>
                  )}
                  <div className="flex justify-between pt-1 border-t border-slate-200">
                    <span className="text-slate-500">Application Date:</span>
                    <span className="font-mono font-bold text-slate-700">{pendingApplication.appliedDate}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons: Print/Download Receipt, Coders Zone, Back */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => setReceiptModalApp(pendingApplication)}
                  className="flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print / Download Receipt</span>
                </button>

                <button
                  onClick={() => setActiveTab('playzone')}
                  className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
                >
                  <Code2 className="w-4 h-4 text-amber-300" />
                  <span>Go to Coders Zone</span>
                </button>

                <a
                  id="student-pending-download-apk"
                  href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
                  download="PixelPathsala.apk"
                  className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition cursor-pointer"
                  title="Download Official Mobile App (.apk)"
                >
                  <Download className="w-4 h-4" />
                  <span>Download App (.APK)</span>
                </a>
              </div>

              <button
                onClick={() => setPendingApplication(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs sm:text-sm transition cursor-pointer"
              >
                Sign In with Another Account
              </button>
            </div>
          </div>
        </div>

        {/* Admission Receipt Modal */}
        {receiptModalApp && (
          <AdmissionReceiptModal
            application={receiptModalApp}
            onClose={() => setReceiptModalApp(null)}
          />
        )}
      </div>
    );
  }

  // If not logged in, show Login Screen
  if (!currentStudent) {
    return (
      <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 py-12">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-12">
          {/* Left Hero side (5 cols) */}
          <div className="md:col-span-5 bg-gradient-to-br from-indigo-900 via-indigo-950 to-slate-900 p-8 text-white flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center font-bold text-xl mb-4">
                PP
              </div>
              <h2 className="text-2xl font-black tracking-tight">{centerInfo.name}</h2>
              <p className="text-indigo-200 text-xs mt-1">Student Portal & Admission Status</p>
              
              <div className="mt-8 space-y-3 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Check Admission Status & Receipts</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Check Monthly Fee Dues & Billing</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Pay Online via UPI QR or Cash</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Download & Print Official Receipts</span>
                </div>
              </div>

              {/* Coders zone shortcut in login sidebar */}
              <div className="mt-6 pt-5 border-t border-slate-800/90">
                <button
                  onClick={() => setActiveTab('playzone')}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
                >
                  <Code2 className="w-3.5 h-3.5 text-amber-300" />
                  <span>Go to Coders Zone</span>
                </button>
              </div>

              {/* Direct Android APK Download Card in Student Login Sidebar */}
              <div className="mt-4 pt-4 border-t border-slate-800/80">
                <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-400/30 text-white space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Student Android App</span>
                    </span>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-emerald-500/20 text-emerald-300 uppercase">
                      Direct APK
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-snug">
                    Direct APK download to your mobile device with no Google Drive preview.
                  </p>
                  <a
                    id="student-login-sidebar-apk-btn"
                    href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
                    download="PixelPathsala.apk"
                    className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                    title="Download Official Mobile App (.apk)"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download App (.APK)</span>
                  </a>
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800 text-[11px] text-slate-400">
              Need help? Contact Pixel Pathsala Helpdesk at <span className="text-indigo-300 font-mono">{centerInfo.phonePrimary}</span>
            </div>
          </div>

          {/* Right Login Form (7 cols) */}
          <div className="md:col-span-7 p-8 sm:p-10 flex flex-col justify-center">
            <div className="mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">Student & Applicant Sign In</span>
              <h3 className="text-2xl font-bold text-slate-900 mt-1">Login to Student Portal</h3>
              <p className="text-xs text-slate-500 mt-1">
                Enter your registered Mobile Number and Aadhaar Number (or Application No) to check your status or access your account.
              </p>
            </div>

            {loginError && (
              <div className="p-3.5 mb-5 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{loginError}</span>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Registered Mobile Number
                </label>
                <input
                  id="stu-login-mobile"
                  type="tel"
                  required
                  maxLength={10}
                  value={mobileInput}
                  onChange={(e) => setMobileInput(e.target.value)}
                  placeholder="10-digit mobile number"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  AADHAAR Number (12 Digits or Last 4) / Application No
                </label>
                <input
                  id="stu-login-aadhaar"
                  type="text"
                  required
                  value={aadhaarInput}
                  onChange={(e) => setAadhaarInput(e.target.value)}
                  placeholder="e.g. 4532 8901 2345 or APP/2026/101"
                  className="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm font-mono"
                />
              </div>

              <button
                id="btn-submit-student-login"
                type="submit"
                className="w-full py-3 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-md transition cursor-pointer text-sm"
              >
                Sign In / Check Admission Status
              </button>

              <div className="pt-3 flex items-center justify-between text-xs">
                <span className="text-slate-500">Want to practice coding?</span>
                <button
                  type="button"
                  onClick={() => setActiveTab('playzone')}
                  className="font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>Go to Coders Zone</span>
                </button>
              </div>
            </form>

            {/* Direct APK Download Card on Student Login Form */}
            <div className="mt-6 pt-5 border-t border-slate-200">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-200/90 shadow-xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-600 text-white flex items-center justify-center shrink-0 shadow-xs">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="text-xs font-bold text-slate-900">Student Android App (.APK)</h4>
                      <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-emerald-100 text-emerald-800 uppercase">
                        Direct File
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      Direct APK download to phone with no Google Drive container
                    </p>
                  </div>
                </div>

                <a
                  id="student-login-direct-apk-btn"
                  href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
                  download="PixelPathsala.apk"
                  className="shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs cursor-pointer"
                  title="Download Mobile App (.apk)"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download APK</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // LOGGED IN VIEW:
  const studentCourse = courses.find(c => c.id === currentStudent.courseId);
  const studentBatch = batches.find(b => b.id === currentStudent.batchId);
  const studentPayments = payments.filter(p => p.studentId === currentStudent.id);
  const studentActualClass = getStudentActualClass(currentStudent, studentCourse, studentBatch);

  // Filter study materials accurately for student's admission class, course, or batch from database
  const studentMaterials = studyMaterials.filter(mat =>
    isMaterialForStudent(mat, currentStudent, courses, batches)
  );

  // Filter class recordings accurately for student's admission class, course, or batch from database
  const studentRecordings = classRecordings.filter(rec =>
    isRecordingForStudent(rec, currentStudent, courses, batches)
  );

  // Extract subjects for filters
  const materialSubjects = Array.from(new Set(studentMaterials.map(m => m.subject).filter(Boolean))) as string[];
  const recordingSubjects = Array.from(new Set(studentRecordings.map(r => r.subject).filter(Boolean))) as string[];

  // Filtered study materials by search, subject, and file type
  const filteredMaterials = studentMaterials.filter(mat => {
    const matchesSearch = !materialSearchQuery.trim() || 
      mat.title.toLowerCase().includes(materialSearchQuery.toLowerCase()) ||
      (mat.subject && mat.subject.toLowerCase().includes(materialSearchQuery.toLowerCase())) ||
      (mat.description && mat.description.toLowerCase().includes(materialSearchQuery.toLowerCase())) ||
      (mat.fileName && mat.fileName.toLowerCase().includes(materialSearchQuery.toLowerCase()));
    const matchesSubject = materialSelectedSubject === 'all' || mat.subject === materialSelectedSubject;
    const matchesType = materialTypeFilter === 'all' || mat.fileType === materialTypeFilter;
    return matchesSearch && matchesSubject && matchesType;
  });

  // Filtered recordings by search and subject
  const filteredRecordings = studentRecordings.filter(rec => {
    const matchesSearch = !recordingSearchQuery.trim() ||
      rec.title.toLowerCase().includes(recordingSearchQuery.toLowerCase()) ||
      (rec.subject && rec.subject.toLowerCase().includes(recordingSearchQuery.toLowerCase())) ||
      (rec.topic && rec.topic.toLowerCase().includes(recordingSearchQuery.toLowerCase())) ||
      (rec.chapter && rec.chapter.toLowerCase().includes(recordingSearchQuery.toLowerCase())) ||
      (rec.educatorName && rec.educatorName.toLowerCase().includes(recordingSearchQuery.toLowerCase()));
    const matchesSubject = recordingSelectedSubject === 'all' || rec.subject === recordingSelectedSubject;
    return matchesSearch && matchesSubject;
  });

  // Helper to get embeddable iframe URL for video playback
  const getRecordingEmbedUrl = (url: string, type?: VideoSourceType | string): string => {
    if (!url) return '';
    const cleanType = (type || 'youtube').toLowerCase();
    if (cleanType === 'youtube' || url.includes('youtube') || url.includes('youtu.be')) {
      const match = url.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);
      if (match && match[1]) {
        return `https://www.youtube-nocookie.com/embed/${match[1]}?autoplay=1&rel=0`;
      }
    } else if (cleanType === 'drive' || url.includes('drive.google.com')) {
      const driveMatch = url.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
      if (driveMatch && driveMatch[1]) {
        return `https://drive.google.com/file/d/${driveMatch[1]}/preview`;
      }
    } else if (cleanType === 'vimeo' || url.includes('vimeo.com')) {
      const vimeoMatch = url.match(/vimeo\.com\/(\d+)/);
      if (vimeoMatch && vimeoMatch[1]) {
        return `https://player.vimeo.com/video/${vimeoMatch[1]}?autoplay=1`;
      }
    }
    return url;
  };

  // Calculate student monthly dues
  const billingSummary = getStudentMonthlyBilling(
    currentStudent,
    studentCourse,
    discounts,
    payments
  );

  // Filter due months for payment modal
  const unpaidMonths = billingSummary.monthlyStatuses.filter(m => !m.isPaid && !m.isPendingApproval);

  const handleOpenPaymentModal = () => {
    // default select all due months or first due month
    const dues = unpaidMonths.map(m => m.monthKey);
    setSelectedMonthsToPay(dues);
    setShowPayModal(true);
  };

  const handleToggleMonthSelection = (monthKey: string) => {
    setSelectedMonthsToPay(prev => 
      prev.includes(monthKey) ? prev.filter(k => k !== monthKey) : [...prev, monthKey]
    );
  };

  // Calculate total amount to pay in modal
  const modalTotalPayAmount = selectedMonthsToPay.reduce((sum, mKey) => {
    const st = billingSummary.monthlyStatuses.find(m => m.monthKey === mKey);
    return sum + (st ? st.netFeeDue : 0);
  }, 0);

  const qrCodeForDue = getUpiQrCodeUrl({
    upiId: centerInfo.upiId,
    payeeName: centerInfo.upiName,
    amount: modalTotalPayAmount,
    transactionNote: `Fee:${currentStudent.name}`,
    size: 200
  });

  const upiDeepLinkForDue = getUpiDeepLink({
    upiId: centerInfo.upiId,
    payeeName: centerInfo.upiName,
    amount: modalTotalPayAmount,
    note: `Fee:${currentStudent.name}`
  });

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(centerInfo.upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleSubmitDuePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedMonthsToPay.length === 0) {
      alert('Please select at least one month to pay for.');
      return;
    }
    if (paymentMode === 'UPI' && !transactionRef.trim()) {
      alert('Please enter your UPI Reference / UTR Number.');
      return;
    }

    submitStudentFeePayment({
      studentId: currentStudent.id,
      months: selectedMonthsToPay,
      amount: modalTotalPayAmount,
      mode: paymentMode,
      transactionRef: transactionRef.trim() || 'CASH-AT-CENTER',
      remarks: studentRemarks.trim() || undefined
    });

    setShowPayModal(false);
    setTransactionRef('');
    setStudentRemarks('');
  };

  // Local state to track read notifications (for both stored and dynamically derived class notices)
  const [readNotifIds, setReadNotifIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(`read_notifs_${currentStudent?.id}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const handleMarkNoticeAsRead = (notifId: string) => {
    markNotificationAsRead(notifId, currentStudent?.id || '');
    setReadNotifIds(prev => {
      const next = Array.from(new Set([...prev, notifId]));
      try {
        localStorage.setItem(`read_notifs_${currentStudent?.id}`, JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const handleMarkAllNoticesAsRead = () => {
    if (currentStudent?.id) {
      clearAllStudentNotifications(currentStudent.id);
      const allIds = studentNotifs.map(n => n.id);
      setReadNotifIds(allIds);
      try {
        localStorage.setItem(`read_notifs_${currentStudent.id}`, JSON.stringify(allIds));
      } catch {}
    }
  };

  // 1. Stored database notifications (strictly excluding fake dummy seed data)
  const dbStoredNotifs = (notifications || []).filter(n => {
    if (n.id === 'notif-1' || n.id === 'notif-2') return false; // Filter out dummy seed items
    if (n.batchId === 'all') return true;
    if (currentStudent && n.batchId === currentStudent.batchId) return true;
    if (currentStudent && n.studentId === currentStudent.id) return true;
    if (currentStudent && n.courseId === currentStudent.courseId) return true;
    return false;
  });

  // 2. Real-time class notices directly derived from liveClasses in database
  const studentLiveSessions = liveClasses.filter(c => {
    if (!currentStudent) return false;
    const matchesBatch = !c.batchId || c.batchId === 'all' || c.batchId === currentStudent.batchId;
    const matchesCourse = !c.courseId || c.courseId === 'all' || c.courseId === currentStudent.courseId;
    const matchesClass = !c.academicClass || c.academicClass === 'all' || c.academicClass.toLowerCase().includes(studentActualClass.toLowerCase());
    return (matchesBatch && matchesCourse) || (c.batchId === currentStudent.batchId) || (matchesCourse && matchesClass);
  });

  const sessionDerivedNotifs: StudentNotification[] = [];

  for (const session of studentLiveSessions) {
    if (session.status === 'postponed' || session.isPostponed) {
      sessionDerivedNotifs.push({
        id: `notice-postpone-${session.id}`,
        title: `⚠️ Class Postponed: ${session.title}`,
        message: `Official Notice: Class "${session.title}" (${session.subject || 'Lecture'}) has been postponed.${session.postponedReason ? ` Reason: ${session.postponedReason}.` : ''}${session.rescheduledDate ? ` Rescheduled to: ${session.rescheduledDate}${session.rescheduledStartTime ? ` (${session.rescheduledStartTime})` : ''}.` : ' New date will be announced shortly.'}`,
        type: 'class_postponed',
        courseId: session.courseId,
        batchId: session.batchId,
        studentId: 'all',
        classSessionId: session.id,
        classTitle: session.title,
        scheduledDate: session.originalDate || session.scheduledDate || session.date || '',
        rescheduledDate: session.rescheduledDate,
        timeSlot: session.rescheduledStartTime ? `${session.rescheduledStartTime} - ${session.rescheduledEndTime || ''}` : `${session.startTime} - ${session.endTime}`,
        reason: session.postponedReason || 'Administrative postponement',
        createdAt: session.postponedAt ? session.postponedAt.split('T')[0] : (session.createdAt || session.scheduledDate || new Date().toISOString().split('T')[0]),
        readBy: []
      });
    } else if (session.status === 'scheduled') {
      sessionDerivedNotifs.push({
        id: `notice-sched-${session.id}`,
        title: `📅 Scheduled Class: ${session.title}`,
        message: `Class "${session.title}" (${session.subject || 'Subject'}) is scheduled on ${session.scheduledDate || session.date} at ${session.startTime} - ${session.endTime}. Platform: ${session.platform === 'google_meet' ? 'Google Meet' : session.platform === 'zoom' ? 'Zoom' : 'In-App Live Stream'}. Educator: ${session.educatorName || 'Faculty'}.`,
        type: 'class_scheduled',
        courseId: session.courseId,
        batchId: session.batchId,
        studentId: 'all',
        classSessionId: session.id,
        classTitle: session.title,
        scheduledDate: session.scheduledDate || session.date || '',
        timeSlot: `${session.startTime} - ${session.endTime}`,
        reason: 'Course Batch Academic Schedule',
        createdAt: session.createdAt || session.scheduledDate || new Date().toISOString().split('T')[0],
        readBy: []
      });
    } else if (session.status === 'live') {
      sessionDerivedNotifs.push({
        id: `notice-live-${session.id}`,
        title: `🔴 Class Live Now: ${session.title}`,
        message: `Live class on "${session.subject}" is currently in progress (${session.startTime} - ${session.endTime}). Click to join immediately!`,
        type: 'class_scheduled',
        courseId: session.courseId,
        batchId: session.batchId,
        studentId: 'all',
        classSessionId: session.id,
        classTitle: session.title,
        scheduledDate: session.scheduledDate || session.date || '',
        timeSlot: `${session.startTime} - ${session.endTime}`,
        reason: 'Live Session in Progress',
        createdAt: session.createdAt || new Date().toISOString().split('T')[0],
        readBy: []
      });
    }
  }

  // 3. Center Announcement notice if configured in database
  const centerAnnouncementNotifs: StudentNotification[] = (centerInfo.announcement && centerInfo.announcement.trim()) ? [
    {
      id: 'center-announcement-notice',
      title: '📢 Center Official Announcement',
      message: centerInfo.announcement.trim(),
      type: 'general',
      courseId: 'all',
      batchId: 'all',
      studentId: 'all',
      createdAt: new Date().toISOString().split('T')[0],
      readBy: []
    }
  ] : [];

  // Combine and deduplicate
  const seenSessionTypes = new Set<string>();
  const combinedNotifs: StudentNotification[] = [];

  for (const n of dbStoredNotifs) {
    if (n.classSessionId) seenSessionTypes.add(`${n.classSessionId}-${n.type}`);
    combinedNotifs.push(n);
  }

  for (const n of sessionDerivedNotifs) {
    const key = `${n.classSessionId}-${n.type}`;
    if (!seenSessionTypes.has(key)) {
      seenSessionTypes.add(key);
      combinedNotifs.push(n);
    }
  }

  for (const n of centerAnnouncementNotifs) {
    combinedNotifs.push(n);
  }

  const studentNotifs = combinedNotifs;
  const unreadNotifs = studentNotifs.filter(n => !n.readBy?.includes(currentStudent?.id || '') && !readNotifIds.includes(n.id));
  const topPriorityAlert = unreadNotifs.find(n => n.type === 'class_postponed') || unreadNotifs[0];

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Profile Header */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center font-bold text-2xl sm:text-3xl shadow-md">
            {currentStudent.name.split(' ').slice(0, 2).map(n => n[0]).join('')}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                {currentStudent.name}
              </h1>
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                currentStudent.status === 'active' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
              }`}>
                {currentStudent.status}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 mt-1 font-mono">
              <span>Roll: <strong className="text-slate-800">{currentStudent.rollNo}</strong></span>
              <span>•</span>
              <span>Aadhaar: <strong className="text-slate-800">{currentStudent.aadhaarNo}</strong></span>
              <span>•</span>
              <span>Mobile: <strong className="text-slate-800">{currentStudent.mobile}</strong></span>
            </div>

            <div className="text-xs font-medium text-indigo-700 mt-1.5 flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" />
                <span>{studentCourse?.title || 'Enrolled Course'} ({studentBatch?.name || 'Batch'})</span>
              </div>
              <span className="px-2 py-0.5 rounded-md text-[11px] font-bold bg-violet-100 text-violet-800 border border-violet-200">
                {studentActualClass}
              </span>
              {(currentStudent.mode || studentBatch?.mode) && (
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold ${
                  (currentStudent.mode || studentBatch?.mode) === 'online'
                    ? 'bg-sky-50 text-sky-700 border border-sky-200'
                    : (currentStudent.mode || studentBatch?.mode) === 'hybrid'
                    ? 'bg-purple-50 text-purple-700 border border-purple-200'
                    : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                }`}>
                  {(currentStudent.mode || studentBatch?.mode) === 'online' ? (
                    <Radio className="w-3 h-3 text-sky-600 animate-pulse" />
                  ) : (currentStudent.mode || studentBatch?.mode) === 'hybrid' ? (
                    <Sparkles className="w-3 h-3 text-purple-600" />
                  ) : (
                    <Building2 className="w-3 h-3 text-indigo-600" />
                  )}
                  <span>
                    {(currentStudent.mode || studentBatch?.mode) === 'online' ? 'Online Live' : (currentStudent.mode || studentBatch?.mode) === 'hybrid' ? 'Hybrid' : 'Offline Classroom'}
                  </span>
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto justify-end flex-wrap">
          {/* Notifications Bell Button */}
          <button
            onClick={() => setShowNotificationModal(true)}
            className="relative flex items-center gap-2 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs transition cursor-pointer"
            title="Class Schedule & Postpone Alerts"
          >
            <Bell className={`w-4 h-4 ${unreadNotifs.length > 0 ? 'text-amber-600 animate-bounce' : 'text-slate-500'}`} />
            <span>Alerts</span>
            {unreadNotifs.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full bg-rose-600 text-white font-mono text-[10px] font-black animate-pulse">
                {unreadNotifs.length}
              </span>
            )}
          </button>

          <a
            id="student-dashboard-download-apk"
            href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
            download="PixelPathsala.apk"
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs shadow-sm transition transform hover:scale-[1.02] cursor-pointer"
            title="Download Official Mobile App (.apk)"
          >
            <Download className="w-4 h-4" />
            <span>Download App (.APK)</span>
          </a>

          <button
            id="student-portal-signout-btn"
            onClick={() => {
              logoutStudent();
              setActiveTab('website');
            }}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold rounded-xl text-xs transition cursor-pointer shadow-xs"
            title="Sign Out from Student Portal"
          >
            <LogOut className="w-4 h-4 text-rose-600" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* ⚠️ HIGH-PRIORITY TOP NOTIFICATION ALERT BANNER FOR STUDENT */}
      {topPriorityAlert && (
        <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-orange-600 rounded-3xl p-4 sm:p-5 text-white shadow-xl border-2 border-amber-300 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 animate-fadeIn">
          <div className="flex items-start gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-xs flex items-center justify-center shrink-0 mt-0.5 border border-white/20">
              {topPriorityAlert.type === 'class_postponed' ? (
                <AlertTriangle className="w-5 h-5 text-white animate-bounce" />
              ) : (
                <Bell className="w-5 h-5 text-white" />
              )}
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-white text-amber-900 shadow-xs">
                  {topPriorityAlert.type === 'class_postponed' ? '⚠️ Class Postponed Notice' : '📅 Class Schedule Alert'}
                </span>
                <span className="text-[11px] text-amber-100 font-mono">
                  {topPriorityAlert.createdAt}
                </span>
              </div>
              <h3 className="text-sm sm:text-base font-extrabold text-white leading-tight">
                {topPriorityAlert.title}
              </h3>
              <p className="text-xs text-amber-50 max-w-2xl leading-relaxed">
                {topPriorityAlert.message}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto justify-end shrink-0">
            <button
              onClick={() => {
                handleMarkNoticeAsRead(topPriorityAlert.id);
                setStudentActiveTab('live');
              }}
              className="px-4 py-2 bg-white hover:bg-amber-50 text-amber-900 font-extrabold rounded-xl text-xs shadow-md transition cursor-pointer flex items-center gap-1.5"
            >
              <Radio className="w-3.5 h-3.5 text-rose-600" />
              <span>View Classes Hub</span>
            </button>

            <button
              onClick={() => handleMarkNoticeAsRead(topPriorityAlert.id)}
              className="px-3 py-2 bg-white/20 hover:bg-white/30 text-white font-bold rounded-xl text-xs transition cursor-pointer"
              title="Acknowledge Alert"
            >
              Acknowledge
            </button>
          </div>
        </div>
      )}

      {/* Student Portal Tabbed Navigation */}
      <div className="flex items-center gap-2 p-1.5 bg-slate-200/80 rounded-2xl w-full overflow-x-auto">
        <button
          id="student-tab-dashboard"
          onClick={() => setStudentActiveTab('billing')}
          className={`flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shrink-0 ${
            studentActiveTab === 'billing'
              ? 'bg-white text-indigo-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>Dashboard & Fee Billing</span>
        </button>

        <button
          id="student-tab-live"
          onClick={() => setStudentActiveTab('live')}
          className={`flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shrink-0 ${
            studentActiveTab === 'live'
              ? 'bg-white text-rose-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Radio className={`w-4 h-4 ${liveClasses.some(c => c.status === 'live' && (c.batchId === 'all' || c.batchId === currentStudent?.batchId)) ? 'text-rose-600 animate-pulse' : 'text-slate-500'}`} />
          <span>Live Classes</span>
          {liveClasses.some(c => c.status === 'live' && (c.batchId === 'all' || c.batchId === currentStudent?.batchId)) && (
            <span className="px-1.5 py-0.5 text-[9px] font-black bg-rose-600 text-white rounded-md animate-pulse">
              LIVE
            </span>
          )}
        </button>

        {/* 📼 RECORDED CLASSES TAB IN MENU */}
        <button
          id="student-tab-recordings"
          onClick={() => setStudentActiveTab('recordings')}
          className={`flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shrink-0 ${
            studentActiveTab === 'recordings'
              ? 'bg-white text-indigo-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <PlayCircle className="w-4 h-4 text-indigo-600" />
          <span>Recorded Classes ({studentRecordings.length})</span>
          {studentRecordings.length > 0 && (
            <span className="px-1.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700 font-mono text-[9px] font-black">
              {studentRecordings.length}
            </span>
          )}
        </button>

        {/* 📚 STUDY MATERIAL TAB IN MENU */}
        <button
          id="student-tab-study-material"
          onClick={() => setStudentActiveTab('study-material')}
          className={`flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shrink-0 ${
            studentActiveTab === 'study-material'
              ? 'bg-white text-teal-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FolderDown className="w-4 h-4 text-teal-600" />
          <span>Study Material ({studentMaterials.length})</span>
          {studentMaterials.length > 0 && (
            <span className="px-1.5 py-0.5 rounded-full bg-teal-100 text-teal-800 font-mono text-[9px] font-black">
              {studentMaterials.length}
            </span>
          )}
        </button>

        <button
          id="student-tab-notices"
          onClick={() => setStudentActiveTab('notices')}
          className={`flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shrink-0 ${
            studentActiveTab === 'notices'
              ? 'bg-white text-amber-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Bell className={`w-4 h-4 ${unreadNotifs.length > 0 ? 'text-amber-600 animate-pulse' : 'text-slate-500'}`} />
          <span>Class Notices ({studentNotifs.length})</span>
          {unreadNotifs.length > 0 && (
            <span className="px-1.5 py-0.5 rounded-full bg-rose-600 text-white font-mono text-[9px] font-black">
              {unreadNotifs.length}
            </span>
          )}
        </button>

        <button
          id="student-tab-codezone"
          onClick={() => setStudentActiveTab('codezone')}
          className={`flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shrink-0 ${
            studentActiveTab === 'codezone'
              ? 'bg-white text-violet-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Code2 className="w-4 h-4 text-violet-600" />
          <span>Codezone Workspace</span>
        </button>

        <button
          id="student-tab-exams"
          onClick={() => setStudentActiveTab('exams')}
          className={`flex items-center gap-2 px-4 sm:px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shrink-0 ${
            studentActiveTab === 'exams'
              ? 'bg-white text-indigo-600 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileQuestion className="w-4 h-4 text-indigo-600" />
          <span>Online Exam & Tests</span>
        </button>
      </div>

      {/* TAB 1: DASHBOARD & FEE BILLING */}
      {studentActiveTab === 'billing' && (
        <div className="space-y-8">
          {/* Financial Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Total Fees Since Admission</span>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">
            ₹{billingSummary.totalPayableSinceAdmission.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">From {formatMonthKey(currentStudent.admissionMonth)}</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-emerald-700 font-medium flex items-center gap-1">
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Total Paid Amount</span>
          </span>
          <div className="text-2xl font-black text-emerald-700 font-mono mt-1">
            ₹{billingSummary.totalPaid.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Verified & Approved receipts</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
          <span className="text-xs text-amber-700 font-medium flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            <span>Pending Approvals</span>
          </span>
          <div className="text-2xl font-black text-amber-600 font-mono mt-1">
            ₹{billingSummary.totalPendingApproval.toLocaleString('en-IN')}
          </div>
          <span className="text-[11px] text-slate-400 mt-1 block">Under review by Center Admin</span>
        </div>

        <div className={`p-5 rounded-2xl border shadow-xs flex flex-col justify-between ${
          billingSummary.totalDueAmount > 0 
            ? 'bg-red-50/70 border-red-200 text-red-900' 
            : 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
        }`}>
          <div>
            <span className="text-xs font-bold uppercase tracking-wider">
              {billingSummary.totalDueAmount > 0 ? 'Outstanding Dues' : 'Fee Status'}
            </span>
            <div className="text-2xl font-black font-mono mt-1">
              {billingSummary.totalDueAmount > 0 
                ? `₹${billingSummary.totalDueAmount.toLocaleString('en-IN')}` 
                : 'All Cleared! 🎉'}
            </div>
          </div>

          {billingSummary.totalDueAmount > 0 && (
            <button
              id="btn-pay-due-now"
              onClick={handleOpenPaymentModal}
              className="mt-3 w-full py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-sm transition cursor-pointer flex items-center justify-center gap-1"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Pay Due Amount</span>
            </button>
          )}
        </div>
      </div>

          {/* Targeted Live Class & Schedule Widget for Enrolled Batch */}
          {(() => {
            const targetedLiveClasses = liveClasses.filter(c => {
              if (!currentStudent) return false;
              const matchesBatch = c.batchId === 'all' || c.batchId === currentStudent.batchId;
              const matchesCourse = !c.courseId || c.courseId === 'all' || c.courseId === currentStudent.courseId;
              return matchesBatch && matchesCourse;
            });

            const nowLive = targetedLiveClasses.filter(c => c.status === 'live');
            const upcoming = targetedLiveClasses.filter(c => c.status === 'scheduled');

            return (
              <div className="space-y-4">
                {/* 🔴 LIVE CLASS HAPPENING NOW ALERT */}
                {nowLive.length > 0 && (
                  <div className="bg-gradient-to-r from-rose-600 via-red-600 to-indigo-700 rounded-3xl p-6 text-white shadow-xl shadow-rose-900/20 border-2 border-rose-400 flex flex-col md:flex-row justify-between items-start md:items-center gap-5">
                    <div className="space-y-2 max-w-xl">
                      <div className="flex items-center gap-2">
                        <span className="px-3 py-1 rounded-full text-xs font-black bg-white text-rose-700 animate-pulse flex items-center gap-1.5 shadow-md">
                          <span className="w-2.5 h-2.5 rounded-full bg-rose-600"></span>
                          LIVE CLASS HAPPENING NOW
                        </span>
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-white/20 text-white backdrop-blur-xs">
                          {studentBatch?.name || 'Your Batch'}
                        </span>
                      </div>
                      <h3 className="text-xl sm:text-2xl font-black text-white leading-tight">
                        {nowLive[0].title}
                      </h3>
                      <p className="text-xs text-rose-100 flex items-center gap-2">
                        <BookOpen className="w-4 h-4" />
                        <span>{nowLive[0].subject}</span>
                        <span>•</span>
                        <GraduationCap className="w-4 h-4" />
                        <span>Faculty: <strong>{nowLive[0].educatorName}</strong></span>
                        <span>•</span>
                        <Clock className="w-3.5 h-3.5" />
                        <span>{nowLive[0].startTime} - {nowLive[0].endTime}</span>
                      </p>
                    </div>

                    <div className="flex items-center gap-3 w-full md:w-auto shrink-0">
                      <a
                        href={nowLive[0].meetingUrl || '#'}
                        target="_blank"
                        rel="noreferrer"
                        className="flex-1 md:flex-none px-6 py-3.5 bg-white hover:bg-slate-100 text-rose-700 font-extrabold rounded-2xl text-sm shadow-xl transition transform hover:scale-105 flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Tv className="w-5 h-5 text-rose-600 animate-bounce" />
                        <span>Join Live Classroom</span>
                      </a>
                      <button
                        onClick={() => setStudentActiveTab('live')}
                        className="px-4 py-3.5 bg-white/15 hover:bg-white/25 text-white font-bold rounded-2xl text-xs transition cursor-pointer"
                      >
                        Live Hub &rarr;
                      </button>
                    </div>
                  </div>
                )}

                {/* UPCOMING SCHEDULED CLASS OR BATCH SCHEDULE BANNER */}
                {nowLive.length === 0 && (
                  <div className="bg-white rounded-3xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div className="flex items-start sm:items-center gap-3.5">
                      <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl shrink-0">
                        <Radio className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black uppercase tracking-wider text-indigo-600">
                            Batch Live Schedule & Classes
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700">
                            {studentBatch?.name || 'Assigned Batch'}
                          </span>
                        </div>

                        {upcoming.length > 0 ? (
                          <div className="mt-1">
                            <h4 className="text-sm sm:text-base font-extrabold text-slate-900">
                              Next Live Class: {upcoming[0].title}
                            </h4>
                            <p className="text-xs text-slate-500 mt-0.5 flex flex-wrap items-center gap-2">
                              <span className="text-indigo-600 font-semibold">{upcoming[0].subject}</span>
                              <span>•</span>
                              <span className="flex items-center gap-1 font-mono font-medium text-slate-700">
                                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                                {upcoming[0].scheduledDate} ({upcoming[0].startTime} - {upcoming[0].endTime})
                              </span>
                              <span>•</span>
                              <span>Faculty: {upcoming[0].educatorName}</span>
                            </p>
                          </div>
                        ) : (
                          <div className="mt-1">
                            <h4 className="text-sm font-bold text-slate-800">
                              Regular Schedule: {studentBatch?.scheduleDays ? studentBatch.scheduleDays.join(', ') : 'Weekly'}{' '}
                              {studentBatch?.timing ? `(${studentBatch.timing})` : ''}
                            </h4>
                            <p className="text-xs text-slate-500 mt-0.5">
                              No special live masterclasses currently active. You can browse all previous recorded lectures in the Live Hub.
                            </p>
                          </div>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => setStudentActiveTab('live')}
                      className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition cursor-pointer shrink-0 flex items-center gap-1.5 shadow-sm"
                    >
                      <Radio className="w-3.5 h-3.5" />
                      <span>{upcoming.length > 0 ? 'View Full Schedule & Link' : 'Open Live Hub & Recordings'}</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })()}

          {/* Batch Study Materials & Handouts Section */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <FolderDown className="w-5 h-5 text-indigo-600" />
                <span>Batch Study Material & Handouts</span>
              </h2>
              {studentMaterials.length > 0 && (
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800">
                  {studentMaterials.length} Files
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Course notes, PDF handouts, homework assignments, and resource links uploaded for <strong className="text-slate-800">{studentBatch?.name || 'Your Batch'}</strong>.
            </p>
          </div>

          <div className="text-xs text-slate-500 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 flex items-center gap-1.5 font-medium">
            <Layers className="w-3.5 h-3.5 text-indigo-600" />
            <span>Batch: <strong className="text-slate-900 font-bold">{studentBatch?.name || 'Enrolled Batch'}</strong></span>
          </div>
        </div>

        {studentMaterials.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
            {studentMaterials.map((mat) => {
              const isLink = mat.fileType === 'link';

              return (
                <div
                  key={mat.id}
                  className="bg-slate-50/70 hover:bg-white border border-slate-200 hover:border-indigo-300 rounded-2xl p-4.5 shadow-2xs hover:shadow-md transition flex flex-col justify-between group"
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-indigo-600 shadow-2xs">
                        {mat.fileType === 'pdf' ? (
                          <FileText className="w-5 h-5 text-red-600" />
                        ) : mat.fileType === 'doc' ? (
                          <FileText className="w-5 h-5 text-blue-600" />
                        ) : mat.fileType === 'zip' ? (
                          <FileArchive className="w-5 h-5 text-amber-600" />
                        ) : mat.fileType === 'link' ? (
                          <Link2 className="w-5 h-5 text-emerald-600" />
                        ) : (
                          <FileCode className="w-5 h-5 text-indigo-600" />
                        )}
                      </div>

                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-white border border-slate-200 text-slate-600">
                        {mat.fileType}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-bold text-slate-900 text-sm leading-snug line-clamp-2 group-hover:text-indigo-600 transition-colors">
                        {mat.title}
                      </h4>
                      {mat.subject && (
                        <span className="inline-block text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded mt-1">
                          {mat.subject}
                        </span>
                      )}
                    </div>

                    {mat.description && (
                      <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                        {mat.description}
                      </p>
                    )}
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200/80 flex items-center justify-between">
                    <div className="text-[11px] text-slate-400">
                      <span>{mat.fileSize || 'PDF Document'}</span>
                      {mat.uploadedDate && (
                        <span className="block text-[10px] text-slate-400">{mat.uploadedDate}</span>
                      )}
                    </div>

                    <button
                      onClick={() => downloadStudyMaterial(mat)}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-xs flex items-center gap-1.5"
                    >
                      {isLink ? <ExternalLink className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
                      <span>{isLink ? 'Open Link' : 'Download'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-center text-slate-400">
            <FolderDown className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="font-bold text-slate-700 text-sm">No Study Materials Uploaded Yet</h4>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Your educator or center administrator has not published files for {studentBatch?.name || 'this batch'} yet. Check back soon for notes and handouts!
            </p>
          </div>
        )}
      </div>

      {/* Month-wise Billing Timeline & Dues */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-600" />
              <span>Month-by-Month Fee Schedule</span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Fee charged for each month starting from your admission month ({formatMonthKey(currentStudent.admissionMonth)}).
            </p>
          </div>

          {billingSummary.totalDueAmount > 0 && (
            <button
              onClick={handleOpenPaymentModal}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md transition cursor-pointer flex items-center gap-1.5"
            >
              <CreditCard className="w-4 h-4" />
              <span>Pay Due Balance (₹{billingSummary.totalDueAmount})</span>
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <th className="p-3">Billing Month</th>
                <th className="p-3">Standard Monthly Fee</th>
                <th className="p-3">Discount Applied</th>
                <th className="p-3">Net Fee</th>
                <th className="p-3">Payment Status</th>
                <th className="p-3 text-right">Receipt & Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {billingSummary.monthlyStatuses.map((m) => (
                <tr key={m.monthKey} className="hover:bg-slate-50/50">
                  <td className="p-3 font-semibold text-slate-900">
                    {m.monthLabel}
                  </td>
                  <td className="p-3 font-mono text-slate-600">
                    ₹{m.baseFee}
                  </td>
                  <td className="p-3 font-mono text-emerald-600">
                    {m.discountAmount > 0 ? (
                      <div>
                        <span>-₹{m.discountAmount}</span>
                        {m.discountNote && <span className="block text-[10px] text-slate-400 font-sans">{m.discountNote}</span>}
                      </div>
                    ) : (
                      '—'
                    )}
                  </td>
                  <td className="p-3 font-mono font-bold text-slate-900">
                    ₹{m.netFeeDue}
                  </td>
                  <td className="p-3">
                    {m.isPaid ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold bg-emerald-100 text-emerald-800 border border-emerald-300">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Fully Paid</span>
                      </span>
                    ) : m.isPendingApproval ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold bg-amber-100 text-amber-800 border border-amber-300">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        <span>Pending Admin Approval</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-extrabold bg-red-100 text-red-800 border border-red-300">
                        <AlertCircle className="w-3.5 h-3.5 text-red-600" />
                        <span>Due: ₹{m.netFeeDue}</span>
                      </span>
                    )}
                  </td>
                  <td className="p-3 text-right">
                    {m.isPaid && m.paymentId ? (
                      <button
                        onClick={() => {
                          const p = payments.find(pay => pay.id === m.paymentId);
                          if (p) setSelectedReceiptForPrint(p);
                        }}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-lg text-xs transition cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print Receipt</span>
                      </button>
                    ) : !m.isPaid && !m.isPendingApproval ? (
                      <button
                        onClick={() => {
                          setSelectedMonthsToPay([m.monthKey]);
                          setShowPayModal(true);
                        }}
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-xs transition cursor-pointer"
                      >
                        <span>Pay ₹{m.netFeeDue}</span>
                      </button>
                    ) : (
                      <span className="text-xs text-slate-400 italic">Processing</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment History Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm">
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 mb-4">
          <Receipt className="w-5 h-5 text-indigo-600" />
          <span>Payment History & Receipts</span>
        </h2>

        {studentPayments.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <th className="p-3">Receipt No</th>
                  <th className="p-3">Billing Months</th>
                  <th className="p-3">Amount Paid</th>
                  <th className="p-3">Mode & UTR</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">A4 Receipt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {studentPayments.map((pay) => (
                  <tr key={pay.id} className="hover:bg-slate-50/50">
                    <td className="p-3 font-mono font-bold text-indigo-900">
                      {pay.receiptNo}
                    </td>
                    <td className="p-3 font-semibold text-slate-800">
                      {pay.month}
                    </td>
                    <td className="p-3 font-mono font-bold text-slate-900">
                      ₹{pay.finalAmountPaid.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded font-mono text-xs">
                        {pay.paymentMode}
                      </span>
                      {pay.transactionRef && (
                        <span className="block text-[11px] text-slate-500 font-mono mt-0.5">
                          {pay.transactionRef}
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-slate-600">
                      {pay.paymentDate}
                    </td>
                    <td className="p-3">
                      {pay.status === 'approved' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Approved</span>
                        </span>
                      ) : pay.status === 'pending' ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Pending Approval</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-800" title={pay.rejectionReason}>
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Rejected: {pay.rejectionReason}</span>
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-right">
                      {pay.status === 'approved' && (
                        <button
                          onClick={() => setSelectedReceiptForPrint(pay)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs transition cursor-pointer shadow-xs"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>Print A4</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center text-slate-400 italic">
            No payment records found yet.
          </div>
        )}
      </div>
    </div>
  )}

  {/* TAB 2: LIVE CLASSES & SCHEDULE */}
  {studentActiveTab === 'live' && (
    <div className="space-y-6">
      <StudentLiveClassPortal />
    </div>
  )}

  {/* TAB: RECORDED CLASSES (CLASS-WISE FROM DATABASE) */}
  {studentActiveTab === 'recordings' && (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 flex items-center gap-1.5">
              <Film className="w-3.5 h-3.5 text-indigo-400" />
              <span>Admission Standard: {studentActualClass}</span>
            </span>
            <span className="text-xs text-slate-300">
              Batch: <strong className="text-white">{studentBatch?.name || 'Enrolled Batch'}</strong>
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Class-Wise Recorded Video Lectures
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Re-watch past classroom lectures, revision sessions, practical demonstrations, and problem-solving walkthroughs uploaded specifically for <strong className="text-white">{studentActualClass}</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-white/10 px-4 py-2.5 rounded-2xl shrink-0 backdrop-blur-xs border border-white/15">
          <PlayCircle className="w-5 h-5 text-indigo-400" />
          <div>
            <div className="text-lg font-black text-white font-mono leading-none">
              {studentRecordings.length}
            </div>
            <div className="text-[10px] text-slate-300 uppercase tracking-wider font-semibold">
              Available Lectures
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={recordingSearchQuery}
              onChange={(e) => setRecordingSearchQuery(e.target.value)}
              placeholder="Search lectures by topic, chapter, title, faculty..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs sm:text-sm"
            />
            {recordingSearchQuery && (
              <button
                onClick={() => setRecordingSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 shrink-0">
            <Filter className="w-3.5 h-3.5 text-indigo-600" />
            <span>Class Filter:</span>
            <span className="font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200">
              {studentActualClass}
            </span>
          </div>
        </div>

        {/* Subject Filter Pills */}
        {recordingSubjects.length > 0 && (
          <div className="flex items-center gap-2 overflow-x-auto pt-1 pb-1">
            <span className="text-xs font-bold text-slate-600 shrink-0">Subjects:</span>
            <button
              onClick={() => setRecordingSelectedSubject('all')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 ${
                recordingSelectedSubject === 'all'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              All Subjects ({studentRecordings.length})
            </button>
            {recordingSubjects.map(sub => {
              const count = studentRecordings.filter(r => r.subject === sub).length;
              return (
                <button
                  key={sub}
                  onClick={() => setRecordingSelectedSubject(sub)}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 ${
                    recordingSelectedSubject === sub
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {sub} ({count})
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Active Video Player Modal */}
      {activeRecordingVideo && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="bg-slate-900 rounded-3xl border border-slate-800 shadow-2xl max-w-4xl w-full overflow-hidden flex flex-col max-h-[92vh]">
            <div className="p-4 sm:p-5 bg-slate-950 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2 overflow-hidden">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-rose-600 text-white shrink-0">
                  {activeRecordingVideo.targetClass || activeRecordingVideo.academicClass || studentActualClass}
                </span>
                <h3 className="font-bold text-white text-sm sm:text-base truncate">
                  {activeRecordingVideo.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveRecordingVideo(null)}
                className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition cursor-pointer shrink-0 ml-2"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Video Viewport */}
            <div className="relative aspect-video w-full bg-black">
              {activeRecordingVideo.videoUrl ? (
                activeRecordingVideo.videoSourceType === 'mp4' ? (
                  <video
                    src={activeRecordingVideo.videoUrl}
                    controls
                    autoPlay
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <iframe
                    src={getRecordingEmbedUrl(activeRecordingVideo.videoUrl, activeRecordingVideo.videoSourceType)}
                    title={activeRecordingVideo.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowFullScreen
                    className="w-full h-full border-0"
                  />
                )
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-slate-400 p-6 text-center">
                  <Film className="w-12 h-12 text-slate-600 mb-2" />
                  <p className="text-sm font-semibold">Video stream link not configured.</p>
                </div>
              )}
            </div>

            {/* Video Details Bar */}
            <div className="p-4 sm:p-5 bg-slate-900 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-semibold text-indigo-400">
                    Subject: {activeRecordingVideo.subject || 'General'}
                  </span>
                  {activeRecordingVideo.chapter && (
                    <span className="text-xs text-slate-400">• Chapter: {activeRecordingVideo.chapter}</span>
                  )}
                  {activeRecordingVideo.topic && (
                    <span className="text-xs text-slate-400">• Topic: {activeRecordingVideo.topic}</span>
                  )}
                </div>
                <div className="text-xs text-slate-400">
                  Faculty: <strong className="text-slate-200">{activeRecordingVideo.educatorName || 'Faculty'}</strong> • Recorded: <span className="font-mono text-slate-300">{activeRecordingVideo.recordedDate}</span> • Duration: {activeRecordingVideo.durationMinutes} mins
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {activeRecordingVideo.notesPdfUrl && (
                  <a
                    href={activeRecordingVideo.notesPdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-sm"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Notes</span>
                  </a>
                )}
                {activeRecordingVideo.videoUrl && (
                  <a
                    href={activeRecordingVideo.videoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition cursor-pointer flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open in New Tab</span>
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Recordings Grid */}
      {filteredRecordings.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredRecordings.map((rec) => (
            <div
              key={rec.id}
              className="bg-white rounded-3xl border border-slate-200 hover:border-indigo-400 shadow-xs hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col justify-between group"
            >
              <div>
                {/* Thumbnail / Header Box */}
                <div
                  onClick={() => {
                    setActiveRecordingVideo(rec);
                    incrementRecordingViews(rec.id);
                  }}
                  className="relative aspect-video bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 cursor-pointer flex items-center justify-center group-hover:brightness-105 transition"
                >
                  <div className="w-14 h-14 rounded-full bg-rose-600/90 group-hover:bg-rose-600 text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition duration-300 ring-4 ring-white/20">
                    <Play className="w-6 h-6 ml-1 text-white fill-current" />
                  </div>

                  <div className="absolute top-3 left-3 flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-black/60 text-indigo-300 backdrop-blur-xs border border-white/10">
                      {rec.targetClass || rec.academicClass || studentActualClass}
                    </span>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-rose-600/90 text-white backdrop-blur-xs">
                      {rec.subject || 'Core'}
                    </span>
                  </div>

                  <div className="absolute bottom-3 right-3 flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-black/70 text-white backdrop-blur-xs">
                      {rec.durationMinutes || 60} mins
                    </span>
                  </div>
                </div>

                <div className="p-5 space-y-2.5">
                  <div>
                    <h3
                      onClick={() => {
                        setActiveRecordingVideo(rec);
                        incrementRecordingViews(rec.id);
                      }}
                      className="font-extrabold text-slate-900 text-base leading-snug line-clamp-2 group-hover:text-indigo-600 transition cursor-pointer"
                    >
                      {rec.title}
                    </h3>
                    {(rec.chapter || rec.topic) && (
                      <p className="text-xs text-indigo-600 font-semibold mt-1">
                        {rec.chapter ? `${rec.chapter}: ` : ''}{rec.topic || ''}
                      </p>
                    )}
                  </div>

                  <div className="text-xs text-slate-500 space-y-1">
                    <div className="flex items-center gap-1.5 text-slate-700">
                      <GraduationCap className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                      <span className="font-semibold truncate">{rec.educatorName || 'Senior Faculty'}</span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-100">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 dust h-3" />
                        <span>{rec.recordedDate}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        <span>{(rec.viewCount || 0) + 1} views</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-5 pt-0 flex items-center justify-between gap-2 border-t border-slate-100 mt-2">
                <button
                  onClick={() => {
                    setActiveRecordingVideo(rec);
                    incrementRecordingViews(rec.id);
                  }}
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Watch Lecture</span>
                </button>

                {rec.notesPdfUrl && (
                  <a
                    href={rec.notesPdfUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs transition cursor-pointer shrink-0"
                    title="Download Accompanying PDF Notes"
                  >
                    <Download className="w-4 h-4 text-slate-600" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-dashed border-slate-200 p-12 text-center space-y-3">
          <Film className="w-12 h-12 text-slate-300 mx-auto" />
          <h4 className="text-base font-bold text-slate-800">
            {recordingSearchQuery ? 'No Matching Recorded Classes Found' : `No Recorded Classes Uploaded for ${studentActualClass} Yet`}
          </h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {recordingSearchQuery
              ? `No recordings matched "${recordingSearchQuery}". Try clearing search filters.`
              : `Lectures recorded by faculty for ${studentActualClass} will appear here automatically. Check back after your next live session.`}
          </p>
          {recordingSearchQuery && (
            <button
              onClick={() => {
                setRecordingSearchQuery('');
                setRecordingSelectedSubject('all');
              }}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
            >
              Reset Search Filter
            </button>
          )}
        </div>
      )}
    </div>
  )}

  {/* TAB: STUDY MATERIAL (CLASS-WISE FROM DATABASE) */}
  {studentActiveTab === 'study-material' && (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-teal-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-teal-500/20 text-teal-300 border border-teal-400/30 flex items-center gap-1.5">
              <FolderDown className="w-3.5 h-3.5 text-teal-400" />
              <span>Admission Standard: {studentActualClass}</span>
            </span>
            <span className="text-xs text-slate-300">
              Batch: <strong className="text-white">{studentBatch?.name || 'Enrolled Batch'}</strong>
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Class-Wise Study Material & Handouts
          </h2>
          <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
            Course notes, PDF handouts, chapter summaries, homework assignments, and resource links curated specifically for <strong className="text-white">{studentActualClass}</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-white/10 px-4 py-2.5 rounded-2xl shrink-0 backdrop-blur-xs border border-white/15">
          <FolderDown className="w-5 h-5 text-teal-400" />
          <div>
            <div className="text-lg font-black text-white font-mono leading-none">
              {studentMaterials.length}
            </div>
            <div className="text-[10px] text-slate-300 uppercase tracking-wider font-semibold">
              Study Files
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={materialSearchQuery}
              onChange={(e) => setMaterialSearchQuery(e.target.value)}
              placeholder="Search notes, PDF handouts, homework, topics..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 text-xs sm:text-sm"
            />
            {materialSearchQuery && (
              <button
                onClick={() => setMaterialSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                Clear
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-500 shrink-0">
            <Filter className="w-3.5 h-3.5 text-teal-600" />
            <span>Class Filter:</span>
            <span className="font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-lg border border-teal-200">
              {studentActualClass}
            </span>
          </div>
        </div>

        {/* File Type Filters & Subject Filters */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100">
          {materialSubjects.length > 0 && (
            <div className="flex items-center gap-1.5 overflow-x-auto">
              <span className="text-xs font-bold text-slate-600 shrink-0">Subject:</span>
              <button
                onClick={() => setMaterialSelectedSubject('all')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 ${
                  materialSelectedSubject === 'all'
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                All ({studentMaterials.length})
              </button>
              {materialSubjects.map(sub => {
                const count = studentMaterials.filter(m => m.subject === sub).length;
                return (
                  <button
                    key={sub}
                    onClick={() => setMaterialSelectedSubject(sub)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 ${
                      materialSelectedSubject === sub
                        ? 'bg-teal-600 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {sub} ({count})
                  </button>
                );
              })}
            </div>
          )}

          <div className="flex items-center gap-1.5 overflow-x-auto">
            <span className="text-xs font-bold text-slate-600 shrink-0">Type:</span>
            {['all', 'pdf', 'link', 'doc', 'zip'].map(type => (
              <button
                key={type}
                onClick={() => setMaterialTypeFilter(type)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase transition cursor-pointer shrink-0 ${
                  materialTypeFilter === type
                    ? 'bg-slate-800 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {type === 'all' ? 'All Types' : type}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Materials Cards Grid */}
      {filteredMaterials.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredMaterials.map((mat) => {
            const isLink = mat.fileType === 'link';

            return (
              <div
                key={mat.id}
                className="bg-white rounded-3xl border border-slate-200 hover:border-teal-400 p-5 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="w-12 h-12 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-teal-600 group-hover:bg-teal-50 transition shadow-2xs">
                      {mat.fileType === 'pdf' ? (
                        <FileText className="w-6 h-6 text-red-600" />
                      ) : mat.fileType === 'doc' ? (
                        <FileText className="w-6 h-6 text-blue-600" />
                      ) : mat.fileType === 'zip' ? (
                        <FileArchive className="w-6 h-6 text-amber-600" />
                      ) : mat.fileType === 'link' ? (
                        <Link2 className="w-6 h-6 text-emerald-600" />
                      ) : (
                        <FileCode className="w-6 h-6 text-indigo-600" />
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-teal-50 text-teal-800 border border-teal-200">
                        {studentActualClass}
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                        {mat.fileType}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-extrabold text-slate-900 text-base leading-snug line-clamp-2 group-hover:text-teal-700 transition-colors">
                      {mat.title}
                    </h4>
                    {mat.subject && (
                      <span className="inline-block text-[10px] font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded-md mt-1 border border-teal-200">
                        {mat.subject}
                      </span>
                    )}
                  </div>

                  {mat.description ? (
                    <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                      {mat.description}
                    </p>
                  ) : (
                    <p className="text-xs text-slate-400 italic">
                      Class study material and learning handout
                    </p>
                  )}
                </div>

                <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between gap-3">
                  <div className="text-[11px] text-slate-400">
                    <span className="font-mono">{mat.fileSize || 'PDF Document'}</span>
                    {mat.uploadedDate && (
                      <span className="block text-[10px] text-slate-400">{mat.uploadedDate}</span>
                    )}
                  </div>

                  <button
                    onClick={() => downloadStudyMaterial(mat)}
                    className="px-4 py-2 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-xs flex items-center gap-1.5"
                  >
                    {isLink ? <ExternalLink className="w-3.5 h-3.5" /> : <Download className="w-3.5 h-3.5" />}
                    <span>{isLink ? 'Open Link' : 'Download'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-dashed border-slate-200 p-12 text-center space-y-3">
          <FolderDown className="w-12 h-12 text-slate-300 mx-auto" />
          <h4 className="text-base font-bold text-slate-800">
            {materialSearchQuery ? 'No Matching Study Material Found' : `No Study Materials Uploaded for ${studentActualClass} Yet`}
          </h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {materialSearchQuery
              ? `No resources matched "${materialSearchQuery}". Try clearing search filters.`
              : `Handouts, notes, and revision sheets for ${studentActualClass} will appear here when uploaded by faculty.`}
          </p>
          {materialSearchQuery && (
            <button
              onClick={() => {
                setMaterialSearchQuery('');
                setMaterialSelectedSubject('all');
                setMaterialTypeFilter('all');
              }}
              className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs transition cursor-pointer"
            >
              Reset Search Filter
            </button>
          )}
        </div>
      )}
    </div>
  )}

  {/* TAB 3: CODEZONE WORKSPACE */}
  {studentActiveTab === 'codezone' && (
    <div className="space-y-6">
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-violet-50 text-violet-600 rounded-2xl">
            <Code2 className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-lg">
              Student Codezone & Practice IDE
            </h3>
            <p className="text-xs text-slate-500">
              Interactive coding compiler for C, Python, JavaScript, and SQL with curated test cases.
            </p>
          </div>
        </div>
      </div>

      <Playzone />
    </div>
  )}

  {/* TAB 3: ONLINE EXAM & TESTS */}
  {studentActiveTab === 'exams' && (
    <div className="space-y-6">
      <StudentOnlineExam />
    </div>
  )}

  {/* TAB 4: CLASS NOTICES & TIMETABLE ANNOUNCEMENTS */}
  {studentActiveTab === 'notices' && (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-amber-500/20 text-amber-300 border border-amber-400/30 flex items-center gap-1.5">
              <Bell className="w-3.5 h-3.5 text-amber-400" />
              Student Notice Board
            </span>
            <span className="text-xs text-slate-300">
              Batch: <strong className="text-white">{studentBatch?.name || 'Assigned Batch'}</strong>
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white">
            Class Schedule & Postponement Notices
          </h2>
          <p className="text-xs text-slate-300 max-w-xl">
            Real-time administrative notices, timetable alerts, faculty leaves, and rescheduled class timings broadcasted directly to your account.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0 flex-wrap">
          {unreadNotifs.length > 0 && (
            <button
              onClick={handleMarkAllNoticesAsRead}
              className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 border border-white/10"
            >
              <Check className="w-3.5 h-3.5 text-emerald-300" />
              <span>Mark All as Read</span>
            </button>
          )}

          <button
            onClick={() => setStudentActiveTab('live')}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-md shadow-indigo-600/30"
          >
            <Radio className="w-3.5 h-3.5 text-rose-400" />
            <span>Go to Live Hub</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2 overflow-x-auto">
          {[
            { id: 'all', label: `All Notices (${studentNotifs.length})` },
            { id: 'postponed', label: `⚠️ Postponed Classes (${studentNotifs.filter(n => n.type === 'class_postponed').length})` },
            { id: 'scheduled', label: `📅 Schedules (${studentNotifs.filter(n => n.type === 'class_scheduled').length})` }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setNoticeFilterType(f.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer shrink-0 ${
                noticeFilterType === f.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <span className="text-xs text-slate-500 font-medium">
          {unreadNotifs.length} unread notification{unreadNotifs.length === 1 ? '' : 's'}
        </span>
      </div>

      {/* Notice Cards List */}
      {(() => {
        const filteredList = studentNotifs.filter(n => {
          if (noticeFilterType === 'postponed') return n.type === 'class_postponed';
          if (noticeFilterType === 'scheduled') return n.type === 'class_scheduled';
          return true;
        });

        if (filteredList.length === 0) {
          return (
            <div className="bg-white p-12 rounded-3xl border border-slate-200 text-center space-y-3">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center">
                <Bell className="w-6 h-6" />
              </div>
              <h4 className="font-extrabold text-slate-800 text-sm">No Notices Found</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                No class postponement or schedule alerts are active under this filter. You are all set!
              </p>
            </div>
          );
        }

        return (
          <div className="space-y-4">
            {filteredList.map((notif) => {
              const isUnread = !notif.readBy?.includes(currentStudent.id) && !readNotifIds.includes(notif.id);
              const isPostponed = notif.type === 'class_postponed';
              const session = notif.classSessionId ? liveClasses.find(s => s.id === notif.classSessionId) : null;
              const sessionLink = session?.meetingUrl || session?.meetingLink;

              return (
                <div
                  key={notif.id}
                  className={`rounded-3xl p-5 sm:p-6 border transition flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 ${
                    isPostponed
                      ? 'bg-amber-50/70 border-amber-300 shadow-xs'
                      : isUnread
                      ? 'bg-indigo-50/50 border-indigo-200 shadow-xs'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="space-y-2 max-w-2xl">
                    <div className="flex items-center gap-2">
                      {isPostponed ? (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase bg-amber-500 text-white flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          CLASS POSTPONED
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-indigo-100 text-indigo-700">
                          CLASS SCHEDULED
                        </span>
                      )}

                      <span className="text-[11px] font-mono text-slate-500">
                        {notif.createdAt}
                      </span>

                      {isUnread && (
                        <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-rose-600 text-white animate-pulse">
                          NEW
                        </span>
                      )}
                    </div>

                    <h4 className="text-base font-extrabold text-slate-900 leading-snug">
                      {notif.title}
                    </h4>

                    <p className="text-xs text-slate-700 leading-relaxed">
                      {notif.message}
                    </p>

                    {/* Rescheduled or timeSlot box */}
                    {(notif.rescheduledDate || notif.timeSlot || sessionLink) && (
                      <div className="p-3 bg-white/80 rounded-2xl border border-slate-200/80 text-xs text-slate-800 space-y-1">
                        {notif.rescheduledDate && (
                          <div className="font-extrabold text-amber-950 flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-amber-600" />
                            <span>👉 Rescheduled Date: {notif.rescheduledDate}</span>
                          </div>
                        )}
                        {notif.timeSlot && (
                          <div className="text-[11px] text-slate-600">
                            Timing Slot: <strong>{notif.timeSlot}</strong>
                          </div>
                        )}
                        {notif.reason && (
                          <div className="text-[11px] text-slate-500">
                            Reason: <em>{notif.reason}</em>
                          </div>
                        )}
                        {sessionLink && !isPostponed && (
                          <div className="pt-1 flex items-center gap-2">
                            <a
                              href={sessionLink}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-[11px] font-bold transition shadow-xs"
                            >
                              <Radio className="w-3 h-3 animate-pulse" />
                              <span>Join Session Link</span>
                            </a>
                            <span className="text-[10px] text-slate-400 font-mono">
                              Platform: {session?.platform === 'google_meet' ? 'Google Meet' : session?.platform === 'zoom' ? 'Zoom' : 'Live Classroom'}
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end gap-2 w-full sm:w-auto shrink-0 justify-between sm:justify-start">
                    {isUnread && (
                      <button
                        onClick={() => handleMarkNoticeAsRead(notif.id)}
                        className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
                      >
                        Acknowledge
                      </button>
                    )}

                    <button
                      onClick={() => setStudentActiveTab('live')}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-medium transition cursor-pointer flex items-center gap-1"
                    >
                      <Radio className="w-3 h-3 text-rose-500" />
                      <span>Check Timetable</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        );
      })()}
    </div>
  )}

  {/* NOTIFICATION QUICK MODAL / DRAWER */}
  {showNotificationModal && (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-5 max-h-[85vh] overflow-y-auto">
        <div className="flex items-start justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">
                Class Notices & Alerts ({studentNotifs.length})
              </h3>
              <p className="text-xs text-slate-500">
                Batch: {studentBatch?.name || 'Assigned Batch'}
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowNotificationModal(false)}
            className="text-slate-400 hover:text-slate-600 p-1 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {studentNotifs.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs">
            No active notices for your batch right now.
          </div>
        ) : (
          <div className="space-y-3">
            {studentNotifs.map(n => {
              const isUnread = !n.readBy?.includes(currentStudent.id) && !readNotifIds.includes(n.id);
              return (
                <div
                  key={n.id}
                  className={`p-4 rounded-2xl border text-xs space-y-1.5 ${
                    n.type === 'class_postponed'
                      ? 'bg-amber-50 border-amber-300'
                      : isUnread
                      ? 'bg-indigo-50/50 border-indigo-200'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-slate-900 text-xs">
                      {n.title}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {n.createdAt}
                    </span>
                  </div>
                  <p className="text-slate-600 text-[11px] leading-relaxed">
                    {n.message}
                  </p>
                  {isUnread && (
                    <div className="pt-1 flex justify-end">
                      <button
                        onClick={() => handleMarkNoticeAsRead(n.id)}
                        className="text-[10px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                      >
                        Mark as Read ✓
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
          {unreadNotifs.length > 0 && (
            <button
              onClick={handleMarkAllNoticesAsRead}
              className="font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
            >
              Mark all as read
            </button>
          )}
          <button
            onClick={() => {
              setShowNotificationModal(false);
              setStudentActiveTab('notices');
            }}
            className="ml-auto px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition cursor-pointer"
          >
            View Full Notice Board
          </button>
        </div>
      </div>
    </div>
  )}

      {/* Make Payment Modal */}
      {showPayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 animate-fadeIn">
            <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-5">
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">
                  Fee Payment Portal
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                  Pay Outstanding Tuition Dues
                </h3>
              </div>
              <button
                onClick={() => setShowPayModal(false)}
                className="text-slate-400 hover:text-slate-700 text-xl font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitDuePayment} className="space-y-4">
              {/* Select which due month(s) to pay */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">
                  Select Months to Clear:
                </label>
                <div className="space-y-2 max-h-40 overflow-y-auto p-2 bg-slate-50 rounded-xl border border-slate-200">
                  {unpaidMonths.map((m) => (
                    <label
                      key={m.monthKey}
                      className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-200 text-xs cursor-pointer hover:bg-indigo-50/50"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={selectedMonthsToPay.includes(m.monthKey)}
                          onChange={() => handleToggleMonthSelection(m.monthKey)}
                          className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                        />
                        <span className="font-semibold text-slate-800">{m.monthLabel}</span>
                      </div>
                      <span className="font-mono font-bold text-indigo-900">₹{m.netFeeDue}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Total Payable Amount Banner */}
              <div className="bg-indigo-50 p-3.5 rounded-xl border border-indigo-200 flex justify-between items-center">
                <span className="text-xs font-bold text-indigo-900">Total Payable for Selected:</span>
                <span className="text-xl font-black text-indigo-950 font-mono">
                  ₹{modalTotalPayAmount.toLocaleString('en-IN')}
                </span>
              </div>

              {/* Payment Mode Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-2">
                  Select Payment Option:
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentMode('UPI')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-2 cursor-pointer transition ${
                      paymentMode === 'UPI'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-950 font-bold'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    <QrCode className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs">UPI QR (Instant)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMode('CASH')}
                    className={`p-3 rounded-xl border text-left flex items-center gap-2 cursor-pointer transition ${
                      paymentMode === 'CASH'
                        ? 'border-indigo-600 bg-indigo-50 text-indigo-950 font-bold'
                        : 'border-slate-200 text-slate-700'
                    }`}
                  >
                    <Building2 className="w-4 h-4 text-emerald-600" />
                    <span className="text-xs">Cash at Center</span>
                  </button>
                </div>
              </div>

              {/* UPI QR Display */}
              {paymentMode === 'UPI' && (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-center">
                  <div className="text-xs font-bold text-slate-800 mb-2">
                    Scan with GPay / PhonePe / Paytm / BHIM
                  </div>

                  <div className="inline-block p-2 bg-white rounded-2xl border border-slate-200 shadow-xs mb-2">
                    {qrCodeForDue ? (
                      <img
                        src={qrCodeForDue}
                        alt="UPI QR"
                        className="w-36 h-36 object-contain mx-auto"
                      />
                    ) : null}
                  </div>

                  {/* Clickable UPI link */}
                  <div className="mb-3">
                    <a
                      href={upiDeepLinkForDue}
                      className="inline-flex items-center justify-center gap-2 w-full py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md transition transform hover:scale-[1.01]"
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>Click here to Pay with UPI App</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>

                  <div className="flex items-center justify-center gap-2 mb-3">
                    <span className="font-mono text-xs font-bold text-indigo-900 bg-indigo-100 px-2.5 py-1 rounded-lg">
                      {centerInfo.upiId}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyUpi}
                      className="p-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs transition cursor-pointer flex items-center gap-1"
                    >
                      {copiedUpi ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedUpi ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>

                  <div className="text-left">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                      Enter UPI Transaction Reference (UTR) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={transactionRef}
                      onChange={(e) => setTransactionRef(e.target.value)}
                      placeholder="12-digit UPI UTR number"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono bg-white"
                    />
                  </div>
                </div>
              )}

              {paymentMode === 'CASH' && (
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-xs text-emerald-900 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <Building2 className="w-4 h-4 text-emerald-700" />
                    <span>Cash Payment at Center Desk</span>
                  </div>
                  <p>
                    Submit this request and deposit ₹{modalTotalPayAmount} cash at Pixel Pathsala reception counter. Admin will verify and mark your receipt approved.
                  </p>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide mb-1">
                  Optional Remarks / Note
                </label>
                <input
                  type="text"
                  value={studentRemarks}
                  onChange={(e) => setStudentRemarks(e.target.value)}
                  placeholder="e.g. Paid via GPay from father's account"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPayModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Submit Payment for Approval</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
