import React, { useState, useEffect, useMemo } from 'react';
import { PLAYZONE_PROBLEMS } from '../../data/seedData';
import { PlayzoneProblem } from '../../types';
import { 
  executeCCode, 
  executePythonCode, 
  globalSqlDb, 
  ExecutionResult 
} from '../../utils/codeRunner';
import confetti from 'canvas-confetti';
import { 
  Play, 
  RotateCcw, 
  Code2, 
  Terminal, 
  Database, 
  Globe, 
  FileCode, 
  Sparkles, 
  Copy, 
  Check, 
  ExternalLink,
  BookOpen,
  FileSpreadsheet,
  Layers,
  ArrowRight,
  Calculator,
  Plus,
  HelpCircle
} from 'lucide-react';

type LangType = 'c' | 'python' | 'sql' | 'html' | 'excel';

interface W3Resource {
  title: string;
  category: string;
  tryUrl: string;
  docUrl: string;
  topics: { name: string; url: string; exampleCode: string; description: string }[];
  description: string;
}

const W3_RESOURCES: Record<LangType, W3Resource> = {
  c: {
    title: 'C Programming',
    category: 'Procedural Systems & Memory Logic',
    tryUrl: 'https://www.w3schools.com/c/tryc.php?filename=demo_output_quotes_err',
    docUrl: 'https://www.w3schools.com/c/',
    description: 'Learn foundational syntax, variables, pointers, structs, arrays, memory management, and file I/O on W3Schools.',
    topics: [
      { 
        name: 'C Syntax & Output (printf)', 
        url: 'https://www.w3schools.com/c/c_syntax.php',
        exampleCode: '#include <stdio.h>\n\nint main() {\n    printf("Hello Pixel Pathsala!\\n");\n    printf("Welcome to C programming.\\n");\n    return 0;\n}',
        description: 'Output text using standard printf formatting.'
      },
      { 
        name: 'Variables & Data Types', 
        url: 'https://www.w3schools.com/c/c_variables.php',
        exampleCode: '#include <stdio.h>\n\nint main() {\n    int roll = 101;\n    float marks = 92.5;\n    char grade = \'A\';\n    printf("Roll: %d | Marks: %.1f | Grade: %c\\n", roll, marks, grade);\n    return 0;\n}',
        description: 'Store integers, floats, characters and format output.'
      },
      { 
        name: 'If...Else & Switch Decisions', 
        url: 'https://www.w3schools.com/c/c_conditions.php',
        exampleCode: '#include <stdio.h>\n\nint main() {\n    int marks = 78;\n    if (marks >= 90) {\n        printf("Grade O (Outstanding)\\n");\n    } else if (marks >= 75) {\n        printf("Grade E (Excellent)\\n");\n    } else {\n        printf("Grade A (Good)\\n");\n    }\n    return 0;\n}',
        description: 'Control program flow with branching conditions.'
      },
      { 
        name: 'For & While Loops', 
        url: 'https://www.w3schools.com/c/c_while_loop.php',
        exampleCode: '#include <stdio.h>\n\nint main() {\n    int sum = 0;\n    for (int i = 1; i <= 10; i++) {\n        sum += i;\n    }\n    printf("Sum of 1 to 10 = %d\\n", sum);\n    return 0;\n}',
        description: 'Iterate over ranges and compute series.'
      },
      { 
        name: 'Arrays & Strings', 
        url: 'https://www.w3schools.com/c/c_arrays.php',
        exampleCode: '#include <stdio.h>\n\nint main() {\n    int numbers[] = {12, 45, 67, 89, 23};\n    int n = 5;\n    int max = numbers[0];\n    for (int i = 1; i < n; i++) {\n        if (numbers[i] > max) max = numbers[i];\n    }\n    printf("Largest element = %d\\n", max);\n    return 0;\n}',
        description: 'Store linear elements and traverse arrays.'
      },
      { 
        name: 'Pointers & Memory Addresses', 
        url: 'https://www.w3schools.com/c/c_pointers.php',
        exampleCode: '#include <stdio.h>\n\nint main() {\n    int age = 18;\n    int *ptr = &age;\n    printf("Value of age = %d\\n", *ptr);\n    printf("Memory address of age = %p\\n", (void*)ptr);\n    return 0;\n}',
        description: 'Dereference pointers and access variable memory.'
      }
    ]
  },
  python: {
    title: 'Python 3',
    category: 'General Purpose, Automation & Data',
    tryUrl: 'https://www.w3schools.com/python/trypython.asp?filename=demo_sys_version',
    docUrl: 'https://www.w3schools.com/python/',
    description: 'Master Python syntax, lists, dictionaries, functions, OOP classes, lambda functions, and file handling.',
    topics: [
      { 
        name: 'Python Syntax & Indentation', 
        url: 'https://www.w3schools.com/python/python_syntax.asp',
        exampleCode: 'print("Pixel Pathsala Python Engine")\nx = 10\ny = 25\nprint(f"The product of {x} and {y} is {x * y}")',
        description: 'Python print, f-strings, and variables.'
      },
      { 
        name: 'Lists, Tuples & Comprehensions', 
        url: 'https://www.w3schools.com/python/python_lists.asp',
        exampleCode: 'scores = [78, 92, 85, 64, 99]\nhonors = [s for s in scores if s >= 80]\nprint("Original scores:", scores)\nprint("Honors list (>= 80):", honors)\nprint("Top score:", max(scores))',
        description: 'Filter and manipulate lists cleanly.'
      },
      { 
        name: 'Dictionaries & Key-Value Maps', 
        url: 'https://www.w3schools.com/python/python_dictionaries.asp',
        exampleCode: 'student = {\n    "name": "Rohan Sharma",\n    "course": "Computer Science & Python",\n    "batch": "Alpha MWF",\n    "marks": 94\n}\n\nfor key, val in student.items():\n    print(f"{key.capitalize()}: {val}")',
        description: 'Store structured records using dict objects.'
      },
      { 
        name: 'Functions & Default Arguments', 
        url: 'https://www.w3schools.com/python/python_functions.asp',
        exampleCode: 'def calculate_bill(fee, discount_pct=10):\n    discount = (fee * discount_pct) / 100\n    final_payable = fee - discount\n    return final_payable, discount\n\npayable, disc = calculate_bill(1200, 15)\nprint(f"Fee: Rs 1200 | Discount: Rs {disc} | Payable: Rs {payable}")',
        description: 'Define modular functions with parameters.'
      },
      { 
        name: 'Classes & Objects (OOP)', 
        url: 'https://www.w3schools.com/python/python_classes.asp',
        exampleCode: 'class Course:\n    def __init__(self, title, fee):\n        self.title = title\n        self.fee = fee\n        \n    def get_details(self):\n        return f"Course: {self.title} (Fee: Rs {self.fee}/mo)"\n\nc = Course("Python & DBMS Masterclass", 1200)\nprint(c.get_details())',
        description: 'Create classes, constructors, and methods.'
      }
    ]
  },
  sql: {
    title: 'SQL / Relational DBMS',
    category: 'Database Querying & Schema Design',
    tryUrl: 'https://www.w3schools.com/sql/trysql.asp?filename=trysql_select_and',
    docUrl: 'https://www.w3schools.com/sql/',
    description: 'Execute queries, filters, joins, aggregations, table creations, and subqueries on relational databases.',
    topics: [
      { 
        name: 'SELECT & Filtering WHERE', 
        url: 'https://www.w3schools.com/sql/sql_select.asp',
        exampleCode: 'SELECT roll_no, name, course_name, monthly_fee \nFROM students \nWHERE status = "active"\nORDER BY name ASC;',
        description: 'Retrieve and filter records from tables.'
      },
      { 
        name: 'Aggregate Functions (SUM, AVG, COUNT)', 
        url: 'https://www.w3schools.com/sql/sql_count_avg_sum.asp',
        exampleCode: 'SELECT \n    COUNT(*) AS total_students,\n    AVG(monthly_fee) AS avg_fee,\n    SUM(monthly_fee) AS total_revenue\nFROM students;',
        description: 'Calculate summary totals and averages.'
      },
      { 
        name: 'GROUP BY & Aggregations', 
        url: 'https://www.w3schools.com/sql/sql_groupby.asp',
        exampleCode: 'SELECT \n    course_name, \n    COUNT(*) AS total_enrolled, \n    SUM(monthly_fee) AS monthly_revenue\nFROM students\nGROUP BY course_name;',
        description: 'Group rows and compute summaries per course.'
      },
      { 
        name: 'CREATE TABLE & INSERT Data', 
        url: 'https://www.w3schools.com/sql/sql_create_table.asp',
        exampleCode: 'CREATE TABLE batch_attendance (\n    id INTEGER PRIMARY KEY,\n    student_name TEXT,\n    date TEXT,\n    status TEXT\n);\n\nINSERT INTO batch_attendance VALUES (1, "Rohan Sharma", "2026-08-21", "Present");\nINSERT INTO batch_attendance VALUES (2, "Priyanka Das", "2026-08-21", "Present");\n\nSELECT * FROM batch_attendance;',
        description: 'Create new schemas and insert records.'
      }
    ]
  },
  html: {
    title: 'HTML & Web Design',
    category: 'Web Page Structure & Responsive CSS',
    tryUrl: 'https://www.w3schools.com/html/tryit.asp?filename=tryhtml_default',
    docUrl: 'https://www.w3schools.com/html/',
    description: 'Build modern responsive web pages with HTML5 semantics, CSS styling, forms, tables, and media elements.',
    topics: [
      { 
        name: 'HTML5 Semantic Layout & Header', 
        url: 'https://www.w3schools.com/html/html5_semantic_elements.asp',
        exampleCode: '<!DOCTYPE html>\n<html>\n<head>\n  <style>\n    body { font-family: sans-serif; padding: 20px; background: #f8fafc; }\n    .card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); border: 1px solid #e2e8f0; }\n    h2 { color: #4338ca; margin-top: 0; }\n    .btn { background: #4f46e5; color: white; border: none; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-weight: bold; }\n  </style>\n</head>\n<body>\n  <div class="card">\n    <h2>Pixel Pathsala Coding Hub</h2>\n    <p>Welcome to modern responsive web development.</p>\n    <button class="btn" onclick="alert(\'Welcome to Pixel Pathsala!\')">Explore Courses</button>\n  </div>\n</body>\n</html>',
        description: 'Construct clean responsive UI cards.'
      },
      { 
        name: 'Interactive Forms & Inputs', 
        url: 'https://www.w3schools.com/html/html_forms.asp',
        exampleCode: '<!DOCTYPE html>\n<html>\n<head>\n  <style>\n    body { font-family: sans-serif; padding: 20px; }\n    input, select { display: block; width: 100%; margin: 8px 0 16px; padding: 8px; border: 1px solid #cbd5e1; border-radius: 6px; box-sizing: border-box; }\n    label { font-weight: bold; font-size: 13px; }\n  </style>\n</head>\n<body>\n  <h3>Student Admission Inquiry</h3>\n  <label>Student Full Name</label>\n  <input type="text" placeholder="e.g. Rohan Sharma" />\n  <label>Select Target Course</label>\n  <select>\n    <option>C, Python & SQL Masterclass</option>\n    <option>Class 11-12 Science & JEE</option>\n  </select>\n</body>\n</html>',
        description: 'Create structured user input forms.'
      }
    ]
  },
  excel: {
    title: 'Excel & Spreadsheets',
    category: 'Data Analytics, Formulas & Financial Tables',
    tryUrl: 'https://www.w3schools.com/excel/tryexcel.php?filename=demo_move_cells_context',
    docUrl: 'https://www.w3schools.com/excel/',
    description: 'Master spreadsheet modeling, formulas (SUM, AVERAGE, IF, MAX, MIN, COUNT), conditional formatting, and financial calculations.',
    topics: [
      { 
        name: 'SUM, AVERAGE & Basic Math', 
        url: 'https://www.w3schools.com/excel/excel_formulas.php',
        exampleCode: '=SUM(B2:B6)\n=AVERAGE(B2:B6)\n=MAX(B2:B6)\n=MIN(B2:B6)',
        description: 'Compute statistical totals and averages.'
      },
      { 
        name: 'Logical IF Conditions', 
        url: 'https://www.w3schools.com/excel/excel_if.php',
        exampleCode: '=IF(B2>=40, "PASS", "FAIL")\n=IF(C2>1000, "Eligible for Discount", "Standard")',
        description: 'Conditional logical evaluation.'
      },
      { 
        name: 'VLOOKUP & Data Matching', 
        url: 'https://www.w3schools.com/excel/excel_vlookup.php',
        exampleCode: '=VLOOKUP("PP-2026-001", A2:D20, 2, FALSE)',
        description: 'Lookup values across columns in tabular ranges.'
      }
    ]
  }
};

// Initial Spreadsheet Templates
const EXCEL_TEMPLATES = {
  marks: {
    name: 'Class 10 Student Marks & Average',
    data: {
      A1: 'Roll No', B1: 'Student Name', C1: 'Maths', D1: 'Science', E1: 'Computer', F1: 'Total (SUM)',
      A2: 'PP-101', B2: 'Rohan Sharma', C2: '88', D2: '92', E2: '95', F2: '=SUM(C2:E2)',
      A3: 'PP-102', B3: 'Priyanka Das', C3: '94', D3: '89', E3: '98', F3: '=SUM(C3:E3)',
      A4: 'PP-103', B4: 'Aniket Sen', C4: '76', D4: '82', E4: '85', F4: '=SUM(C4:E4)',
      A5: 'PP-104', B5: 'Debojyoti B.', C5: '85', D5: '90', E5: '92', F5: '=SUM(C5:E5)',
      A6: 'Class Avg', B6: '-', C6: '=AVERAGE(C2:C5)', D6: '=AVERAGE(D2:D5)', E6: '=AVERAGE(E2:E5)', F6: '=AVERAGE(F2:F5)'
    }
  },
  fees: {
    name: 'Monthly Course Fee Collection',
    data: {
      A1: 'Course Code', B1: 'Course Name', C1: 'Enrolled', D1: 'Monthly Fee', E1: 'Total Revenue', F1: 'Status',
      A2: 'CS-101', B2: 'C, Python & SQL', C2: '24', D2: '1200', E2: '=C2*D2', F2: '=IF(C2>=20, "Optimal", "Open")',
      A3: 'SCI-202', B3: 'Class 11-12 Science', C3: '18', D3: '2500', E3: '=C3*D3', F3: '=IF(C3>=20, "Optimal", "Open")',
      A4: 'SEC-303', B4: 'Class 9-10 Boards', C4: '22', D4: '1500', E4: '=C4*D4', F4: '=IF(C4>=20, "Optimal", "Open")',
      A5: 'WEB-404', B5: 'Web Dev & DBMS', C5: '15', D5: '1400', E5: '=C5*D5', F5: '=IF(C5>=20, "Optimal", "Open")',
      A6: 'TOTALS', B6: 'All Batches', C6: '=SUM(C2:C5)', D6: '=AVERAGE(D2:D5)', E6: '=SUM(E2:E5)', F6: 'Active'
    }
  }
};

const COLS = ['A', 'B', 'C', 'D', 'E', 'F'];
const ROWS = [1, 2, 3, 4, 5, 6, 7, 8];

export const Playzone: React.FC = () => {
  const [activeLang, setActiveLang] = useState<LangType>('c');
  const [sandboxMode, setSandboxMode] = useState<'builtin' | 'w3schools'>('builtin');
  const [selectedProblem, setSelectedProblem] = useState<PlayzoneProblem>(PLAYZONE_PROBLEMS[0]);
  const [code, setCode] = useState<string>(selectedProblem.starterCode);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [executionResult, setExecutionResult] = useState<ExecutionResult | null>(null);
  const [htmlOutput, setHtmlOutput] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  // Spreadsheet Engine State
  const [spreadsheetData, setSpreadsheetData] = useState<Record<string, string>>(EXCEL_TEMPLATES.marks.data);
  const [selectedCell, setSelectedCell] = useState<string>('C2');
  const [formulaInput, setFormulaInput] = useState<string>('88');

  const availableProblems = PLAYZONE_PROBLEMS.filter(p => p.language === activeLang);
  const currentW3 = W3_RESOURCES[activeLang];

  const handleLanguageChange = (lang: LangType) => {
    setActiveLang(lang);
    if (lang === 'excel') {
      setSelectedCell('C2');
      setFormulaInput(spreadsheetData['C2'] || '');
    } else {
      const firstProb = PLAYZONE_PROBLEMS.find(p => p.language === lang) || PLAYZONE_PROBLEMS[0];
      setSelectedProblem(firstProb);
      setCode(firstProb.starterCode);
      if (lang === 'html') {
        setHtmlOutput(firstProb.starterCode);
      }
    }
    setExecutionResult(null);
  };

  const handleSelectProblem = (prob: PlayzoneProblem) => {
    setSelectedProblem(prob);
    setCode(prob.starterCode);
    setExecutionResult(null);
    if (activeLang === 'html') {
      setHtmlOutput(prob.starterCode);
    }
  };

  const handleRunCode = () => {
    setIsRunning(true);
    setExecutionResult(null);

    setTimeout(() => {
      let result: ExecutionResult;

      if (activeLang === 'c') {
        result = executeCCode(code);
      } else if (activeLang === 'python') {
        result = executePythonCode(code);
      } else if (activeLang === 'sql') {
        result = globalSqlDb.execute(code);
      } else if (activeLang === 'html') {
        setHtmlOutput(code);
        result = {
          success: true,
          output: 'HTML & CSS preview updated successfully.',
          executionTimeMs: 12
        };
      } else {
        result = {
          success: true,
          output: 'Spreadsheet calculated all live cell values successfully.',
          executionTimeMs: 5
        };
      }

      setExecutionResult(result);
      setIsRunning(false);

      if (result.success) {
        try {
          confetti({
            particleCount: 30,
            spread: 50,
            origin: { y: 0.85 }
          });
        } catch {
          // ignore
        }
      }
    }, 180);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleResetCode = () => {
    setCode(selectedProblem.starterCode);
    setExecutionResult(null);
  };

  // Evaluate spreadsheet cell with full formula support
  const evaluateCell = (cellKey: string, rawVal?: string, visited: Set<string> = new Set()): string => {
    const expr = rawVal !== undefined ? rawVal : (spreadsheetData[cellKey] || '');
    if (!expr.startsWith('=')) {
      return expr;
    }

    if (visited.has(cellKey)) {
      return '#CIRCULAR!';
    }
    visited.add(cellKey);

    const upper = expr.slice(1).trim().toUpperCase();

    // SUM(A1:A5)
    const sumMatch = upper.match(/^SUM\(([A-F][1-9]):([A-F][1-9])\)$/);
    if (sumMatch) {
      const vals = getRangeValues(sumMatch[1], sumMatch[2], visited);
      const sum = vals.reduce((a, b) => a + b, 0);
      return Number.isInteger(sum) ? String(sum) : sum.toFixed(1);
    }

    // AVERAGE(A1:A5)
    const avgMatch = upper.match(/^AVERAGE\(([A-F][1-9]):([A-F][1-9])\)$/);
    if (avgMatch) {
      const vals = getRangeValues(avgMatch[1], avgMatch[2], visited);
      if (vals.length === 0) return '0';
      const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
      return Number.isInteger(avg) ? String(avg) : avg.toFixed(1);
    }

    // MAX(A1:A5)
    const maxMatch = upper.match(/^MAX\(([A-F][1-9]):([A-F][1-9])\)$/);
    if (maxMatch) {
      const vals = getRangeValues(maxMatch[1], maxMatch[2], visited);
      return vals.length > 0 ? String(Math.max(...vals)) : '0';
    }

    // MIN(A1:A5)
    const minMatch = upper.match(/^MIN\(([A-F][1-9]):([A-F][1-9])\)$/);
    if (minMatch) {
      const vals = getRangeValues(minMatch[1], minMatch[2], visited);
      return vals.length > 0 ? String(Math.min(...vals)) : '0';
    }

    // COUNT(A1:A5)
    const countMatch = upper.match(/^COUNT\(([A-F][1-9]):([A-F][1-9])\)$/);
    if (countMatch) {
      const vals = getRangeValues(countMatch[1], countMatch[2], visited);
      return String(vals.length);
    }

    // IF(Condition, TrueVal, FalseVal) e.g. IF(C2>=40, "PASS", "FAIL") or IF(C2*D2>1000, 100, 50)
    const ifMatch = upper.match(/^IF\((.+?),(.+?),(.+?)\)$/);
    if (ifMatch) {
      const condStr = ifMatch[1].trim();
      const trueVal = ifMatch[2].trim().replace(/^["']|["']$/g, '');
      const falseVal = ifMatch[3].trim().replace(/^["']|["']$/g, '');

      try {
        const parsedCond = condStr.replace(/([A-F][1-9])/g, (m) => {
          const val = evaluateCell(m, undefined, new Set(visited));
          const num = parseFloat(val);
          return isNaN(num) ? `"${val}"` : String(num);
        });
        // eslint-disable-next-line no-eval
        const isTrue = Function(`"use strict"; return (${parsedCond})`)();
        return isTrue ? trueVal : falseVal;
      } catch {
        return '#IF_ERR';
      }
    }

    // Basic Arithmetic: e.g. =C2*D2 or =A1+B1
    try {
      const parsedMath = upper.replace(/([A-F][1-9])/g, (m) => {
        const val = evaluateCell(m, undefined, new Set(visited));
        const num = parseFloat(val);
        return isNaN(num) ? '0' : String(num);
      });
      // eslint-disable-next-line no-eval
      const mathRes = Function(`"use strict"; return (${parsedMath})`)();
      if (typeof mathRes === 'number' && !isNaN(mathRes)) {
        return Number.isInteger(mathRes) ? String(mathRes) : mathRes.toFixed(1);
      }
      return String(mathRes);
    } catch {
      return '#VALUE!';
    }
  };

  const getRangeValues = (startCell: string, endCell: string, visited: Set<string>): number[] => {
    const startCol = startCell.charAt(0);
    const startRow = parseInt(startCell.slice(1), 10);
    const endCol = endCell.charAt(0);
    const endRow = parseInt(endCell.slice(1), 10);

    const colStartIdx = COLS.indexOf(startCol);
    const colEndIdx = COLS.indexOf(endCol);
    const minCol = Math.min(colStartIdx, colEndIdx);
    const maxCol = Math.max(colStartIdx, colEndIdx);
    const minRow = Math.min(startRow, endRow);
    const maxRow = Math.max(startRow, endRow);

    const values: number[] = [];
    for (let c = minCol; c <= maxCol; c++) {
      for (let r = minRow; r <= maxRow; r++) {
        const key = `${COLS[c]}${r}`;
        const computed = evaluateCell(key, undefined, new Set(visited));
        const num = parseFloat(computed);
        if (!isNaN(num)) {
          values.push(num);
        }
      }
    }
    return values;
  };

  const computedGrid = useMemo(() => {
    const grid: Record<string, string> = {};
    for (const c of COLS) {
      for (const r of ROWS) {
        const key = `${c}${r}`;
        grid[key] = evaluateCell(key);
      }
    }
    return grid;
  }, [spreadsheetData]);

  const handleCellClick = (cellKey: string) => {
    setSelectedCell(cellKey);
    setFormulaInput(spreadsheetData[cellKey] || '');
  };

  const handleFormulaInputChange = (val: string) => {
    setFormulaInput(val);
    setSpreadsheetData(prev => ({
      ...prev,
      [selectedCell]: val
    }));
  };

  const loadTemplate = (key: keyof typeof EXCEL_TEMPLATES) => {
    setSpreadsheetData(EXCEL_TEMPLATES[key].data);
    setSelectedCell('C2');
    setFormulaInput(EXCEL_TEMPLATES[key].data['C2'] || '');
  };

  const loadW3ExampleToRunner = (exampleCode: string, targetLang: LangType) => {
    setActiveLang(targetLang);
    setSandboxMode('builtin');
    setCode(exampleCode);
    if (targetLang === 'html') {
      setHtmlOutput(exampleCode);
    }
    setExecutionResult(null);
  };

  useEffect(() => {
    if (activeLang === 'html') {
      setHtmlOutput(code);
    }
  }, [code, activeLang]);

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 sm:p-8 rounded-3xl text-white shadow-xl border border-indigo-500/20 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Interactive Code Sandbox & W3Schools Practice Station</span>
          </div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight">
            Pixel Codezone & Practice Lab
          </h1>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
            Live hands-on programming in C, Python 3, SQL / DBMS, HTML & CSS, and Microsoft Excel with interactive code runners and W3Schools curriculum guides.
          </p>
        </div>

        {/* Mode Switcher */}
        <div className="flex flex-col gap-2 shrink-0">
          <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Environment Mode:</div>
          <div className="flex items-center gap-1.5 bg-slate-800/90 p-1.5 rounded-2xl border border-slate-700">
            <button
              id="mode-builtin-btn"
              onClick={() => setSandboxMode('builtin')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                sandboxMode === 'builtin'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>Interactive Code Editor</span>
            </button>

            <button
              id="mode-w3schools-btn"
              onClick={() => setSandboxMode('w3schools')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                sandboxMode === 'w3schools'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>W3Schools Learning Hub</span>
            </button>
          </div>
        </div>
      </div>

      {/* Language Navigation Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-2.5 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex flex-wrap gap-1.5">
          <button
            id="tab-lang-c"
            onClick={() => handleLanguageChange('c')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeLang === 'c'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>C Language</span>
          </button>

          <button
            id="tab-lang-python"
            onClick={() => handleLanguageChange('python')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeLang === 'python'
                ? 'bg-yellow-600 text-white shadow-sm'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Python 3</span>
          </button>

          <button
            id="tab-lang-sql"
            onClick={() => handleLanguageChange('sql')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeLang === 'sql'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>SQL / DBMS</span>
          </button>

          <button
            id="tab-lang-html"
            onClick={() => handleLanguageChange('html')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeLang === 'html'
                ? 'bg-orange-600 text-white shadow-sm'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>HTML & CSS</span>
          </button>

          <button
            id="tab-lang-excel"
            onClick={() => handleLanguageChange('excel')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm transition-all cursor-pointer ${
              activeLang === 'excel'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Excel Spreadsheets</span>
          </button>
        </div>

        {/* Quick W3Schools Launch Tab */}
        <div className="flex items-center gap-2 px-2">
          <a
            href={currentW3.tryUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold transition-all"
            title={`Launch W3Schools ${currentW3.title} Try-It Editor`}
          >
            <Globe className="w-3.5 h-3.5 text-emerald-600" />
            <span>W3Schools {currentW3.title} (New Tab)</span>
            <ExternalLink className="w-3 h-3 text-emerald-600" />
          </a>
        </div>
      </div>

      {/* Main Interactive Work Area */}
      {sandboxMode === 'w3schools' ? (
        /* W3Schools Official Learning Hub & Interactive Launcher */
        <div className="space-y-6">
          {/* Hero Launcher Banner */}
          <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-indigo-950 p-6 sm:p-8 rounded-3xl text-white border border-emerald-500/30 shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                <Globe className="w-4 h-4" />
                <span>W3Schools Official {currentW3.title} Curriculum</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">{currentW3.title} Learning Station</h2>
              <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                {currentW3.description}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <a
                href={currentW3.tryUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-xs sm:text-sm transition-all shadow-md cursor-pointer"
              >
                <Globe className="w-4 h-4" />
                <span>Launch W3Schools Try-It Editor</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              <a
                href={currentW3.docUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-white font-bold text-xs sm:text-sm transition-all border border-slate-700"
              >
                <BookOpen className="w-4 h-4 text-emerald-400" />
                <span>Full Tutorial</span>
              </a>
            </div>
          </div>

          {/* Topic-by-Topic Syllabus Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {currentW3.topics.map((topic, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between space-y-4 hover:border-indigo-300 hover:shadow-md transition-all"
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-bold text-indigo-600 mb-1">
                    <span>Topic {String(idx + 1).padStart(2, '0')}</span>
                    <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 text-[10px]">W3Schools</span>
                  </div>
                  <h3 className="font-bold text-slate-900 text-sm">{topic.name}</h3>
                  <p className="text-xs text-slate-500 mt-1">{topic.description}</p>

                  <div className="mt-3 bg-slate-950 p-2.5 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-200 overflow-x-auto max-h-28 whitespace-pre-wrap">
                    {topic.exampleCode}
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                  <button
                    onClick={() => loadW3ExampleToRunner(topic.exampleCode, activeLang)}
                    className="flex-1 py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <Terminal className="w-3.5 h-3.5" />
                    <span>Try in Editor</span>
                  </button>

                  <a
                    href={topic.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-slate-500 hover:text-indigo-600 bg-slate-50 hover:bg-indigo-50 rounded-xl border border-slate-200 transition"
                    title="Open on W3Schools"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : activeLang === 'excel' ? (
        /* Excel Interactive Live Spreadsheet Engine */
        <div className="space-y-4">
          {/* Spreadsheet Controls & Template Selector */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>Templates:</span>
              </span>
              <button
                onClick={() => loadTemplate('marks')}
                className="px-3 py-1.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition cursor-pointer"
              >
                Student Marks & Averages
              </button>
              <button
                onClick={() => loadTemplate('fees')}
                className="px-3 py-1.5 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 text-xs font-bold rounded-xl border border-slate-200 transition cursor-pointer"
              >
                Course Fee Revenue
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setSpreadsheetData({});
                  setSelectedCell('A1');
                  setFormulaInput('');
                }}
                className="px-3 py-1.5 bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-600 text-xs font-bold rounded-xl border border-slate-200 transition cursor-pointer"
              >
                Clear Sheet
              </button>
              <a
                href={currentW3.tryUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition shadow-xs"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>W3Schools TryExcel</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Formula Bar */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-3">
            <div className="flex items-center gap-1 px-3 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl font-mono text-xs font-bold shrink-0">
              <Calculator className="w-3.5 h-3.5 text-emerald-600" />
              <span>{selectedCell}</span>
            </div>

            <div className="text-slate-400 font-mono font-bold text-sm">fx</div>

            <input
              type="text"
              value={formulaInput}
              onChange={(e) => handleFormulaInputChange(e.target.value)}
              placeholder="Enter text, number, or formula (e.g. =SUM(C2:E2), =AVERAGE(C2:C5), =IF(C2>=40, 'PASS', 'FAIL'))"
              className="flex-1 px-3.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />

            <div className="hidden sm:flex items-center gap-1.5">
              <button
                onClick={() => handleFormulaInputChange(`=SUM(A1:A5)`)}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-[11px] font-mono font-bold rounded-lg text-slate-700 cursor-pointer"
              >
                +SUM
              </button>
              <button
                onClick={() => handleFormulaInputChange(`=AVERAGE(A1:A5)`)}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-[11px] font-mono font-bold rounded-lg text-slate-700 cursor-pointer"
              >
                +AVG
              </button>
              <button
                onClick={() => handleFormulaInputChange(`=IF(C2>=40, "PASS", "FAIL")`)}
                className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-[11px] font-mono font-bold rounded-lg text-slate-700 cursor-pointer"
              >
                +IF
              </button>
            </div>
          </div>

          {/* Interactive Live Spreadsheet Grid */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
            <table className="w-full border-collapse text-xs">
              <thead>
                <tr className="bg-slate-100 text-slate-600 font-bold border-b border-slate-200">
                  <th className="w-12 p-2.5 border-r border-slate-200 text-center font-mono bg-slate-200/60">#</th>
                  {COLS.map((col) => (
                    <th key={col} className="p-2.5 border-r border-slate-200 text-center font-mono font-bold min-w-[140px]">
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {ROWS.map((row) => (
                  <tr key={row} className="hover:bg-slate-50/50">
                    <td className="p-2.5 border-r border-slate-200 text-center font-mono font-bold bg-slate-100 text-slate-500">
                      {row}
                    </td>
                    {COLS.map((col) => {
                      const cellKey = `${col}${row}`;
                      const isSelected = selectedCell === cellKey;
                      const raw = spreadsheetData[cellKey] || '';
                      const isFormula = raw.startsWith('=');
                      const displayVal = computedGrid[cellKey] || '';

                      return (
                        <td
                          key={cellKey}
                          onClick={() => handleCellClick(cellKey)}
                          className={`p-2 border-r border-slate-200 cursor-pointer transition-colors ${
                            isSelected
                              ? 'bg-emerald-50 ring-2 ring-emerald-500 ring-inset font-bold text-slate-950'
                              : row === 1
                              ? 'bg-slate-50 font-bold text-slate-800'
                              : 'text-slate-700'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className="truncate">{displayVal || <span className="text-slate-300">&nbsp;</span>}</span>
                            {isFormula && (
                              <span className="text-[9px] font-mono text-emerald-600 font-bold ml-1">fx</span>
                            )}
                          </div>
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Formula & Function Reference Sheet */}
          <div className="bg-slate-900 rounded-2xl p-5 text-white border border-slate-800 shadow-md">
            <h3 className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <BookOpen className="w-4 h-4" />
              <span>Supported Live Spreadsheet Formulas in Pixel Codezone</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs text-slate-300">
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <div className="font-mono font-bold text-emerald-400">=SUM(start:end)</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Calculates sum of all numerical values in range (e.g. =SUM(C2:E2))</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <div className="font-mono font-bold text-emerald-400">=AVERAGE(start:end)</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Calculates arithmetic mean of range (e.g. =AVERAGE(C2:C5))</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <div className="font-mono font-bold text-emerald-400">=IF(cond, true, false)</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Logical branching (e.g. =IF(C2&gt;=40, &quot;PASS&quot;, &quot;FAIL&quot;))</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <div className="font-mono font-bold text-emerald-400">=MAX(range) & =MIN(range)</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Finds maximum or minimum value in range</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <div className="font-mono font-bold text-emerald-400">=COUNT(start:end)</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Counts non-empty numeric cells in range</div>
              </div>
              <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800">
                <div className="font-mono font-bold text-emerald-400">=A1*B1 or =A1+B1</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Standard arithmetic expressions across any cells</div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Built-in Pixel Practice Runner & Problem Sets (C, Python, SQL, HTML) */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Problem Sidebar */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs">
              <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider mb-3 flex items-center justify-between">
                <span>Practice Challenges ({availableProblems.length})</span>
                <span className="text-[10px] text-slate-500 font-mono">{activeLang.toUpperCase()}</span>
              </h3>

              <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
                {availableProblems.map((prob) => {
                  const isSelected = selectedProblem.id === prob.id;
                  return (
                    <button
                      key={prob.id}
                      onClick={() => handleSelectProblem(prob)}
                      className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-50/80 border-indigo-400 text-indigo-950 ring-1 ring-indigo-400/40 shadow-xs'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          prob.difficulty === 'Beginner'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {prob.difficulty}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">{prob.category}</span>
                      </div>
                      <div className="font-bold text-xs line-clamp-2">{prob.title}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Problem Description Card */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
              <div className="flex items-center gap-2 text-indigo-600 font-bold text-xs uppercase tracking-wider">
                <FileCode className="w-4 h-4" />
                <span>Problem Statement</span>
              </div>
              <h2 className="font-black text-slate-900 text-sm">{selectedProblem.title}</h2>
              <p className="text-xs text-slate-600 leading-relaxed">{selectedProblem.description}</p>
            </div>
          </div>

          {/* Right Code Editor & Execution Console */}
          <div className="lg:col-span-8 space-y-4">
            <div className="bg-slate-950 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
              {/* Editor Action Header */}
              <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
                  <Terminal className="w-4 h-4 text-indigo-400" />
                  <span>main.{activeLang === 'c' ? 'c' : activeLang === 'python' ? 'py' : activeLang === 'html' ? 'html' : 'sql'}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyCode}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
                    title="Copy Code"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    onClick={handleResetCode}
                    className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 cursor-pointer"
                    title="Reset Starter Code"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={handleRunCode}
                    disabled={isRunning}
                    className="flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition cursor-pointer disabled:opacity-50"
                  >
                    <Play className={`w-3.5 h-3.5 fill-current ${isRunning ? 'animate-spin' : ''}`} />
                    <span>{isRunning ? 'Running...' : 'Run Code'}</span>
                  </button>
                </div>
              </div>

              {/* Code Textarea */}
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                rows={14}
                spellCheck={false}
                className="w-full p-4 bg-slate-950 text-slate-100 font-mono text-xs sm:text-sm leading-relaxed border-0 focus:outline-hidden resize-none selection:bg-indigo-600 selection:text-white"
              />
            </div>

            {/* Output & Console */}
            {activeLang === 'html' ? (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 text-xs font-bold text-slate-700 flex items-center gap-2">
                  <Globe className="w-3.5 h-3.5 text-indigo-600" />
                  <span>Live HTML / CSS Render Canvas</span>
                </div>
                <iframe
                  srcDoc={htmlOutput}
                  title="HTML Output Preview"
                  className="w-full h-64 border-0 bg-white"
                />
              </div>
            ) : (
              <div className="bg-slate-900 rounded-2xl border border-slate-800 p-4 shadow-xs text-white">
                <div className="flex items-center justify-between text-xs font-mono text-slate-400 mb-2">
                  <span className="flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Terminal / Database Console Output</span>
                  </span>
                  {executionResult && (
                    <span className="text-[11px] text-slate-500">
                      Finished in {executionResult.executionTimeMs}ms
                    </span>
                  )}
                </div>

                <div className="bg-slate-950 p-3.5 rounded-xl font-mono text-xs text-slate-200 min-h-[120px] max-h-[260px] overflow-y-auto whitespace-pre-wrap">
                  {executionResult ? (
                    <div>
                      {executionResult.tableResults && executionResult.tableResults.length > 0 ? (
                        <div className="overflow-x-auto">
                          <table className="w-full text-left text-xs border-collapse">
                            <thead>
                              <tr className="border-b border-slate-700 text-indigo-300 font-bold">
                                {Object.keys(executionResult.tableResults[0]).map((col, idx) => (
                                  <th key={idx} className="p-2">{col}</th>
                                ))}
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800">
                              {executionResult.tableResults.map((row, rIdx) => (
                                <tr key={rIdx} className="hover:bg-slate-900">
                                  {Object.values(row).map((val: any, cIdx) => (
                                    <td key={cIdx} className="p-2 text-slate-300">{String(val)}</td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <div className={executionResult.success ? 'text-emerald-400' : 'text-red-400'}>
                          {executionResult.output}
                        </div>
                      )}
                    </div>
                  ) : (
                    <span className="text-slate-500 italic">Click "Run Code" above to execute...</span>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
