import { Student, Course, Batch, CenterInfo } from '../types';

export interface FeeReminderPayload {
  student: Student;
  course?: Course;
  batch?: Batch;
  dueAmount: number;
  dueMonths: string[];
  templateType?: 'friendly' | 'standard' | 'urgent';
}

export interface ReminderLog {
  studentId: string;
  studentName: string;
  channel: 'whatsapp' | 'email' | 'sms';
  timestamp: string;
  dueAmount: number;
  status: 'sent' | 'opened' | 'copied';
}

/**
 * Generates formatted reminder message based on student dues, template type, and center settings.
 */
export function buildFeeReminderMessage(
  payload: FeeReminderPayload,
  centerInfo: CenterInfo
): { subject: string; message: string } {
  const { student, course, dueAmount, dueMonths, templateType = 'standard' } = payload;
  const courseTitle = course?.title || 'Enrolled Course';
  const monthsText = dueMonths.length > 0 ? dueMonths.join(', ') : 'Current Academic Month';
  const upiId = centerInfo.upiId || '9775708722@apl';
  const upiName = centerInfo.upiName || centerInfo.name;
  const helpline = centerInfo.phonePrimary || '+91 9775708722';

  let greeting = `Dear Parent / Student,`;
  let toneHeader = `Greetings from ${centerInfo.name}!`;

  if (templateType === 'urgent') {
    toneHeader = `⚠️ *URGENT FEE OVERDUE NOTICE* - ${centerInfo.name}`;
  } else if (templateType === 'friendly') {
    toneHeader = `Friendly reminder from ${centerInfo.name} regarding upcoming monthly fee schedule.`;
  }

  const subject = `Fee Notice: ${student.name} (Roll: ${student.rollNo}) - ${centerInfo.name}`;

  const message = `${toneHeader}

${greeting}

This is a reminder regarding the pending tuition fee for *${student.name}* (Roll: ${student.rollNo}).

📚 *Course:* ${courseTitle}
🗓️ *Pending Month(s):* ${monthsText}
💰 *Total Amount Due:* ₹${dueAmount.toLocaleString('en-IN')}

💳 *Online Payment via UPI:*
• UPI ID: \`${upiId}\`
• Payee Name: ${upiName}

Please clear the fee at your earliest convenience. After making the payment, kindly share the UTR/transaction screenshot via WhatsApp on ${helpline}.

You can also log in to your Student Portal to view receipts and status:
• Mobile: ${student.mobile}
• Aadhaar: ${student.aadhaarNo}

Thank you!
*${centerInfo.name} Accounts Desk*
Helpline: ${helpline}`;

  return { subject, message };
}

/**
 * Service function: Triggers a WhatsApp reminder for a student.
 */
export function sendStudentWhatsAppReminder(
  payload: FeeReminderPayload,
  centerInfo: CenterInfo
): boolean {
  try {
    const { message } = buildFeeReminderMessage(payload, centerInfo);
    const cleanPhone = (payload.student.mobile || '').replace(/[^0-9]/g, '');
    const formattedPhone = cleanPhone.startsWith('91') ? cleanPhone : `91${cleanPhone}`;
    const encoded = encodeURIComponent(message);
    const url = `https://wa.me/${formattedPhone}?text=${encoded}`;
    window.open(url, '_blank');
    return true;
  } catch (err) {
    console.error('Error triggering WhatsApp reminder:', err);
    return false;
  }
}

/**
 * Service function: Triggers an Email reminder for a student.
 */
export function sendStudentEmailReminder(
  payload: FeeReminderPayload,
  centerInfo: CenterInfo
): boolean {
  try {
    const { subject, message } = buildFeeReminderMessage(payload, centerInfo);
    const recipient = payload.student.email || centerInfo.email;
    const encodedSubject = encodeURIComponent(subject);
    const encodedBody = encodeURIComponent(message);
    const url = `mailto:${recipient}?subject=${encodedSubject}&body=${encodedBody}`;
    window.location.href = url;
    return true;
  } catch (err) {
    console.error('Error triggering Email reminder:', err);
    return false;
  }
}

/**
 * Service function: Dispatches batch reminders or copies batch summary.
 */
export function buildBatchFeeReminderDigest(
  items: FeeReminderPayload[],
  centerInfo: CenterInfo
): string {
  const dateStr = new Date().toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' });
  let digest = `📢 *${centerInfo.name} - Outstanding Fee Reminders Digest* (${dateStr})\n`;
  digest += `Total Students with Dues: ${items.length}\n`;
  const totalDues = items.reduce((sum, item) => sum + item.dueAmount, 0);
  digest += `Total Outstanding: ₹${totalDues.toLocaleString('en-IN')}\n\n`;

  items.forEach((item, idx) => {
    digest += `${idx + 1}. *${item.student.name}* (Roll: ${item.student.rollNo})\n`;
    digest += `   📱 Mobile: ${item.student.mobile}\n`;
    digest += `   📚 ${item.course?.title || 'Course'}\n`;
    digest += `   💰 Due: ₹${item.dueAmount.toLocaleString('en-IN')} (${item.dueMonths.join(', ')})\n\n`;
  });

  digest += `Official UPI: ${centerInfo.upiId} | Helpline: ${centerInfo.phonePrimary}`;
  return digest;
}
