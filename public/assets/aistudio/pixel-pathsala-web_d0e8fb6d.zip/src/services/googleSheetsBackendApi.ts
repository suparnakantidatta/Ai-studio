/**
 * Backend Client API Service for Google Sheets Live Database
 * Connects the React Frontend to the secure Express Backend (/api/db/*)
 * Enables persistent one-time Google authorization across all browsers & devices.
 */

import { GoogleUserProfile, googleSheetsService } from '../utils/googleSheetsService';
import { 
  CenterInfo, 
  Student, 
  AdmissionApplication, 
  FeePayment, 
  Course, 
  Batch, 
  Educator, 
  Expense, 
  AdminAccount,
  StudyMaterial,
  ExamQuestion,
  OnlineExam,
  ExamSubmission,
  LiveClassSession,
  ClassRecording,
  Discount,
  StudentNotification
} from '../types';

export interface BackendDbStatus {
  success: boolean;
  isConfigured: boolean;
  isConnected: boolean;
  hasToken: boolean;
  googleSheetId: string | null;
  googleSheetTitle: string;
  spreadsheetUrl: string | null;
  googleUser: GoogleUserProfile | null;
  lastSynced: string | null;
  connectedAt: string | null;
  autoSyncEnabled: boolean;
  tableStats: {
    students: number;
    admissions: number;
    payments: number;
    courses: number;
    batches: number;
    educators: number;
    expenses: number;
    adminAccounts: number;
    studyMaterials?: number;
    questions?: number;
    exams?: number;
    examSubmissions?: number;
    liveClasses?: number;
    classRecordings?: number;
  };
}

export interface BackendLoadResult {
  success: boolean;
  fromLiveGoogleSheet?: boolean;
  fromCache?: boolean;
  data?: {
    students: Student[];
    admissions: AdmissionApplication[];
    payments: FeePayment[];
    courses: Course[];
    batches: Batch[];
    educators: Educator[];
    expenses: Expense[];
    adminAccounts: AdminAccount[];
    studyMaterials?: StudyMaterial[];
    questions?: ExamQuestion[];
    exams?: OnlineExam[];
    examSubmissions?: ExamSubmission[];
    liveClasses?: LiveClassSession[];
    classRecordings?: ClassRecording[];
    centerInfo: Partial<CenterInfo>;
  };
  counts?: Record<string, number>;
  lastSynced?: string;
  spreadsheetId?: string;
  spreadsheetUrl?: string;
  error?: string;
  message?: string;
}

class GoogleSheetsBackendApi {
  private isAvailable: boolean = true;

  public async getStatus(): Promise<BackendDbStatus | null> {
    try {
      const res = await fetch('/api/db/status', {
        headers: { 'Accept': 'application/json' }
      });
      if (!res.ok) return null;
      return await res.json();
    } catch (err) {
      console.warn('Backend status check unavailable:', err);
      return null;
    }
  }

  public async persistSession(
    accessToken: string, 
    googleUser: GoogleUserProfile | null, 
    expiresIn: number = 3600
  ): Promise<{ success: boolean; error?: string; message?: string }> {
    try {
      const res = await fetch('/api/db/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ accessToken, googleUser, expiresIn })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to persist session to server' };
    }
  }

  public async disconnectSession(): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await fetch('/api/db/disconnect', { method: 'POST' });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async createMasterSheet(
    centerInfo: CenterInfo, 
    initialData: any
  ): Promise<{ success: boolean; spreadsheetId?: string; spreadsheetUrl?: string; message?: string; error?: string }> {
    try {
      const token = googleSheetsService.getAccessToken();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const res = await fetch('/api/db/create-master-sheet', {
        method: 'POST',
        headers,
        body: JSON.stringify({ centerInfo, initialData, accessToken: token || undefined })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async linkSheet(
    spreadsheetIdOrUrl: string
  ): Promise<{ success: boolean; spreadsheetId?: string; spreadsheetUrl?: string; title?: string; message?: string; error?: string }> {
    try {
      const token = googleSheetsService.getAccessToken();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const res = await fetch('/api/db/link-sheet', {
        method: 'POST',
        headers,
        body: JSON.stringify({ spreadsheetIdOrUrl, accessToken: token || undefined })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async loadAll(spreadsheetId?: string): Promise<BackendLoadResult> {
    try {
      const token = googleSheetsService.getAccessToken();
      const headers: Record<string, string> = { 'Accept': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const url = spreadsheetId ? `/api/db/load-all?spreadsheetId=${encodeURIComponent(spreadsheetId)}` : '/api/db/load-all';
      const res = await fetch(url, { headers });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async pullAll(spreadsheetId?: string): Promise<BackendLoadResult> {
    try {
      const token = googleSheetsService.getAccessToken();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const res = await fetch('/api/db/pull-all', {
        method: 'POST',
        headers,
        body: JSON.stringify({ spreadsheetId, accessToken: token || undefined })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async saveCenterInfo(
    centerInfo: Partial<CenterInfo>
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/db/save-center-info', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(centerInfo)
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async approveAdmission(
    data: { applicationId: string; student: any; payment?: any; admission: any; centerInfo?: Partial<CenterInfo> }
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/db/approve-admission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async saveAll(
    payload: {
      spreadsheetId?: string;
      students?: Student[];
      admissions?: AdmissionApplication[];
      payments?: FeePayment[];
      courses?: Course[];
      batches?: Batch[];
      educators?: Educator[];
      expenses?: Expense[];
      discounts?: Discount[];
      adminAccounts?: AdminAccount[];
      studyMaterials?: StudyMaterial[];
      questions?: ExamQuestion[];
      exams?: OnlineExam[];
      examSubmissions?: ExamSubmission[];
      liveClasses?: LiveClassSession[];
      classRecordings?: ClassRecording[];
      notifications?: StudentNotification[];
      centerInfo?: Partial<CenterInfo>;
    }
  ): Promise<{ success: boolean; message?: string; lastSynced?: string; error?: string; needsClientSheetsSync?: boolean }> {
    try {
      const token = googleSheetsService.getAccessToken();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const res = await fetch('/api/db/save-all', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          ...payload,
          pushToGoogleSheets: true,
          accessToken: token || undefined
        })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async ensureTables(
    spreadsheetId?: string
  ): Promise<{ success: boolean; spreadsheetId?: string; created?: string[]; existing?: string[]; message?: string; error?: string }> {
    try {
      const token = googleSheetsService.getAccessToken();
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      const res = await fetch('/api/db/ensure-tables', {
        method: 'POST',
        headers,
        body: JSON.stringify({ spreadsheetId, accessToken: token || undefined })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async pushWebhook(
    webhookUrl: string, 
    payload: any
  ): Promise<{ success: boolean; message?: string; error?: string; timestamp?: string }> {
    try {
      const res = await fetch('/api/sheets/push-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ webhookUrl, payload })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Webhook push failed' };
    }
  }

  public async testWebhook(
    webhookUrl: string
  ): Promise<{ success: boolean; message?: string; action?: string; timestamp?: string; error?: string }> {
    try {
      const res = await fetch('/api/sheets/test-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ webhookUrl })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message || 'Webhook test request failed' };
    }
  }

  public async pullWebhook(webhookUrl?: string): Promise<BackendLoadResult> {
    try {
      const res = await fetch('/api/sheets/pull-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ webhookUrl })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async saveWebhookConfig(
    webhookUrl: string, 
    autoWriteBack: boolean
  ): Promise<{ success: boolean; message?: string; error?: string }> {
    try {
      const res = await fetch('/api/sheets/config-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ webhookUrl, autoWriteBack })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }

  public async mutateRecord(
    action: string, 
    payload: any
  ): Promise<{ success: boolean; message?: string; warning?: string }> {
    try {
      const res = await fetch('/api/db/mutate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, payload })
      });
      return await res.json();
    } catch (err: any) {
      console.warn('Backend live mutate call error:', err);
      return { success: true, warning: err.message };
    }
  }

  public async mutate(
    action: string,
    payload: any
  ): Promise<{ success: boolean; message?: string; warning?: string }> {
    return this.mutateRecord(action, payload);
  }

  public async appendRow(
    action: string,
    payload: any
  ): Promise<{ success: boolean; message?: string; warning?: string }> {
    return this.mutateRecord(action, payload);
  }

  public async adminLogin(username: string, password: string): Promise<{ success: boolean; message: string; adminUser?: any }> {
    try {
      const res = await fetch('/api/auth/admin-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, message: err.message || 'Database connection error' };
    }
  }

  public async studentLogin(mobile: string, aadhaarNo: string): Promise<{ success: boolean; message: string; student?: any }> {
    try {
      const res = await fetch('/api/auth/student-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mobile, aadhaarNo })
      });
      return await res.json();
    } catch (err: any) {
      return { success: false, message: err.message || 'Database connection error' };
    }
  }
}

export const googleSheetsBackendApi = new GoogleSheetsBackendApi();
