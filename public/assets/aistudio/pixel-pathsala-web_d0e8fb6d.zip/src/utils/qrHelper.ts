/**
 * Generates standard UPI payment URL and QR image URL
 */
export function buildUpiPaymentUri(params: {
  upiId: string;
  payeeName: string;
  amount?: number;
  transactionNote?: string;
}): string {
  const upiId = encodeURIComponent(params.upiId.trim());
  const pn = encodeURIComponent(params.payeeName.trim());
  let uri = `upi://pay?pa=${upiId}&pn=${pn}&cu=INR`;

  if (params.amount && params.amount > 0) {
    uri += `&am=${params.amount.toFixed(2)}`;
  }
  if (params.transactionNote) {
    uri += `&tn=${encodeURIComponent(params.transactionNote)}`;
  }
  return uri;
}

/**
 * Returns clickable UPI deep link for opening payment app
 */
export function getUpiDeepLink(params: {
  upiId: string;
  payeeName: string;
  amount?: number;
  note?: string;
  transactionNote?: string;
}): string {
  return buildUpiPaymentUri({
    upiId: params.upiId,
    payeeName: params.payeeName,
    amount: params.amount,
    transactionNote: params.note || params.transactionNote
  });
}

/**
 * Returns an instant QR code image URL for scanning
 */
export function getUpiQrCodeUrl(params: {
  upiId: string;
  payeeName: string;
  amount?: number;
  transactionNote?: string;
  size?: number;
}): string {
  const upiUri = buildUpiPaymentUri(params);
  const size = params.size || 240;
  // High-reliability QR API with clean error correction level H
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(upiUri)}&color=0f172a&bgcolor=ffffff&qzone=2&format=svg`;
}
