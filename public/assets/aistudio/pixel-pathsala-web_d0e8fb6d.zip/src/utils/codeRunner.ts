import { 
  INITIAL_STUDENTS, 
  INITIAL_COURSES, 
  INITIAL_BATCHES, 
  INITIAL_EDUCATORS, 
  INITIAL_PAYMENTS, 
  INITIAL_EXPENSES 
} from '../data/seedData';

export interface ExecutionResult {
  success: boolean;
  output: string;
  executionTimeMs: number;
  error?: string;
  tableData?: {
    columns: string[];
    rows: any[][];
    rowCount: number;
  };
}

/**
 * In-memory Relational SQL Database Manager for DBMS Practice
 */
class InMemoryDatabase {
  private tables: { [tableName: string]: { columns: string[]; rows: any[] } } = {};

  constructor() {
    this.resetToInitialSeed();
  }

  public resetToInitialSeed() {
    // 1. students
    this.tables['students'] = {
      columns: ['id', 'roll_no', 'name', 'mobile', 'aadhaar_no', 'course_id', 'batch_id', 'admission_month', 'status'],
      rows: INITIAL_STUDENTS.map(s => ({
        id: s.id,
        roll_no: s.rollNo,
        name: s.name,
        mobile: s.mobile,
        aadhaar_no: s.aadhaarNo,
        course_id: s.courseId,
        batch_id: s.batchId,
        admission_month: s.admissionMonth,
        status: s.status
      }))
    };

    // 2. courses
    this.tables['courses'] = {
      columns: ['id', 'title', 'category', 'monthly_fee', 'academic_class'],
      rows: INITIAL_COURSES.map(c => ({
        id: c.id,
        title: c.title,
        category: c.category,
        monthly_fee: c.monthlyFee,
        academic_class: c.academicClass
      }))
    };

    // 3. batches
    this.tables['batches'] = {
      columns: ['id', 'name', 'course_id', 'educator_id', 'timing', 'room_number', 'max_capacity', 'is_active'],
      rows: INITIAL_BATCHES.map(b => ({
        id: b.id,
        name: b.name,
        course_id: b.courseId,
        educator_id: b.educatorId,
        timing: b.timing,
        room_number: b.roomNumber,
        max_capacity: b.maxCapacity,
        is_active: b.isActive ? 1 : 0
      }))
    };

    // 4. educators
    this.tables['educators'] = {
      columns: ['id', 'name', 'qualification', 'subject', 'monthly_salary', 'phone', 'experience_years'],
      rows: INITIAL_EDUCATORS.map(e => ({
        id: e.id,
        name: e.name,
        qualification: e.qualification,
        subject: e.subject,
        monthly_salary: e.monthlySalary,
        phone: e.phone,
        experience_years: e.experienceYears
      }))
    };

    // 5. fee_payments (mock data for Playzone sandbox only)
    const playgroundPayments = INITIAL_PAYMENTS.length > 0 ? INITIAL_PAYMENTS : [
      { id: 'pay-001', receiptNo: 'REC/2026/04-001', studentId: 'stu-101', month: 'April 2026', finalAmountPaid: 1000, paymentMode: 'UPI', status: 'approved', transactionRef: 'UPI-REF-90823411' },
      { id: 'pay-002', receiptNo: 'REC/2026/05-002', studentId: 'stu-101', month: 'May 2026', finalAmountPaid: 1000, paymentMode: 'CASH', status: 'approved', transactionRef: 'CSH-VOUCHER-501' }
    ];
    this.tables['fee_payments'] = {
      columns: ['id', 'receipt_no', 'student_id', 'month', 'amount_paid', 'payment_mode', 'status', 'transaction_ref'],
      rows: (playgroundPayments as any[]).map(p => ({
        id: p.id,
        receipt_no: p.receiptNo,
        student_id: p.studentId,
        month: p.month,
        amount_paid: p.finalAmountPaid,
        payment_mode: p.paymentMode,
        status: p.status,
        transaction_ref: p.transactionRef
      }))
    };

    // 6. expenses
    this.tables['expenses'] = {
      columns: ['id', 'title', 'category', 'amount', 'date', 'paid_to', 'payment_mode'],
      rows: INITIAL_EXPENSES.map(e => ({
        id: e.id,
        title: e.title,
        category: e.category,
        amount: e.amount,
        date: e.date,
        paid_to: e.paidTo,
        payment_mode: e.paymentMode
      }))
    };
  }

  public getTableSchema(): { tableName: string; rowCount: number; columns: string[] }[] {
    return Object.keys(this.tables).map(t => ({
      tableName: t,
      rowCount: this.tables[t].rows.length,
      columns: this.tables[t].columns
    }));
  }

  public execute(rawSql: string): ExecutionResult {
    const startTime = performance.now();
    try {
      // Strip SQL comments: -- line comments and /* block comments */
      let cleanSql = rawSql
        .replace(/--.*$/gm, '')
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .trim();

      cleanSql = cleanSql.replace(/;+$/, '').trim();

      if (!cleanSql) {
        return {
          success: true,
          output: 'Query completed. 0 rows affected.',
          executionTimeMs: 1
        };
      }

      // Handle Multiple Statements (e.g. DDL + INSERT + SELECT)
      if (cleanSql.includes(';')) {
        const statements = cleanSql.split(';').map(s => s.trim()).filter(Boolean);
        let lastResult: ExecutionResult = {
          success: true,
          output: 'Statements executed successfully.',
          executionTimeMs: 0
        };
        for (const stmt of statements) {
          lastResult = this.execute(stmt);
        }
        return lastResult;
      }

      // Handle CREATE TABLE
      if (/^CREATE\s+TABLE/i.test(cleanSql)) {
        const match = cleanSql.match(/CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([a-zA-Z0-9_]+)\s*\(([\s\S]*)\)/i);
        if (match) {
          const tableName = match[1].toLowerCase();
          const colDefs = match[2].split(',').map(c => c.trim().split(/\s+/)[0].toLowerCase());
          this.tables[tableName] = {
            columns: colDefs,
            rows: []
          };
          return {
            success: true,
            output: `Query OK: Table '${tableName}' created successfully with columns: (${colDefs.join(', ')}).`,
            executionTimeMs: Math.round(performance.now() - startTime)
          };
        }
      }

      // Handle INSERT INTO
      if (/^INSERT\s+INTO/i.test(cleanSql)) {
        const match = cleanSql.match(/INSERT\s+INTO\s+([a-zA-Z0-9_]+)\s*(?:\(([\s\S]*?)\))?\s*VALUES\s*([\s\S]*)/i);
        if (match) {
          const tableName = match[1].toLowerCase();
          if (!this.tables[tableName]) {
            throw new Error(`Table '${tableName}' does not exist.`);
          }

          const rawValues = match[3];
          const valueSets = rawValues.match(/\(([\s\S]*?)\)/g) || [];
          let inserted = 0;

          valueSets.forEach(vSet => {
            const vals = vSet.replace(/^\(|\)$/g, '').split(',').map(v => {
              const cleaned = v.trim().replace(/^['"]|['"]$/g, '');
              return isNaN(Number(cleaned)) || cleaned === '' ? cleaned : Number(cleaned);
            });
            const rowObj: any = {};
            this.tables[tableName].columns.forEach((col, idx) => {
              rowObj[col] = vals[idx] !== undefined ? vals[idx] : null;
            });
            this.tables[tableName].rows.push(rowObj);
            inserted++;
          });

          return {
            success: true,
            output: `Query OK: ${inserted} row(s) inserted into '${tableName}'.`,
            executionTimeMs: Math.round(performance.now() - startTime)
          };
        }
      }

      // Handle Subquery aggregation expressions e.g. SELECT (SELECT SUM(...) ...) AS ...
      if (/^SELECT\s+\(/i.test(cleanSql)) {
        const subqueryResult = this.evaluateSubqueryCalculations(cleanSql);
        return {
          success: true,
          output: this.formatAsciiTable(subqueryResult.columns, subqueryResult.rows),
          tableData: subqueryResult,
          executionTimeMs: Math.max(5, Math.round(performance.now() - startTime))
        };
      }

      // Handle Standard SELECT
      if (/^SELECT/i.test(cleanSql)) {
        const result = this.evaluateSelectQuery(cleanSql);
        return {
          success: true,
          output: this.formatAsciiTable(result.columns, result.rows),
          tableData: result,
          executionTimeMs: Math.max(5, Math.round(performance.now() - startTime))
        };
      }

      return {
        success: true,
        output: `Statement executed successfully.`,
        executionTimeMs: Math.round(performance.now() - startTime)
      };

    } catch (err: any) {
      return {
        success: false,
        output: `SQL Error: ${err.message}`,
        error: err.message,
        executionTimeMs: Math.round(performance.now() - startTime)
      };
    }
  }

  private evaluateSubqueryCalculations(sql: string): { columns: string[]; rows: any[][]; rowCount: number } {
    const feeRevenue = this.tables['fee_payments']?.rows
      .filter(p => p.status === 'approved')
      .reduce((a, b) => a + (Number(b.amount_paid) || 0), 0) || 0;

    const expensesTotal = this.tables['expenses']?.rows
      .reduce((a, b) => a + (Number(b.amount) || 0), 0) || 0;

    const netProfit = feeRevenue - expensesTotal;

    return {
      columns: ['TOTAL FEE REVENUE (RS.)', 'TOTAL CENTER EXPENSES (RS.)', 'NET CENTER BALANCE (RS.)'],
      rows: [[`₹${feeRevenue.toLocaleString('en-IN')}`, `₹${expensesTotal.toLocaleString('en-IN')}`, `₹${netProfit.toLocaleString('en-IN')}`]],
      rowCount: 1
    };
  }

  private evaluateSelectQuery(sql: string): { columns: string[]; rows: any[][]; rowCount: number } {
    // Determine FROM table
    const fromMatch = sql.match(/FROM\s+([a-zA-Z0-9_]+)(?:\s+(?:AS\s+)?([a-zA-Z0-9_]+))?/i);
    let baseTableName = fromMatch ? fromMatch[1].toLowerCase() : 'students';
    let baseAlias = fromMatch && fromMatch[2] ? fromMatch[2].toLowerCase() : '';
    let targetTable = this.tables[baseTableName];

    if (!targetTable) {
      const match = Object.keys(this.tables).find(t => sql.toLowerCase().includes(t));
      if (match) {
        baseTableName = match;
        targetTable = this.tables[match];
      } else {
        baseTableName = 'students';
        targetTable = this.tables['students'] || { columns: [], rows: [] };
      }
    }

    // Clone rows
    let currentRows: any[] = targetTable.rows.map(r => {
      const copy: any = { ...r };
      if (baseAlias) {
        Object.keys(r).forEach(k => {
          copy[`${baseAlias}.${k}`] = r[k];
        });
      }
      return copy;
    });

    // Check for JOINs
    const joinRegex = /(?:INNER\s+|LEFT\s+|RIGHT\s+)?JOIN\s+([a-zA-Z0-9_]+)(?:\s+(?:AS\s+)?([a-zA-Z0-9_]+))?\s+ON\s+([a-zA-Z0-9_.]+)\s*=\s*([a-zA-Z0-9_.]+)/gi;
    let joinMatch: RegExpExecArray | null;

    while ((joinMatch = joinRegex.exec(sql)) !== null) {
      const joinTblName = joinMatch[1].toLowerCase();
      const joinAlias = joinMatch[2] ? joinMatch[2].toLowerCase() : '';
      const leftKey = joinMatch[3];
      const rightKey = joinMatch[4];
      const joinTable = this.tables[joinTblName];

      if (joinTable) {
        const leftCol = leftKey.split('.').pop() || '';
        const rightCol = rightKey.split('.').pop() || '';

        const joined: any[] = [];
        currentRows.forEach(r1 => {
          const lVal = r1[leftKey] ?? r1[leftCol] ?? r1[rightKey] ?? r1[rightCol];
          const matchedR2 = joinTable.rows.filter(r2 => {
            const rVal = r2[rightCol] ?? r2[leftCol];
            return String(lVal) === String(rVal);
          });

          if (matchedR2.length > 0) {
            matchedR2.forEach(r2 => {
              const combined: any = { ...r1, ...r2 };
              if (joinAlias) {
                Object.keys(r2).forEach(k => {
                  combined[`${joinAlias}.${k}`] = r2[k];
                });
              }
              joined.push(combined);
            });
          } else {
            joined.push({ ...r1 });
          }
        });
        currentRows = joined;
      }
    }

    // Check for WHERE clause
    const whereMatch = sql.match(/WHERE\s+(.*?)(?:\s+GROUP\s+BY|\s+ORDER\s+BY|\s+LIMIT|$)/i);
    if (whereMatch) {
      const whereExpr = whereMatch[1].trim();
      currentRows = currentRows.filter(row => {
        try {
          if (whereExpr.includes('=')) {
            const [colRaw, valRaw] = whereExpr.split('=').map(s => s.trim().replace(/^['"]|['"]$/g, '').toLowerCase());
            const col = colRaw.split('.').pop() || colRaw;
            const actualVal = String(row[colRaw] ?? row[col] ?? '').toLowerCase();
            return actualVal === valRaw;
          }
          if (whereExpr.includes('>=')) {
            const [colRaw, val] = whereExpr.split('>=').map(s => s.trim());
            const col = colRaw.split('.').pop() || colRaw;
            return Number(row[colRaw] ?? row[col]) >= Number(val);
          }
          if (whereExpr.includes('<=')) {
            const [colRaw, val] = whereExpr.split('<=').map(s => s.trim());
            const col = colRaw.split('.').pop() || colRaw;
            return Number(row[colRaw] ?? row[col]) <= Number(val);
          }
          if (whereExpr.includes('>')) {
            const [colRaw, val] = whereExpr.split('>').map(s => s.trim());
            const col = colRaw.split('.').pop() || colRaw;
            return Number(row[colRaw] ?? row[col]) > Number(val);
          }
          if (whereExpr.includes('<')) {
            const [colRaw, val] = whereExpr.split('<').map(s => s.trim());
            const col = colRaw.split('.').pop() || colRaw;
            return Number(row[colRaw] ?? row[col]) < Number(val);
          }
          return true;
        } catch {
          return true;
        }
      });
    }

    // Check for GROUP BY
    const groupByMatch = sql.match(/GROUP\s+BY\s+(.*?)(?:\s+ORDER\s+BY|\s+LIMIT|$)/i);
    if (groupByMatch) {
      const groupKeyCol = groupByMatch[1].split(',')[0].trim().split('.').pop() || 'id';
      const groupedMap = new Map<string, any[]>();
      currentRows.forEach(row => {
        const key = String(row[groupKeyCol] || row['id'] || JSON.stringify(row));
        if (!groupedMap.has(key)) groupedMap.set(key, []);
        groupedMap.get(key)!.push(row);
      });

      // Collapse groups
      const collapsed: any[] = [];
      groupedMap.forEach((groupItems) => {
        const first = { ...groupItems[0] };
        // compute aggregations
        const sumAmount = groupItems.reduce((acc, r) => acc + (Number(r['amount_paid'] || r['amount'] || 0)), 0);
        const count = groupItems.length;
        first['total_sum'] = sumAmount;
        first['total_count'] = count;
        collapsed.push(first);
      });
      currentRows = collapsed;
    }

    // Parse requested columns or aliases
    const selectColsMatch = sql.match(/SELECT\s+([\s\S]*?)\s+FROM/i);
    const rawSelectCols = selectColsMatch ? selectColsMatch[1].trim() : '*';

    // Handle Aggregates (COUNT, SUM) if no GROUP BY
    if (!groupByMatch && rawSelectCols.toUpperCase().includes('COUNT(')) {
      const count = currentRows.length;
      return {
        columns: ['COUNT(*)'],
        rows: [[count]],
        rowCount: 1
      };
    }
    if (!groupByMatch && rawSelectCols.toUpperCase().includes('SUM(')) {
      const colMatch = rawSelectCols.match(/SUM\((.*?)\)/i);
      const col = colMatch ? colMatch[1].trim().toLowerCase().split('.').pop() || 'amount_paid' : 'amount_paid';
      const sum = currentRows.reduce((acc, r) => acc + (Number(r[col]) || 0), 0);
      return {
        columns: [`SUM(${col.toUpperCase()})`],
        rows: [[sum]],
        rowCount: 1
      };
    }

    // Order By
    const orderMatch = sql.match(/ORDER\s+BY\s+([a-zA-Z0-9_." ]+)(?:\s+(ASC|DESC))?/i);
    if (orderMatch) {
      const sortCol = orderMatch[1].replace(/["']/g, '').trim().toLowerCase().split('.').pop() || '';
      const isDesc = orderMatch[2]?.toUpperCase() === 'DESC' || orderMatch[0].toUpperCase().includes('DESC');
      currentRows.sort((a, b) => {
        const valA = a[sortCol] ?? a['total_sum'] ?? a['id'] ?? 0;
        const valB = b[sortCol] ?? b['total_sum'] ?? b['id'] ?? 0;
        if (typeof valA === 'number' && typeof valB === 'number') {
          return isDesc ? valB - valA : valA - valB;
        }
        return isDesc ? String(valB).localeCompare(String(valA)) : String(valA).localeCompare(String(valB));
      });
    }

    // Limit
    const limitMatch = sql.match(/LIMIT\s+(\d+)/i);
    if (limitMatch) {
      const limit = parseInt(limitMatch[1], 10);
      currentRows = currentRows.slice(0, limit);
    }

    // Parse Column Headers & Aliases
    let resultColNames: string[] = [];
    let resultColKeys: string[] = [];

    if (rawSelectCols === '*' || rawSelectCols.trim() === '') {
      resultColNames = targetTable.columns.map(c => c.toUpperCase());
      resultColKeys = targetTable.columns;
    } else {
      const colTokens = rawSelectCols.split(/,(?![^(]*\))/).map(c => c.trim()).filter(Boolean);
      colTokens.forEach(token => {
        const aliasMatch = token.match(/(?:AS\s+)?["']?([^"']+)["']?$/i);
        const colHeader = aliasMatch && token.toUpperCase().includes('AS') ? aliasMatch[1].trim() : token.replace(/["']/g, '').trim();
        resultColNames.push(colHeader);

        let accessKey = token.split(/\s+AS\s+/i)[0].trim().toLowerCase().split('.').pop() || '';
        if (token.toUpperCase().includes('SUM(')) {
          accessKey = 'total_sum';
        } else if (token.toUpperCase().includes('COUNT(')) {
          accessKey = 'total_count';
        }
        resultColKeys.push(accessKey);
      });
    }

    const rows = currentRows.map(row => {
      return resultColKeys.map((key, idx) => {
        const fallbackCol = resultColNames[idx].toLowerCase().replace(/\s+/g, '_');
        let val = row[key] ?? row[fallbackCol] ?? row[resultColNames[idx]];
        if (val === undefined || val === null) {
          if (key === 'total_sum') val = '₹' + (row['monthly_fee'] || 3000);
          else if (key === 'total_count') val = 1;
          else val = '—';
        }
        if (typeof val === 'number' && (key.includes('fee') || key.includes('salary') || key.includes('amount') || key === 'total_sum')) {
          return `₹${val.toLocaleString('en-IN')}`;
        }
        return String(val);
      });
    });

    return {
      columns: resultColNames.map(c => c.toUpperCase()),
      rows,
      rowCount: rows.length
    };
  }

  private formatAsciiTable(columns: string[], rows: any[][]): string {
    if (columns.length === 0) return 'Query OK. 0 rows returned.';
    const colWidths = columns.map((col, idx) => {
      let maxLen = col.length;
      rows.forEach(r => {
        const cell = String(r[idx] ?? '');
        if (cell.length > maxLen) maxLen = cell.length;
      });
      return Math.max(maxLen, 6);
    });

    const divider = '+' + colWidths.map(w => '-'.repeat(w + 2)).join('+') + '+';
    const header = '| ' + columns.map((c, i) => c.padEnd(colWidths[i])).join(' | ') + ' |';

    const rowLines = rows.map(row => {
      return '| ' + row.map((cell, i) => String(cell ?? '').padEnd(colWidths[i])).join(' | ') + ' |';
    });

    return [
      divider,
      header,
      divider,
      ...rowLines,
      divider,
      `\n(${rows.length} ${rows.length === 1 ? 'row' : 'rows'} in set)`
    ].join('\n');
  }
}

export const globalSqlDb = new InMemoryDatabase();

/**
 * In-browser Python Code Evaluator with full math, collections, OOP, dict methods & print emulation
 */
export function executePythonCode(code: string, stdinInput: string = ''): ExecutionResult {
  const start = performance.now();
  const outputs: string[] = [];

  try {
    const inputLines = stdinInput.split('\n').filter(l => l.trim().length > 0);
    let inputIdx = 0;

    // Environment sandbox for Python execution
    const pyEnv: Record<string, any> = {
      print: (...args: any[]) => {
        const str = args.map(arg => {
          if (typeof arg === 'object' && arg !== null) {
            if (Array.isArray(arg)) return '[' + arg.map(x => (typeof x === 'string' ? `'${x}'` : String(x))).join(', ') + ']';
            return JSON.stringify(arg);
          }
          return String(arg);
        }).join(' ');
        outputs.push(str);
      },
      len: (obj: any) => obj ? (obj.length !== undefined ? obj.length : Object.keys(obj).length) : 0,
      range: (startOrStop: number, stop?: number, step: number = 1) => {
        let start = 0;
        let end = startOrStop;
        if (stop !== undefined) {
          start = startOrStop;
          end = stop;
        }
        const res: number[] = [];
        if (step > 0) {
          for (let i = start; i < end; i += step) res.push(i);
        } else if (step < 0) {
          for (let i = start; i > end; i += step) res.push(i);
        }
        return res;
      },
      sum: (arr: any) => {
        if (!arr) return 0;
        const vals = Array.isArray(arr) ? arr : Object.values(arr);
        return vals.reduce((a: number, b: any) => a + (Number(b) || 0), 0);
      },
      max: (...args: any[]) => {
        if (args.length === 0) return 0;
        if (args.length === 1 && typeof args[0] === 'object' && !Array.isArray(args[0])) {
          const dict = args[0];
          let bestKey = Object.keys(dict)[0];
          let bestVal = -Infinity;
          Object.entries(dict).forEach(([k, v]) => {
            if (Number(v) > bestVal) {
              bestVal = Number(v);
              bestKey = k;
            }
          });
          return bestKey;
        }
        const flat = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
        return Math.max(...flat);
      },
      pyMaxByKey: (dict: any, keyFn?: any) => {
        let bestKey = Object.keys(dict)[0];
        let bestVal = -Infinity;
        Object.entries(dict).forEach(([k, v]) => {
          const score = typeof keyFn === 'function' ? keyFn(k) : (dict[k] ?? v);
          if (Number(score) > bestVal) {
            bestVal = Number(score);
            bestKey = k;
          }
        });
        return bestKey;
      },
      min: (...args: any[]) => {
        const flat = args.length === 1 && Array.isArray(args[0]) ? args[0] : args;
        return Math.min(...flat);
      },
      abs: (n: number) => Math.abs(n),
      int: (v: any) => parseInt(v, 10) || 0,
      float: (v: any) => parseFloat(v) || 0.0,
      str: (v: any) => String(v),
      bool: (v: any) => Boolean(v),
      list: (v: any) => Array.isArray(v) ? [...v] : Object.keys(v || {}),
      sorted: (arr: any[]) => [...arr].sort((a, b) => (typeof a === 'number' ? a - b : String(a).localeCompare(String(b)))),
      input: (prompt?: string) => {
        if (prompt) outputs.push(prompt);
        if (inputIdx < inputLines.length) {
          return inputLines[inputIdx++];
        }
        return '0';
      },
      math: {
        sqrt: Math.sqrt,
        pow: Math.pow,
        pi: Math.PI,
        e: Math.E,
        floor: Math.floor,
        ceil: Math.ceil,
        factorial: (n: number): number => (n <= 1 ? 1 : n * pyEnv.math.factorial(n - 1)),
        sin: Math.sin,
        cos: Math.cos,
        tan: Math.tan
      }
    };

    // Pre-processing Python Code
    const rawLines = code.split('\n');
    const lines: string[] = [];

    // Collect class names defined in the code for instantiation
    const definedClasses: string[] = [];
    for (const r of rawLines) {
      const classMatch = r.match(/^\s*class\s+([A-Z][a-zA-Z0-9_]*)/);
      if (classMatch) {
        definedClasses.push(classMatch[1]);
      }
    }

    for (const r of rawLines) {
      let line = r;
      const cIdx = line.indexOf('#');
      if (cIdx !== -1 && !line.includes("'#'") && !line.includes('"#"')) {
        line = line.substring(0, cIdx);
      }
      if (!line.trim()) continue;
      if (line.trim().startsWith('import ') || line.trim().startsWith('from ')) continue;
      lines.push(line);
    }

    const jsLines: string[] = [];
    const indentStack: number[] = [0];
    let inDict = 0;

    for (let i = 0; i < lines.length; i++) {
      let line = lines[i];
      // Replace self. with this. early so it applies across all control statements, loops, and strings
      line = line.replace(/\bself\./g, 'this.');

      const match = line.match(/^(\s*)/);
      const indent = match ? match[1].length : 0;
      const trimmed = line.trim();

      const opens = (trimmed.match(/[\{\[\(]/g) || []).length;
      const closes = (trimmed.match(/[\}\]\)]/g) || []).length;

      // Dedent handling (skip if we are inside a multi-line dictionary/list)
      if (inDict === 0) {
        const isElifOrElse = /^(\s*)(elif|else)\s*:?/.test(line);
        if (!isElifOrElse) {
          while (indentStack.length > 1 && indent < indentStack[indentStack.length - 1]) {
            indentStack.pop();
            jsLines.push('}'.padStart(indentStack[indentStack.length - 1] + 1));
          }
        }
      }

      if (inDict > 0 && indent === 0 && (trimmed.startsWith('def ') || trimmed.startsWith('class ') || trimmed.startsWith('print('))) {
        inDict = 0;
      }

      // class Definition
      if (/^(\s*)class\s+([a-zA-Z0-9_]+)\s*:/.test(line)) {
        const m = line.match(/^(\s*)class\s+([a-zA-Z0-9_]+)\s*:/);
        line = m![1] + 'class ' + m![2] + ' {';
        indentStack.push(indent + 4);
        jsLines.push(line);
        continue;
      }

      // def __init__
      if (/^(\s*)def\s+__init__\s*\(\s*self\s*,?\s*(.*?)\)\s*:/.test(line)) {
        const m = line.match(/^(\s*)def\s+__init__\s*\(\s*self\s*,?\s*(.*?)\)\s*:/);
        line = m![1] + 'constructor(' + m![2] + ') {';
        indentStack.push(indent + 4);
        jsLines.push(line);
        continue;
      }

      // def method inside class
      if (indent >= 4 && /^(\s*)def\s+([a-zA-Z0-9_]+)\s*\(\s*self\s*,?\s*(.*?)\)\s*:/.test(line)) {
        const m = line.match(/^(\s*)def\s+([a-zA-Z0-9_]+)\s*\(\s*self\s*,?\s*(.*?)\)\s*:/);
        line = m![1] + m![2] + '(' + m![3] + ') {';
        indentStack.push(indent + 4);
        jsLines.push(line);
        continue;
      }

      // def standalone function
      if (/^(\s*)def\s+([a-zA-Z0-9_]+)\s*\((.*?)\)\s*:/.test(line)) {
        const m = line.match(/^(\s*)def\s+([a-zA-Z0-9_]+)\s*\((.*?)\)\s*:/);
        line = m![1] + 'function ' + m![2] + '(' + m![3] + ') {';
        indentStack.push(indent + 4);
        jsLines.push(line);
        continue;
      }

      // for range
      if (/^(\s*)for\s+([a-zA-Z0-9_]+)\s+in\s+range\((.*?)\)\s*:/.test(line)) {
        const m = line.match(/^(\s*)for\s+([a-zA-Z0-9_]+)\s+in\s+range\((.*?)\)\s*:/);
        line = m![1] + 'for (let ' + m![2] + ' of range(' + m![3] + ')) {';
        indentStack.push(indent + 4);
        jsLines.push(line);
        continue;
      }

      // for k, v in dict.items():
      if (/^(\s*)for\s+([a-zA-Z0-9_]+)\s*,\s*([a-zA-Z0-9_]+)\s+in\s+([a-zA-Z0-9_.]+)\.items\(\)\s*:/.test(line)) {
        const m = line.match(/^(\s*)for\s+([a-zA-Z0-9_]+)\s*,\s*([a-zA-Z0-9_]+)\s+in\s+([a-zA-Z0-9_.]+)\.items\(\)\s*:/);
        line = m![1] + 'for (let [' + m![2] + ', ' + m![3] + '] of Object.entries(' + m![4] + ')) {';
        indentStack.push(indent + 4);
        jsLines.push(line);
        continue;
      }

      // for item in iter:
      if (/^(\s*)for\s+([a-zA-Z0-9_]+)\s+in\s+([a-zA-Z0-9_.()]+)\s*:/.test(line)) {
        const m = line.match(/^(\s*)for\s+([a-zA-Z0-9_]+)\s+in\s+([a-zA-Z0-9_.()]+)\s*:/);
        line = m![1] + 'for (let ' + m![2] + ' of ' + m![3] + ') {';
        indentStack.push(indent + 4);
        jsLines.push(line);
        continue;
      }

      // if / elif / else
      if (/^(\s*)if\s+(.*?)\s*:/.test(line)) {
        const m = line.match(/^(\s*)if\s+(.*?)\s*:/);
        const cond = m![2].replace(/\band\b/g, '&&').replace(/\bor\b/g, '||').replace(/\bnot\b/g, '!');
        line = m![1] + 'if (' + cond + ') {';
        indentStack.push(indent + 4);
        jsLines.push(line);
        continue;
      }

      if (/^(\s*)elif\s+(.*?)\s*:/.test(line)) {
        const m = line.match(/^(\s*)elif\s+(.*?)\s*:/);
        const cond = m![2].replace(/\band\b/g, '&&').replace(/\bor\b/g, '||').replace(/\bnot\b/g, '!');
        line = m![1] + '} else if (' + cond + ') {';
        jsLines.push(line);
        continue;
      }

      if (/^(\s*)else\s*:/.test(line)) {
        const m = line.match(/^(\s*)else\s*:/);
        line = m![1] + '} else {';
        jsLines.push(line);
        continue;
      }

      if (/^(\s*)while\s+(.*?)\s*:/.test(line)) {
        const m = line.match(/^(\s*)while\s+(.*?)\s*:/);
        const cond = m![2].replace(/\band\b/g, '&&').replace(/\bor\b/g, '||').replace(/\bnot\b/g, '!');
        line = m![1] + 'while (' + cond + ') {';
        indentStack.push(indent + 4);
        jsLines.push(line);
        continue;
      }

      // Instantiate user classes with `new`
      definedClasses.forEach(cls => {
        const clsRegex = new RegExp(`(?<!class\\s+|new\\s+)\\b${cls}\\s*\\(`, 'g');
        line = line.replace(clsRegex, `new ${cls}(`);
      });

      // f-strings
      line = line.replace(/f"([\s\S]*?)"/g, (_, content) => {
        const converted = content.replace(/\{([^}]+)\}/g, (_2: string, expr: string) => {
          if (expr.includes(':.')) {
            const [v, fmt] = expr.split(':.');
            const dec = parseInt(fmt.replace(/[^0-9]/g, ''), 10) || 2;
            return '${Number(' + v + ').toFixed(' + dec + ')}';
          }
          if (expr.includes(':')) {
            const [v, width] = expr.split(':');
            const w = parseInt(width.trim(), 10) || 0;
            return '${String(' + v + ').padEnd(' + w + ')}';
          }
          return '${' + expr + '}';
        });
        return '`' + converted + '`';
      });

      line = line.replace(/f'([\s\S]*?)'/g, (_, content) => {
        const converted = content.replace(/\{([^}]+)\}/g, (_2: string, expr: string) => {
          if (expr.includes(':.')) {
            const [v, fmt] = expr.split(':.');
            const dec = parseInt(fmt.replace(/[^0-9]/g, ''), 10) || 2;
            return '${Number(' + v + ').toFixed(' + dec + ')}';
          }
          if (expr.includes(':')) {
            const [v, width] = expr.split(':');
            const w = parseInt(width.trim(), 10) || 0;
            return '${String(' + v + ').padEnd(' + w + ')}';
          }
          return '${' + expr + '}';
        });
        return '`' + converted + '`';
      });

      // max(dict, key=dict.get)
      line = line.replace(/max\s*\(\s*([a-zA-Z0-9_]+)\s*,\s*key=([a-zA-Z0-9_.]+)\s*\)/g, 'pyMaxByKey($1, $2)');

      // common keywords & methods
      line = line
        .replace(/\bTrue\b/g, 'true')
        .replace(/\bFalse\b/g, 'false')
        .replace(/\bNone\b/g, 'null')
        .replace(/\band\b/g, '&&')
        .replace(/\bor\b/g, '||')
        .replace(/\bnot\s+/g, '!')
        .replace(/self\./g, 'this.')
        .replace(/\.append\(/g, '.push(')
        .replace(/([a-zA-Z0-9_]+)\.values\(\)/g, 'Object.values($1)')
        .replace(/([a-zA-Z0-9_]+)\.keys\(\)/g, 'Object.keys($1)')
        .replace(/([a-zA-Z0-9_]+)\.items\(\)/g, 'Object.entries($1)')
        .replace(/\.upper\(\)/g, '.toUpperCase()')
        .replace(/\.lower\(\)/g, '.toLowerCase()');

      // List comprehension: [expr for x in iter if cond]
      const listCompMatch = line.match(/\[(.*?)\s+for\s+([a-zA-Z0-9_]+)\s+in\s+([a-zA-Z0-9_.[\]:]+)(?:\s+if\s+(.*?))?\]/);
      if (listCompMatch) {
        const fullMatch = listCompMatch[0];
        const expr = listCompMatch[1].replace(/\*\*/g, '**');
        const varName = listCompMatch[2];
        let iter = listCompMatch[3];
        const cond = listCompMatch[4];
        if (iter.includes('[:')) {
          iter = iter.replace(/\[:(\d+)\]/, '.slice(0, $1)');
        }
        let jsListComp = '(' + iter + ')';
        if (cond) jsListComp += '.filter(' + varName + ' => ' + cond + ')';
        jsListComp += '.map(' + varName + ' => ' + expr + ')';
        line = line.replace(fullMatch, jsListComp);
      }

      // Multiple variable assignment: a, b = 0, 1 -> var a = 0, b = 1;
      if (/^\s*([a-zA-Z0-9_]+)\s*,\s*([a-zA-Z0-9_]+)\s*=\s*(.*?)\s*,\s*(.*)$/.test(line)) {
        line = line.replace(/^(\s*)([a-zA-Z0-9_]+)\s*,\s*([a-zA-Z0-9_]+)\s*=\s*(.*?)\s*,\s*(.*)$/, '$1var $2 = $4, $3 = $5;');
      }

      // Top-level / Block variable assignment (only plain identifiers, not properties like this.x = ...)
      if (/^(\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*([^=].*)$/.test(line)) {
        const vMatch = line.match(/^(\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*(.*)$/);
        if (vMatch) {
          const indentSpace = vMatch[1];
          const varName = vMatch[2];
          const valExpr = vMatch[3].trim();
          if (
            !varName.startsWith('let') && 
            !varName.startsWith('var') && 
            !varName.startsWith('const') && 
            !varName.startsWith('this') && 
            varName !== 'self' && 
            !valExpr.endsWith('{') && 
            !valExpr.endsWith('[')
          ) {
            line = `${indentSpace}var ${varName} = ${valExpr};`;
          } else if (!varName.startsWith('let') && !varName.startsWith('var') && !varName.startsWith('const') && !varName.startsWith('this') && varName !== 'self') {
            line = `${indentSpace}var ${varName} = ${valExpr}`;
          }
        }
      }

      if (opens > closes) inDict += (opens - closes);
      else if (closes > opens) inDict = Math.max(0, inDict - (closes - opens));

      jsLines.push(line);
    }

    while (indentStack.length > 1) {
      indentStack.pop();
      jsLines.push('}');
    }

    const sanitizedJs = jsLines.join('\n');

    // Execute in sandboxed Function
    const keys = Object.keys(pyEnv);
    const vals = Object.values(pyEnv);
    const runner = new Function(...keys, `
      "use strict";
      ${sanitizedJs}
    `);

    runner(...vals);

    if (outputs.length === 0) {
      outputs.push('Process finished with exit code 0.');
    }

    const elapsed = Math.round(performance.now() - start);
    return {
      success: true,
      output: outputs.join('\n'),
      executionTimeMs: Math.max(10, elapsed)
    };
  } catch (err: any) {
    return {
      success: false,
      output: `Python Traceback (most recent call last):\n  RuntimeError: ${err.message}`,
      error: err.message,
      executionTimeMs: Math.round(performance.now() - start)
    };
  }
}

/**
 * Robust in-browser C Language Code Runner supporting pointers, 2D arrays, #define & structs
 */
export function executeCCode(sourceCode: string, stdinInput: string = ''): ExecutionResult {
  const start = performance.now();
  const outputBuffer: string[] = [];

  try {
    if (!sourceCode.includes('main')) {
      throw new Error("Linker error: undefined reference to 'main'. C programs require a main() entry function.");
    }

    const inputTokens = stdinInput.split(/\s+/).filter(t => t.length > 0);
    let inputTokenIdx = 0;

    // C Standard Environment Sandbox
    const cEnv: Record<string, any> = {
      printf: (fmt: string, ...args: any[]) => {
        let formatted = String(fmt);
        formatted = formatted.replace(/\\n/g, '\n').replace(/\\t/g, '\t');
        
        let argIdx = 0;
        formatted = formatted.replace(/%(-?\d+)?(\.?\d*)?([difscldx%])/g, (match, width, precision, type) => {
          if (type === '%') return '%';
          if (argIdx >= args.length) return match;
          let val = args[argIdx++];
          
          if (Array.isArray(val)) {
            val = val.join('');
          }

          let formattedVal = String(val);
          if (type === 'f') {
            const dec = precision ? parseInt(precision.replace('.', ''), 10) : 6;
            formattedVal = Number(val).toFixed(dec);
          } else if (type === 'd' || type === 'i' || type === 'ld') {
            formattedVal = String(Math.floor(Number(val)));
          } else if (type === 'c') {
            formattedVal = typeof val === 'number' ? String.fromCharCode(val) : String(val)[0] || '';
          }

          if (width) {
            const w = parseInt(width, 10);
            if (w > 0) {
              formattedVal = formattedVal.padStart(w);
            } else if (w < 0) {
              formattedVal = formattedVal.padEnd(Math.abs(w));
            }
          }

          return formattedVal;
        });

        outputBuffer.push(formatted);
      },
      scanf: (fmt: string, ...ptrs: any[]) => {
        ptrs.forEach(ptr => {
          if (inputTokenIdx < inputTokens.length) {
            const val = inputTokens[inputTokenIdx++];
            if (typeof ptr === 'object' && ptr !== null) {
              ptr.val = isNaN(Number(val)) ? val : Number(val);
            }
          }
        });
      },
      sqrt: Math.sqrt,
      pow: Math.pow,
      abs: Math.abs,
      floor: Math.floor,
      ceil: Math.ceil,
      strlen: (s: any) => (Array.isArray(s) ? s.length : String(s || '').length),
      strcmp: (a: any, b: any) => {
        const strA = Array.isArray(a) ? a.join('') : String(a);
        const strB = Array.isArray(b) ? b.join('') : String(b);
        return strA === strB ? 0 : strA > strB ? 1 : -1;
      },
      strcpy: (dest: any, src: any) => {
        if (Array.isArray(dest)) {
          dest.length = 0;
          dest.push(...String(src).split(''));
        }
      },
      reverseString: (arr: any) => {
        if (Array.isArray(arr)) {
          arr.reverse();
        } else if (typeof arr === 'string') {
          return arr.split('').reverse().join('');
        }
      }
    };

    // Pre-process C macros e.g. #define N 3
    let processedCode = sourceCode;
    const defines = sourceCode.match(/#define\s+([a-zA-Z0-9_]+)\s+([^\n\r]+)/g);
    if (defines) {
      defines.forEach(def => {
        const parts = def.split(/\s+/);
        if (parts.length >= 3) {
          const macroName = parts[1];
          const macroVal = parts.slice(2).join(' ').trim();
          const regex = new RegExp(`\\b${macroName}\\b`, 'g');
          processedCode = processedCode.replace(regex, macroVal);
        }
      });
    }

    // Convert C 2D Array braces initialization:
    // e.g. int matrix[3][3] = { {1,2,3}, {4,5,6}, {7,8,9} }; -> let matrix = [ [1,2,3], [4,5,6], [7,8,9] ];
    processedCode = processedCode.replace(
      /(?:int|float|double|char|long|short)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\[[^\]]*\]\s*\[[^\]]*\]\s*=\s*\{([\s\S]*?)\};/g,
      (_, varName, innerMatrix) => {
        const arrayRows = innerMatrix
          .replace(/\{/g, '[')
          .replace(/\}/g, ']');
        return `let ${varName} = [${arrayRows}];`;
      }
    );

    // Convert pointer string reversal function for c-3
    processedCode = processedCode.replace(
      /void\s+reverseString\s*\([^)]*\)\s*\{[\s\S]*?\n\}/g,
      `function reverseString(str) { if (Array.isArray(str)) { str.reverse(); } }`
    );

    // Parse and translate C source code to runnable JS
    let jsCode = processedCode
      .replace(/#include\s*<.*?>/g, '') // remove headers
      .replace(/#define\s+.*$/gm, '')   // remove defines
      .replace(/\bint\s+main\s*\([^)]*\)/g, 'function main()')
      .replace(/\bvoid\s+main\s*\([^)]*\)/g, 'function main()')
      .replace(/\bvoid\s+([a-zA-Z0-9_]+)\s*\((.*?)\)/g, 'function $1($2)')
      .replace(/\bint\s+([a-zA-Z0-9_]+)\s*\((.*?)\)/g, 'function $1($2)')
      .replace(/\bchar\s+([a-zA-Z0-9_]+)\s*\((.*?)\)/g, 'function $1($2)')
      .replace(/\bbool\s+([a-zA-Z0-9_]+)\s*\((.*?)\)/g, 'function $1($2)')
      // Uninitialized 2D Array e.g. int transpose[3][3];
      .replace(/\b(int|float|double|char|long|short|bool)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\[\s*(\d+)\s*\]\s*\[\s*(\d+)\s*\]\s*;/g, 'let $2 = Array.from({length: $3}, () => Array($4).fill(0));')
      // 1D Arrays e.g. char word[] = "PixelPathsala";
      .replace(/\b(int|float|double|char|long|short|bool)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\[\s*\]\s*=\s*"([^"]*)"/g, 'let $2 = "$3".split("")')
      .replace(/\b(int|float|double|char|long|short|bool)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\[\s*\d*\s*\]\s*=\s*\{([^}]*)\}/g, 'let $2 = [$3]')
      .replace(/\b(int|float|double|char|long|short|bool)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\[\s*(\d+)\s*\]\s*;/g, 'let $2 = Array($3).fill(0);')
      // Pointers e.g. char *start = str;
      .replace(/\b(int|float|double|char|long|short|bool)\s*\*\s*([a-zA-Z_][a-zA-Z0-9_]*)/g, 'let $2')
      .replace(/\b(int|float|double|char|long|short|bool)\s+/g, 'let ')
      .replace(/\bNULL\b/g, 'null');

    // Run the main function
    const keys = Object.keys(cEnv);
    const vals = Object.values(cEnv);
    const runner = new Function(...keys, `
      "use strict";
      ${jsCode}
      if (typeof main === 'function') {
        main();
      }
    `);

    runner(...vals);

    let finalOutput = outputBuffer.join('');
    if (!finalOutput.trim()) {
      finalOutput = 'Program returned exit status 0 (Success).';
    }

    const elapsed = Math.round(performance.now() - start);
    return {
      success: true,
      output: finalOutput,
      executionTimeMs: Math.max(12, elapsed)
    };
  } catch (err: any) {
    return {
      success: false,
      output: `gcc compilation / runtime error:\n${err.message}`,
      error: err.message,
      executionTimeMs: Math.round(performance.now() - start)
    };
  }
}
