import * as XLSX from 'xlsx';
import { Batch, Student, Course, Educator, CenterInfo, FeePayment, Expense, StudentBillingSummary } from '../types';
import { formatMonthKey } from './feeCalculator';

/**
 * Trigger browser download of an XLSX workbook
 */
function downloadWorkbook(workbook: XLSX.WorkBook, filename: string) {
  XLSX.writeFile(workbook, filename);
}

/**
 * 1. Export Batch-wise Student Details Report to Excel
 */
export function exportBatchStudentDetailsToExcel({
  batch,
  students,
  courses,
  educators,
  centerInfo
}: {
  batch: Batch | null;
  students: Student[];
  courses: Course[];
  educators: Educator[];
  centerInfo: CenterInfo;
}) {
  const courseMap = new Map(courses.map(c => [c.id, c.title]));
  const educatorMap = new Map(educators.map(e => [e.id, `${e.name} (${e.subject})`]));

  const filteredStudents = batch 
    ? students.filter(s => s.batchId === batch.id)
    : students;

  const title = batch ? `Batch Student Directory - ${batch.name}` : `All Students Directory`;
  const reportDate = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  // Construct tabular data
  const data: Array<Record<string, any>> = [];

  filteredStudents.forEach((st, idx) => {
    data.push({
      'Sl No.': idx + 1,
      'Roll Number': st.rollNo,
      'Student Name': st.name,
      'Status': st.status.toUpperCase(),
      'Mobile Number': st.mobile,
      'Aadhaar Number': st.aadhaarNo,
      'Course Name': courseMap.get(st.courseId) || 'N/A',
      'Batch': batch ? batch.name : 'Assigned Batch',
      'Admission Month': formatMonthKey(st.admissionMonth),
      'Admission Date': st.admissionDate,
      'Guardian Name': st.guardianName,
      'Guardian Contact': st.guardianPhone,
      'Email ID': st.email || 'N/A',
      'Residential Address': st.address || 'N/A',
    });
  });

  const worksheet = XLSX.utils.json_to_sheet(data);

  // Auto column widths
  const colWidths = [
    { wch: 8 },  // Sl No
    { wch: 14 }, // Roll No
    { wch: 22 }, // Name
    { wch: 12 }, // Status
    { wch: 15 }, // Mobile
    { wch: 16 }, // Aadhaar
    { wch: 26 }, // Course
    { wch: 20 }, // Batch
    { wch: 16 }, // Admission Month
    { wch: 14 }, // Admission Date
    { wch: 20 }, // Guardian Name
    { wch: 16 }, // Guardian Contact
    { wch: 22 }, // Email
    { wch: 30 }, // Address
  ];
  worksheet['!cols'] = colWidths;

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Student Directory');

  // Add a Metadata summary sheet
  const summaryData = [
    ['Institute Name', centerInfo.name],
    ['Tagline', centerInfo.tagline],
    ['Center Registration No', centerInfo.regNumber],
    ['Helpline Phone', centerInfo.phonePrimary],
    ['Report Title', title],
    ['Generated On', reportDate],
    ['Total Records', filteredStudents.length],
    ['Active Students', filteredStudents.filter(s => s.status === 'active').length],
    ['Passed Out Students', filteredStudents.filter(s => s.status === 'passed_out').length],
    batch ? ['Assigned Educator', educatorMap.get(batch.educatorId) || 'N/A'] : ['Scope', 'Institute Wide'],
    batch ? ['Class Schedule', `${batch.scheduleDays.join(', ')} (${batch.timing})`] : ['Room', 'All Classrooms']
  ];
  const summarySheet = XLSX.utils.aoa_to_sheet(summaryData);
  summarySheet['!cols'] = [{ wch: 24 }, { wch: 40 }];
  XLSX.utils.book_append_sheet(workbook, summarySheet, 'Report Summary');

  const filename = `${centerInfo.name.replace(/\s+/g, '_')}_Students_${batch ? batch.name.replace(/\s+/g, '_') : 'All'}_${new Date().toISOString().split('T')[0]}.xlsx`;
  downloadWorkbook(workbook, filename);
}

/**
 * 2. Export Batch-wise Due and Payment Details Report to Excel
 */
export function exportBatchWiseDuesAndPaymentsToExcel({
  batch,
  batches,
  students,
  courses,
  billingMap,
  centerInfo
}: {
  batch: Batch | null;
  batches: Batch[];
  students: Student[];
  courses: Course[];
  billingMap: Record<string, StudentBillingSummary>;
  centerInfo: CenterInfo;
}) {
  const courseMap = new Map(courses.map(c => [c.id, c.title]));
  const batchMap = new Map(batches.map(b => [b.id, b.name]));

  const filteredStudents = batch 
    ? students.filter(s => s.batchId === batch.id)
    : students;

  const reportDate = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  const data: Array<Record<string, any>> = [];

  let grandTotalPayable = 0;
  let grandTotalPaid = 0;
  let grandTotalPending = 0;
  let grandTotalDue = 0;

  filteredStudents.forEach((st, idx) => {
    const billing = billingMap[st.id] || {
      totalPayableSinceAdmission: 0,
      totalPaid: 0,
      totalPendingApproval: 0,
      totalDueAmount: 0,
      totalDiscountAvailed: 0,
      monthlyStatuses: []
    };

    grandTotalPayable += billing.totalPayableSinceAdmission;
    grandTotalPaid += billing.totalPaid;
    grandTotalPending += billing.totalPendingApproval;
    grandTotalDue += billing.totalDueAmount;

    // Collect list of overdue/unpaid months
    const unpaidMonths = billing.monthlyStatuses
      .filter(m => !m.isPaid)
      .map(m => m.monthLabel)
      .join(', ');

    data.push({
      'Sl No.': idx + 1,
      'Roll Number': st.rollNo,
      'Student Name': st.name,
      'Status': st.status.toUpperCase(),
      'Batch Name': batchMap.get(st.batchId) || 'N/A',
      'Course': courseMap.get(st.courseId) || 'N/A',
      'Mobile No': st.mobile,
      'Admission Month': formatMonthKey(st.admissionMonth),
      'Total Payable Fees (₹)': billing.totalPayableSinceAdmission,
      'Total Paid Fees (₹)': billing.totalPaid,
      'Pending Approval (₹)': billing.totalPendingApproval,
      'Outstanding Due Amount (₹)': billing.totalDueAmount,
      'Discounts Availed (₹)': billing.totalDiscountAvailed,
      'Fee Clearance Status': billing.totalDueAmount === 0 ? 'CLEARED' : 'PENDING DUES',
      'Unpaid / Due Months': unpaidMonths || 'None (All Cleared)',
    });
  });

  // Add Grand Total summary row
  data.push({
    'Sl No.': 'TOTAL',
    'Roll Number': '—',
    'Student Name': `TOTALS (${filteredStudents.length} Students)`,
    'Status': '—',
    'Batch Name': '—',
    'Course': '—',
    'Mobile No': '—',
    'Admission Month': '—',
    'Total Payable Fees (₹)': grandTotalPayable,
    'Total Paid Fees (₹)': grandTotalPaid,
    'Pending Approval (₹)': grandTotalPending,
    'Outstanding Due Amount (₹)': grandTotalDue,
    'Discounts Availed (₹)': '—',
    'Fee Clearance Status': grandTotalDue === 0 ? '100% COLLECTED' : `${((grandTotalPaid / (grandTotalPayable || 1)) * 100).toFixed(1)}% RECOVERED`,
    'Unpaid / Due Months': '—',
  });

  const worksheet = XLSX.utils.json_to_sheet(data);

  worksheet['!cols'] = [
    { wch: 8 },  // Sl No
    { wch: 14 }, // Roll
    { wch: 22 }, // Name
    { wch: 12 }, // Status
    { wch: 20 }, // Batch
    { wch: 24 }, // Course
    { wch: 15 }, // Mobile
    { wch: 16 }, // Adm Month
    { wch: 20 }, // Payable
    { wch: 18 }, // Paid
    { wch: 18 }, // Pending
    { wch: 22 }, // Due
    { wch: 18 }, // Discounts
    { wch: 18 }, // Clearance
    { wch: 32 }, // Unpaid Months
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Dues & Collections');

  // Summary KPI Sheet
  const kpiData = [
    ['Institute Name', centerInfo.name],
    ['Report Name', 'Batch-wise Fee Dues & Collection MIS'],
    ['Target Batch', batch ? batch.name : 'All Batches (Center Consolidated)'],
    ['Generated Date', reportDate],
    ['Total Enrolled Students', filteredStudents.length],
    ['Gross Billed Fees (₹)', grandTotalPayable],
    ['Total Realized Fees (₹)', grandTotalPaid],
    ['Pending Student Approvals (₹)', grandTotalPending],
    ['Total Outstanding Unpaid Dues (₹)', grandTotalDue],
    ['Overall Collection Efficiency', `${((grandTotalPaid / (grandTotalPayable || 1)) * 100).toFixed(2)}%`],
    ['Official UPI For Dues', centerInfo.upiId]
  ];
  const kpiSheet = XLSX.utils.aoa_to_sheet(kpiData);
  kpiSheet['!cols'] = [{ wch: 30 }, { wch: 40 }];
  XLSX.utils.book_append_sheet(workbook, kpiSheet, 'MIS Executive Summary');

  const filename = `${centerInfo.name.replace(/\s+/g, '_')}_Fee_Dues_${batch ? batch.name.replace(/\s+/g, '_') : 'Consolidated'}_${new Date().toISOString().split('T')[0]}.xlsx`;
  downloadWorkbook(workbook, filename);
}

/**
 * 3. Export Financial Year (FY) Wise Financial Income, Expenditure & Balance Report to Excel
 */
export interface FYFinancialMonthRow {
  monthKey: string;
  monthName: string;
  grossIncome: number;
  approvedReceiptsCount: number;
  grossExpenditure: number;
  expenseVouchersCount: number;
  netSurplus: number;
  cumulativeBalance: number;
  categoryBreakdown: Record<string, number>;
}

export function exportFinancialYearMISReportToExcel({
  fyLabel,
  monthsData,
  expenses,
  payments,
  centerInfo
}: {
  fyLabel: string;
  monthsData: FYFinancialMonthRow[];
  expenses: Expense[];
  payments: FeePayment[];
  centerInfo: CenterInfo;
}) {
  const reportDate = new Date().toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });

  // Sheet 1: Month by Month Income vs Expenditure Ledger
  let totalIncome = 0;
  let totalExpense = 0;
  let totalReceipts = 0;
  let totalVouchers = 0;

  const monthlyLedgerData: Array<Record<string, any>> = monthsData.map((m, idx) => {
    totalIncome += m.grossIncome;
    totalExpense += m.grossExpenditure;
    totalReceipts += m.approvedReceiptsCount;
    totalVouchers += m.expenseVouchersCount;

    return {
      'Sl No.': idx + 1,
      'Month': m.monthName,
      'Billing Month Code': m.monthKey,
      'Fee Collection (Income ₹)': m.grossIncome,
      'Approved Receipts (#)': m.approvedReceiptsCount,
      'Operational Costs (Expense ₹)': m.grossExpenditure,
      'Expense Vouchers (#)': m.expenseVouchersCount,
      'Monthly Net Surplus/Deficit (₹)': m.netSurplus,
      'Cumulative Financial Balance (₹)': m.cumulativeBalance,
      'Operating Margin (%)': m.grossIncome > 0 ? `${((m.netSurplus / m.grossIncome) * 100).toFixed(1)}%` : '0.0%'
    };
  });

  // Grand Total Row
  const totalNet = totalIncome - totalExpense;
  monthlyLedgerData.push({
    'Sl No.': 'TOTAL',
    'Month': `FY ${fyLabel} ANNUAL CONSOLIDATION`,
    'Billing Month Code': '—',
    'Fee Collection (Income ₹)': totalIncome,
    'Approved Receipts (#)': totalReceipts,
    'Operational Costs (Expense ₹)': totalExpense,
    'Expense Vouchers (#)': totalVouchers,
    'Monthly Net Surplus/Deficit (₹)': totalNet,
    'Cumulative Financial Balance (₹)': totalNet,
    'Operating Margin (%)': totalIncome > 0 ? `${((totalNet / totalIncome) * 100).toFixed(2)}%` : '0.0%'
  });

  const ledgerWorksheet = XLSX.utils.json_to_sheet(monthlyLedgerData);
  ledgerWorksheet['!cols'] = [
    { wch: 8 },  // Sl No
    { wch: 20 }, // Month
    { wch: 18 }, // Month Code
    { wch: 24 }, // Income
    { wch: 20 }, // Receipts #
    { wch: 26 }, // Expense
    { wch: 20 }, // Vouchers #
    { wch: 28 }, // Net Surplus
    { wch: 28 }, // Cumulative Balance
    { wch: 20 }, // Margin
  ];

  // Sheet 2: Expense Category-wise Distribution
  const categoryTotals: Record<string, number> = {};
  expenses.forEach(e => {
    categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amount;
  });

  const categoryData = Object.entries(categoryTotals).map(([cat, amt], idx) => ({
    'Sl No.': idx + 1,
    'Expense Category': cat,
    'Total Amount Spent (₹)': amt,
    '% Share of Total Expenditure': totalExpense > 0 ? `${((amt / totalExpense) * 100).toFixed(2)}%` : '0%'
  }));

  const categoryWorksheet = XLSX.utils.json_to_sheet(categoryData);
  categoryWorksheet['!cols'] = [
    { wch: 8 },
    { wch: 30 },
    { wch: 22 },
    { wch: 24 }
  ];

  // Sheet 3: Full Vouchers Detailed Log
  const expenseLogs = expenses.map((exp, idx) => ({
    'Voucher No': exp.id,
    'Date': exp.date,
    'Title / Purpose': exp.title,
    'Category': exp.category,
    'Amount (₹)': exp.amount,
    'Payment Mode': exp.paymentMode,
    'Paid To / Vendor': exp.paidTo || '—',
    'Bill Reference #': exp.receiptNo || '—',
    'Notes': exp.notes || '—'
  }));
  const expenseSheet = XLSX.utils.json_to_sheet(expenseLogs);
  expenseSheet['!cols'] = [
    { wch: 16 },
    { wch: 14 },
    { wch: 28 },
    { wch: 24 },
    { wch: 16 },
    { wch: 14 },
    { wch: 20 },
    { wch: 18 },
    { wch: 24 },
  ];

  // Sheet 4: Fee Income Vouchers Log
  const incomeLogs = payments.filter(p => p.status === 'approved').map(p => ({
    'Receipt No': p.receiptNo,
    'Date': p.paymentDate,
    'Student Name': p.studentName,
    'Months Paid': p.month,
    'Base Amount (₹)': p.totalBaseFee,
    'Discount (₹)': p.totalDiscount,
    'Final Paid (₹)': p.finalAmountPaid,
    'Payment Mode': p.paymentMode,
    'Bank / UTR Reference': p.transactionRef || '—'
  }));
  const incomeSheet = XLSX.utils.json_to_sheet(incomeLogs);
  incomeSheet['!cols'] = [
    { wch: 16 },
    { wch: 14 },
    { wch: 22 },
    { wch: 18 },
    { wch: 16 },
    { wch: 16 },
    { wch: 16 },
    { wch: 16 },
    { wch: 24 },
  ];

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, ledgerWorksheet, 'FY Income vs Expenditure');
  XLSX.utils.book_append_sheet(workbook, categoryWorksheet, 'Expense Categories');
  XLSX.utils.book_append_sheet(workbook, incomeSheet, 'Fee Collections Log');
  XLSX.utils.book_append_sheet(workbook, expenseSheet, 'Expense Vouchers Log');

  const filename = `${centerInfo.name.replace(/\s+/g, '_')}_FY_${fyLabel.replace(/\s+/g, '_')}_MIS_Financial_Report_${new Date().toISOString().split('T')[0]}.xlsx`;
  downloadWorkbook(workbook, filename);
}
