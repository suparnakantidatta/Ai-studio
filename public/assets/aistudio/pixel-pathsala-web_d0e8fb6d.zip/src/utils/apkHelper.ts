/**
 * Helper to process, validate, and convert APK download URLs
 * Supports:
 * 1. GitHub Releases links (converts release pages to automatic direct .apk downloads)
 * 2. Google Drive sharing links (converts to direct download links bypassing preview container)
 * 3. Dropbox links (converts dl=0 to dl=1)
 * 4. Direct CDN / Server APK URLs
 */

export function extractGoogleDriveFileId(url?: string | null): string | null {
  if (!url) return null;
  const trimmed = url.trim();

  // Pattern 1: /file/d/FILE_ID
  const match1 = trimmed.match(/\/file\/d\/([a-zA-Z0-9_-]+)/i);
  if (match1 && match1[1]) return match1[1];

  // Pattern 2: id=FILE_ID
  const match2 = trimmed.match(/[?&]id=([a-zA-Z0-9_-]+)/i);
  if (match2 && match2[1]) return match2[1];

  // Pattern 3: /d/FILE_ID
  const match3 = trimmed.match(/\/d\/([a-zA-Z0-9_-]+)/i);
  if (match3 && match3[1]) return match3[1];

  // Pattern 4: Bare ID (at least 20 chars of alphanumeric/hyphen/underscore)
  if (/^[a-zA-Z0-9_-]{25,}$/.test(trimmed)) {
    return trimmed;
  }

  return null;
}

export interface GitHubReleaseDetails {
  owner: string;
  repo: string;
  tag?: string;
  isDirectApk: boolean;
  assetName?: string;
  isReleasePage: boolean;
}

/**
 * Parses a GitHub URL and extracts repository, release tag, and asset information.
 */
export function extractGitHubReleaseDetails(url?: string | null): GitHubReleaseDetails | null {
  if (!url) return null;
  let clean = url.trim();
  if ((clean.startsWith('"') && clean.endsWith('"')) || (clean.startsWith("'") && clean.endsWith("'"))) {
    clean = clean.slice(1, -1).trim();
  }

  if (!clean.includes('github.com')) return null;

  // Pattern 1: Direct asset download URL: .../releases/download/:tag/:asset.apk
  const directMatch = clean.match(/github\.com\/([^\/\s#\?]+)\/([^\/\s#\?]+)\/releases\/download\/([^\/\s#\?]+)\/([^\/\s#\?]+\.(?:apk|aab))/i);
  if (directMatch) {
    let repo = directMatch[2];
    if (repo.endsWith('.git')) repo = repo.slice(0, -4);
    return {
      owner: directMatch[1],
      repo,
      tag: directMatch[3],
      isDirectApk: true,
      assetName: directMatch[4],
      isReleasePage: false
    };
  }

  // Pattern 2: Latest direct asset: .../releases/latest/download/:asset.apk
  const latestDirectMatch = clean.match(/github\.com\/([^\/\s#\?]+)\/([^\/\s#\?]+)\/releases\/latest\/download\/([^\/\s#\?]+\.(?:apk|aab))/i);
  if (latestDirectMatch) {
    let repo = latestDirectMatch[2];
    if (repo.endsWith('.git')) repo = repo.slice(0, -4);
    return {
      owner: latestDirectMatch[1],
      repo,
      tag: 'latest',
      isDirectApk: true,
      assetName: latestDirectMatch[3],
      isReleasePage: false
    };
  }

  // Pattern 3: Tagged release page: .../releases/tag/:tag
  const tagPageMatch = clean.match(/github\.com\/([^\/\s#\?]+)\/([^\/\s#\?]+)\/releases\/tag\/([^\/\s#\?]+)/i);
  if (tagPageMatch) {
    let repo = tagPageMatch[2];
    if (repo.endsWith('.git')) repo = repo.slice(0, -4);
    return {
      owner: tagPageMatch[1],
      repo,
      tag: tagPageMatch[3],
      isDirectApk: false,
      isReleasePage: true
    };
  }

  // Pattern 4: General repository release page: .../releases/latest or .../releases
  const generalRepoMatch = clean.match(/github\.com\/([^\/\s#\?]+)\/([^\/\s#\?]+)(?:\/releases(?:\/latest)?)?/i);
  if (generalRepoMatch) {
    let repo = generalRepoMatch[2];
    if (repo.endsWith('.git')) repo = repo.slice(0, -4);
    return {
      owner: generalRepoMatch[1],
      repo,
      tag: clean.includes('/releases/latest') ? 'latest' : undefined,
      isDirectApk: false,
      isReleasePage: true
    };
  }

  return null;
}

export function isDirectGitHubApkUrl(url?: string | null): boolean {
  const details = extractGitHubReleaseDetails(url);
  return Boolean(details && details.isDirectApk);
}

export function isGitHubReleasePageUrl(url?: string | null): boolean {
  const details = extractGitHubReleaseDetails(url);
  return Boolean(details && details.isReleasePage);
}

/**
 * Transforms any Google Drive sharing link, GitHub Release link, Dropbox link, or CDN URL
 * into an immediate direct file download URL (no GitHub webpage, no Google Drive preview screen).
 */
export function getDirectApkDownloadUrl(rawUrl?: string | null): string {
  if (!rawUrl) return '/api/download-apk';
  let url = rawUrl.trim();
  if (!url) return '/api/download-apk';

  // Remove surrounding quotes if pasted by user
  if ((url.startsWith('"') && url.endsWith('"')) || (url.startsWith("'") && url.endsWith("'"))) {
    url = url.slice(1, -1).trim();
  }

  // Handle GitHub links
  if (url.includes('github.com')) {
    const ghDetails = extractGitHubReleaseDetails(url);
    if (ghDetails) {
      // If it's already a direct .apk download link, return it directly
      if (ghDetails.isDirectApk) {
        return url;
      }
      // If it's a GitHub release page (e.g. /releases/latest, /releases/tag/v1.0, etc.),
      // route via our server-side download engine which fetches the release via GitHub API
      // and immediately redirects to the .apk asset, never opening the GitHub webpage!
      return `/api/download-apk?url=${encodeURIComponent(url)}`;
    }
  }

  // Handle Google Drive links
  if (
    url.includes('drive.google.com') ||
    url.includes('docs.google.com') ||
    url.includes('drive.usercontent.google.com')
  ) {
    const fileId = extractGoogleDriveFileId(url);
    if (fileId) {
      // Direct download URL bypassing Google Drive preview container and virus warning prompt
      return `https://drive.usercontent.google.com/download?id=${fileId}&export=download&confirm=t`;
    }
  }

  // Handle Dropbox links (replace dl=0 with dl=1)
  if (url.includes('dropbox.com')) {
    if (url.includes('dl=0')) {
      return url.replace('dl=0', 'dl=1');
    }
    if (!url.includes('dl=1')) {
      return url.includes('?') ? `${url}&dl=1` : `${url}?dl=1`;
    }
  }

  // Auto-prepend https:// if protocol is omitted
  if (url.startsWith('www.') || (!url.startsWith('http://') && !url.startsWith('https://') && url.includes('.'))) {
    return `https://${url}`;
  }

  return url;
}

/**
 * Asynchronously resolves a GitHub Release URL or custom link to its final direct .apk download URL.
 */
export async function resolveDirectApkUrl(rawUrl?: string | null): Promise<{
  directDownloadUrl: string;
  fileName?: string;
  tagName?: string;
  size?: number;
}> {
  if (!rawUrl || !rawUrl.trim()) {
    return { directDownloadUrl: '/api/download-apk' };
  }

  const clean = rawUrl.trim();

  // If already a direct Google Drive or Dropbox link
  if (clean.includes('drive.google.com') || clean.includes('dropbox.com') || isDirectGitHubApkUrl(clean)) {
    return { directDownloadUrl: getDirectApkDownloadUrl(clean) };
  }

  // Query server-side resolver
  try {
    const res = await fetch(`/api/resolve-apk-url?url=${encodeURIComponent(clean)}`);
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.directDownloadUrl) {
        return {
          directDownloadUrl: data.directDownloadUrl,
          fileName: data.fileName,
          tagName: data.tagName,
          size: data.size
        };
      }
    }
  } catch (err) {
    console.warn('Could not resolve direct APK URL via API:', err);
  }

  return { directDownloadUrl: getDirectApkDownloadUrl(clean) };
}
