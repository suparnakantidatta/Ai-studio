/**
 * Image and Media helper to sanitize and convert web links 
 * (Google Drive, Google Photos, Facebook CDN/Profile, Dropbox, Imgur, PostImg, etc.)
 * into directly embeddable image URLs for <img> tags with no-referrer compatibility.
 */

export function extractDriveFileId(url: string): string | null {
  if (!url) return null;
  const trimmed = url.trim();

  // Pattern 1: /file/d/FILE_ID
  const match1 = trimmed.match(/\/file\/d\/([a-zA-Z0-9_-]+)/i);
  if (match1 && match1[1]) return match1[1];

  // Pattern 2: id=FILE_ID
  const match2 = trimmed.match(/[?&]id=([a-zA-Z0-9_-]+)/i);
  if (match2 && match2[1]) return match2[1];

  // Pattern 3: /d/FILE_ID
  const match3 = trimmed.match(/\/d\/([a-zA-Z0-9_-]+)/i);
  if (match3 && match3[1]) return match3[1];

  return null;
}

/**
 * Normalizes user-pasted image URLs from Google Drive, Google Photos,
 * Facebook, Instagram, Dropbox, Imgur, GitHub, etc. into direct image sources.
 */
export function normalizeImageUrl(url?: string | null): string {
  if (!url || typeof url !== 'string') return '';
  let trimmed = url.trim();
  if (!trimmed) return '';

  // Clean any surrounding quotes that users might paste
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
    trimmed = trimmed.slice(1, -1).trim();
  }

  // 1. If it's already a base64 Data URL or blob URL, return as is
  if (trimmed.startsWith('data:image/') || trimmed.startsWith('blob:')) {
    return trimmed;
  }

  // 2. Google Drive Links conversion (use reliable thumbnail CDN URL)
  if (
    trimmed.includes('drive.google.com') || 
    trimmed.includes('docs.google.com') || 
    trimmed.includes('drive.usercontent.google.com') ||
    trimmed.includes('lh3.googleusercontent.com/d/')
  ) {
    const fileId = extractDriveFileId(trimmed);
    if (fileId) {
      // Return high-resolution direct Google image thumbnail CDN link
      return `https://drive.google.com/thumbnail?id=${fileId}&sz=w1000`;
    }
  }

  // 3. Google Photos / Google User Content direct links
  if (trimmed.includes('googleusercontent.com') || trimmed.includes('ggpht.com')) {
    // If it has sizing parameters like =w500-h500 or =s96-c, ensure high quality
    if (trimmed.includes('=w') || trimmed.includes('=s')) {
      return trimmed;
    }
    return `${trimmed}=s800`;
  }

  // 4. Facebook Profile URLs (e.g. facebook.com/username or facebook.com/profile.php?id=123)
  if (trimmed.includes('facebook.com') || trimmed.includes('fb.com')) {
    // Check if it's already a direct CDN link
    if (trimmed.includes('fbcdn.net') || trimmed.includes('fbsbx.com')) {
      return trimmed;
    }
    // If it's a profile URL like facebook.com/john.doe
    const profileMatch = trimmed.match(/facebook\.com\/(?:profile\.php\?id=)?([a-zA-Z0-9._-]+)/i);
    if (profileMatch && profileMatch[1] && !['photo', 'photos', 'watch', 'share', 'groups', 'pages', 'events'].includes(profileMatch[1].toLowerCase())) {
      return `https://graph.facebook.com/${profileMatch[1]}/picture?type=large&width=500&height=500`;
    }
    return trimmed;
  }

  // 5. Dropbox Links (replace dl=0 with raw=1)
  if (trimmed.includes('dropbox.com/')) {
    if (trimmed.includes('dl=0')) {
      return trimmed.replace('dl=0', 'raw=1');
    }
    if (!trimmed.includes('raw=1')) {
      return trimmed.includes('?') ? `${trimmed}&raw=1` : `${trimmed}?raw=1`;
    }
    return trimmed;
  }

  // 6. Imgur standard page links -> direct image
  const imgurPageRegex = /^https?:\/\/(?:www\.)?imgur\.com\/(?:a\/|gallery\/)?([a-zA-Z0-9]+)$/i;
  const matchImgur = trimmed.match(imgurPageRegex);
  if (matchImgur && matchImgur[1]) {
    return `https://i.imgur.com/${matchImgur[1]}.jpg`;
  }

  // 7. GitHub raw/blob links conversion
  if (trimmed.includes('github.com/') && trimmed.includes('/blob/')) {
    return trimmed.replace('github.com/', 'raw.githubusercontent.com/').replace('/blob/', '/');
  }

  // 8. PostImage page links -> direct
  if (trimmed.includes('postimg.cc/') && !trimmed.includes('i.postimg.cc')) {
    const postimgMatch = trimmed.match(/postimg\.cc\/([a-zA-Z0-9]+)/);
    if (postimgMatch && postimgMatch[1]) {
      return `https://i.postimg.cc/${postimgMatch[1]}/image.jpg`;
    }
    return trimmed;
  }

  // Auto-prepend https:// for protocol-less URLs
  if (trimmed.startsWith('www.') || (!trimmed.startsWith('http://') && !trimmed.startsWith('https://') && trimmed.includes('.'))) {
    trimmed = `https://${trimmed}`;
  }

  return trimmed;
}

/**
 * Lenient Meeting URL cleaner and normalizer.
 * Supports Google Meet codes (xxx-yyyy-zzz), Meet URLs, Zoom links, YouTube live, Jitsi, etc.
 */
export function cleanMeetingUrl(url?: string | null): string {
  if (!url || typeof url !== 'string') return '';
  let trimmed = url.trim();
  if (!trimmed) return '';

  // Clean surrounding quotes
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
    trimmed = trimmed.slice(1, -1).trim();
  }

  // If user enters just a 10-char Google Meet code like "abc-defg-hij" or "abcdefghij"
  if (/^[a-z]{3}-[a-z]{4}-[a-z]{3}$/i.test(trimmed)) {
    return `https://meet.google.com/${trimmed.toLowerCase()}`;
  }

  // If starts with meet.google.com without protocol
  if (trimmed.startsWith('meet.google.com')) {
    return `https://${trimmed}`;
  }

  // If starts with zoom.us or us04web.zoom.us without protocol
  if (trimmed.includes('zoom.us') && !trimmed.startsWith('http')) {
    return `https://${trimmed}`;
  }

  // If starts with youtu.be or youtube.com without protocol
  if ((trimmed.startsWith('youtube.com') || trimmed.startsWith('youtu.be')) && !trimmed.startsWith('http')) {
    return `https://${trimmed}`;
  }

  // If starts with meet.jit.si without protocol
  if (trimmed.startsWith('meet.jit.si') && !trimmed.startsWith('http')) {
    return `https://${trimmed}`;
  }

  // If starts with www.
  if (trimmed.startsWith('www.')) {
    return `https://${trimmed}`;
  }

  // If it's a web link missing https://
  if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://') && trimmed.includes('.')) {
    return `https://${trimmed}`;
  }

  return trimmed;
}

/**
 * Standard Academic Class list across Pixel Pathsala
 */
export const ACADEMIC_CLASSES = [
  'Class 1',
  'Class 2',
  'Class 3',
  'Class 4',
  'Class 5',
  'Class 6',
  'Class 7',
  'Class 8',
  'Class 9',
  'Class 10 (Secondary)',
  'Class 11 (Science)',
  'Class 11 (Commerce)',
  'Class 11 (Arts)',
  'Class 12 (Science)',
  'Class 12 (Commerce)',
  'Class 12 (Arts)',
  'BCA / B.Sc (Computer Science)',
  'College / Degree / Diploma',
  'Coding & Professional Foundation',
  'General / Competitive'
] as const;

export type AcademicClassOption = typeof ACADEMIC_CLASSES[number] | string;

