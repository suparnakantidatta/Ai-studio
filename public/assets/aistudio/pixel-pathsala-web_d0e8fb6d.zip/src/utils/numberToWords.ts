/**
 * Converts a number to Indian currency words representation
 * e.g., 2500 -> "Two Thousand Five Hundred Rupees Only"
 */
export function numberToIndianRupees(amount: number): string {
  if (amount === 0) return 'Zero Rupees Only';
  if (isNaN(amount) || amount < 0) return '';

  const units = [
    '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
    'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen',
    'Seventeen', 'Eighteen', 'Nineteen'
  ];

  const tens = [
    '', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'
  ];

  function convertTwoDigits(n: number): string {
    if (n < 20) return units[n];
    const digit1 = Math.floor(n / 10);
    const digit2 = n % 10;
    return `${tens[digit1]}${digit2 > 0 ? ' ' + units[digit2] : ''}`;
  }

  function convertThreeDigits(n: number): string {
    const hundred = Math.floor(n / 100);
    const rest = n % 100;
    let res = '';
    if (hundred > 0) {
      res += `${units[hundred]} Hundred`;
    }
    if (rest > 0) {
      res += `${res.length > 0 ? ' ' : ''}${convertTwoDigits(rest)}`;
    }
    return res;
  }

  const integerPart = Math.floor(amount);
  const crore = Math.floor(integerPart / 10000000);
  const lakh = Math.floor((integerPart % 10000000) / 100000);
  const thousand = Math.floor((integerPart % 100000) / 1000);
  const hundredAndBelow = integerPart % 1000;

  const parts: string[] = [];

  if (crore > 0) {
    parts.push(`${convertTwoDigits(crore)} Crore`);
  }
  if (lakh > 0) {
    parts.push(`${convertTwoDigits(lakh)} Lakh`);
  }
  if (thousand > 0) {
    parts.push(`${convertTwoDigits(thousand)} Thousand`);
  }
  if (hundredAndBelow > 0) {
    parts.push(convertThreeDigits(hundredAndBelow));
  }

  const words = parts.join(' ').trim();
  return words ? `Rupees ${words} Only` : 'Zero Rupees Only';
}
