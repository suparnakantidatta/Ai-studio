import { Course, Batch, Student, ClassRecording, StudyMaterial } from '../types';
import { ACADEMIC_CLASSES } from './imageHelper';

export type DeliveryMode = 'offline' | 'online';

/**
 * Normalizes class identifiers to comparable digit string (e.g. "12", "11", "10", "9", "8")
 */
export function normalizeClassNum(str?: string | null): string | null {
  if (!str) return null;
  const s = String(str).toLowerCase().trim();
  if (s.includes('12') || s.includes('xii') || s.includes('higher secondary') || s.includes('coms-012') || s.includes('coma-012')) return '12';
  if (s.includes('11') || s.includes('xi') || s.includes('coms-011') || s.includes('coma-011')) return '11';
  if (s.includes('10') || s.includes('x') || s.includes('secondary') || s.includes('coms-010')) return '10';
  if (s.includes('9') || s.includes('ix')) return '9';
  if (s.includes('8') || s.includes('viii')) return '8';
  return null;
}

/**
 * Checks if a target/item class string matches the student's admission class
 */
export function matchesAcademicClass(itemClass?: string | null, studentClass?: string | null): boolean {
  if (!itemClass || !studentClass) return true;
  const cleanItem = String(itemClass).trim().toLowerCase();
  const cleanStudent = String(studentClass).trim().toLowerCase();

  if (cleanItem === 'all' || cleanItem === 'all classes' || cleanItem === 'universal' || cleanItem === 'common') {
    return true;
  }

  const itemNum = normalizeClassNum(cleanItem);
  const studentNum = normalizeClassNum(cleanStudent);
  if (itemNum && studentNum) {
    return itemNum === studentNum;
  }

  return cleanItem.includes(cleanStudent) || cleanStudent.includes(cleanItem);
}

/**
 * Returns distinct academic classes configured in existing courses.
 * If courses is empty, returns clean defaults.
 */
export function getDistinctAcademicClasses(courses: Course[]): string[] {
  const classList: string[] = [];
  const classSet = new Set<string>();

  if (Array.isArray(courses) && courses.length > 0) {
    for (const c of courses) {
      if (c.academicClass && typeof c.academicClass === 'string' && c.academicClass.trim()) {
        const trimmed = c.academicClass.trim();
        if (!classSet.has(trimmed)) {
          classSet.add(trimmed);
          classList.push(trimmed);
        }
      }
    }
  }

  // If no classes configured yet, fallback to clean distinct list
  if (classList.length === 0) {
    return [
      'Class 8',
      'Class 9',
      'Class 10',
      'Class 11 Science',
      'Class 12 Science',
      'BCA / College',
      'Coding & Foundation'
    ];
  }

  return classList;
}

/**
 * Normalizes academic class names and returns only matching courses.
 * If no course matches the selected class, returns an empty array [] so the UI can show "Not Found".
 */
export function getCoursesForClass(courses: Course[], selectedClass: string): Course[] {
  if (!selectedClass || !courses || courses.length === 0) {
    return courses || [];
  }

  const cleanClass = selectedClass.trim().toLowerCase();

  // Extract number if any (e.g. "9", "10", "11", "12", "8")
  const numMatch = cleanClass.match(/\b([1-9]|1[0-2])\b/);
  const classNum = numMatch ? numMatch[1] : null;

  const isCollege = cleanClass.includes('bca') || cleanClass.includes('college') || cleanClass.includes('degree') || cleanClass.includes('diploma') || cleanClass.includes('computer science');
  const isCoding = cleanClass.includes('coding') || cleanClass.includes('foundation');

  const filtered = courses.filter(course => {
    const courseClass = (course.academicClass || '').toLowerCase().trim();
    const courseTitle = (course.title || '').toLowerCase().trim();

    // Exact match
    if (courseClass === cleanClass) {
      return true;
    }

    // Direct substring match
    if (courseClass && (courseClass.includes(cleanClass) || cleanClass.includes(courseClass))) {
      return true;
    }

    // Universal / Open courses
    if (
      courseClass.includes('all') ||
      courseClass.includes('class 8-12') ||
      courseClass.includes('class 1-12') ||
      courseClass.includes('8-12')
    ) {
      return true;
    }

    // Match by class number if found
    if (classNum) {
      const regex = new RegExp(`\\b(class\\s*)?${classNum}\\b`, 'i');
      if (regex.test(courseClass) || regex.test(courseTitle)) {
        return true;
      }

      // Check standard ranges
      if ((classNum === '9' || classNum === '10') && (courseClass.includes('9-10') || courseClass.includes('8-10') || courseClass.includes('secondary'))) {
        return true;
      }

      if ((classNum === '11' || classNum === '12') && (courseClass.includes('11-12') || courseClass.includes('11 & 12') || courseClass.includes('higher secondary') || courseClass.includes('competitive'))) {
        return true;
      }

      if (parseInt(classNum, 10) <= 8 && (courseClass.includes('foundation') || courseClass.includes('middle school') || courseClass.includes('school'))) {
        return true;
      }
    }

    // College / BCA match
    if (isCollege && (courseClass.includes('bca') || courseClass.includes('college') || courseTitle.includes('python') || courseTitle.includes('c,') || courseTitle.includes('sql') || courseTitle.includes('computer'))) {
      return true;
    }

    // Coding match
    if (isCoding && (courseClass.includes('coding') || courseTitle.includes('coding') || courseTitle.includes('programming'))) {
      return true;
    }

    return false;
  });

  // Return strictly matching courses (can be [] if not found)
  return filtered;
}

/**
 * Filter batches by course ID
 */
export function getBatchesForCourse(batches: Batch[], courseId?: string): Batch[] {
  if (!batches || batches.length === 0) return [];
  if (!courseId) return [];
  return batches.filter(b => b.courseId === courseId);
}

/**
 * Get distinct available delivery modes for a selected course from database batches.
 * Only returns 'offline' and/or 'online'.
 */
export function getModesForCourse(batches: Batch[], courseId?: string): DeliveryMode[] {
  if (!batches || batches.length === 0) {
    return ['offline', 'online'];
  }

  const courseBatches = courseId ? batches.filter(b => b.courseId === courseId) : batches;
  const modesSet = new Set<DeliveryMode>();

  for (const b of courseBatches) {
    if (b.mode === 'online') {
      modesSet.add('online');
    } else {
      modesSet.add('offline');
    }
  }

  if (modesSet.size === 0) {
    return ['offline', 'online'];
  }

  return Array.from(modesSet);
}

/**
 * Filter batches based on Course and Delivery Mode (offline / online)
 */
export function getBatchesForCourseAndMode(
  batches: Batch[],
  courseId?: string,
  mode?: string
): Batch[] {
  if (!batches || batches.length === 0) return [];
  if (!courseId) return [];

  const courseBatches = batches.filter(b => b.courseId === courseId);
  if (courseBatches.length === 0) return [];

  if (mode && mode !== 'all') {
    const cleanMode = mode.toLowerCase();
    const modeFiltered = courseBatches.filter(b => {
      const bMode = (b.mode || 'offline').toLowerCase();
      if (cleanMode === 'online') return bMode === 'online';
      return bMode === 'offline';
    });
    return modeFiltered;
  }

  return courseBatches;
}

export function formatModeLabel(mode: string): string {
  switch (mode?.toLowerCase()) {
    case 'offline':
      return 'Offline (Classroom)';
    case 'online':
      return 'Online (Live Interactive)';
    default:
      return mode ? mode.toUpperCase() : 'Offline';
  }
}

/**
 * Resolves student's actual academic class reliably from student record, enrolled course, or batch.
 * Guarantees that students enrolled in Class 12 / Class 11 etc. display their real database class instead of a generic fallback.
 */
export function getStudentActualClass(
  student?: Partial<Student> | null,
  course?: Partial<Course> | null,
  batch?: Partial<Batch> | null
): string {
  if (student?.studentClass && typeof student.studentClass === 'string' && student.studentClass.trim()) {
    return student.studentClass.trim();
  }
  if ((student as any)?.class && typeof (student as any).class === 'string' && (student as any).class.trim()) {
    return (student as any).class.trim();
  }
  if ((student as any)?.academicClass && typeof (student as any).academicClass === 'string' && (student as any).academicClass.trim()) {
    return (student as any).academicClass.trim();
  }

  // Authoritative course academic standard
  if (course?.academicClass && typeof course.academicClass === 'string' && course.academicClass.trim()) {
    return course.academicClass.trim();
  }

  // Batch academic class
  if (batch?.academicClass && typeof batch.academicClass === 'string' && batch.academicClass.trim()) {
    return batch.academicClass.trim();
  }

  // Infer from course title or batch title if available
  const text = `${course?.title || ''} ${course?.code || ''} ${batch?.name || ''}`.toUpperCase();
  if (text.includes('XII') || text.includes('CLASS 12') || text.includes('COMS-012') || text.includes('COMA-012') || text.includes('COMA-12')) {
    return 'Class 12';
  }
  if (text.includes('XI') || text.includes('CLASS 11') || text.includes('COMS-011') || text.includes('COMA-011')) {
    return 'Class 11';
  }
  if (text.includes('CLASS 10') || text.includes('SECONDARY') || text.includes('COMS-010')) {
    return 'Class 10';
  }
  if (text.includes('CLASS 9')) {
    return 'Class 9';
  }
  if (text.includes('CLASS 8')) {
    return 'Class 8';
  }
  if (text.includes('BCA') || text.includes('B.SC') || text.includes('COLLEGE')) {
    return 'BCA / Higher Edu';
  }

  return 'Class 12';
}

/**
 * Accurately determines if a class recording belongs to a student based on their admission class,
 * enrolled course, or enrolled batch. Universal recordings (marked 'all' with no specific class) are shown to everyone.
 */
export function isRecordingForStudent(
  rec: ClassRecording,
  student?: Partial<Student> | null,
  courses: Course[] = [],
  batches: Batch[] = []
): boolean {
  if (!student) return false;

  const studentCourse = courses.find(c => c.id === student.courseId);
  const studentBatch = batches.find(b => b.id === student.batchId);
  const studentActualClass = getStudentActualClass(student, studentCourse, studentBatch);

  // 1. Direct student batch match
  if (student.batchId && rec.batchId && rec.batchId === student.batchId) {
    return true;
  }

  // 2. Direct student course match
  if (student.courseId && rec.courseId && rec.courseId === student.courseId) {
    return true;
  }

  // 3. Resolve recording's academic class
  let recClass = (rec.academicClass || rec.targetClass || '').trim();

  // If recording has a courseId specified, use course's academicClass
  if ((!recClass || recClass.toLowerCase() === 'all' || recClass.toLowerCase() === 'all classes') && rec.courseId && rec.courseId !== 'all') {
    const matchedCourse = courses.find(c => c.id === rec.courseId);
    if (matchedCourse?.academicClass) {
      recClass = matchedCourse.academicClass;
    }
  }

  // If recording has a batchId specified, use batch's academicClass
  if ((!recClass || recClass.toLowerCase() === 'all' || recClass.toLowerCase() === 'all classes') && rec.batchId && rec.batchId !== 'all') {
    const matchedBatch = batches.find(b => b.id === rec.batchId);
    if (matchedBatch?.academicClass) {
      recClass = matchedBatch.academicClass;
    }
  }

  // 4. If recording class is explicitly specified and not universal, it MUST match the student's admission class
  if (recClass && recClass.toLowerCase() !== 'all' && recClass.toLowerCase() !== 'all classes') {
    return matchesAcademicClass(recClass, studentActualClass);
  }

  // 5. Universal recording open to all
  if ((!rec.batchId || rec.batchId === 'all') && (!rec.courseId || rec.courseId === 'all')) {
    if (!recClass || recClass.toLowerCase() === 'all' || recClass.toLowerCase() === 'all classes') {
      return true;
    }
  }

  return matchesAcademicClass(recClass, studentActualClass);
}

/**
 * Accurately determines if study material belongs to a student based on their admission class,
 * enrolled course, or enrolled batch.
 */
export function isMaterialForStudent(
  mat: StudyMaterial,
  student?: Partial<Student> | null,
  courses: Course[] = [],
  batches: Batch[] = []
): boolean {
  if (!student) return false;

  const studentCourse = courses.find(c => c.id === student.courseId);
  const studentBatch = batches.find(b => b.id === student.batchId);
  const studentActualClass = getStudentActualClass(student, studentCourse, studentBatch);

  // 1. Direct student batch match
  if (student.batchId && mat.batchId && mat.batchId === student.batchId) {
    return true;
  }

  // 2. Direct student course match
  if (student.courseId && mat.courseId && mat.courseId === student.courseId) {
    return true;
  }

  // 3. Resolve study material's academic class
  let matClass = ((mat as any).academicClass || (mat as any).targetClass || '').trim();

  // If material is linked to a course, check course's academicClass or title
  if (!matClass && mat.courseId && mat.courseId !== 'all') {
    const matchedCourse = courses.find(c => c.id === mat.courseId);
    if (matchedCourse) {
      matClass = matchedCourse.academicClass || matchedCourse.title;
    }
  }

  // If material is linked to a batch, check batch's academicClass or name
  if (!matClass && mat.batchId && mat.batchId !== 'all') {
    const matchedBatch = batches.find(b => b.id === mat.batchId);
    if (matchedBatch) {
      matClass = matchedBatch.academicClass || matchedBatch.name;
    }
  }

  // 4. If material class is identified, match with student's actual class
  if (matClass && matClass.toLowerCase() !== 'all' && matClass.toLowerCase() !== 'all classes') {
    return matchesAcademicClass(matClass, studentActualClass);
  }

  // 5. If marked 'all' batch and 'all' course with no specific class, it is universal
  if ((!mat.batchId || mat.batchId === 'all') && (!mat.courseId || mat.courseId === 'all')) {
    return true;
  }

  return matchesAcademicClass(matClass, studentActualClass);
}


