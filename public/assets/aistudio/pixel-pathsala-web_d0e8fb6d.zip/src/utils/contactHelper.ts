/**
 * Utility helpers for formatting interactive Contact links (WhatsApp, Phone, Email)
 */

export function cleanPhoneDigits(phone?: string): string {
  if (!phone) return '';
  return phone.replace(/\D/g, '');
}

/**
 * Formats a phone number for WhatsApp wa.me links.
 * If 10 digits (standard Indian mobile without country code), adds 91 prefix.
 */
export function getWhatsAppUrl(
  whatsappNo?: string, 
  centerName: string = 'Pixel Pathsala',
  customMessage?: string
): string {
  const digits = cleanPhoneDigits(whatsappNo || '9775708722');
  if (!digits) return '#';
  
  let formattedNumber = digits;
  if (digits.length === 10) {
    formattedNumber = `91${digits}`;
  }

  const defaultMsg = `Hello ${centerName}, I would like to inquire about course admissions, batch timings, and fee structures.`;
  const text = customMessage || defaultMsg;

  return `https://wa.me/${formattedNumber}?text=${encodeURIComponent(text)}`;
}

/**
 * Returns a tel: link for click-to-call
 */
export function getPhoneTelUrl(phone?: string): string {
  if (!phone) return '#';
  return `tel:${phone.replace(/\s+/g, '')}`;
}

/**
 * Returns a mailto: link with pre-populated subject & template
 */
export function getEmailMailtoUrl(
  email?: string, 
  centerName: string = 'Pixel Pathsala',
  subject?: string
): string {
  if (!email) return '#';
  const mailSubject = subject || `Course & Admission Inquiry - ${centerName}`;
  const mailBody = `Hello ${centerName} Admissions Team,\n\nI am writing to inquire about the courses and admission process.\n\nThank you.`;
  
  return `mailto:${email}?subject=${encodeURIComponent(mailSubject)}&body=${encodeURIComponent(mailBody)}`;
}
