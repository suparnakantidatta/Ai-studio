import { Student, Course, Batch, Discount, FeePayment, StudentMonthDueStatus } from '../types';

export const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

/**
 * Converts "2026-04" -> "April 2026"
 */
export function formatMonthKey(monthKey: string): string {
  if (!monthKey || !monthKey.includes('-')) return monthKey;
  const [yearStr, monthStr] = monthKey.split('-');
  const monthIdx = parseInt(monthStr, 10) - 1;
  const year = parseInt(yearStr, 10);
  if (monthIdx >= 0 && monthIdx < 12) {
    return `${MONTH_NAMES[monthIdx]} ${year}`;
  }
  return monthKey;
}

/**
 * Returns current real-time year-month key in YYYY-MM format (e.g. "2026-10")
 */
export function getCurrentMonthKey(): string {
  const d = new Date();
  const yr = d.getFullYear();
  const mo = d.getMonth() + 1;
  return `${yr}-${mo < 10 ? '0' + mo : mo}`;
}

/**
 * Returns an array of YYYY-MM keys from startMonth to endMonth (inclusive).
 * Dynamically defaults endMonth to current calendar month in real time.
 */
export function getMonthRange(startMonthKey: string, endMonthKey?: string): string[] {
  const targetEnd = endMonthKey || getCurrentMonthKey();
  if (!startMonthKey) return [targetEnd];
  
  const [startYear, startMonth] = startMonthKey.split('-').map(Number);
  const [endYear, endMonth] = targetEnd.split('-').map(Number);

  const months: string[] = [];
  let curYear = startYear;
  let curMonth = startMonth;

  while (curYear < endYear || (curYear === endYear && curMonth <= endMonth)) {
    const formattedMonth = curMonth < 10 ? `0${curMonth}` : `${curMonth}`;
    months.push(`${curYear}-${formattedMonth}`);
    
    curMonth++;
    if (curMonth > 12) {
      curMonth = 1;
      curYear++;
    }
  }

  return months.length > 0 ? months : [startMonthKey];
}

export interface TargetDiscountParams {
  studentClass?: string;
  courseId?: string;
  batchId?: string;
  studentId?: string;
  monthKey?: string;
  baseFee: number;
  discounts: Discount[];
  course?: Course;
}

/**
 * Calculates discount for any target (academic class, course, batch, or individual student) in a given month.
 * Suitable for both existing students and prospective students during Admission / Add Student flows.
 */
export function calculateTargetDiscount({
  studentClass,
  courseId,
  batchId,
  studentId,
  monthKey = getCurrentMonthKey(),
  baseFee,
  discounts,
  course
}: TargetDiscountParams): {
  discountAmount: number;
  finalFee: number;
  notes: string[];
  appliedDiscounts: Discount[];
} {
  let totalDiscount = 0;
  const notes: string[] = [];
  const appliedDiscounts: Discount[] = [];

  if (!discounts || !Array.isArray(discounts) || discounts.length === 0 || baseFee <= 0) {
    return { discountAmount: 0, finalFee: Math.max(0, baseFee), notes: [], appliedDiscounts: [] };
  }

  const isMonthApplicable = (disc: Discount, mKey: string): boolean => {
    if (!disc.applicableMonthsType || disc.applicableMonthsType === 'all_months') return true;
    if (!disc.selectedMonths || !Array.isArray(disc.selectedMonths) || disc.selectedMonths.length === 0) return true;
    const targetKey = mKey.trim().toLowerCase();
    const formattedTarget = formatMonthKey(mKey).toLowerCase();
    return disc.selectedMonths.some(m => {
      const mStr = String(m).trim().toLowerCase();
      return mStr === targetKey || mStr === formattedTarget || targetKey.startsWith(mStr) || mStr.startsWith(targetKey);
    });
  };

  const matchingCandidates: {
    discount: Discount;
    amount: number;
    percentage?: number;
    flatAmount?: number;
    formatted: string;
  }[] = [];

  for (const disc of discounts) {
    // Check if active
    const isActive = disc.active !== false && String(disc.active).toLowerCase() !== 'false';
    if (!isActive) continue;

    // Check target matching
    let isMatch = false;
    const discScope = (disc.scope || 'all').toLowerCase();

    if (discScope === 'all' || discScope === 'center') {
      isMatch = true;
    } else if (discScope === 'class') {
      const targetClass = (disc.academicClass || '').toLowerCase().trim();
      const stuClass = (studentClass || '').toLowerCase().trim();
      const crsClass = (course?.academicClass || '').toLowerCase().trim();
      isMatch = !targetClass || targetClass === 'all' || targetClass === 'all classes' || Boolean(
        stuClass.includes(targetClass) ||
        targetClass.includes(stuClass) ||
        crsClass.includes(targetClass) ||
        targetClass.includes(crsClass)
      );
    } else if (discScope === 'course') {
      isMatch = !disc.courseId || disc.courseId === 'all' || (Boolean(courseId) && disc.courseId === courseId);
    } else if (discScope === 'batch') {
      isMatch = !disc.batchId || disc.batchId === 'all' || (Boolean(batchId) && disc.batchId === batchId);
    } else if (discScope === 'student') {
      isMatch = !disc.studentId || disc.studentId === 'all' || (Boolean(studentId) && disc.studentId === studentId);
    }

    if (!isMatch) continue;

    // Check month applicability
    if (!isMonthApplicable(disc, monthKey)) continue;

    let discVal = 0;
    const rawVal = Number(disc.value) || 0;
    if (disc.type === 'percentage') {
      discVal = (baseFee * rawVal) / 100;
    } else {
      discVal = rawVal;
    }

    if (discVal > 0) {
      const formatted = disc.type === 'percentage' ? `${rawVal}%` : `₹${discVal}`;
      matchingCandidates.push({
        discount: disc,
        amount: discVal,
        percentage: disc.type === 'percentage' ? rawVal : undefined,
        flatAmount: disc.type === 'flat' ? rawVal : undefined,
        formatted
      });
    }
  }

  if (matchingCandidates.length === 0) {
    return { discountAmount: 0, finalFee: Math.max(0, baseFee), notes: [], appliedDiscounts: [] };
  }

  // Where multiple discounts are found, choose ONLY the highest discount (do not sum up)
  matchingCandidates.sort((a, b) => b.amount - a.amount);
  const best = matchingCandidates[0];

  const finalDiscount = Math.min(baseFee, best.amount);
  const roundedDiscount = Math.round(finalDiscount);
  const finalFee = Math.max(0, Math.round(baseFee - roundedDiscount));

  const noteText = matchingCandidates.length > 1
    ? `${best.discount.title} (Highest Concession: -${best.formatted})`
    : `${best.discount.title} (-${best.formatted})`;

  return {
    discountAmount: roundedDiscount,
    finalFee,
    notes: [noteText],
    appliedDiscounts: [best.discount]
  };
}

export interface CourseDiscountInfo {
  hasDiscount: boolean;
  discountAmount: number;
  finalFee: number;
  baseFee: number;
  percentage?: number;
  flatAmount?: number;
  ribbonText: string;
  discountTitle: string;
  notes: string[];
  appliedDiscounts: Discount[];
}

/**
 * Calculates the best active discount info for a given course on the public website.
 * When multiple discounts are found for one course, it selects ONLY the highest discount (does not sum them up),
 * and formats the badge text with "UPTO" (e.g. "UPTO 20% OFF" or "UPTO ₹250 OFF").
 */
export function getCourseDiscountInfo(
  course: Course,
  discounts: Discount[],
  batches?: Batch[],
  monthKey?: string
): CourseDiscountInfo {
  const baseFee = course?.monthlyFee || 0;
  if (!course || baseFee <= 0 || !discounts || !Array.isArray(discounts)) {
    return {
      hasDiscount: false,
      discountAmount: 0,
      finalFee: baseFee,
      baseFee,
      ribbonText: '',
      discountTitle: '',
      notes: [],
      appliedDiscounts: []
    };
  }

  // Find course's batches if available
  const courseBatches = batches?.filter(b => b.courseId === course.id) || [];
  const batchIds = courseBatches.map(b => b.id);

  // Check matching discounts
  const matchingCandidates: {
    discount: Discount;
    amount: number;
    percentage?: number;
    flatAmount?: number;
    formatted: string;
  }[] = [];

  for (const disc of discounts) {
    if (disc.active === false || String(disc.active).toLowerCase() === 'false') continue;

    const discScope = (disc.scope || 'all').toLowerCase();
    let isMatch = false;

    if (discScope === 'all' || discScope === 'center') {
      isMatch = true;
    } else if (discScope === 'course') {
      isMatch = !disc.courseId || disc.courseId === 'all' || disc.courseId === course.id;
    } else if (discScope === 'class') {
      const targetClass = (disc.academicClass || '').toLowerCase().trim();
      const crsClass = (course.academicClass || '').toLowerCase().trim();
      isMatch = !targetClass || targetClass === 'all' || targetClass === 'all classes' || Boolean(crsClass.includes(targetClass) || targetClass.includes(crsClass));
    } else if (discScope === 'batch') {
      isMatch = !disc.batchId || disc.batchId === 'all' || Boolean(batchIds.includes(disc.batchId));
    }

    if (isMatch) {
      // Check month if monthKey provided
      if (monthKey && disc.applicableMonthsType === 'selected_months' && disc.selectedMonths?.length) {
        const targetKey = monthKey.toLowerCase();
        const formattedTarget = formatMonthKey(monthKey).toLowerCase();
        const matchesMonth = disc.selectedMonths.some(m => {
          const mStr = String(m).toLowerCase();
          return mStr === targetKey || mStr === formattedTarget;
        });
        if (!matchesMonth) continue;
      }

      const rawVal = Number(disc.value) || 0;
      let calculatedAmt = 0;
      let pct: number | undefined = undefined;
      let flat: number | undefined = undefined;

      if (disc.type === 'percentage') {
        calculatedAmt = (baseFee * rawVal) / 100;
        pct = rawVal;
      } else {
        calculatedAmt = rawVal;
        flat = rawVal;
      }

      if (calculatedAmt > 0) {
        matchingCandidates.push({
          discount: disc,
          amount: calculatedAmt,
          percentage: pct,
          flatAmount: flat,
          formatted: disc.type === 'percentage' ? `${rawVal}%` : `₹${calculatedAmt}`
        });
      }
    }
  }

  if (matchingCandidates.length === 0) {
    return {
      hasDiscount: false,
      discountAmount: 0,
      finalFee: baseFee,
      baseFee,
      ribbonText: '',
      discountTitle: '',
      notes: [],
      appliedDiscounts: []
    };
  }

  // Where multiple discounts are found, select ONLY the highest discount (do not sum up)
  matchingCandidates.sort((a, b) => b.amount - a.amount);
  const highest = matchingCandidates[0];

  const discountAmount = Math.min(baseFee, Math.round(highest.amount));
  const finalFee = Math.max(0, Math.round(baseFee - discountAmount));

  // Add "UPTO" to the amount or percentage
  let ribbonText = '';
  if (highest.percentage && highest.percentage > 0) {
    ribbonText = `UPTO ${highest.percentage}% OFF`;
  } else if (discountAmount > 0) {
    ribbonText = `UPTO ₹${discountAmount} OFF`;
  } else {
    ribbonText = 'SPECIAL OFFER';
  }

  const notes = matchingCandidates.length > 1
    ? [`${highest.discount.title} (Highest discount: ${highest.formatted} off)`]
    : [`${highest.discount.title} (${highest.formatted} off)`];

  return {
    hasDiscount: discountAmount > 0,
    discountAmount,
    finalFee,
    baseFee,
    percentage: highest.percentage,
    flatAmount: highest.flatAmount,
    ribbonText,
    discountTitle: highest.discount.title,
    notes,
    appliedDiscounts: [highest.discount]
  };
}

export interface BatchDiscountInfo {
  batchId: string;
  batchName: string;
  hasDiscount: boolean;
  discountAmount: number;
  finalFee: number;
  baseFee: number;
  percentage?: number;
  flatAmount?: number;
  discountText: string;
  discountTitle: string;
  notes: string[];
  appliedDiscounts: Discount[];
}

/**
 * Calculates the highest discount for a specific batch.
 * Where multiple discounts apply, it picks ONLY the highest discount (no sum),
 * and formats with 'UPTO' if applicable.
 */
export function getBatchDiscountInfo(
  batch: Batch,
  course: Course,
  discounts: Discount[],
  monthKey?: string
): BatchDiscountInfo {
  const baseFee = course?.monthlyFee || 0;
  if (!batch || !course || baseFee <= 0 || !discounts || !Array.isArray(discounts)) {
    return {
      batchId: batch?.id || '',
      batchName: batch?.name || '',
      hasDiscount: false,
      discountAmount: 0,
      finalFee: baseFee,
      baseFee,
      discountText: '',
      discountTitle: '',
      notes: [],
      appliedDiscounts: []
    };
  }

  const matchingCandidates: {
    discount: Discount;
    amount: number;
    percentage?: number;
    flatAmount?: number;
    formatted: string;
  }[] = [];

  for (const disc of discounts) {
    if (disc.active === false || String(disc.active).toLowerCase() === 'false') continue;

    const discScope = (disc.scope || 'all').toLowerCase();
    let isMatch = false;

    if (discScope === 'all' || discScope === 'center') {
      isMatch = true;
    } else if (discScope === 'course') {
      isMatch = !disc.courseId || disc.courseId === 'all' || disc.courseId === course.id;
    } else if (discScope === 'class') {
      const targetClass = (disc.academicClass || '').toLowerCase().trim();
      const crsClass = (course.academicClass || '').toLowerCase().trim();
      isMatch = !targetClass || targetClass === 'all' || targetClass === 'all classes' || Boolean(crsClass.includes(targetClass) || targetClass.includes(crsClass));
    } else if (discScope === 'batch') {
      isMatch = disc.batchId === batch.id || disc.batchId === 'all';
    }

    if (isMatch) {
      if (monthKey && disc.applicableMonthsType === 'selected_months' && disc.selectedMonths?.length) {
        const targetKey = monthKey.toLowerCase();
        const formattedTarget = formatMonthKey(monthKey).toLowerCase();
        const matchesMonth = disc.selectedMonths.some(m => {
          const mStr = String(m).toLowerCase();
          return mStr === targetKey || mStr === formattedTarget;
        });
        if (!matchesMonth) continue;
      }

      const rawVal = Number(disc.value) || 0;
      let calculatedAmt = 0;
      let pct: number | undefined = undefined;
      let flat: number | undefined = undefined;

      if (disc.type === 'percentage') {
        calculatedAmt = (baseFee * rawVal) / 100;
        pct = rawVal;
      } else {
        calculatedAmt = rawVal;
        flat = rawVal;
      }

      if (calculatedAmt > 0) {
        matchingCandidates.push({
          discount: disc,
          amount: calculatedAmt,
          percentage: pct,
          flatAmount: flat,
          formatted: disc.type === 'percentage' ? `${rawVal}%` : `₹${calculatedAmt}`
        });
      }
    }
  }

  if (matchingCandidates.length === 0) {
    return {
      batchId: batch.id,
      batchName: batch.name,
      hasDiscount: false,
      discountAmount: 0,
      finalFee: baseFee,
      baseFee,
      discountText: '',
      discountTitle: '',
      notes: [],
      appliedDiscounts: []
    };
  }

  // Where multiple discounts are found, select ONLY the highest discount (do not sum up)
  matchingCandidates.sort((a, b) => b.amount - a.amount);
  const highest = matchingCandidates[0];

  const discountAmount = Math.min(baseFee, Math.round(highest.amount));
  const finalFee = Math.max(0, Math.round(baseFee - discountAmount));

  let discountText = '';
  if (highest.percentage && highest.percentage > 0) {
    discountText = `UPTO ${highest.percentage}% OFF`;
  } else if (discountAmount > 0) {
    discountText = `UPTO ₹${discountAmount} OFF`;
  } else {
    discountText = 'SPECIAL OFFER';
  }

  const notes = matchingCandidates.length > 1
    ? [`${highest.discount.title} (Highest: -${highest.formatted})`]
    : [`${highest.discount.title} (-${highest.formatted})`];

  return {
    batchId: batch.id,
    batchName: batch.name,
    hasDiscount: discountAmount > 0,
    discountAmount,
    finalFee,
    baseFee,
    percentage: highest.percentage,
    flatAmount: highest.flatAmount,
    discountText,
    discountTitle: highest.discount.title,
    notes,
    appliedDiscounts: [highest.discount]
  };
}

/**
 * Calculates discount for a specific student and month
 */
export function calculateMonthDiscount(
  student: Student,
  monthKey: string,
  baseFee: number,
  discounts: Discount[],
  course?: Course
): { discountAmount: number; notes: string[] } {
  const res = calculateTargetDiscount({
    studentClass: student.studentClass,
    courseId: student.courseId,
    batchId: student.batchId,
    studentId: student.id,
    monthKey,
    baseFee,
    discounts,
    course
  });

  return {
    discountAmount: res.discountAmount,
    notes: res.notes
  };
}

/**
 * Calculates month-by-month billing status for a student from their admissionMonth/admissionDate.
 * Adjusts payments across previous and next months:
 * e.g., If student paid ₹400 on admission and next month pays ₹800; if in next month the batch is discounted to ₹200/mo,
 * then ₹800 paid covers 4 months (or total ₹1200 covers 6 months), and dues are shown as negative (advance credit).
 */
export function getStudentMonthlyBilling(
  student: Student,
  course: Course | undefined,
  discounts: Discount[],
  payments: FeePayment[],
  targetEndMonth?: string
): {
  monthlyStatuses: StudentMonthDueStatus[];
  totalPayableSinceAdmission: number;
  totalPaid: number;
  totalPendingApproval: number;
  totalDueAmount: number;
  unpaidMonthsCount: number;
  monthsCoveredCount: number;
  advanceAmount: number;
  advanceMonthsCount: number;
} {
  const currentRealMonth = getCurrentMonthKey();
  const effectiveEndMonth = targetEndMonth || currentRealMonth;
  const baseMonthlyFee = student.customMonthlyFeeOverride ?? (course?.monthlyFee ?? 1200);
  const startMonth = student.admissionMonth || (student.admissionDate ? student.admissionDate.substring(0, 7) : currentRealMonth);
  const monthKeys = getMonthRange(startMonth, effectiveEndMonth);

  const studentPayments = payments.filter(p => p.studentId === student.id);
  const approvedPayments = studentPayments.filter(p => p.status === 'approved');
  const pendingPayments = studentPayments.filter(p => p.status === 'pending');

  const totalPaid = approvedPayments.reduce((sum, p) => sum + (Number(p.finalAmountPaid) || 0), 0);
  const totalPendingApproval = pendingPayments.reduce((sum, p) => sum + (Number(p.finalAmountPaid) || 0), 0);

  let runningPaidPool = totalPaid;
  let runningPendingPool = totalPendingApproval;
  let totalPayableSinceAdmission = 0;
  let unpaidMonthsCount = 0;
  let monthsCoveredCount = 0;

  const monthlyStatuses: StudentMonthDueStatus[] = [];

  // Pass 1: Standard months from admission to target end month
  for (const monthKey of monthKeys) {
    const { discountAmount, notes } = calculateMonthDiscount(
      student,
      monthKey,
      baseMonthlyFee,
      discounts,
      course
    );
    const netFeeDue = Math.max(0, baseMonthlyFee - discountAmount);
    totalPayableSinceAdmission += netFeeDue;

    // Direct matching payment check for receipt linking
    const approvedPayment = approvedPayments.find(p =>
      p.monthsCovered?.includes(monthKey) || p.month === formatMonthKey(monthKey)
    );
    const pendingPayment = pendingPayments.find(p =>
      p.monthsCovered?.includes(monthKey) || p.month === formatMonthKey(monthKey)
    );

    if (runningPaidPool >= netFeeDue && netFeeDue > 0) {
      // Month fully covered by available paid funds
      runningPaidPool -= netFeeDue;
      monthsCoveredCount++;
      monthlyStatuses.push({
        monthKey,
        monthLabel: formatMonthKey(monthKey),
        baseFee: baseMonthlyFee,
        discountAmount,
        discountNote: notes.join(', '),
        netFeeDue,
        isPaid: true,
        paidAmount: netFeeDue,
        paymentId: approvedPayment?.id || approvedPayments[0]?.id,
        paymentReceiptNo: approvedPayment?.receiptNo || approvedPayments[0]?.receiptNo,
        paymentDate: approvedPayment?.paymentDate || approvedPayments[0]?.paymentDate
      });
    } else if (netFeeDue === 0) {
      // 100% scholarship / free month
      monthsCoveredCount++;
      monthlyStatuses.push({
        monthKey,
        monthLabel: formatMonthKey(monthKey),
        baseFee: baseMonthlyFee,
        discountAmount,
        discountNote: notes.join(', ') || '100% Scholarship Waiver',
        netFeeDue: 0,
        isPaid: true,
        paidAmount: 0
      });
    } else if (runningPaidPool > 0) {
      // Partially covered
      const portionPaid = runningPaidPool;
      runningPaidPool = 0;
      unpaidMonthsCount++;
      monthlyStatuses.push({
        monthKey,
        monthLabel: formatMonthKey(monthKey),
        baseFee: baseMonthlyFee,
        discountAmount,
        discountNote: notes.join(', '),
        netFeeDue,
        isPaid: false,
        paidAmount: portionPaid,
        paymentId: approvedPayment?.id,
        paymentReceiptNo: approvedPayment?.receiptNo
      });
    } else if (runningPendingPool >= netFeeDue) {
      // Covered by pending payment submission
      runningPendingPool -= netFeeDue;
      monthlyStatuses.push({
        monthKey,
        monthLabel: formatMonthKey(monthKey),
        baseFee: baseMonthlyFee,
        discountAmount,
        discountNote: notes.join(', '),
        netFeeDue,
        isPaid: false,
        isPendingApproval: true,
        pendingPaymentId: pendingPayment?.id || pendingPayments[0]?.id
      });
    } else {
      // Unpaid due
      unpaidMonthsCount++;
      monthlyStatuses.push({
        monthKey,
        monthLabel: formatMonthKey(monthKey),
        baseFee: baseMonthlyFee,
        discountAmount,
        discountNote: notes.join(', '),
        netFeeDue,
        isPaid: false
      });
    }
  }

  // Pass 2: If student has surplus advance balance (runningPaidPool > 0), adjust with upcoming next months!
  let advanceMonthsCount = 0;
  let nextMonthCursor = monthKeys[monthKeys.length - 1];

  while (runningPaidPool > 0) {
    // Determine next month key
    const [yr, mo] = (nextMonthCursor || effectiveEndMonth).split('-').map(Number);
    let nextYr = yr;
    let nextMo = mo + 1;
    if (nextMo > 12) {
      nextMo = 1;
      nextYr++;
    }
    const nextMonthKey = `${nextYr}-${nextMo < 10 ? '0' + nextMo : nextMo}`;
    nextMonthCursor = nextMonthKey;

    const { discountAmount, notes } = calculateMonthDiscount(
      student,
      nextMonthKey,
      baseMonthlyFee,
      discounts,
      course
    );
    const nextNetFee = Math.max(1, baseMonthlyFee - discountAmount);

    if (runningPaidPool >= nextNetFee) {
      runningPaidPool -= nextNetFee;
      monthsCoveredCount++;
      advanceMonthsCount++;
      monthlyStatuses.push({
        monthKey: nextMonthKey,
        monthLabel: `${formatMonthKey(nextMonthKey)} (Advance)`,
        baseFee: baseMonthlyFee,
        discountAmount,
        discountNote: notes.join(', ') || 'Advance Paid',
        netFeeDue: nextNetFee,
        isPaid: true,
        isAdvancePaid: true,
        paidAmount: nextNetFee,
        paymentId: approvedPayments[approvedPayments.length - 1]?.id,
        paymentReceiptNo: approvedPayments[approvedPayments.length - 1]?.receiptNo
      });
    } else {
      // Partial surplus covering part of next month
      monthlyStatuses.push({
        monthKey: nextMonthKey,
        monthLabel: `${formatMonthKey(nextMonthKey)} (Partial Advance)`,
        baseFee: baseMonthlyFee,
        discountAmount,
        discountNote: notes.join(', '),
        netFeeDue: nextNetFee,
        isPaid: false,
        isAdvancePaid: true,
        paidAmount: runningPaidPool
      });
      runningPaidPool = 0;
      break;
    }
  }

  // Net due calculation (negative means advance surplus credit)
  const totalDueAmount = totalPayableSinceAdmission - totalPaid;
  const advanceAmount = Math.max(0, totalPaid - totalPayableSinceAdmission);

  return {
    monthlyStatuses,
    totalPayableSinceAdmission,
    totalPaid,
    totalPendingApproval,
    totalDueAmount,
    unpaidMonthsCount,
    monthsCoveredCount,
    advanceAmount,
    advanceMonthsCount
  };
}
