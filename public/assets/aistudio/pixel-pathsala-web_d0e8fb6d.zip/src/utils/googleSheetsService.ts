/**
 * Google Workspace / Google Sheets API Integration Service
 * Uses Google Identity Services (GSI) OAuth Token Flow (Client-Side)
 * Handles Sheets Creation, Schema Initialization, Data Synchronization, and Live Pull/Push.
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  User 
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { 
  CenterInfo, 
  Student, 
  StudentStatus,
  FeePayment, 
  PaymentMode,
  AdmissionApplication, 
  Course, 
  Batch, 
  Educator, 
  Expense, 
  Discount,
  AdminAccount,
  StudyMaterial,
  QuestionBankItem,
  OnlineExam,
  ExamSubmission,
  LiveClassSession,
  ClassRecording
} from '../types';
import { getStudentMonthlyBilling } from './feeCalculator';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/spreadsheets');
provider.addScope('https://www.googleapis.com/auth/drive.file');
provider.setCustomParameters({
  prompt: 'consent'
});

export interface GoogleUserProfile {
  email: string;
  name: string;
  picture?: string;
}

export interface GoogleSheetsSyncResult {
  success: boolean;
  message: string;
  spreadsheetId?: string;
  spreadsheetUrl?: string;
  updatedSheets?: string[];
  recordsCount?: number;
  timestamp?: string;
}

const TOKEN_STORAGE_KEY = 'pixelpathsala_google_access_token';
const TOKEN_EXPIRY_KEY = 'pixelpathsala_google_token_expiry';
const USER_STORAGE_KEY = 'pixelpathsala_google_user';

class GoogleSheetsService {
  private accessToken: string | null = null;

  constructor() {
    this.loadPersistedToken();
  }

  private loadPersistedToken() {
    try {
      const token = localStorage.getItem(TOKEN_STORAGE_KEY);
      const expiry = localStorage.getItem(TOKEN_EXPIRY_KEY);
      if (token && expiry && Number(expiry) > Date.now()) {
        this.accessToken = token;
      } else {
        this.clearToken();
      }
    } catch {
      this.clearToken();
    }
  }

  public getAccessToken(): string | null {
    if (this.accessToken) {
      const expiry = localStorage.getItem(TOKEN_EXPIRY_KEY);
      if (expiry && Number(expiry) <= Date.now()) {
        this.clearToken();
        return null;
      }
      return this.accessToken;
    }
    return null;
  }

  public getGoogleUser(): GoogleUserProfile | null {
    try {
      const saved = localStorage.getItem(USER_STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  }

  public clearToken() {
    this.accessToken = null;
    localStorage.removeItem(TOKEN_STORAGE_KEY);
    localStorage.removeItem(TOKEN_EXPIRY_KEY);
    localStorage.removeItem(USER_STORAGE_KEY);
    signOut(auth).catch(() => {});
  }

  /**
   * Triggers Firebase Auth Google Sign-In Popup with Spreadsheets & Drive Scopes
   */
  public async requestOAuthToken(): Promise<{ success: boolean; token?: string; error?: string }> {
    try {
      const result = await signInWithPopup(auth, provider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      const token = credential?.accessToken;

      if (!token) {
        return { 
          success: false, 
          error: 'Could not retrieve Google OAuth access token. Please check permissions.' 
        };
      }

      this.accessToken = token;
      // Access tokens are typically valid for 1 hour
      const expiresIn = 3600 * 1000;
      localStorage.setItem(TOKEN_STORAGE_KEY, token);
      localStorage.setItem(TOKEN_EXPIRY_KEY, String(Date.now() + expiresIn - 60000));

      const profile: GoogleUserProfile = {
        email: result.user.email || 'User',
        name: result.user.displayName || result.user.email || 'User',
        picture: result.user.photoURL || undefined
      };
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(profile));

      return { success: true, token };
    } catch (err: any) {
      console.error('Google Sign-In Error:', err);
      let errorMsg = err.message || 'Failed to authenticate with Google.';
      if (err.code === 'auth/popup-closed-by-user') {
        errorMsg = 'Sign-in popup was closed before completing authorization.';
      } else if (err.code === 'auth/cancelled-popup-request') {
        errorMsg = 'Sign-in cancelled.';
      }
      return { success: false, error: errorMsg };
    }
  }

  /**
   * Helper to perform authenticated Google Sheets REST calls
   */
  private async fetchSheetsApi(endpoint: string, options: RequestInit = {}): Promise<any> {
    const token = this.getAccessToken();
    if (!token) {
      throw new Error('Google Account is not connected or session expired. Please sign in with Google.');
    }

    const headers = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...options.headers,
    };

    const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets${endpoint}`, {
      ...options,
      headers,
    });

    if (!res.ok) {
      let errBody = '';
      try {
        const json = await res.json();
        errBody = json.error?.message || JSON.stringify(json);
      } catch {
        errBody = await res.text();
      }
      throw new Error(`Google Sheets API Error (${res.status}): ${errBody}`);
    }

    return res.json();
  }

  /**
   * Creates a brand-new structured Google Sheet specifically organized for Pixel Pathsala
   */
  public async createPixelPathsalaSpreadsheet(centerName: string = 'Pixel Pathsala'): Promise<{ id: string; url: string }> {
    if (!this.getAccessToken()) {
      const authRes = await this.requestOAuthToken();
      if (!authRes.success || !this.getAccessToken()) {
        throw new Error(authRes.error || 'Google Account authorization required to create spreadsheets in Google Drive.');
      }
    }

    const title = `${centerName} - Master ERP Database (${new Date().toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })})`;

    const sheetPayload = {
      properties: {
        title,
      },
      sheets: [
        { properties: { title: 'Students' } },
        { properties: { title: 'Admissions' } },
        { properties: { title: 'Fee_Transactions' } },
        { properties: { title: 'Courses_Batches' } },
        { properties: { title: 'Educators' } },
        { properties: { title: 'Expenses' } },
        { properties: { title: 'Admin_Credentials' } },
        { properties: { title: 'Center_Overview' } },
        { properties: { title: 'Study_Materials' } },
        { properties: { title: 'Question_Bank' } },
        { properties: { title: 'Exams' } },
        { properties: { title: 'Exam_Submissions' } },
        { properties: { title: 'Live_Classes' } },
        { properties: { title: 'Class_Recordings' } }
      ],
    };

    const created = await this.fetchSheetsApi('', {
      method: 'POST',
      body: JSON.stringify(sheetPayload),
    });

    const spreadsheetId = created.spreadsheetId;
    const url = created.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

    return { id: spreadsheetId, url };
  }

  /**
   * Verifies if a given spreadsheet ID exists and has read/write access
   */
  public async testSpreadsheetAccess(spreadsheetId: string): Promise<{ title: string; sheets: string[] }> {
    const cleanId = this.extractSpreadsheetId(spreadsheetId);
    if (!this.getAccessToken()) {
      const authRes = await this.requestOAuthToken();
      if (!authRes.success || !this.getAccessToken()) {
        throw new Error(authRes.error || 'Google Account is not connected. Please sign in with Google.');
      }
    }

    const data = await this.fetchSheetsApi(`/${cleanId}?fields=properties.title,sheets.properties.title`);
    const title = data.properties?.title || 'Google Sheet Database';
    const sheets = (data.sheets || []).map((s: any) => s.properties?.title || '');
    return { title, sheets };
  }

  /**
   * Extracts clean 44-character Spreadsheet ID from either ID or full URL
   */
  public extractSpreadsheetId(input: string): string {
    if (!input) return '';
    const trimmed = input.trim();
    const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    if (match && match[1]) {
      return match[1];
    }
    return trimmed;
  }

  /**
   * Full database push: Exports all local state tables into structured Google Sheet tabs
   */
  public async syncAllToGoogleSheet(
    spreadsheetId: string,
    data: {
      centerInfo: CenterInfo;
      students: Student[];
      admissions: AdmissionApplication[];
      payments: FeePayment[];
      courses: Course[];
      batches: Batch[];
      educators: Educator[];
      expenses: Expense[];
      discounts: Discount[];
      adminAccounts?: AdminAccount[];
      studyMaterials?: StudyMaterial[];
      questions?: QuestionBankItem[];
      exams?: OnlineExam[];
      examSubmissions?: ExamSubmission[];
      liveClasses?: LiveClassSession[];
      classRecordings?: ClassRecording[];
    }
  ): Promise<GoogleSheetsSyncResult> {
    const cleanId = this.extractSpreadsheetId(spreadsheetId);
    if (!cleanId) {
      return { success: false, message: 'Invalid or missing Google Spreadsheet ID.' };
    }

    // Check if token is missing
    if (!this.getAccessToken()) {
      // If Webhook URL is configured in CenterInfo, try pushing via webhook directly
      if (data.centerInfo?.googleSheetWebhookUrl) {
        try {
          const webhookUrl = data.centerInfo.googleSheetWebhookUrl;
          const tablesPayload: Record<string, any[][]> = {
            Students: [
              ['Student ID', 'Roll No', 'Full Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Residential Address', 'Course ID', 'Batch ID', 'Admission Date', 'Status', 'Custom Fee Override (₹)', 'Monthly Base Fee (₹)', 'Total Paid (₹)', 'Outstanding Due (₹)'],
              ...((data.students || []).map((s: any) => [
                s.id || '', s.rollNo || '', s.name || '', s.mobile || '', s.aadhaarNo || '', s.email || '',
                s.guardianName || '', s.guardianPhone || '', s.address || '', s.courseId || '', s.batchId || '',
                s.admissionDate || '', s.status || 'active', s.customMonthlyFeeOverride || '', s.monthlyFee || '',
                s.totalPaid || '', s.totalDue || ''
              ]))
            ],
            Admissions: [
              ['Application ID', 'Student Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Target Course ID', 'Status', 'Applied Date', 'Initial Fee Status', 'Payment Mode', 'Transaction Ref / UPI', 'Staff Remarks', 'Rejection Reason', 'Address'],
              ...((data.admissions || []).map((a: any) => [
                a.id || a.applicationNo || '', a.studentName || '', a.mobile || '', a.aadhaarNo || '', a.email || '',
                a.guardianName || '', a.guardianPhone || '', a.targetCourseId || a.courseId || '', a.status || 'pending', a.appliedDate || '',
                a.initialPaymentStatus || a.initialFeeStatus || 'UNPAID', a.initialPaymentMode || a.paymentMode || 'UPI', a.initialPaymentRef || a.transactionRef || '', a.remarks || '', a.rejectionReason || '', a.address || ''
              ]))
            ],
            Fee_Transactions: [
              ['Receipt No', 'Payment ID', 'Student ID', 'Student Name', 'Amount Paid (₹)', 'Payment Mode', 'Months Covered', 'Transaction Ref / UPI', 'Payment Date', 'Approval Status', 'Approved By', 'Rejection Reason'],
              ...((data.payments || []).map((p: any) => [
                p.receiptNo || '', p.id || '', p.studentId || '', p.studentName || '', p.finalAmountPaid || 0,
                p.paymentMode || 'UPI', (p.feeMonthsCovered || p.selectedMonths || []).join(', '), p.transactionRef || '', p.paymentDate || '',
                p.status || 'approved', p.approvedBy || '', p.rejectionReason || ''
              ]))
            ],
            Courses_Batches: [
              ['Type', 'ID', 'Title / Name', 'Code', 'Duration (Months)', 'Total Fee (₹)', 'Monthly Base Fee (₹)', 'Admission Fee (₹)', 'Max Capacity', 'Schedule / Timing', 'Mode'],
              ...((data.courses || []).map((c: any) => [
                'Course', c.id || '', c.title || '', c.code || '', c.durationMonths || c.duration || 1, c.totalFee || 0,
                c.monthlyFee || 0, c.admissionFee || 0, c.maxCapacity || 30, '', ''
              ])),
              ...((data.batches || []).map((b: any) => [
                'Batch', b.id || '', b.name || '', b.code || '', '', '', '', '', b.capacity || 30,
                `${b.timing || ''} (${b.days ? b.days.join(', ') : ''})`, b.mode || 'offline'
              ]))
            ],
            Educators: [
              ['Educator ID', 'Full Name', 'Qualification', 'Subject Specialization', 'Phone', 'Email', 'Monthly Salary (₹)', 'Experience (Yrs)', 'Status', 'Join Date', 'Photo URL'],
              ...((data.educators || []).map((e: any) => [
                e.id || '', e.name || '', e.qualification || '', e.subject || '', e.phone || '', e.email || '',
                e.monthlySalary || 0, e.experienceYears || 0, e.status || 'active', e.joiningDate || e.joinDate || '', e.photoUrl || ''
              ]))
            ],
            Expenses: [
              ['Expense ID', 'Category', 'Title / Description', 'Amount (₹)', 'Date', 'Paid To', 'Payment Mode', 'Receipt Ref', 'Notes'],
              ...((data.expenses || []).map((x: any) => [
                x.id || '', x.category || '', x.title || '', x.amount || 0, x.date || '', x.paidTo || '',
                x.paymentMode || 'UPI', x.receiptNo || '', x.notes || ''
              ]))
            ],
            Admin_Credentials: [
              ['Admin ID', 'Username', 'Full Name', 'Role', 'Official Email', 'Passcode / Password', 'Security PIN', 'Account Status', 'Last Login', 'Last Updated'],
              ...((data.adminAccounts && data.adminAccounts.length > 0 ? data.adminAccounts : [{
                id: 'ADM-001', username: 'admin', password: '••••••••', name: 'Director', role: 'Master Admin', email: data.centerInfo.email || '', phone: data.centerInfo.phonePrimary, securityPin: '7722', status: 'active', lastLogin: '', updatedAt: ''
              }]).map((adm: any) => [
                adm.id || '', adm.username || '', adm.name || '', adm.role || '', adm.email || '', adm.password || '',
                adm.securityPin || '', adm.status || 'active', adm.lastLogin || '', adm.updatedAt || ''
              ]))
            ],
            Center_Overview: [
              ['Parameter / Property', 'Current Center Value'],
              ['Institute Name', data.centerInfo?.name || 'Pixel Pathsala'],
              ['Tagline / Motto', data.centerInfo?.tagline || ''],
              ['Campus Address', data.centerInfo?.address || ''],
              ['City & State', data.centerInfo?.cityState || ''],
              ['Primary Helpline Phone', data.centerInfo?.phonePrimary || ''],
              ['Office Desk Phone (Alternate)', data.centerInfo?.phoneSecondary || ''],
              ['Official WhatsApp Number', data.centerInfo?.whatsapp || ''],
              ['Official Email', data.centerInfo?.email || ''],
              ['Facebook Page URL', data.centerInfo?.facebookUrl || ''],
              ['YouTube Channel URL', data.centerInfo?.youtubeUrl || ''],
              ['UPI ID for Fees', data.centerInfo?.upiId || ''],
              ['UPI Payee Name', data.centerInfo?.upiName || ''],
              ['Registration Number', data.centerInfo?.regNumber || ''],
              ['Established Year', String(data.centerInfo?.establishedYear || '2021')],
              ['Admissions Status', data.centerInfo?.admissionOpen !== false ? 'Open' : 'Closed'],
              ['Announcement Notice Banner', data.centerInfo?.announcement || ''],
              ['Homepage Welcome Overview', data.centerInfo?.welcomeMessage || ''],
              ['Google Sheet Webhook URL', data.centerInfo?.googleSheetWebhookUrl || ''],
              ['Google Sheet Database ID', data.centerInfo?.googleSheetId || ''],
              ['Active Students Count', (data.students || []).filter(s => s.status === 'active').length],
              ['Total Enrolled Students', (data.students || []).length],
              ['Total Admissions Count', (data.admissions || []).length],
              ['Total Courses Count', (data.courses || []).length],
              ['Total Batches Count', (data.batches || []).length],
              ['Total Educators Count', (data.educators || []).length],
              ['Total Fee Collections Count', (data.payments || []).length],
              ['Total Fees Collected (₹)', (data.payments || []).reduce((acc, p) => acc + (p.finalAmountPaid || 0), 0)],
              ['Total Expenses (₹)', (data.expenses || []).reduce((acc, x) => acc + (x.amount || 0), 0)],
              ['Last Cloud Push / Sync', new Date().toISOString()]
            ],
            Study_Materials: [
              ['Material ID', 'Title', 'Subject', 'Course ID', 'Batch ID', 'File Type', 'File Name', 'File Size', 'File URL / Link', 'Uploaded By', 'Uploaded Date', 'Download Count', 'Description'],
              ...((data.studyMaterials || []).map(m => [
                m.id || '', m.title || '', m.subject || '', m.courseId || 'all', m.batchId || 'all', m.fileType || 'pdf',
                m.fileName || '', m.fileSize || '', m.fileUrl || '', m.uploadedBy || 'Faculty', m.uploadedDate || '', m.downloadCount || 0, m.description || ''
              ]))
            ],
            Question_Bank: [
              ['Question ID', 'Course ID', 'Academic Class', 'Subject', 'Topic', 'Marks', 'Difficulty', 'Question Text', 'Option A', 'Option B', 'Option C', 'Option D', 'Correct Option Index', 'Code Snippet', 'Explanation', 'Created At'],
              ...((data.questions || []).map(q => [
                q.id || '', q.courseId || 'all', q.academicClass || '', q.subject || '', q.topic || '', q.marks || 1, q.difficulty || 'medium',
                q.questionText || '', (q.options && q.options[0]) || '', (q.options && q.options[1]) || '', (q.options && q.options[2]) || '',
                (q.options && q.options[3]) || '', q.correctOptionIndex ?? 0, q.codeSnippet || '', q.explanation || '', q.createdAt || ''
              ]))
            ],
            Exams: [
              ['Exam ID', 'Exam Code', 'Title', 'Course ID', 'Batch ID', 'Academic Class', 'Subject', 'Duration (Mins)', 'Total Marks', 'Passing Marks', 'Passing %', 'Status', 'Mode', 'Scheduled Date', 'Start Time', 'End Time', 'Question Count', 'Question IDs', 'Instructions', 'Published', 'Created At'],
              ...((data.exams || []).map(x => [
                x.id || '', x.examCode || '', x.title || '', x.courseId || 'all', x.batchId || 'all', x.academicClass || '', x.subject || '',
                x.durationMinutes || 45, x.totalMarks || 25, x.passingMarks || 10, x.passingPercentage || 40, x.status || 'scheduled', x.mode || 'online',
                x.scheduledDate || '', x.startTime || '', x.endTime || '', (x.questionIds || []).length, (x.questionIds || []).join(', '),
                x.instructions || '', x.isPublished ? 'Yes' : 'No', x.createdAt || ''
              ]))
            ],
            Exam_Submissions: [
              ['Submission ID', 'Exam ID', 'Exam Title', 'Student ID', 'Student Name', 'Roll No', 'Aadhaar No', 'Course ID', 'Batch ID', 'Score Obtained', 'Total Marks', 'Percentage (%)', 'Result Status', 'Time Spent (Secs)', 'Submitted At', 'Answers Summary'],
              ...((data.examSubmissions || []).map(sub => [
                sub.id || '', sub.examId || '', sub.examTitle || '', sub.studentId || '', sub.studentName || '', sub.studentRollNo || '',
                sub.studentAadhaar || '', sub.courseId || '', sub.batchId || '', sub.score || 0, sub.totalMarks || 25, sub.percentage || 0,
                sub.passed ? 'PASSED' : 'NEEDS IMPROVEMENT', sub.timeSpentSeconds || 0, sub.submittedAt || '', JSON.stringify(sub.answers || {})
              ]))
            ],
            Live_Classes: [
              ['Session ID', 'Class Title', 'Subject', 'Course ID', 'Batch ID', 'Educator Name', 'Scheduled Date', 'Start Time', 'End Time', 'Status', 'Platform', 'Meeting Link / Room ID', 'Recording Available', 'Created At'],
              ...((data.liveClasses || []).map(lc => [
                lc.id || '', lc.title || '', lc.subject || '', lc.courseId || 'all', lc.batchId || 'all', lc.educatorName || 'Faculty',
                lc.scheduledDate || '', lc.startTime || '', lc.endTime || '', lc.status || 'scheduled', lc.platform || 'in_app',
                lc.meetingUrl || lc.inAppRoomId || '', lc.isRecordingAvailable ? 'Yes' : 'No', lc.createdAt || ''
              ]))
            ],
            Class_Recordings: [
              ['Recording ID', 'Title', 'Subject', 'Topic', 'Chapter', 'Course ID', 'Batch ID', 'Educator Name', 'Recorded Date', 'Duration (Mins)', 'Source Type', 'Video URL', 'Notes PDF URL', 'View Count', 'Created At'],
              ...((data.classRecordings || []).map(rec => [
                rec.id || '', rec.title || '', rec.subject || '', rec.topic || '', rec.chapter || '', rec.courseId || 'all', rec.batchId || 'all',
                rec.educatorName || 'Faculty', rec.recordedDate || '', rec.durationMinutes || 60, rec.videoSourceType || 'youtube',
                rec.videoUrl || '', rec.notesPdfUrl || '', rec.viewCount || 0, rec.createdAt || ''
              ]))
            ]
          };

          const wbRes = await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'syncAll',
              timestamp: new Date().toISOString(),
              tables: tablesPayload,
              ...data
            }),
            redirect: 'follow'
          });

          const wbText = await wbRes.text();
          console.log('Webhook push result:', wbText);
          const totalRecords = (data.students?.length || 0) + (data.admissions?.length || 0) + (data.payments?.length || 0) + (data.studyMaterials?.length || 0) + (data.exams?.length || 0) + (data.liveClasses?.length || 0) + (data.classRecordings?.length || 0);
          return {
            success: true,
            message: `Successfully pushed all database tables (${totalRecords} records) to Google Sheets via Webhook!`,
            spreadsheetId: cleanId,
            spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${cleanId}/edit`,
            recordsCount: totalRecords
          };
        } catch (wbErr: any) {
          console.warn('Direct webhook push failed:', wbErr);
        }
      }

      // Automatically request OAuth token popup if not signed in and no webhook
      const authRes = await this.requestOAuthToken();
      if (!authRes.success || !this.getAccessToken()) {
        return {
          success: false,
          message: 'Google Sign-In Required: Google Sheets REST API requires Google Account authorization to write data (even for "Anyone with the link can edit" sheets). Please click "Sign In with Google" or use the Apps Script Webhook URL.'
        };
      }
    }

    try {
      // 1. Check existing sheets
      const existingInfo = await this.testSpreadsheetAccess(cleanId);
      const existingSheetTitles = new Set(existingInfo.sheets);

      // Required sheets (all 15 tables)
      const requiredSheets = [
        'Students',
        'Admissions',
        'Fee_Transactions',
        'Courses_Batches',
        'Educators',
        'Expenses',
        'Admin_Credentials',
        'Center_Overview',
        'Study_Materials',
        'Question_Bank',
        'Exams',
        'Exam_Submissions',
        'Live_Classes',
        'Class_Recordings',
        'Discounts'
      ];

      // Add missing sheets if needed
      const sheetsToAdd = requiredSheets.filter(title => !existingSheetTitles.has(title));
      if (sheetsToAdd.length > 0) {
        const addRequests = sheetsToAdd.map(title => ({
          addSheet: { properties: { title } }
        }));
        await this.fetchSheetsApi(`/${cleanId}:batchUpdate`, {
          method: 'POST',
          body: JSON.stringify({ requests: addRequests })
        });
      }

      // 2. Prepare tabular data rows for each sheet
      const nowFormatted = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

      // Table 1: Students
      const studentsHeader = [
        'Student ID', 'Roll No', 'Full Name', 'Mobile', 'Aadhaar No', 'Email',
        'Guardian Name', 'Guardian Phone', 'Address', 'Course Title', 'Batch Timing',
        'Admission Date', 'Status', 'Monthly Fee (₹)', 'Total Paid (₹)', 'Total Due (₹)',
        'Last Synced'
      ];
      const studentsRows = data.students.map(s => {
        const course = data.courses.find(c => c.id === s.courseId);
        const batch = data.batches.find(b => b.id === s.batchId);
        const billing = getStudentMonthlyBilling(s, course, data.discounts, data.payments);
        return [
          s.id,
          s.rollNo,
          s.name,
          s.mobile,
          s.aadhaarNo,
          s.email || '',
          s.guardianName,
          s.guardianPhone,
          s.address,
          course ? course.title : s.courseId,
          batch ? `${batch.name} (${batch.timing})` : (s.batchId || ''),
          s.admissionDate,
          s.status,
          s.customMonthlyFeeOverride ?? (course?.monthlyFee || 0),
          billing.totalPaid || 0,
          billing.totalDueAmount || 0,
          nowFormatted
        ];
      });

      // Table 2: Admissions
      const admissionsHeader = [
        'Application No', 'Student Name', 'Mobile', 'Aadhaar No', 'Email',
        'Guardian Name', 'Guardian Phone', 'Target Course', 'Status',
        'Applied Date', 'Initial Payment Status', 'Payment Mode', 'Transaction Ref',
        'Remarks', 'Rejection Reason'
      ];
      const admissionsRows = data.admissions.map(a => {
        const course = data.courses.find(c => c.id === a.targetCourseId);
        return [
          a.applicationNo,
          a.studentName,
          a.mobile,
          a.aadhaarNo,
          a.email || '',
          a.guardianName,
          a.guardianPhone,
          course ? course.title : a.targetCourseId,
          a.status,
          a.appliedDate,
          a.initialPaymentStatus,
          a.initialPaymentMode || '',
          a.initialPaymentRef || '',
          a.remarks || '',
          a.rejectionReason || ''
        ];
      });

      // Table 3: Fee Transactions
      const paymentsHeader = [
        'Receipt No', 'Payment ID', 'Student ID', 'Student Name', 'Amount Paid (₹)',
        'Payment Mode', 'Fee Months Covered', 'Transaction / UPI Ref', 'Date of Payment',
        'Status', 'Approved By', 'Remarks'
      ];
      const paymentsRows = data.payments.map(p => {
        const student = data.students.find(s => 
          s.id === p.studentId || 
          (s.rollNo && s.rollNo === p.studentId) || 
          (s.aadhaarNo && s.aadhaarNo === p.studentId) ||
          (p.studentName && s.name.toLowerCase().trim() === p.studentName.toLowerCase().trim())
        );
        return [
          p.receiptNo || '',
          p.id,
          p.studentId,
          p.studentName || student?.name || student?.rollNo || 'Student',
          p.finalAmountPaid,
          p.paymentMode,
          (Array.isArray(p.monthsCovered) ? p.monthsCovered : [p.month]).filter(Boolean).join(', '),
          p.transactionRef || '',
          p.paymentDate,
          p.status || 'approved',
          p.status === 'approved' ? (p.approvedBy || 'Admin') : '',
          p.rejectionReason || p.remarks || ''
        ];
      });

      // Table 4: Courses & Batches
      const coursesBatchesHeader = [
        'Record Type', 'ID', 'Title / Batch Name', 'Code / Course ID', 'Class / Time Slot',
        'Category / Days', 'Monthly Fee / Capacity', 'Assigned Educator / Popular', 'Description / Room', 'Batch Mode / Delivery Mode'
      ];
      const coursesRows = data.courses.map(c => [
        'COURSE',
        c.id,
        c.title,
        c.code,
        c.academicClass,
        c.category,
        c.monthlyFee,
        c.isPopular ? 'Popular' : '',
        c.description,
        'Offline & Online (Classroom & Live)'
      ]);
      const batchesRows = data.batches.map(b => {
        const educator = data.educators.find(e => e.id === b.educatorId);
        return [
          'BATCH',
          b.id,
          b.name,
          b.courseId,
          b.timing,
          (b.scheduleDays || []).join(', '),
          `Max ${b.maxCapacity}`,
          educator ? educator.name : (b.educatorId || ''),
          `Room ${b.roomNumber} - ${b.isActive ? 'Active' : 'Inactive'}`,
          b.mode === 'online' ? 'Online (Live)' : 'Offline (Classroom)'
        ];
      });

      // Table 5: Educators
      const educatorsHeader = [
        'Educator ID', 'Full Name', 'Qualification', 'Subject Specialization',
        'Phone', 'Email', 'Monthly Salary (₹)', 'Experience (Yrs)', 'Status', 'Join Date', 'Photo URL'
      ];
      const educatorsRows = data.educators.map(e => [
        e.id,
        e.name,
        e.qualification,
        e.subject,
        e.phone,
        e.email || '',
        e.monthlySalary,
        e.experienceYears,
        e.status,
        e.joiningDate || e.joinDate || '',
        e.photoUrl || ''
      ]);

      // Table 6: Expenses
      const expensesHeader = [
        'Expense ID', 'Category', 'Title / Description', 'Amount (₹)', 'Date',
        'Paid To', 'Payment Mode', 'Receipt Ref', 'Notes'
      ];
      const expensesRows = data.expenses.map(x => [
        x.id,
        x.category,
        x.title,
        x.amount,
        x.date,
        x.paidTo,
        x.paymentMode,
        x.receiptNo || '',
        x.notes || ''
      ]);

      // Table 7: Admin Credentials
      const adminCredsHeader = [
        'Admin ID', 'Username', 'Full Name', 'Role', 'Official Email', 'Passcode / Password',
        'Security PIN', 'Account Status', 'Last Login', 'Last Updated'
      ];
      const defaultAdminList: AdminAccount[] = data.adminAccounts && data.adminAccounts.length > 0 
        ? data.adminAccounts 
        : [
            {
              id: 'ADM-001',
              username: 'admin',
              password: '•••••••• (Protected)',
              name: 'Director / Center Administrator',
              role: 'Master Administrator',
              email: data.centerInfo.email || 'admin@pixelpathsala.com',
              phone: data.centerInfo.phonePrimary,
              securityPin: '7722',
              status: 'active',
              lastLogin: nowFormatted,
              updatedAt: nowFormatted
            }
          ];

      const adminRows = defaultAdminList.map(a => [
        a.id,
        a.username,
        a.name,
        a.role,
        a.email,
        a.password,
        a.securityPin || '7722',
        a.status,
        a.lastLogin || nowFormatted,
        a.updatedAt || nowFormatted
      ]);

      // Table 8: Center Overview
      const totalCollections = data.payments.filter(p => p.status === 'approved').reduce((sum, p) => sum + p.finalAmountPaid, 0);
      const totalPendingDue = data.students.reduce((sum, s) => {
        const c = data.courses.find(crs => crs.id === s.courseId);
        const b = getStudentMonthlyBilling(s, c, data.discounts, data.payments);
        return sum + (b.totalDueAmount || 0);
      }, 0);

      const overviewRows = [
        ['Parameter / Property', 'Current Center Value'],
        ['Institute Name', data.centerInfo?.name || 'Pixel Pathsala'],
        ['Tagline / Motto', data.centerInfo?.tagline || ''],
        ['Campus Address', data.centerInfo?.address || ''],
        ['City & State', data.centerInfo?.cityState || ''],
        ['Primary Helpline Phone', data.centerInfo?.phonePrimary || ''],
        ['Office Desk Phone (Alternate)', data.centerInfo?.phoneSecondary || ''],
        ['Official WhatsApp Number', data.centerInfo?.whatsapp || ''],
        ['Official Email', data.centerInfo?.email || ''],
        ['Facebook Page URL', data.centerInfo?.facebookUrl || ''],
        ['YouTube Channel URL', data.centerInfo?.youtubeUrl || ''],
        ['UPI ID for Fees', data.centerInfo?.upiId || ''],
        ['UPI Payee Name', data.centerInfo?.upiName || ''],
        ['Registration Number', data.centerInfo?.regNumber || ''],
        ['Established Year', String(data.centerInfo?.establishedYear || '2021')],
        ['Admissions Status', data.centerInfo?.admissionOpen !== false ? 'Open' : 'Closed'],
        ['Announcement Notice Banner', data.centerInfo?.announcement || ''],
        ['Homepage Welcome Overview', data.centerInfo?.welcomeMessage || ''],
        ['Google Sheet Webhook URL', data.centerInfo?.googleSheetWebhookUrl || ''],
        ['Google Sheet Database ID', data.centerInfo?.googleSheetId || ''],
        ['Active Students Count', data.students.filter(s => s.status === 'active').length],
        ['Total Enrolled Students', data.students.length],
        ['Total Admissions Count', (data.admissions || []).length],
        ['Total Courses Count', (data.courses || []).length],
        ['Total Batches Count', (data.batches || []).length],
        ['Total Educators Count', (data.educators || []).length],
        ['Total Fee Collections Count', (data.payments || []).length],
        ['Total Fees Collected (₹)', totalCollections],
        ['Total Pending Due (₹)', totalPendingDue],
        ['Total Expenses (₹)', (data.expenses || []).reduce((acc, x) => acc + (x.amount || 0), 0)],
        ['Last Cloud Sync Time', nowFormatted]
      ];

      // Table 9: Study Materials
      const studyMaterialsHeader = [
        'Material ID', 'Title', 'Subject', 'Course ID', 'Batch ID', 'File Type',
        'File Name', 'File Size', 'File URL / Link', 'Uploaded By', 'Uploaded Date', 'Download Count', 'Description'
      ];
      const studyMaterialsRows = (data.studyMaterials || []).map(m => [
        m.id,
        m.title,
        m.subject,
        m.courseId || 'all',
        m.batchId || 'all',
        m.fileType,
        m.fileName,
        m.fileSize,
        m.fileUrl,
        m.uploadedBy || 'Faculty',
        m.uploadedDate,
        m.downloadCount || 0,
        m.description || ''
      ]);

      // Table 10: Question Bank
      const questionsHeader = [
        'Question ID', 'Course ID', 'Academic Class', 'Subject', 'Topic', 'Marks',
        'Difficulty', 'Question Text', 'Option A', 'Option B', 'Option C', 'Option D',
        'Correct Option Index', 'Code Snippet', 'Explanation', 'Created At'
      ];
      const questionsRows = (data.questions || []).map(q => [
        q.id,
        q.courseId || 'all',
        q.academicClass || '',
        q.subject,
        q.topic,
        q.marks,
        q.difficulty,
        q.questionText,
        (q.options && q.options[0]) || '',
        (q.options && q.options[1]) || '',
        (q.options && q.options[2]) || '',
        (q.options && q.options[3]) || '',
        q.correctOptionIndex,
        q.codeSnippet || '',
        q.explanation || '',
        q.createdAt
      ]);

      // Table 11: Exams
      const examsHeader = [
        'Exam ID', 'Exam Code', 'Title', 'Course ID', 'Batch ID', 'Academic Class',
        'Subject', 'Duration (Mins)', 'Total Marks', 'Passing Marks', 'Passing %',
        'Status', 'Mode', 'Scheduled Date', 'Start Time', 'End Time', 'Question Count', 'Question IDs', 'Instructions', 'Published', 'Created At'
      ];
      const examsRows = (data.exams || []).map(x => [
        x.id,
        x.examCode,
        x.title,
        x.courseId,
        x.batchId,
        x.academicClass || '',
        x.subject,
        x.durationMinutes,
        x.totalMarks,
        x.passingMarks,
        x.passingPercentage,
        x.status,
        x.mode,
        x.scheduledDate,
        x.startTime,
        x.endTime,
        (x.questionIds || []).length,
        (x.questionIds || []).join(', '),
        x.instructions || '',
        x.isPublished ? 'Yes' : 'No',
        x.createdAt
      ]);

      // Table 12: Exam Submissions
      const submissionsHeader = [
        'Submission ID', 'Exam ID', 'Exam Title', 'Student ID', 'Student Name',
        'Roll No', 'Aadhaar No', 'Course ID', 'Batch ID', 'Score Obtained',
        'Total Marks', 'Percentage (%)', 'Result Status', 'Time Spent (Secs)', 'Submitted At', 'Answers Summary'
      ];
      const submissionsRows = (data.examSubmissions || []).map(sub => [
        sub.id,
        sub.examId,
        sub.examTitle,
        sub.studentId,
        sub.studentName,
        sub.studentRollNo,
        sub.studentAadhaar,
        sub.courseId,
        sub.batchId,
        sub.score,
        sub.totalMarks,
        sub.percentage,
        sub.passed ? 'PASSED' : 'NEEDS IMPROVEMENT',
        sub.timeSpentSeconds,
        sub.submittedAt,
        JSON.stringify(sub.answers || {})
      ]);

      // Table 13: Live Classes
      const liveClassesHeader = [
        'Session ID', 'Class Title', 'Academic Class', 'Subject', 'Course ID', 'Batch ID', 'Educator Name',
        'Scheduled Date', 'Start Time', 'End Time', 'Status', 'Platform', 'Meeting Link / Room ID',
        'Recording Available', 'Created At'
      ];
      const liveClassesRows = (data.liveClasses || []).map(lc => [
        lc.id,
        lc.title,
        lc.academicClass || lc.targetClass || 'All Classes',
        lc.subject || 'General',
        lc.courseId || 'all',
        lc.batchId || 'all',
        lc.educatorName || 'Faculty',
        lc.scheduledDate,
        lc.startTime,
        lc.endTime,
        lc.status,
        lc.platform,
        lc.meetingUrl || lc.inAppRoomId || '',
        lc.isRecordingAvailable ? 'Yes' : 'No',
        lc.createdAt
      ]);

      // Table 14: Class Recordings
      const recordingsHeader = [
        'Recording ID', 'Title', 'Academic Class', 'Subject', 'Topic', 'Chapter', 'Course ID', 'Batch ID',
        'Educator Name', 'Recorded Date', 'Duration (Mins)', 'Source Type', 'Video URL',
        'Notes PDF URL', 'View Count', 'Created At'
      ];
      const recordingsRows = (data.classRecordings || []).map(rec => [
        rec.id,
        rec.title,
        rec.academicClass || rec.targetClass || 'All Classes',
        rec.subject || 'General',
        rec.topic || '',
        rec.chapter || '',
        rec.courseId || 'all',
        rec.batchId || 'all',
        rec.educatorName || 'Faculty',
        rec.recordedDate,
        rec.durationMinutes,
        rec.videoSourceType,
        rec.videoUrl,
        rec.notesPdfUrl || '',
        rec.viewCount || 0,
        rec.createdAt
      ]);

      // Table 15: Discounts
      const discountsHeader = [
        'Discount ID', 'Discount Title', 'Discount Type (flat/percentage)', 'Value (₹ / %)',
        'Scope (all/class/course/batch/student)', 'Target Academic Class', 'Target Course ID',
        'Target Batch ID', 'Target Student ID', 'Applicable Months Type', 'Selected Months',
        'Reason / Description', 'Active Status', 'Created At'
      ];
      const discountsRows = (data.discounts || []).map(d => [
        d.id || `disc-${Date.now()}`,
        d.title || 'Concession Offer',
        d.type || 'flat',
        d.value || 0,
        d.scope || 'all',
        d.academicClass || '',
        d.courseId || '',
        d.batchId || '',
        d.studentId || '',
        d.applicableMonthsType || 'all_months',
        Array.isArray(d.selectedMonths) ? d.selectedMonths.join(', ') : '',
        d.reason || '',
        d.active !== false ? 'Active' : 'Disabled',
        d.createdAt || new Date().toISOString().split('T')[0]
      ]);

      // 3. Clear existing contents and write updated values in bulk
      const updateData = [
        {
          range: 'Students!A1:Q500',
          values: [studentsHeader, ...studentsRows]
        },
        {
          range: 'Admissions!A1:P500',
          values: [admissionsHeader, ...admissionsRows]
        },
        {
          range: 'Fee_Transactions!A1:L500',
          values: [paymentsHeader, ...paymentsRows]
        },
        {
          range: 'Courses_Batches!A1:J500',
          values: [coursesBatchesHeader, ...coursesRows, ...batchesRows]
        },
        {
          range: 'Educators!A1:K500',
          values: [educatorsHeader, ...educatorsRows]
        },
        {
          range: 'Expenses!A1:I500',
          values: [expensesHeader, ...expensesRows]
        },
        {
          range: 'Admin_Credentials!A1:J100',
          values: [adminCredsHeader, ...adminRows]
        },
        {
          range: 'Center_Overview!A1:B50',
          values: overviewRows
        },
        {
          range: 'Study_Materials!A1:M500',
          values: [studyMaterialsHeader, ...studyMaterialsRows]
        },
        {
          range: 'Question_Bank!A1:P500',
          values: [questionsHeader, ...questionsRows]
        },
        {
          range: 'Exams!A1:U500',
          values: [examsHeader, ...examsRows]
        },
        {
          range: 'Exam_Submissions!A1:P500',
          values: [submissionsHeader, ...submissionsRows]
        },
        {
          range: 'Live_Classes!A1:O500',
          values: [liveClassesHeader, ...liveClassesRows]
        },
        {
          range: 'Class_Recordings!A1:P500',
          values: [recordingsHeader, ...recordingsRows]
        },
        {
          range: 'Discounts!A1:N500',
          values: [discountsHeader, ...discountsRows]
        }
      ];

      // Clear previous ranges first to avoid stale trailing records
      await Promise.all([
        this.fetchSheetsApi(`/${cleanId}/values/Students!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Admissions!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Fee_Transactions!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Courses_Batches!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Educators!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Expenses!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Admin_Credentials!A1:Z100:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Center_Overview!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Study_Materials!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Question_Bank!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Exams!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Exam_Submissions!A1:Z1000:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Live_Classes!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Class_Recordings!A1:Z500:clear`, { method: 'POST' }).catch(() => {}),
        this.fetchSheetsApi(`/${cleanId}/values/Discounts!A1:Z500:clear`, { method: 'POST' }).catch(() => {})
      ]);

      // Batch update the new structured matrix
      await this.fetchSheetsApi(`/${cleanId}/values:batchUpdate`, {
        method: 'POST',
        body: JSON.stringify({
          valueInputOption: 'USER_ENTERED',
          data: updateData
        })
      });

      const totalRecords = 
        studentsRows.length + 
        admissionsRows.length + 
        paymentsRows.length + 
        coursesRows.length + 
        batchesRows.length + 
        educatorsRows.length + 
        expensesRows.length + 
        adminRows.length +
        studyMaterialsRows.length +
        questionsRows.length +
        examsRows.length +
        submissionsRows.length +
        liveClassesRows.length +
        recordingsRows.length +
        discountsRows.length;

      return {
        success: true,
        message: `Successfully synchronized ${totalRecords} ERP database records across all 15 sheets to Google Sheets!`,
        spreadsheetId: cleanId,
        spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${cleanId}/edit`,
        updatedSheets: requiredSheets,
        recordsCount: totalRecords,
        timestamp: nowFormatted
      };
    } catch (err: any) {
      console.error('Error syncing to Google Sheet:', err);
      return {
        success: false,
        message: err.message || 'Failed to update Google Sheet.'
      };
    }
  }

  /**
   * Comprehensive Two-Way Data Pull: Fetches all 12 sheets and parses them back into typed ERP state
   */
  public async pullAllFromGoogleSheet(spreadsheetId: string): Promise<{
    success: boolean;
    message: string;
    parsedData?: {
      students?: Student[];
      admissions?: AdmissionApplication[];
      payments?: FeePayment[];
      courses?: Course[];
      batches?: Batch[];
      educators?: Educator[];
      expenses?: Expense[];
      adminAccounts?: AdminAccount[];
      centerInfo?: Partial<CenterInfo>;
      studyMaterials?: StudyMaterial[];
      questions?: QuestionBankItem[];
      exams?: OnlineExam[];
      examSubmissions?: ExamSubmission[];
      liveClasses?: LiveClassSession[];
      classRecordings?: ClassRecording[];
    };
    counts?: {
      students: number;
      admissions: number;
      payments: number;
      courses: number;
      batches: number;
      educators: number;
      expenses: number;
      adminAccounts: number;
      studyMaterials: number;
      questions: number;
      exams: number;
      examSubmissions: number;
      liveClasses: number;
      classRecordings: number;
    };
    error?: string;
  }> {
    const cleanId = this.extractSpreadsheetId(spreadsheetId);
    if (!cleanId) return { success: false, message: 'Invalid Google Sheet ID.' };

    try {
      const ranges = [
        'Students!A2:Q500',
        'Admissions!A2:P500',
        'Fee_Transactions!A2:L500',
        'Courses_Batches!A2:J500',
        'Educators!A2:K500',
        'Expenses!A2:I500',
        'Admin_Credentials!A2:J100',
        'Center_Overview!A1:B50',
        'Study_Materials!A2:M500',
        'Question_Bank!A2:P500',
        'Exams!A2:U500',
        'Exam_Submissions!A2:P1000',
        'Live_Classes!A2:O500',
        'Class_Recordings!A2:P500'
      ];
      const rangeParam = ranges.map(r => `ranges=${encodeURIComponent(r)}`).join('&');
      const res = await this.fetchSheetsApi(`/${cleanId}/values:batchGet?${rangeParam}`);
      
      const valueRanges = res.valueRanges || [];
      const getValues = (index: number) => valueRanges[index]?.values || [];

      const studentsRows: any[][] = getValues(0);
      const admissionsRows: any[][] = getValues(1);
      const paymentsRows: any[][] = getValues(2);
      const coursesBatchesRows: any[][] = getValues(3);
      const educatorsRows: any[][] = getValues(4);
      const expensesRows: any[][] = getValues(5);
      const adminRows: any[][] = getValues(6);
      const overviewRows: any[][] = getValues(7);
      const studyMaterialsRows: any[][] = getValues(8);
      const questionsRows: any[][] = getValues(9);
      const examsRows: any[][] = getValues(10);
      const examSubmissionsRows: any[][] = getValues(11);
      const liveClassesRows: any[][] = getValues(12);
      const classRecordingsRows: any[][] = getValues(13);

      // Parse Courses and Batches
      const parsedCourses: Course[] = [];
      const parsedBatches: Batch[] = [];

      for (const row of coursesBatchesRows) {
        if (!row || row.length < 2) continue;
        const type = String(row[0] || '').toUpperCase();
        if (type === 'COURSE') {
          parsedCourses.push({
            id: String(row[1] || `CRS-${Date.now()}`),
            title: String(row[2] || 'Untitled Course'),
            code: String(row[3] || 'CRS'),
            academicClass: String(row[4] || 'Class 9-10'),
            category: (row[5] as any) || 'Foundation',
            monthlyFee: Number(row[6]) || 1200,
            isPopular: String(row[7] || '').toLowerCase().includes('popular'),
            description: String(row[8] || ''),
            syllabusPoints: ['Comprehensive Curriculum', 'Formula Bank', 'Chapter Tests'],
            highlights: ['Smart Classrooms', 'Live Doubt Clearing', 'Doubt Sessions'],
            showOnWebsite: true
          });
        } else if (type === 'BATCH') {
          const rawMode = String(row[9] || '').toLowerCase().trim();
          const rawRoomOrName = String(row[8] || '').toLowerCase() + ' ' + String(row[2] || '').toLowerCase();
          const mode: 'offline' | 'online' = (rawMode.includes('online') || rawMode.includes('live')) 
            ? 'online' 
            : (rawMode.includes('offline') || rawMode.includes('classroom'))
            ? 'offline'
            : (rawRoomOrName.includes('online') || rawRoomOrName.includes('live'))
            ? 'online'
            : 'offline';

          parsedBatches.push({
            id: String(row[1] || `BAT-${Date.now()}`),
            name: String(row[2] || 'Batch'),
            courseId: String(row[3] || ''),
            timing: String(row[4] || '5:00 PM - 6:30 PM'),
            scheduleDays: row[5] ? String(row[5]).split(',').map(s => s.trim()) : ['Mon', 'Wed', 'Fri'],
            maxCapacity: parseInt(String(row[6]).replace(/\D/g, '')) || 30,
            educatorId: String(row[7] || ''),
            roomNumber: String(row[8] || 'Room 101'),
            isActive: !String(row[8] || '').includes('Inactive'),
            mode,
            startDate: '2026-04-01'
          });
        }
      }

      // Parse Students
      const parsedStudents: Student[] = [];
      for (const row of studentsRows) {
        if (!row || !row[0] || !row[2]) continue; // Needs ID and Name
        const rawStatus = String(row[12] || '').toLowerCase();
        const studentStatus: StudentStatus = rawStatus === 'passed_out' || rawStatus === 'completed' 
          ? 'passed_out' 
          : rawStatus === 'dropped' || rawStatus === 'inactive' 
          ? 'dropped' 
          : 'active';

        parsedStudents.push({
          id: String(row[0]),
          rollNo: String(row[1] || ''),
          name: String(row[2]),
          mobile: String(row[3] || ''),
          aadhaarNo: String(row[4] || ''),
          email: String(row[5] || ''),
          guardianName: String(row[6] || 'Parent/Guardian'),
          guardianPhone: String(row[7] || ''),
          address: String(row[8] || ''),
          courseId: String(row[9] || 'CRS-001'),
          batchId: String(row[10] || 'BAT-001'),
          admissionDate: String(row[11] || new Date().toISOString().split('T')[0]),
          admissionMonth: String(row[11] || '2026-04').substring(0, 7),
          status: studentStatus,
          customMonthlyFeeOverride: row[13] ? Number(row[13]) : undefined
        });
      }

      // Parse Admissions
      const parsedAdmissions: AdmissionApplication[] = [];
      for (const row of admissionsRows) {
        if (!row || !row[0] || !row[1]) continue;
        const rawPaymentMode = String(row[11] || 'UPI').toUpperCase();
        const paymentMode: PaymentMode = (['UPI', 'CASH', 'ONLINE_GATEWAY', 'BANK_TRANSFER'].includes(rawPaymentMode))
          ? (rawPaymentMode as PaymentMode)
          : 'UPI';

        parsedAdmissions.push({
          id: String(row[0]),
          applicationNo: String(row[0]),
          studentName: String(row[1]),
          mobile: String(row[2] || ''),
          aadhaarNo: String(row[3] || ''),
          email: String(row[4] || ''),
          guardianName: String(row[5] || ''),
          guardianPhone: String(row[6] || ''),
          address: String(row[15] || 'Patna, Bihar'),
          targetCourseId: String(row[7] || 'CRS-001'),
          status: (row[8] as any) || 'pending',
          appliedDate: String(row[9] || new Date().toISOString().split('T')[0]),
          initialPaymentStatus: (row[10] === 'unpaid' ? 'unpaid' : row[10] === 'at_center' ? 'at_center' : 'paid_advance'),
          initialPaymentMode: paymentMode,
          initialPaymentRef: String(row[12] || ''),
          remarks: String(row[13] || ''),
          rejectionReason: String(row[14] || '')
        });
      }

      // Parse Fee Payments
      const parsedPayments: FeePayment[] = [];
      for (const row of paymentsRows) {
        if (!row || !row[1]) continue;
        const monthsList = row[6] ? String(row[6]).split(',').map(s => s.trim()).filter(Boolean) : [];
        const rawPaymentMode = String(row[5] || 'UPI').toUpperCase();
        const paymentMode: PaymentMode = (['UPI', 'CASH', 'ONLINE_GATEWAY', 'BANK_TRANSFER'].includes(rawPaymentMode))
          ? (rawPaymentMode as PaymentMode)
          : 'UPI';
        const feeAmount = Number(row[4]) || 0;

        parsedPayments.push({
          receiptNo: String(row[0] || `REC-${Date.now()}`),
          id: String(row[1]),
          studentId: String(row[2] || ''),
          studentName: String(row[3] || '').trim(), // preserve name from sheet column 4
          studentMobile: '',
          studentAadhaar: '',
          courseTitle: 'Tuition Program',
          batchName: 'Active Batch',
          baseMonthlyFee: feeAmount,
          finalAmountPaid: feeAmount,
          totalBaseFee: feeAmount,
          totalDiscount: 0,
          remainingDue: 0,
          paymentMode,
          monthsCovered: monthsList.length > 0 ? monthsList : ['2026-04'],
          month: monthsList[0] || 'Monthly Fee',
          transactionRef: String(row[7] || ''),
          paymentDate: String(row[8] || new Date().toISOString().split('T')[0]),
          status: (row[9] as any) || 'approved',
          approvedBy: String(row[10] || 'Admin'),
          rejectionReason: String(row[11] || ''),
          createdAt: new Date().toISOString()
        });
      }

      // Re-link payment student names & identifiers
      for (const pay of parsedPayments) {
        const matchingStudent = parsedStudents.find(s => 
          s.id === pay.studentId || 
          (s.rollNo && s.rollNo === pay.studentId) || 
          (s.aadhaarNo && s.aadhaarNo === pay.studentId) ||
          (pay.studentName && s.name.toLowerCase().trim() === pay.studentName.toLowerCase().trim())
        );
        if (matchingStudent) {
          pay.studentId = matchingStudent.id;
          if (!pay.studentName) pay.studentName = matchingStudent.name;
          pay.studentMobile = matchingStudent.mobile;
          pay.studentAadhaar = matchingStudent.aadhaarNo;
        }
      }

      // Parse Educators
      const parsedEducators: Educator[] = [];
      for (const row of educatorsRows) {
        if (!row || !row[0] || !row[1]) continue;
        parsedEducators.push({
          id: String(row[0]),
          name: String(row[1]),
          qualification: String(row[2] || 'M.Sc / B.Tech'),
          subject: String(row[3] || 'Faculty'),
          phone: String(row[4] || ''),
          email: String(row[5] || ''),
          monthlySalary: Number(row[6]) || 25000,
          assignedBatchIds: [],
          experienceYears: Number(row[7]) || 3,
          status: (row[8] as any) || 'active',
          joiningDate: String(row[9] || '2024-01-01'),
          photoUrl: String(row[10] || '')
        });
      }

      // Parse Expenses
      const parsedExpenses: Expense[] = [];
      for (const row of expensesRows) {
        if (!row || !row[0] || !row[2]) continue;
        parsedExpenses.push({
          id: String(row[0]),
          category: (row[1] as any) || 'general',
          title: String(row[2]),
          amount: Number(row[3]) || 0,
          date: String(row[4] || new Date().toISOString().split('T')[0]),
          paidTo: String(row[5] || 'Vendor'),
          paymentMode: (row[6] as any) || 'UPI',
          receiptNo: String(row[7] || ''),
          notes: String(row[8] || '')
        });
      }

      // Parse Admin Accounts
      const parsedAdminAccounts: AdminAccount[] = [];
      for (const row of adminRows) {
        if (!row || !row[0] || !row[1]) continue;
        parsedAdminAccounts.push({
          id: String(row[0]),
          username: String(row[1]),
          name: String(row[2] || 'Admin'),
          role: String(row[3] || 'Administrator'),
          email: String(row[4] || 'admin@pixelpathsala.com'),
          password: String(row[5] || 'admin123'),
          securityPin: String(row[6] || '7722'),
          status: (row[7] as any) || 'active',
          lastLogin: String(row[8] || ''),
          updatedAt: String(row[9] || '')
        });
      }

      // Parse Center Overview
      const parsedCenterInfo: Partial<CenterInfo> = {};
      for (const row of overviewRows) {
        if (!row || row.length < 2) continue;
        const key = String(row[0] || '').trim().toLowerCase();
        const val = String(row[1] || '').trim();
        if ((key.includes('center name') || key.includes('institute name')) && val) parsedCenterInfo.name = val;
        if ((key.includes('tagline') || key.includes('motto')) && val) parsedCenterInfo.tagline = val;
        if ((key.includes('campus address') || key.includes('center address') || key === 'address') && val) parsedCenterInfo.address = val;
        if ((key.includes('city') || key.includes('state')) && val) parsedCenterInfo.cityState = val;
        if ((key.includes('primary helpline') || key.includes('primary phone') || key === 'phone') && val) parsedCenterInfo.phonePrimary = val;
        if ((key.includes('alternate phone') || key.includes('office desk') || key.includes('secondary phone')) && val) parsedCenterInfo.phoneSecondary = val;
        if (key.includes('whatsapp') && val) parsedCenterInfo.whatsapp = val;
        if ((key.includes('official email') || key === 'email') && val) parsedCenterInfo.email = val;
        if (key.includes('facebook') && val) parsedCenterInfo.facebookUrl = val;
        if (key.includes('youtube') && val) parsedCenterInfo.youtubeUrl = val;
        if (key.includes('upi id') && val) parsedCenterInfo.upiId = val;
        if ((key.includes('upi name') || key.includes('payee name') || key.includes('account name')) && val) parsedCenterInfo.upiName = val;
        if ((key.includes('registration number') || key.includes('reg number')) && val) parsedCenterInfo.regNumber = val;
        if ((key.includes('established year') || key.includes('estd')) && val) parsedCenterInfo.establishedYear = val;
        if (key.includes('admission') && (key.includes('status') || key.includes('open'))) {
          parsedCenterInfo.admissionOpen = val.toLowerCase().includes('open') || val.toLowerCase().includes('yes') || val.toLowerCase().includes('true');
          (parsedCenterInfo as any).isAdmissionsOpen = parsedCenterInfo.admissionOpen;
        }
        if ((key.includes('announcement') || key.includes('notice')) && val) parsedCenterInfo.announcement = val;
        if ((key.includes('welcome') || key.includes('homepage overview')) && val) parsedCenterInfo.welcomeMessage = val;
        if ((key.includes('webhook url') || key.includes('google sheet webhook')) && val) parsedCenterInfo.googleSheetWebhookUrl = val;
        if ((key.includes('database id') || key.includes('sheet id') || key.includes('spreadsheet id')) && val) (parsedCenterInfo as any).googleSheetId = val;
      }

      // Parse Study Materials
      const parsedStudyMaterials: StudyMaterial[] = [];
      for (const row of studyMaterialsRows) {
        if (!row || !row[0] || !row[1]) continue;
        parsedStudyMaterials.push({
          id: String(row[0]),
          title: String(row[1]),
          subject: String(row[2] || 'General'),
          courseId: String(row[3] || 'all'),
          batchId: String(row[4] || 'all'),
          fileType: (row[5] as any) || 'notes',
          fileName: String(row[6] || 'Document'),
          fileSize: String(row[7] || '1.0 MB'),
          fileUrl: String(row[8] || '#'),
          uploadedBy: String(row[9] || 'Faculty'),
          uploadedDate: String(row[10] || new Date().toISOString().split('T')[0]),
          downloadCount: Number(row[11]) || 0,
          description: String(row[12] || '')
        });
      }

      // Parse Question Bank
      const parsedQuestions: QuestionBankItem[] = [];
      for (const row of questionsRows) {
        if (!row || !row[0] || !row[7]) continue; // id and questionText
        const opts = [
          String(row[8] || ''),
          String(row[9] || ''),
          String(row[10] || ''),
          String(row[11] || '')
        ].filter(Boolean);

        parsedQuestions.push({
          id: String(row[0]),
          courseId: String(row[1] || 'all'),
          academicClass: String(row[2] || ''),
          subject: String(row[3] || 'General'),
          topic: String(row[4] || 'Module'),
          marks: Number(row[5]) || 4,
          difficulty: (['easy', 'medium', 'hard'].includes(String(row[6]).toLowerCase()) ? String(row[6]).toLowerCase() : 'medium') as any,
          questionText: String(row[7]),
          options: opts.length > 0 ? opts : ['Option A', 'Option B', 'Option C', 'Option D'],
          correctOptionIndex: Number(row[12]) || 0,
          codeSnippet: String(row[13] || ''),
          explanation: String(row[14] || ''),
          createdAt: String(row[15] || new Date().toISOString())
        });
      }

      // Parse Exams
      const parsedExams: OnlineExam[] = [];
      for (const row of examsRows) {
        if (!row || !row[0] || !row[2]) continue; // id and title
        const rawQuestionIds = row[17] ? String(row[17]).split(',').map(s => s.trim()).filter(Boolean) : [];
        parsedExams.push({
          id: String(row[0]),
          examCode: String(row[1] || `EXAM-${Date.now()}`),
          title: String(row[2]),
          courseId: String(row[3] || 'all'),
          batchId: String(row[4] || 'all'),
          academicClass: String(row[5] || ''),
          subject: String(row[6] || 'General'),
          durationMinutes: Number(row[7]) || 60,
          totalMarks: Number(row[8]) || 100,
          passingMarks: Number(row[9]) || 40,
          passingPercentage: Number(row[10]) || 40,
          status: (['draft', 'scheduled', 'live', 'completed'].includes(String(row[11]).toLowerCase()) ? String(row[11]).toLowerCase() : 'scheduled') as any,
          mode: (['online', 'offline_omr', 'hybrid'].includes(String(row[12]).toLowerCase()) ? String(row[12]).toLowerCase() : 'online') as any,
          scheduledDate: String(row[13] || new Date().toISOString().split('T')[0]),
          startTime: String(row[14] || '10:00 AM'),
          endTime: String(row[15] || '11:00 AM'),
          questionIds: rawQuestionIds,
          instructions: String(row[18] || 'Read all questions carefully.'),
          isPublished: String(row[19] || '').toLowerCase() === 'yes' || String(row[19] || '').toLowerCase() === 'true',
          createdAt: String(row[20] || new Date().toISOString())
        });
      }

      // Parse Exam Submissions
      const parsedSubmissions: ExamSubmission[] = [];
      for (const row of examSubmissionsRows) {
        if (!row || !row[0] || !row[1]) continue;
        let parsedAnswers: Record<string, number> = {};
        try {
          if (row[15]) {
            parsedAnswers = JSON.parse(String(row[15]));
          }
        } catch {
          parsedAnswers = {};
        }

        parsedSubmissions.push({
          id: String(row[0]),
          examId: String(row[1]),
          examTitle: String(row[2] || 'Exam'),
          studentId: String(row[3] || ''),
          studentName: String(row[4] || 'Student'),
          studentRollNo: String(row[5] || ''),
          studentAadhaar: String(row[6] || ''),
          courseId: String(row[7] || ''),
          batchId: String(row[8] || ''),
          score: Number(row[9]) || 0,
          totalMarks: Number(row[10]) || 100,
          percentage: Number(row[11]) || 0,
          passed: String(row[12] || '').toUpperCase() === 'PASSED',
          timeSpentSeconds: Number(row[13]) || 0,
          submittedAt: String(row[14] || new Date().toISOString()),
          answers: parsedAnswers,
          questionBreakdown: []
        });
      }

      // Parse Live Classes
      const parsedLiveClasses: LiveClassSession[] = [];
      for (const row of liveClassesRows) {
        if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'session id') continue;

        let academicClass = 'All Classes';
        let subject = 'General';
        let courseId = 'all';
        let batchId = 'all';
        let educatorName = 'Faculty';
        let scheduledDate = new Date().toISOString().split('T')[0];
        let startTime = '10:00 AM';
        let endTime = '11:00 AM';
        let status = 'scheduled';
        let platform = 'in_app';
        let meetingUrl = '';
        let isRecordingAvailable = false;
        let createdAt = new Date().toISOString();

        const is15ColFormat = 
          row.length >= 15 ||
          ['scheduled', 'live', 'completed', 'cancelled'].includes(String(row[10] || '').toLowerCase().trim()) ||
          ['google_meet', 'zoom', 'youtube_live', 'in_app', 'jitsi', 'custom'].includes(String(row[11] || '').toLowerCase().trim()) ||
          (row[7] && /^\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(String(row[7]).trim())) ||
          (row[8] && /(am|pm|:\d{2})/i.test(String(row[8]).trim()));

        if (is15ColFormat) {
          academicClass = String(row[2] || 'All Classes');
          subject = String(row[3] || 'General');
          courseId = String(row[4] || 'all');
          batchId = String(row[5] || 'all');
          educatorName = String(row[6] || 'Faculty');
          scheduledDate = String(row[7] || scheduledDate);
          startTime = String(row[8] || startTime);
          endTime = String(row[9] || endTime);
          status = (['scheduled', 'live', 'completed', 'cancelled'].includes(String(row[10] || '').toLowerCase()) ? String(row[10]).toLowerCase() : 'scheduled');
          platform = (['in_app', 'google_meet', 'zoom', 'youtube_live', 'jitsi', 'custom'].includes(String(row[11] || '').toLowerCase()) ? String(row[11]).toLowerCase() : 'in_app');
          meetingUrl = String(row[12] || '');
          isRecordingAvailable = String(row[13] || '').toLowerCase() === 'yes' || String(row[13] || '').toLowerCase() === 'true';
          createdAt = String(row[14] || createdAt);
        } else {
          subject = String(row[2] || 'General');
          courseId = String(row[3] || 'all');
          batchId = String(row[4] || 'all');
          educatorName = String(row[5] || 'Faculty');
          scheduledDate = String(row[6] || scheduledDate);
          startTime = String(row[7] || startTime);
          endTime = String(row[8] || endTime);
          status = (['scheduled', 'live', 'completed', 'cancelled'].includes(String(row[9] || '').toLowerCase()) ? String(row[9]).toLowerCase() : 'scheduled');
          platform = (['in_app', 'google_meet', 'zoom', 'youtube_live', 'jitsi', 'custom'].includes(String(row[10] || '').toLowerCase()) ? String(row[10]).toLowerCase() : 'in_app');
          meetingUrl = String(row[11] || '');
          isRecordingAvailable = String(row[12] || '').toLowerCase() === 'yes' || String(row[12] || '').toLowerCase() === 'true';
          createdAt = String(row[13] || createdAt);
        }

        parsedLiveClasses.push({
          id: String(row[0]),
          title: String(row[1]),
          academicClass,
          targetClass: academicClass,
          subject,
          courseId,
          batchId,
          educatorName,
          scheduledDate,
          startTime,
          endTime,
          status: status as any,
          platform: platform as any,
          meetingUrl,
          isRecordingAvailable,
          createdAt
        });
      }

      // Parse Class Recordings
      const parsedClassRecordings: ClassRecording[] = [];
      for (const row of classRecordingsRows) {
        if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'recording id') continue;

        let academicClass = 'All Classes';
        let subject = 'General';
        let topic = '';
        let chapter = '';
        let courseId = 'all';
        let batchId = 'all';
        let educatorName = 'Faculty';
        let recordedDate = new Date().toISOString().split('T')[0];
        let durationMinutes = 60;
        let videoSourceType = 'youtube';
        let videoUrl = '';
        let notesPdfUrl = '';
        let viewCount = 0;
        let createdAt = new Date().toISOString();

        const is16ColFormat =
          row.length >= 16 ||
          ['youtube', 'drive', 'mp4', 'vimeo', 'embed', 'zoom_cloud'].includes(String(row[11] || '').toLowerCase().trim()) ||
          (row[9] && /^\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(String(row[9]).trim()));

        if (is16ColFormat) {
          academicClass = String(row[2] || 'All Classes');
          subject = String(row[3] || 'General');
          topic = String(row[4] || '');
          chapter = String(row[5] || '');
          courseId = String(row[6] || 'all');
          batchId = String(row[7] || 'all');
          educatorName = String(row[8] || 'Faculty');
          recordedDate = String(row[9] || recordedDate);
          durationMinutes = Number(row[10]) || 60;
          videoSourceType = String(row[11] || 'youtube').toLowerCase();
          videoUrl = String(row[12] || '');
          notesPdfUrl = String(row[13] || '');
          viewCount = Number(row[14]) || 0;
          createdAt = String(row[15] || createdAt);
        } else {
          subject = String(row[2] || 'General');
          topic = String(row[3] || '');
          chapter = String(row[4] || '');
          courseId = String(row[5] || 'all');
          batchId = String(row[6] || 'all');
          educatorName = String(row[7] || 'Faculty');
          recordedDate = String(row[8] || recordedDate);
          durationMinutes = Number(row[9]) || 60;
          videoSourceType = String(row[10] || 'youtube').toLowerCase();
          videoUrl = String(row[11] || '');
          notesPdfUrl = String(row[12] || '');
          viewCount = Number(row[13]) || 0;
          createdAt = String(row[14] || createdAt);
        }

        parsedClassRecordings.push({
          id: String(row[0]),
          title: String(row[1]),
          academicClass,
          targetClass: academicClass,
          subject,
          topic,
          chapter,
          courseId,
          batchId,
          educatorName,
          recordedDate,
          durationMinutes,
          videoSourceType: (['youtube', 'drive', 'vimeo', 'mp4', 'embed'].includes(videoSourceType) ? videoSourceType : 'youtube') as any,
          videoUrl,
          notesPdfUrl,
          viewCount,
          createdAt
        });
      }

      const totalPulled = 
        parsedStudents.length + 
        parsedAdmissions.length + 
        parsedPayments.length + 
        parsedCourses.length + 
        parsedBatches.length + 
        educatorsRows.length + 
        expensesRows.length + 
        adminRows.length +
        parsedStudyMaterials.length +
        parsedQuestions.length +
        parsedExams.length +
        parsedSubmissions.length +
        parsedLiveClasses.length +
        parsedClassRecordings.length;

      return {
        success: true,
        message: `Successfully pulled & verified ${totalPulled} records across all database sheets from Google Sheets!`,
        parsedData: {
          students: parsedStudents,
          admissions: parsedAdmissions,
          payments: parsedPayments,
          courses: parsedCourses,
          batches: parsedBatches,
          educators: parsedEducators,
          expenses: parsedExpenses,
          adminAccounts: parsedAdminAccounts.length > 0 ? parsedAdminAccounts : undefined,
          centerInfo: Object.keys(parsedCenterInfo).length > 0 ? parsedCenterInfo : undefined,
          studyMaterials: parsedStudyMaterials,
          questions: parsedQuestions,
          exams: parsedExams,
          examSubmissions: parsedSubmissions,
          liveClasses: parsedLiveClasses,
          classRecordings: parsedClassRecordings
        },
        counts: {
          students: parsedStudents.length,
          admissions: parsedAdmissions.length,
          payments: parsedPayments.length,
          courses: parsedCourses.length,
          batches: parsedBatches.length,
          educators: parsedEducators.length,
          expenses: parsedExpenses.length,
          adminAccounts: parsedAdminAccounts.length,
          studyMaterials: parsedStudyMaterials.length,
          questions: parsedQuestions.length,
          exams: parsedExams.length,
          examSubmissions: parsedSubmissions.length,
          liveClasses: parsedLiveClasses.length,
          classRecordings: parsedClassRecordings.length
        }
      };
    } catch (err: any) {
      console.error('Error pulling data from Google Sheet:', err);
      return {
        success: false,
        message: err.message || 'Failed to pull and parse records from Google Sheet.',
        error: err.message
      };
    }
  }

  /**
   * Generates Google Apps Script Webhook code that user can paste in Apps Script
   * to enable 2-way global webhooks from anywhere in the world for all 14 tables
   */
  public generateAppsScriptCode(centerName: string = 'Pixel Pathsala'): string {
    return `/**
 * ============================================================================
 * ${centerName} - Master Cloud ERP Google Sheets Webhook API v2.0
 * Full Two-Way Synchronization Engine for All 14 Database Tables
 * ============================================================================
 * 
 * 🚀 STEP-BY-STEP DEPLOYMENT GUIDE (Takes 1 Minute):
 * ----------------------------------------------------------------------------
 * 1. In your Google Sheet, click on: "Extensions" -> "Apps Script"
 * 2. Delete any existing sample code in the editor.
 * 3. Paste this ENTIRE code script into the editor.
 * 4. Click the Save icon (💾 Disk icon or Ctrl+S / Cmd+S).
 * 5. In the toolbar function dropdown, select "setupAll14Tables" (or "setupAll12Tables") and click "Run".
 *    -> Click "Review Permissions" -> Choose your Google Account -> Click "Advanced" -> Click "Go to Untitled project (unsafe)" -> Click "Allow".
 * 6. Click the blue "Deploy" button (top right) -> Select "New deployment".
 * 7. Click the Gear icon ⚙️ next to "Select type" -> Choose "Web app".
 * 8. Set the exact configuration options:
 *    - Description: Pixel Pathsala ERP Live Webhook v2
 *    - Execute as: "Me (your email address)"
 *    - Who has access: "Anyone"   <-- [CRITICAL: Do NOT select "Only myself" or "Anyone with Google account"]
 * 9. Click "Deploy".
 * 10. Copy the generated "Web app URL" (ends with "/exec", NOT "/dev").
 * 11. Return to Pixel Pathsala ERP -> Admin -> Google Sheets Hub.
 * 12. Paste the URL into "Google Apps Script Web App URL" -> Click "Test Endpoint" & "Save Webhook".
 * 
 * ⚠️ IMPORTANT: If you ever edit or update this script in the future, you must:
 * Click "Deploy" -> "Manage deployments" -> Click the ✏️ Pencil icon -> Select "Version: New version" -> Click "Deploy".
 */

function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('🏫 Pixel Pathsala ERP')
    .addItem('⚡ Format & Initialize All 14 Sheets', 'setupAll14Tables')
    .addItem('📊 Check Database Health & Row Counts', 'checkDatabaseHealth')
    .addToUi();
}

/**
 * Creates and formats all 14 required ERP sheets if they do not exist
 */
function setupAll14Tables() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var tables = [
    {
      name: 'Students',
      headers: ['Student ID', 'Roll No', 'Full Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Residential Address', 'Course ID', 'Batch ID', 'Admission Date', 'Status', 'Custom Fee Override (₹)', 'Monthly Base Fee (₹)', 'Total Paid (₹)', 'Outstanding Due (₹)']
    },
    {
      name: 'Admissions',
      headers: ['Application ID', 'Student Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Target Course ID', 'Status', 'Applied Date', 'Initial Fee Status', 'Payment Mode', 'Transaction Ref / UPI', 'Staff Remarks', 'Rejection Reason', 'Address']
    },
    {
      name: 'Fee_Transactions',
      headers: ['Receipt No', 'Payment ID', 'Student ID', 'Student Name', 'Amount Paid (₹)', 'Payment Mode', 'Months Covered', 'Transaction Ref / UPI', 'Payment Date', 'Approval Status', 'Approved By', 'Rejection Reason']
    },
    {
      name: 'Courses_Batches',
      headers: ['Record Type', 'ID', 'Title / Batch Name', 'Code / Course ID', 'Academic Class / Timings', 'Category / Schedule Days', 'Monthly Fee (₹) / Max Capacity', 'Popular / Educator ID', 'Description / Room', 'Batch Mode / Delivery Mode']
    },
    {
      name: 'Educators',
      headers: ['Educator ID', 'Full Name', 'Qualification', 'Specialization Subject', 'Phone Number', 'Email Address', 'Monthly Salary (₹)', 'Experience (Yrs)', 'Employment Status', 'Joining Date', 'Photo URL']
    },
    {
      name: 'Expenses',
      headers: ['Expense ID', 'Category', 'Expense Title', 'Amount Paid (₹)', 'Payment Date', 'Paid To / Vendor', 'Payment Mode', 'Receipt Reference', 'Notes']
    },
    {
      name: 'Admin_Credentials',
      headers: ['Admin ID', 'Username', 'Full Name', 'Role Title', 'Email Address', 'Password Hash/Plain', 'Security PIN', 'Status', 'Last Login', 'Updated At']
    },
    {
      name: 'Center_Overview',
      headers: ['Parameter / Property', 'Current Center Value']
    },
    {
      name: 'Study_Materials',
      headers: ['Material ID', 'Title', 'Subject', 'Course ID', 'Batch ID', 'File Type', 'File Name', 'File Size', 'File URL / Link', 'Uploaded By', 'Uploaded Date', 'Download Count', 'Description']
    },
    {
      name: 'Question_Bank',
      headers: ['Question ID', 'Course ID', 'Academic Class', 'Subject', 'Topic', 'Marks', 'Difficulty', 'Question Text', 'Option A', 'Option B', 'Option C', 'Option D', 'Correct Option Index', 'Code Snippet', 'Explanation', 'Created At']
    },
    {
      name: 'Exams',
      headers: ['Exam ID', 'Exam Code', 'Title', 'Course ID', 'Batch ID', 'Academic Class', 'Subject', 'Duration (Mins)', 'Total Marks', 'Passing Marks', 'Passing %', 'Status', 'Mode', 'Scheduled Date', 'Start Time', 'End Time', 'Question Count', 'Question IDs', 'Instructions', 'Published', 'Created At']
    },
    {
      name: 'Exam_Submissions',
      headers: ['Submission ID', 'Exam ID', 'Exam Title', 'Student ID', 'Student Name', 'Roll No', 'Aadhaar No', 'Course ID', 'Batch ID', 'Score Obtained', 'Total Marks', 'Percentage (%)', 'Result Status', 'Time Spent (Secs)', 'Submitted At', 'Answers Summary']
    },
    {
      name: 'Live_Classes',
      headers: ['Session ID', 'Class Title', 'Academic Class', 'Subject', 'Course ID', 'Batch ID', 'Educator Name', 'Date', 'Start Time', 'End Time', 'Status', 'Platform', 'Meeting Link / Room ID', 'Recording Available', 'Created At']
    },
    {
      name: 'Class_Recordings',
      headers: ['Recording ID', 'Title', 'Academic Class', 'Subject', 'Topic', 'Chapter', 'Course ID', 'Batch ID', 'Educator Name', 'Recorded Date', 'Duration (Mins)', 'Source Type', 'Video URL', 'Notes PDF URL', 'View Count', 'Created At']
    },
    {
      name: 'Discounts',
      headers: ['Discount ID', 'Discount Title', 'Discount Type (flat/percentage)', 'Value (₹ / %)', 'Scope (all/class/course/batch/student)', 'Target Academic Class', 'Target Course ID', 'Target Batch ID', 'Target Student ID', 'Applicable Months Type', 'Selected Months', 'Reason / Description', 'Active Status', 'Created At']
    }
  ];

  for (var i = 0; i < tables.length; i++) {
    var t = tables[i];
    var sheet = ss.getSheetByName(t.name) || ss.insertSheet(t.name);
    if (sheet.getLastRow() === 0) {
      sheet.getRange(1, 1, 1, t.headers.length).setValues([t.headers]);
      sheet.getRange(1, 1, 1, t.headers.length)
        .setFontWeight("bold")
        .setBackground("#1e293b")
        .setFontColor("#ffffff");
      sheet.setFrozenRows(1);
    }
    
    // Ensure Center_Overview has all canonical rows so no rows are ever missing
    if (t.name === 'Center_Overview' && sheet.getLastRow() <= 1) {
      var initialOverview = [
        ['Institute Name', '${centerName || 'Pixel Pathsala'}'],
        ['Tagline / Motto', 'Empowering Next-Gen Learners with Skills & Excellence'],
        ['Campus Address', '124, Station Road, Academic Hub'],
        ['City & State', 'Kolkata, West Bengal, India'],
        ['Primary Helpline Phone', '+91 9775708722'],
        ['Office Desk Phone (Alternate)', '+91 9832014567'],
        ['Official WhatsApp Number', '+91 9775708722'],
        ['Official Email', 'contact@pixelpathsala.com'],
        ['Facebook Page URL', 'https://facebook.com'],
        ['YouTube Channel URL', 'https://youtube.com'],
        ['UPI ID for Fees', '9775708722@ybl'],
        ['UPI Payee Name', 'Pixel Pathsala Education'],
        ['Registration Number', 'WB-EDU-2021-8849'],
        ['Established Year', '2021'],
        ['Admissions Status', 'Open'],
        ['Announcement Notice Banner', 'Admissions open for Academic Session 2026-2027! Enquire now.'],
        ['Homepage Welcome Overview', 'Welcome to Pixel Pathsala. Providing world-class coaching, doubt clearing, and career guidance.'],
        ['Google Sheet Webhook URL', ''],
        ['Google Sheet Database ID', ''],
        ['Active Students Count', 0],
        ['Total Enrolled Students', 0],
        ['Total Admissions Count', 0],
        ['Total Courses Count', 0],
        ['Total Batches Count', 0],
        ['Total Educators Count', 0],
        ['Total Fee Collections Count', 0],
        ['Total Fees Collected (₹)', 0],
        ['Total Expenses (₹)', 0],
        ['Database Engine', 'Google Sheets Live Cloud Database (Pixel Pathsala ERP)'],
        ['Last Cloud Sync Time', new Date().toISOString()]
      ];
      sheet.getRange(2, 1, initialOverview.length, 2).setValues(initialOverview);
    }
  }

  return "All 14 ERP sheets configured and ready.";
}

function setupAll12Tables() {
  return setupAll14Tables();
}

function checkDatabaseHealth() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheets = ss.getSheets();
  var msg = "🏫 Database Health Report:\\n\\n";
  for (var i = 0; i < sheets.length; i++) {
    msg += "• " + sheets[i].getName() + ": " + Math.max(0, sheets[i].getLastRow() - 1) + " records\\n";
  }
  SpreadsheetApp.getUi().alert(msg);
}

/**
 * Handle GET Requests (Health Check, Pull Data, Ping)
 */
function doGet(e) {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var action = (e && e.parameter && e.parameter.action) || 'getAll';
    
    if (action === 'ping' || action === 'status') {
      return ContentService.createTextOutput(JSON.stringify({ 
        success: true, 
        status: "ok", 
        message: "Pixel Pathsala Webhook Live & Responsive", 
        timestamp: new Date().toISOString(),
        tablesCount: ss.getSheets().length
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    var response = {};
    var sheets = ss.getSheets();
    for (var i = 0; i < sheets.length; i++) {
      var name = sheets[i].getName();
      var data = sheets[i].getDataRange().getValues();
      response[name] = data;
    }
    
    return ContentService.createTextOutput(JSON.stringify({ success: true, data: response }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ success: false, error: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Handle POST Requests (Live Record Appends & Full 12-Table Bulk Sync)
 */
function doPost(e) {
  try {
    var rawText = (e && e.postData && e.postData.contents) ? e.postData.contents : '{}';
    var contents = {};
    try {
      contents = JSON.parse(rawText);
    } catch (parseErr) {
      contents = (e && e.parameter) ? e.parameter : {};
    }

    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var action = contents.action || 'syncAll';
    
    // 1. Diagnostics Ping Handler
    if (action === 'ping') {
      return ContentService.createTextOutput(JSON.stringify({ 
        success: true, 
        message: "Webhook ping acknowledged successfully!", 
        timestamp: new Date().toISOString(),
        action: "ping"
      })).setMimeType(ContentService.MimeType.JSON);
    }

    // 2. Full 12-Table Bulk Sync (Write-Back Matrix)
    if (action === 'saveAll' || action === 'sync' || action === 'syncAll') {
      var tables = contents.tables;
      var updatedSheets = [];

      if (tables && typeof tables === 'object') {
        for (var tableName in tables) {
          var matrix = tables[tableName];
          if (Array.isArray(matrix) && matrix.length > 0) {
            // Find max column count in this table to prevent ragged array errors in Apps Script
            var maxCols = 0;
            for (var r = 0; r < matrix.length; r++) {
              if (Array.isArray(matrix[r]) && matrix[r].length > maxCols) {
                maxCols = matrix[r].length;
              }
            }

            if (maxCols > 0) {
              // Normalize matrix so every row has exact same number of columns
              var normalizedMatrix = [];
              for (var r = 0; r < matrix.length; r++) {
                var row = Array.isArray(matrix[r]) ? matrix[r].slice() : [matrix[r]];
                while (row.length < maxCols) {
                  row.push('');
                }
                normalizedMatrix.push(row);
              }

              var targetSheet = ss.getSheetByName(tableName) || ss.insertSheet(tableName);
              targetSheet.clearContents();
              targetSheet.getRange(1, 1, normalizedMatrix.length, maxCols).setValues(normalizedMatrix);
              
              // Format Header Row
              targetSheet.getRange(1, 1, 1, maxCols)
                .setFontWeight("bold")
                .setBackground("#1e293b")
                .setFontColor("#ffffff");
              targetSheet.setFrozenRows(1);

              updatedSheets.push(tableName + ' (' + (normalizedMatrix.length - 1) + ' rows)');
            }
          }
        }
      }

      return ContentService.createTextOutput(JSON.stringify({ 
        success: true, 
        message: "Full 12-table ERP sync completed successfully in Google Sheets!", 
        updatedTables: updatedSheets,
        timestamp: new Date().toISOString()
      })).setMimeType(ContentService.MimeType.JSON);
    }

    // 3. Admission Approval & Enrollment with Automatic Fee Transaction Receipt
    if (action === 'approveAdmission' || action === 'enrollStudent') {
      var admSheet = ss.getSheetByName('Admissions') || ss.insertSheet('Admissions');
      var stuSheet = ss.getSheetByName('Students') || ss.insertSheet('Students');
      var feeSheet = ss.getSheetByName('Fee_Transactions') || ss.insertSheet('Fee_Transactions');
      
      var appId = contents.applicationId || (contents.admission && (contents.admission.id || contents.admission.applicationNo)) || '';
      var student = contents.student || {};
      var payment = contents.payment;
      
      // Update status in Admissions sheet
      if (appId && admSheet.getLastRow() > 1) {
        var admData = admSheet.getDataRange().getValues();
        for (var i = 1; i < admData.length; i++) {
          if (String(admData[i][0]) === String(appId) || String(admData[i][1]) === String(student.name)) {
            admSheet.getRange(i + 1, 9).setValue('approved'); // Column I: Status
            admSheet.getRange(i + 1, 11).setValue('paid_advance'); // Column K: Initial Fee Status
            break;
          }
        }
      }
      
      // Append Student to Students sheet
      var stuRow = [
        student.id || 'STU-' + new Date().getTime(),
        student.rollNo || '',
        student.name || student.studentName || '',
        student.mobile || '',
        student.aadhaarNo || '',
        student.email || '',
        student.guardianName || '',
        student.guardianPhone || '',
        student.address || '',
        student.courseId || '',
        student.batchId || '',
        student.admissionDate || new Date().toISOString().split('T')[0],
        'active',
        student.customMonthlyFeeOverride || '',
        student.monthlyFee || (payment ? payment.baseMonthlyFee || payment.finalAmountPaid : ''),
        student.totalPaid || (payment ? (payment.finalAmountPaid || payment.amount || 0) : 0),
        student.totalDue || 0
      ];
      stuSheet.appendRow(stuRow);
      
      // If payment was made/verified during admission, append to Fee_Transactions
      var paymentAdded = false;
      if (payment && (payment.finalAmountPaid > 0 || payment.amount > 0 || contents.isPaid)) {
        var feeRow = [
          payment.receiptNo || 'REC-' + new Date().getTime(),
          payment.id || 'PAY-' + new Date().getTime(),
          student.id || payment.studentId || '',
          student.name || payment.studentName || '',
          payment.finalAmountPaid || payment.amount || 0,
          payment.paymentMode || 'UPI',
          Array.isArray(payment.monthsCovered) ? payment.monthsCovered.join(', ') : (payment.month || '2026-04'),
          payment.transactionRef || '',
          payment.paymentDate || new Date().toISOString().split('T')[0],
          payment.status || 'approved',
          payment.approvedBy || 'Admin (Application Approval)',
          payment.remarks || ('Admission Fee & Tuition (App #' + appId + ')')
        ];
        feeSheet.appendRow(feeRow);
        paymentAdded = true;
      }
      
      return ContentService.createTextOutput(JSON.stringify({ 
        success: true, 
        message: "Admission approved, student enrolled" + (paymentAdded ? " and payment receipt recorded in Fee_Transactions!" : "!"),
        paymentRecorded: paymentAdded
      })).setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'rejectAdmission') {
      var admSheet = ss.getSheetByName('Admissions') || ss.insertSheet('Admissions');
      var appId = contents.applicationId || (contents.admission && contents.admission.id) || '';
      var reason = contents.reason || contents.rejectionReason || 'Application rejected';
      if (appId && admSheet.getLastRow() > 1) {
        var admData = admSheet.getDataRange().getValues();
        for (var i = 1; i < admData.length; i++) {
          if (String(admData[i][0]) === String(appId)) {
            admSheet.getRange(i + 1, 9).setValue('rejected');
            admSheet.getRange(i + 1, 15).setValue(reason);
            break;
          }
        }
      }
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Application rejected in Admissions sheet." }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // 4. Center Information & Gateway Configuration Save
    if (action === 'saveCenterInfo' || action === 'updateCenterInfo' || action === 'updateGateway' || action === 'updateCenterOverview') {
      var ovSheet = ss.getSheetByName('Center_Overview') || ss.insertSheet('Center_Overview');
      var cInfo = contents.centerInfo || contents || {};
      
      var paramMap = {
        'Institute Name': cInfo.name,
        'Tagline / Motto': cInfo.tagline,
        'Campus Address': cInfo.address,
        'City & State': cInfo.cityState,
        'Primary Helpline Phone': cInfo.phonePrimary,
        'Office Desk Phone (Alternate)': cInfo.phoneSecondary,
        'Official WhatsApp Number': cInfo.whatsapp || cInfo.phonePrimary,
        'Official Email': cInfo.email,
        'Facebook Page URL': cInfo.facebookUrl,
        'YouTube Channel URL': cInfo.youtubeUrl,
        'UPI ID for Fees': cInfo.upiId,
        'UPI Payee Name': cInfo.upiName,
        'Registration Number': cInfo.regNumber,
        'Established Year': cInfo.establishedYear,
        'Admissions Status': (cInfo.isAdmissionsOpen !== false && cInfo.admissionOpen !== false) ? 'Open' : 'Closed',
        'Announcement Notice Banner': cInfo.announcement,
        'Homepage Welcome Overview': cInfo.welcomeMessage,
        'Google Sheet Webhook URL': cInfo.googleSheetWebhookUrl,
        'Google Sheet Database ID': cInfo.googleSheetId
      };
      
      var existingData = ovSheet.getDataRange().getValues();
      var existingParams = {};
      for (var r = 0; r < existingData.length; r++) {
        if (existingData[r] && existingData[r][0]) {
          existingParams[String(existingData[r][0]).trim().toLowerCase()] = r + 1;
        }
      }
      
      for (var paramName in paramMap) {
        var val = paramMap[paramName];
        if (val !== undefined && val !== null) {
          var rowIdx = existingParams[paramName.toLowerCase()];
          if (rowIdx) {
            ovSheet.getRange(rowIdx, 2).setValue(String(val));
          } else {
            ovSheet.appendRow([paramName, String(val)]);
          }
        }
      }
      
      var syncRow = existingParams['last cloud sync time'];
      if (syncRow) {
        ovSheet.getRange(syncRow, 2).setValue(new Date().toISOString());
      } else {
        ovSheet.appendRow(['Last Cloud Sync Time', new Date().toISOString()]);
      }
      
      return ContentService.createTextOutput(JSON.stringify({ 
        success: true, 
        message: "Center Information & Gateway Configuration saved to Center_Overview sheet successfully!" 
      })).setMimeType(ContentService.MimeType.JSON);
    }

    // 5. Single Record Appenders for All Forms in ERP
    if (action === 'newAdmission' || action === 'addAdmission') {
      var sheet = ss.getSheetByName('Admissions') || ss.insertSheet('Admissions');
      sheet.appendRow(contents.row || [
        contents.id || contents.applicationNo || 'APP-' + new Date().getTime(),
        contents.studentName || '',
        contents.mobile || '',
        contents.aadhaarNo || '',
        contents.email || '',
        contents.guardianName || '',
        contents.guardianPhone || '',
        contents.targetCourseId || 'CRS-001',
        contents.status || 'pending',
        contents.appliedDate || new Date().toISOString().split('T')[0],
        contents.initialPaymentStatus || 'paid_advance',
        contents.initialPaymentMode || 'UPI',
        contents.initialPaymentRef || '',
        contents.remarks || '',
        contents.rejectionReason || '',
        contents.address || ''
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Admission record appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }
    
    if (action === 'newFeePayment' || action === 'addPayment' || action === 'collectFee') {
      var sheet = ss.getSheetByName('Fee_Transactions') || ss.insertSheet('Fee_Transactions');
      var stuSheet = ss.getSheetByName('Students');
      var p = contents.payment || contents;
      var receiptNo = p.receiptNo || 'REC-' + new Date().getTime();
      var studentId = p.studentId || '';
      var amount = Number(p.finalAmountPaid || p.amount || 0);

      sheet.appendRow(contents.row || [
        receiptNo,
        p.id || 'PAY-' + new Date().getTime(),
        studentId,
        p.studentName || '',
        amount,
        p.paymentMode || 'UPI',
        Array.isArray(p.monthsCovered) ? p.monthsCovered.join(', ') : (p.month || '2026-04'),
        p.transactionRef || '',
        p.paymentDate || new Date().toISOString().split('T')[0],
        p.status || 'approved',
        p.approvedBy || 'Admin Desk',
        p.remarks || ''
      ]);

      // Update student's Total Paid & Due in Students sheet
      if (stuSheet && studentId && stuSheet.getLastRow() > 1) {
        var stuData = stuSheet.getDataRange().getValues();
        for (var s = 1; s < stuData.length; s++) {
          if (String(stuData[s][0]) === String(studentId) || String(stuData[s][1]) === String(studentId)) {
            var currPaid = Number(stuData[s][15]) || 0;
            var newPaid = currPaid + amount;
            stuSheet.getRange(s + 1, 16).setValue(newPaid);
            var baseFee = Number(stuData[s][14]) || amount;
            stuSheet.getRange(s + 1, 17).setValue(Math.max(0, baseFee - newPaid));
            break;
          }
        }
      }

      return ContentService.createTextOutput(JSON.stringify({ 
        success: true, 
        message: "Fee payment receipt #" + receiptNo + " recorded in Fee_Transactions!",
        receiptNo: receiptNo
      })).setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newStudent' || action === 'addStudent') {
      var sheet = ss.getSheetByName('Students') || ss.insertSheet('Students');
      sheet.appendRow(contents.row || [
        contents.id || 'STU-' + new Date().getTime(),
        contents.rollNo || '',
        contents.name || '',
        contents.mobile || '',
        contents.aadhaarNo || '',
        contents.email || '',
        contents.guardianName || '',
        contents.guardianPhone || '',
        contents.address || '',
        contents.courseId || '',
        contents.batchId || '',
        contents.admissionDate || new Date().toISOString().split('T')[0],
        contents.status || 'active',
        contents.customMonthlyFeeOverride || '',
        '',
        '',
        ''
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Student record appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newExpense' || action === 'addExpense') {
      var sheet = ss.getSheetByName('Expenses') || ss.insertSheet('Expenses');
      sheet.appendRow(contents.row || [
        contents.id || 'EXP-' + new Date().getTime(),
        contents.category || 'General',
        contents.title || '',
        contents.amount || 0,
        contents.date || new Date().toISOString().split('T')[0],
        contents.paidTo || '',
        contents.paymentMode || 'UPI',
        contents.receiptNo || '',
        contents.notes || ''
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Expense record appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newEducator' || action === 'addEducator') {
      var sheet = ss.getSheetByName('Educators') || ss.insertSheet('Educators');
      sheet.appendRow(contents.row || [
        contents.id || 'EDU-' + new Date().getTime(),
        contents.name || '',
        contents.qualification || '',
        contents.specialization || '',
        contents.phone || '',
        contents.email || '',
        contents.salary || 0,
        contents.experienceYears || 0,
        contents.status || 'active',
        contents.joiningDate || new Date().toISOString().split('T')[0],
        contents.photoUrl || ''
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Educator record appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newCourse' || action === 'addCourse') {
      var sheet = ss.getSheetByName('Courses_Batches') || ss.insertSheet('Courses_Batches');
      sheet.appendRow(contents.row || [
        'COURSE',
        contents.id || 'CRS-' + new Date().getTime(),
        contents.title || '',
        contents.code || '',
        contents.academicClass || '',
        contents.category || '',
        contents.monthlyFee || 0,
        contents.isPopular ? 'Yes' : 'No',
        contents.description || '',
        contents.deliveryMode || 'Offline & Online Hybrid'
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Course record appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newBatch' || action === 'addBatch') {
      var sheet = ss.getSheetByName('Courses_Batches') || ss.insertSheet('Courses_Batches');
      sheet.appendRow(contents.row || [
        'BATCH',
        contents.id || 'BAT-' + new Date().getTime(),
        contents.name || '',
        contents.courseId || '',
        contents.timing || '',
        (contents.days || []).join(', '),
        contents.maxCapacity || 30,
        contents.educatorId || '',
        contents.roomNumber || 'Room 101',
        contents.mode || 'offline'
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Batch record appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newStudyMaterial' || action === 'addStudyMaterial') {
      var sheet = ss.getSheetByName('Study_Materials') || ss.insertSheet('Study_Materials');
      sheet.appendRow(contents.row || [
        contents.id || 'MAT-' + new Date().getTime(),
        contents.title || '',
        contents.subject || '',
        contents.courseId || 'all',
        contents.batchId || 'all',
        contents.fileType || 'pdf',
        contents.fileName || '',
        contents.fileSize || '',
        contents.fileUrl || '',
        contents.uploadedBy || 'Faculty',
        contents.uploadedDate || new Date().toISOString().split('T')[0],
        contents.downloadCount || 0,
        contents.description || ''
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Study material record appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newQuestion' || action === 'addQuestion') {
      var sheet = ss.getSheetByName('Question_Bank') || ss.insertSheet('Question_Bank');
      sheet.appendRow(contents.row || [
        contents.id || 'Q-' + new Date().getTime(),
        contents.courseId || 'all',
        contents.academicClass || '',
        contents.subject || '',
        contents.topic || '',
        contents.marks || 1,
        contents.difficulty || 'medium',
        contents.questionText || '',
        (contents.options && contents.options[0]) || '',
        (contents.options && contents.options[1]) || '',
        (contents.options && contents.options[2]) || '',
        (contents.options && contents.options[3]) || '',
        contents.correctOptionIndex ?? 0,
        contents.codeSnippet || '',
        contents.explanation || '',
        contents.createdAt || new Date().toISOString()
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Question item appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newExam' || action === 'addExam') {
      var sheet = ss.getSheetByName('Exams') || ss.insertSheet('Exams');
      sheet.appendRow(contents.row || [
        contents.id || 'EXAM-' + new Date().getTime(),
        contents.examCode || '',
        contents.title || '',
        contents.courseId || 'all',
        contents.batchId || 'all',
        contents.academicClass || '',
        contents.subject || '',
        contents.durationMinutes || 45,
        contents.totalMarks || 25,
        contents.passingMarks || 10,
        contents.passingPercentage || 40,
        contents.status || 'scheduled',
        contents.mode || 'online',
        contents.scheduledDate || '',
        contents.startTime || '',
        contents.endTime || '',
        (contents.questionIds || []).length,
        (contents.questionIds || []).join(', '),
        contents.instructions || '',
        contents.isPublished ? 'Yes' : 'No',
        contents.createdAt || new Date().toISOString()
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Exam record appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newExamSubmission' || action === 'addExamSubmission') {
      var sheet = ss.getSheetByName('Exam_Submissions') || ss.insertSheet('Exam_Submissions');
      sheet.appendRow(contents.row || [
        contents.id || 'SUB-' + new Date().getTime(),
        contents.examId || '',
        contents.examTitle || '',
        contents.studentId || '',
        contents.studentName || '',
        contents.studentRollNo || '',
        contents.studentAadhaar || '',
        contents.courseId || '',
        contents.batchId || '',
        contents.score || 0,
        contents.totalMarks || 25,
        contents.percentage || 0,
        contents.passed ? 'PASSED' : 'NEEDS IMPROVEMENT',
        contents.timeSpentSeconds || 0,
        contents.submittedAt || new Date().toISOString(),
        JSON.stringify(contents.answers || {})
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Exam submission record appended successfully!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newLiveClass' || action === 'addLiveClass' || action === 'scheduleLiveClass') {
      var sheet = ss.getSheetByName('Live_Classes') || ss.insertSheet('Live_Classes');
      sheet.appendRow(contents.row || [
        contents.id || 'LIVE-' + new Date().getTime(),
        contents.title || '',
        contents.academicClass || contents.targetClass || 'All Classes',
        contents.subject || '',
        contents.courseId || 'all',
        contents.batchId || 'all',
        contents.educatorName || 'Faculty',
        contents.date || contents.scheduledDate || new Date().toISOString().split('T')[0],
        contents.startTime || '10:00 AM',
        contents.endTime || '11:00 AM',
        contents.status || 'scheduled',
        contents.platform || 'in-app',
        contents.meetingLink || contents.meetingUrl || '',
        contents.recordingAvailable ? 'Yes' : 'No',
        contents.createdAt || new Date().toISOString()
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Live class session scheduled in Live_Classes!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newClassRecording' || action === 'addClassRecording' || action === 'uploadRecording') {
      var sheet = ss.getSheetByName('Class_Recordings') || ss.insertSheet('Class_Recordings');
      sheet.appendRow(contents.row || [
        contents.id || 'REC-' + new Date().getTime(),
        contents.title || '',
        contents.academicClass || contents.targetClass || 'All Classes',
        contents.subject || '',
        contents.topic || '',
        contents.chapter || '',
        contents.courseId || 'all',
        contents.batchId || 'all',
        contents.educatorName || 'Faculty',
        contents.recordedDate || new Date().toISOString().split('T')[0],
        contents.durationMinutes || 60,
        contents.sourceType || contents.videoSourceType || 'youtube',
        contents.videoUrl || '',
        contents.notesPdfUrl || '',
        contents.viewCount || 0,
        contents.createdAt || new Date().toISOString()
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Class recording saved in Class_Recordings!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'newDiscount' || action === 'addDiscount' || action === 'updateDiscount' || action === 'deleteDiscount') {
      var dSheet = ss.getSheetByName('Discounts') || ss.insertSheet('Discounts');
      var disc = contents.discount || contents.payload || contents;
      var discId = disc.id || contents.id || 'disc-' + new Date().getTime();

      if (action === 'deleteDiscount') {
        var dData = dSheet.getDataRange().getValues();
        for (var i = 1; i < dData.length; i++) {
          if (String(dData[i][0]) === String(discId)) {
            dSheet.deleteRow(i + 1);
            break;
          }
        }
        return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Discount removed from Discounts sheet!" }))
          .setMimeType(ContentService.MimeType.JSON);
      }

      if (action === 'updateDiscount') {
        var dData = dSheet.getDataRange().getValues();
        var foundRow = -1;
        for (var i = 1; i < dData.length; i++) {
          if (String(dData[i][0]) === String(discId)) {
            foundRow = i + 1;
            break;
          }
        }
        if (foundRow > 0) {
          if (disc.title !== undefined) dSheet.getRange(foundRow, 2).setValue(disc.title);
          if (disc.type !== undefined) dSheet.getRange(foundRow, 3).setValue(disc.type);
          if (disc.value !== undefined) dSheet.getRange(foundRow, 4).setValue(disc.value);
          if (disc.scope !== undefined) dSheet.getRange(foundRow, 5).setValue(disc.scope);
          if (disc.academicClass !== undefined) dSheet.getRange(foundRow, 6).setValue(disc.academicClass || '');
          if (disc.courseId !== undefined) dSheet.getRange(foundRow, 7).setValue(disc.courseId || '');
          if (disc.batchId !== undefined) dSheet.getRange(foundRow, 8).setValue(disc.batchId || '');
          if (disc.studentId !== undefined) dSheet.getRange(foundRow, 9).setValue(disc.studentId || '');
          if (disc.active !== undefined) dSheet.getRange(foundRow, 13).setValue(disc.active ? 'Active' : 'Disabled');
          return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Discount updated in Discounts sheet!" }))
            .setMimeType(ContentService.MimeType.JSON);
        }
      }

      dSheet.appendRow(contents.row || [
        discId,
        disc.title || 'Concession',
        disc.type || 'flat',
        disc.value || 0,
        disc.scope || 'all',
        disc.academicClass || '',
        disc.courseId || '',
        disc.batchId || '',
        disc.studentId || '',
        disc.applicableMonthsType || 'all_months',
        Array.isArray(disc.selectedMonths) ? disc.selectedMonths.join(', ') : '',
        disc.reason || '',
        disc.active !== false ? 'Active' : 'Disabled',
        disc.createdAt || new Date().toISOString().split('T')[0]
      ]);
      return ContentService.createTextOutput(JSON.stringify({ success: true, message: "Discount appended to Discounts sheet!" }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    return ContentService.createTextOutput(JSON.stringify({ 
      success: true, 
      message: "Webhook processed successfully", 
      action: action 
    })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ 
      success: false, 
      error: err.toString(),
      message: "Apps Script exception: " + err.message
    })).setMimeType(ContentService.MimeType.JSON);
  }
}`;
  }
}

export const googleSheetsService = new GoogleSheetsService();
