import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Hero } from './components/public/Hero';
import { CourseCatalog } from './components/public/CourseCatalog';
import { FacultyList } from './components/public/FacultyList';
import { CenterInfoSection } from './components/public/CenterInfoSection';
import { PublicLiveClassShowcase } from './components/public/PublicLiveClassShowcase';
import { AdmissionForm } from './components/public/AdmissionForm';
import { StudentPortal } from './components/student/StudentPortal';
import { AdminLayout } from './components/admin/AdminLayout';
import { AdminLogin } from './components/admin/AdminLogin';
import { Playzone } from './components/playzone/Playzone';
import { PrintReceiptModal } from './components/common/PrintReceiptModal';
import { UnifiedLoginModal } from './components/common/UnifiedLoginModal';
import { CenterLogo } from './components/common/CenterLogo';
import { SEOMetadataManager } from './components/common/SEOMetadataManager';
import { ApiAndApkHub } from './components/api/ApiAndApkHub';
import { getWhatsAppUrl, getPhoneTelUrl, getEmailMailtoUrl } from './utils/contactHelper';
import { getDirectApkDownloadUrl } from './utils/apkHelper';
import { 
  Building2, 
  Code2, 
  User, 
  ShieldCheck, 
  BookOpen, 
  Sparkles, 
  Phone, 
  PhoneCall,
  MessageCircle,
  Mail,
  GraduationCap, 
  Send, 
  QrCode, 
  CheckCircle, 
  Menu, 
  X, 
  Layers, 
  Globe, 
  ExternalLink, 
  Database, 
  CloudUpload, 
  LogIn,
  LogOut,
  Download,
  Smartphone
} from 'lucide-react';

function AppContent() {
  const { 
    activeTab, 
    setActiveTab, 
    centerInfo, 
    payments, 
    admissions, 
    discounts,
    toast, 
    isAdminLoggedIn,
    adminUser,
    currentStudent,
    logoutStudent,
    openUnifiedLoginModal,
    selectedReceiptForPrint,
    setSelectedReceiptForPrint 
  } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const pendingApprovalsCount = payments.filter(p => p.status === 'pending').length;
  const pendingAdmissionsCount = admissions.filter(a => a.status === 'pending').length;
  const totalAdminAlerts = pendingApprovalsCount + pendingAdmissionsCount;

  const hasActiveDiscounts = discounts.some(d => d.active !== false && String(d.active).toLowerCase() !== 'false');

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Dynamic SEO Meta & Title Manager */}
      <SEOMetadataManager />

      {/* Toast Notification Alert */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-bounce">
          <div className={`px-4 py-3 rounded-2xl shadow-xl border text-xs sm:text-sm font-bold flex items-center gap-2 ${
            toast.type === 'error'
              ? 'bg-red-600 text-white border-red-500'
              : toast.type === 'info'
              ? 'bg-slate-900 text-white border-slate-700'
              : 'bg-emerald-600 text-white border-emerald-500'
          }`}>
            <CheckCircle className="w-4 h-4 shrink-0" />
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Topmost Professional System Bar */}
      <header className="h-16 bg-[#1E293B] flex items-center justify-between px-4 sm:px-8 border-b border-slate-700/60 shadow-xs sticky top-0 z-50">
        <div className="flex items-center gap-3.5">
          {/* Logo Badge */}
          <div
            onClick={() => {
              setActiveTab('website');
              setMobileMenuOpen(false);
            }}
            className="flex items-center gap-3 cursor-pointer select-none group"
          >
            <CenterLogo size="md" />
            <div className="flex flex-col">
              <h1 className="text-white font-extrabold text-base sm:text-lg leading-tight tracking-tight group-hover:text-indigo-200 transition-colors">
                {centerInfo.name}
              </h1>
              <p className="text-indigo-200/90 text-[10px] font-semibold tracking-wider italic">
                Code your dream, decode the future
              </p>
            </div>
          </div>
        </div>

        {/* Center / Right Quick Navigations */}
        <div className="hidden lg:flex items-center gap-2">
          <button
            id="nav-website-btn"
            onClick={() => setActiveTab('website')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'website'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Website</span>
          </button>

          <button
            id="nav-courses-btn"
            onClick={() => setActiveTab('courses')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'courses'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Courses</span>
            {hasActiveDiscounts && (
              <span className="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 text-amber-200 border border-amber-400/40 shadow-2xs uppercase tracking-wider animate-pulse">
                Offers
              </span>
            )}
          </button>

          <button
            id="nav-faculty-btn"
            onClick={() => setActiveTab('faculty')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'faculty'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Faculty</span>
          </button>

          <button
            id="nav-admission-btn"
            onClick={() => setActiveTab('admission')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'admission'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>Admission</span>
            <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Open
            </span>
          </button>

          <button
            id="nav-playzone-btn"
            onClick={() => setActiveTab('playzone')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              activeTab === 'playzone'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-indigo-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Playzone</span>
          </button>

          {/* Public Direct Download APK Button */}
          <a
            id="nav-direct-download-btn"
            href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
            download="PixelPathsala.apk"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-emerald-300 hover:text-white bg-emerald-950/60 hover:bg-emerald-600 border border-emerald-500/40 shadow-xs transition-all cursor-pointer"
            title="Download Official Mobile App (.apk)"
          >
            <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
            <span>Download Mobile App</span>
            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1 py-0.2 rounded font-mono border border-emerald-500/30">
              APK
            </span>
          </a>
        </div>

        {/* Top Navbar Auth & Sign Out Buttons */}
        <div className="hidden sm:flex items-center gap-2">
          {currentStudent ? (
            <>
              <button
                id="nav-student-portal-btn"
                onClick={() => setActiveTab('student-portal')}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs ${
                  activeTab === 'student-portal'
                    ? 'bg-indigo-600 text-white ring-2 ring-indigo-400/40'
                    : 'bg-indigo-950/70 hover:bg-indigo-900 text-indigo-200 border border-indigo-500/30'
                }`}
                title="Open Student Portal"
              >
                <User className="w-3.5 h-3.5 text-indigo-300" />
                <span>Portal: {currentStudent.name.split(' ')[0]}</span>
                <span className="text-[10px] bg-indigo-500/30 text-indigo-200 px-1.5 py-0.2 rounded font-mono">
                  {currentStudent.studentClass || 'Student'}
                </span>
              </button>

              <button
                id="nav-student-logout-btn"
                onClick={() => {
                  logoutStudent();
                  setActiveTab('website');
                }}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-rose-300 hover:text-white bg-rose-950/60 hover:bg-rose-700/90 border border-rose-500/40 shadow-xs transition-all cursor-pointer"
                title="Sign Out from Student Portal"
              >
                <LogOut className="w-3.5 h-3.5 text-rose-400" />
                <span>Sign Out</span>
              </button>
            </>
          ) : isAdminLoggedIn ? (
            <button
              id="nav-admin-erp-btn"
              onClick={() => openUnifiedLoginModal()}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white ring-2 ring-emerald-400/30 transition-all cursor-pointer shadow-sm"
            >
              <LogIn className="w-3.5 h-3.5 text-white" />
              <span>Admin ERP (Logged In)</span>
              <span className="flex items-center gap-1 text-[10px] bg-emerald-950/40 text-emerald-200 border border-emerald-400/30 px-1.5 py-0.2 rounded font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-300 animate-pulse"></span>
                Admin
              </span>
            </button>
          ) : (
            <button
              id="nav-login-btn"
              onClick={() => openUnifiedLoginModal()}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white hover:shadow-indigo-600/30 transition-all transform hover:scale-[1.02] cursor-pointer shadow-sm"
            >
              <LogIn className="w-3.5 h-3.5 text-white" />
              <span>Login</span>
              <span className="text-[10px] bg-white/20 text-white px-1.5 py-0.2 rounded font-mono">
                Portal
              </span>
            </button>
          )}
        </div>

        {/* Mobile menu toggle */}
        <div className="flex items-center gap-2 lg:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-slate-300 hover:bg-slate-800 cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </header>

      {/* Mobile dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-700 bg-[#1E293B] p-4 space-y-3 shadow-xl z-40">
          <div className="space-y-1.5">
            <button
              onClick={() => {
                setActiveTab('website');
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left p-2.5 rounded-lg text-xs font-semibold ${
                activeTab === 'website' ? 'bg-indigo-600 text-white' : 'text-slate-300'
              }`}
            >
              Public Website
            </button>
            <button
              onClick={() => {
                setActiveTab('courses');
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center justify-between p-2.5 rounded-lg text-xs font-semibold ${
                activeTab === 'courses' ? 'bg-indigo-600 text-white' : 'text-slate-300'
              }`}
            >
              <span>Courses & Syllabus</span>
              {hasActiveDiscounts && (
                <span className="px-1.5 py-0.5 rounded-full text-[9px] font-black bg-gradient-to-r from-red-600 to-rose-600 text-amber-200 border border-amber-400/40 uppercase tracking-wider">
                  Discount Offers
                </span>
              )}
            </button>
            <button
              onClick={() => {
                setActiveTab('faculty');
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left p-2.5 rounded-lg text-xs font-semibold ${
                activeTab === 'faculty' ? 'bg-indigo-600 text-white' : 'text-slate-300'
              }`}
            >
              Faculty & Educators
            </button>
            <button
              onClick={() => {
                setActiveTab('admission');
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left p-2.5 rounded-lg text-xs font-semibold ${
                activeTab === 'admission' ? 'bg-indigo-600 text-white' : 'text-slate-300'
              }`}
            >
              Online Admission Application
            </button>
            <button
              onClick={() => {
                setActiveTab('playzone');
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left p-2.5 rounded-lg text-xs font-semibold ${
                activeTab === 'playzone' ? 'bg-indigo-600 text-white' : 'text-indigo-300'
              }`}
            >
              Coding Playzone (C, Python, HTML, SQL)
            </button>

            {/* Mobile Direct Download Option */}
            <a
              id="mobile-direct-download-btn"
              href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
              download="PixelPathsala.apk"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full flex items-center justify-between p-2.5 rounded-lg text-xs font-bold bg-gradient-to-r from-emerald-900/90 via-teal-900/70 to-slate-800 text-emerald-200 border border-emerald-500/40 shadow-xs transition-all hover:text-white"
            >
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>Download Mobile App</span>
                <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-emerald-500 text-slate-950 uppercase tracking-wider">
                  .APK
                </span>
              </div>
              <Download className="w-3.5 h-3.5 text-emerald-300" />
            </a>
          </div>

          {/* Mobile Direct Contact Quick Tabs */}
          <div className="pt-3 border-t border-slate-700 space-y-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block px-1">
              Direct Contact & Chat:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <a
                href={getWhatsAppUrl(centerInfo.whatsapp || centerInfo.phonePrimary, centerInfo.name)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>WhatsApp</span>
              </a>
              <a
                href={getPhoneTelUrl(centerInfo.phonePrimary)}
                className="flex items-center justify-center gap-1.5 p-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Call Helpline</span>
              </a>
            </div>
          </div>

          {/* Mobile Single Unified Login / Logout Buttons */}
          <div className="pt-3 border-t border-slate-700 space-y-2">
            {currentStudent ? (
              <>
                <button
                  id="mobile-student-portal-btn"
                  onClick={() => {
                    setActiveTab('student-portal');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white transition-colors cursor-pointer shadow-md"
                >
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-indigo-300" />
                    <span>Open Student Portal ({currentStudent.name.split(' ')[0]})</span>
                  </div>
                  <span className="text-[10px] bg-indigo-950/60 text-indigo-200 px-2 py-0.5 rounded font-mono">
                    {currentStudent.studentClass || 'Active'}
                  </span>
                </button>

                <button
                  id="mobile-student-logout-btn"
                  onClick={() => {
                    logoutStudent();
                    setActiveTab('website');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-center gap-2 p-2.5 rounded-xl text-xs font-bold bg-rose-950/70 hover:bg-rose-900 text-rose-200 border border-rose-500/40 transition-colors cursor-pointer shadow-xs"
                >
                  <LogOut className="w-4 h-4 text-rose-400" />
                  <span>Sign Out from Student Portal</span>
                </button>
              </>
            ) : (
              <button
                id="mobile-login-btn"
                onClick={() => {
                  openUnifiedLoginModal();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 p-3 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white transition-colors cursor-pointer shadow-md"
              >
                <LogIn className="w-4 h-4" />
                <span>
                  {isAdminLoggedIn 
                    ? 'Admin ERP Session (Active)' 
                    : 'Login (Student / Admin)'}
                </span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Main Tab Content */}
      <main className="flex-1 w-full">
        {activeTab === 'website' && (
          <div>
            <Hero />
            <CourseCatalog />
            <PublicLiveClassShowcase />
            <FacultyList />
            <CenterInfoSection />
          </div>
        )}

        {activeTab === 'courses' && (
          <div className="py-6">
            <CourseCatalog />
          </div>
        )}

        {activeTab === 'faculty' && (
          <div className="py-6">
            <FacultyList />
          </div>
        )}

        {activeTab === 'admission' && <AdmissionForm />}

        {activeTab === 'playzone' && <Playzone />}

        {activeTab === 'student-portal' && <StudentPortal />}

        {activeTab === 'api-docs' && (isAdminLoggedIn ? <ApiAndApkHub /> : <StudentPortal />)}

        {activeTab === 'admin' && (isAdminLoggedIn ? <AdminLayout /> : <AdminLogin />)}
      </main>

      {/* Floating Interactive WhatsApp & Call Tab on Public Screens */}
      {activeTab !== 'admin' && (
        <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-2.5">
          <a
            id="floating-whatsapp-btn"
            href={getWhatsAppUrl(centerInfo.whatsapp || centerInfo.phonePrimary, centerInfo.name)}
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-2.5 px-4 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm rounded-full shadow-2xl shadow-emerald-600/40 hover:shadow-emerald-600/60 transition-all transform hover:scale-105 cursor-pointer border border-emerald-400/40"
            title="Chat directly with Pixel Pathsala on WhatsApp"
          >
            <span className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
              <MessageCircle className="w-4 h-4 fill-current" />
            </span>
            <span className="tracking-tight">Chat on WhatsApp</span>
            <span className="w-2 h-2 rounded-full bg-emerald-300 animate-ping"></span>
          </a>
        </div>
      )}

      {/* Footer in Professional Slate */}
      <footer className="bg-[#1E293B] text-slate-400 text-xs border-t border-slate-800 mt-16 pt-12 pb-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-3 text-white font-bold text-base mb-2">
              <CenterLogo size="sm" />
              <span>{centerInfo.name}</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed mb-3">
              {centerInfo.tagline}. Dedicated to holistic academic coaching for school syllabus, competitive entrance tests, and programming foundations.
            </p>
            <div className="text-[11px] text-slate-500 font-medium">
              Established {centerInfo.establishedYear} • Direct Academic Admissions
            </div>
          </div>

          <div>
            <h4 className="font-bold text-white mb-3 text-xs uppercase tracking-wider text-slate-300">Institute Links</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => setActiveTab('website')} className="hover:text-white transition cursor-pointer">
                  Public Website & Notices
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('courses')} className="hover:text-white transition cursor-pointer">
                  Courses & Curriculum
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('faculty')} className="hover:text-white transition cursor-pointer">
                  Faculty & Educators
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('admission')} className="hover:text-white transition cursor-pointer">
                  Student Online Admission
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('playzone')} className="hover:text-white transition cursor-pointer">
                  Coding Playzone (C, Python, SQL)
                </button>
              </li>
              <li>
                <a
                  href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
                  download="PixelPathsala.apk"
                  className="hover:text-emerald-300 transition cursor-pointer flex items-center gap-1.5 text-emerald-400 font-semibold"
                >
                  <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download Mobile App (.APK)</span>
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-3 text-xs uppercase tracking-wider text-slate-300">Portals & Login</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => openUnifiedLoginModal('student')} 
                  className="hover:text-white transition cursor-pointer flex items-center gap-1.5"
                >
                  <User className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Student Portal (Login)</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => openUnifiedLoginModal('admin')} 
                  className="hover:text-white transition cursor-pointer flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Admin ERP Access</span>
                </button>
              </li>
              <li>
                <a 
                  href={getDirectApkDownloadUrl(centerInfo.apkDownloadUrl || centerInfo.appDownloadUrl) || '/api/download-apk'}
                  download="PixelPathsala.apk"
                  className="hover:text-white transition cursor-pointer flex items-center gap-1.5 text-slate-300"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Direct APK Download</span>
                </a>
              </li>
              <li>
                <span className="text-slate-400">Official UPI: <strong className="text-indigo-400 font-mono">{centerInfo.upiId}</strong></span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-3 text-xs uppercase tracking-wider text-slate-300">Interactive Reach</h4>
            <div className="space-y-2.5 text-xs text-slate-300">
              <p className="text-slate-400">{centerInfo.address}, {centerInfo.cityState}</p>
              
              {/* Interactive WhatsApp Footer Tab */}
              <a
                href={getWhatsAppUrl(centerInfo.whatsapp || centerInfo.phonePrimary, centerInfo.name)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-emerald-400 hover:text-emerald-300 font-bold transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5 fill-current shrink-0" />
                <span>WhatsApp: {centerInfo.whatsapp || centerInfo.phonePrimary}</span>
              </a>

              {/* Interactive Helpline Footer Tab */}
              <a
                href={getPhoneTelUrl(centerInfo.phonePrimary)}
                className="flex items-center gap-2 text-indigo-300 hover:text-indigo-200 font-semibold transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5 shrink-0" />
                <span>Call: {centerInfo.phonePrimary}</span>
              </a>

              {/* Interactive Email Footer Tab */}
              <a
                href={getEmailMailtoUrl(centerInfo.email, centerInfo.name)}
                className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors truncate"
              >
                <Mail className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{centerInfo.email}</span>
              </a>

              {/* Facebook Page */}
              {centerInfo.facebookUrl && (
                <a
                  href={centerInfo.facebookUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-blue-400 hover:text-blue-300 font-semibold transition-colors"
                >
                  <Globe className="w-3.5 h-3.5 shrink-0" />
                  <span>Facebook: {centerInfo.name}</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              )}

              {/* YouTube Channel */}
              {centerInfo.youtubeUrl && (
                <a
                  href={centerInfo.youtubeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-rose-400 hover:text-rose-300 font-semibold transition-colors"
                >
                  <Code2 className="w-3.5 h-3.5 shrink-0" />
                  <span>YouTube: Video Classes & Demos</span>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              )}
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 border-t border-slate-800 flex flex-col sm:flex-row justify-center items-center gap-2 text-[10px] text-slate-400">
          <div>
            {centerInfo.name} Management System &copy; {new Date().getFullYear()} &bull; Professional Academic ERP
          </div>
        </div>
      </footer>

      {/* Global Unified Login Modal (Dual-Option: Student / Admin) */}
      <UnifiedLoginModal />

      {/* Global Printable A4 Receipt Modal */}
      <PrintReceiptModal 
        payment={selectedReceiptForPrint} 
        onClose={() => setSelectedReceiptForPrint(null)} 
      />
    </div>
  );
}

export function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;

