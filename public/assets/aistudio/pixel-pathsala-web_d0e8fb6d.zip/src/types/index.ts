export type StudentStatus = 'active' | 'passed_out' | 'dropped';

export type PaymentMode = 'UPI' | 'CASH' | 'ONLINE_GATEWAY' | 'BANK_TRANSFER';

export type PaymentStatus = 'approved' | 'pending' | 'rejected';

export interface CenterInfo {
  name: string;
  tagline: string;
  logoUrl?: string;
  bgUrl?: string;
  address: string;
  cityState: string;
  phonePrimary: string;
  phoneSecondary?: string;
  whatsapp?: string;
  email: string;
  upiId: string;
  upiName: string;
  regNumber?: string;
  establishedYear: string;
  admissionOpen: boolean;
  isAdmissionsOpen?: boolean;
  announcement?: string;
  welcomeMessage: string;
  facebookUrl?: string;
  youtubeUrl?: string;
  apkDownloadUrl?: string;
  appDownloadUrl?: string;
  googleSheetId?: string;
  googleSheetAutoSync?: boolean;
  googleSheetLastSynced?: string;
  googleSheetWebhookUrl?: string;
  googleSheetAutoWriteBack?: boolean;
  googleSheetWebhookLastStatus?: string;
}

export interface GoogleSheetsConfig {
  sheetId: string;
  spreadsheetUrl: string;
  title: string;
  autoSync: boolean;
  lastSynced?: string;
  isConnected: boolean;
  sheetsList?: string[];
  webhookUrl?: string;
  autoWriteBack?: boolean;
  lastWebhookStatus?: string | {
    success: boolean;
    timestamp: string;
    message: string;
  };
}

export interface Educator {
  id: string;
  name: string;
  qualification: string;
  subject: string;
  phone: string;
  email?: string;
  monthlySalary: number;
  assignedBatchIds: string[];
  photoUrl?: string;
  experienceYears: number;
  joiningDate?: string;
  joinDate?: string;
  status: 'active' | 'inactive';
}

export interface Course {
  id: string;
  title: string;
  code: string;
  academicClass: string; // e.g. "Class 8", "Class 9", "Class 10", "Class 11", "Class 12", "BCA / College", "Foundation & Coding"
  category?: string; // Optional legacy category
  monthlyFee: number;
  description: string;
  syllabusPoints: string[];
  highlights: string[];
  isPopular?: boolean;
  showOnWebsite: boolean;
  createdAt?: string;
}

export interface Batch {
  id: string;
  name: string;
  courseId: string;
  academicClass?: string; // e.g. "Class 10 (Secondary)", "Class 11 (Science)", "BCA / B.Sc (Computer Science)"
  educatorId: string;
  scheduleDays: string[]; // e.g. ['Mon', 'Wed', 'Fri']
  timing: string; // e.g. '05:00 PM - 06:30 PM'
  roomNumber: string;
  maxCapacity: number;
  isActive: boolean;
  startDate: string;
  mode?: 'offline' | 'online'; // Mode selector: Offline Classroom or Online Live
}

export interface Student {
  id: string;
  rollNo: string;
  name: string;
  studentClass?: string; // e.g. "Class 10 (Secondary)", "Class 11 (Science)", "BCA / B.Sc"
  mode?: 'offline' | 'online' | 'hybrid'; // Learning / Attendance mode: Offline Classroom, Online Live, Hybrid
  mobile: string;
  aadhaarNo: string;
  email?: string;
  guardianName: string;
  guardianPhone: string;
  address: string;
  courseId: string;
  batchId: string;
  admissionDate: string; // YYYY-MM-DD
  admissionMonth: string; // YYYY-MM e.g. '2025-04'
  status: StudentStatus;
  notes?: string;
  photoUrl?: string;
  customMonthlyFeeOverride?: number; // optional fee override
}

export interface Discount {
  id: string;
  title: string;
  type: 'percentage' | 'flat';
  value: number; // e.g., 20 for 20% or 200 for ₹200 flat off
  scope: 'all' | 'class' | 'course' | 'batch' | 'student';
  academicClass?: string; // for scope === 'class' or filtering
  courseId?: string; // for scope === 'course'
  batchId?: string; // for scope === 'batch'
  studentId?: string; // for scope === 'student'
  applicableMonthsType: 'all_months' | 'selected_months';
  selectedMonths?: string[]; // e.g. ['2026-04', '2026-05']
  active: boolean;
  reason?: string;
  createdAt: string;
}

export interface FeePayment {
  id: string;
  receiptNo: string;
  studentId: string;
  studentName: string;
  studentAadhaar: string;
  studentMobile: string;
  courseTitle: string;
  batchName: string;
  month: string; // Display month e.g. "April 2026" or primary month
  monthsCovered: string[]; // List of YYYY-MM
  baseMonthlyFee: number;
  totalBaseFee: number;
  totalDiscount: number;
  discountBreakdown?: string;
  finalAmountPaid: number;
  remainingDue: number;
  paymentMode: PaymentMode;
  transactionRef?: string; // UTR or receipt reference
  status: PaymentStatus;
  rejectionReason?: string;
  paymentDate: string; // YYYY-MM-DD
  approvedBy?: string;
  remarks?: string;
  createdAt: string;
}

export type ExpenseCategory = 
  | 'Educator Salary'
  | 'Center Rent'
  | 'Electricity & Utilities'
  | 'Study Material & Printing'
  | 'Software, Hosting & SMS'
  | 'Marketing & Banners'
  | 'Stationery & Assets'
  | 'Maintenance & Cleaning'
  | 'Refreshments'
  | 'Miscellaneous';

export interface Expense {
  id: string;
  title: string;
  category: ExpenseCategory;
  amount: number;
  date: string; // YYYY-MM-DD
  paidTo: string;
  paymentMode: PaymentMode;
  receiptNo?: string;
  notes?: string;
}

export interface AdmissionApplication {
  id: string;
  applicationNo: string;
  studentName: string;
  studentClass?: string; // e.g. "Class 10 (Secondary)", "Class 11 (Science)", "BCA / B.Sc"
  mobile: string;
  aadhaarNo: string;
  email?: string;
  guardianName: string;
  guardianPhone: string;
  address: string;
  targetCourseId: string;
  preferredBatchId?: string;
  previousSchoolOrCollege?: string;
  previousSchool?: string;
  remarks?: string;
  baseFee?: number;
  appliedDiscountAmount?: number;
  appliedDiscountNotes?: string;
  initialPaymentStatus: 'unpaid' | 'paid_advance' | 'at_center';
  initialPaymentMode?: PaymentMode;
  initialPaymentRef?: string;
  initialPaymentAmount?: number;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  appliedDate: string;
  processedDate?: string;
}

export interface StudyMaterial {
  id: string;
  title: string;
  description?: string;
  batchId: string; // 'all' or specific batch id
  courseId: string; // 'all' or specific course id
  subject?: string;
  fileType: 'pdf' | 'doc' | 'zip' | 'link' | 'image' | 'video' | 'other';
  fileUrl: string; // Base64 data URL or web link
  fileName: string;
  fileSize?: string; // e.g. "2.4 MB"
  uploadedBy: string; // Admin or Educator name
  uploadedDate: string; // YYYY-MM-DD
  downloadCount?: number;
}

export interface PlayzoneProblem {
  id: string;
  language: 'c' | 'python' | 'html' | 'sql';
  title: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  category: string;
  description: string;
  starterCode: string;
  solutionCode?: string;
  hints?: string[];
  expectedOutput?: string;
  testCases?: { input: string; output: string }[];
}

export interface AdminAccount {
  id: string;
  username: string;
  password: string;
  name: string;
  role: string;
  email: string;
  phone?: string;
  securityPin?: string;
  status: 'active' | 'suspended';
  lastLogin?: string;
  updatedAt: string;
}

export interface StudentMonthDueStatus {
  monthKey: string; // YYYY-MM
  monthLabel: string; // e.g. "April 2026"
  baseFee: number;
  discountAmount: number;
  discountNote?: string;
  netFeeDue: number;
  isPaid: boolean;
  isAdvancePaid?: boolean;
  paidAmount?: number;
  paymentId?: string;
  paymentReceiptNo?: string;
  paymentDate?: string;
  isPendingApproval?: boolean;
  pendingPaymentId?: string;
}

export interface StudentBillingSummary {
  monthlyStatuses: StudentMonthDueStatus[];
  totalPayableSinceAdmission: number;
  totalPaid: number;
  totalPendingApproval: number;
  totalDueAmount: number;
  totalDiscountAvailed?: number;
  unpaidMonthsCount: number;
  monthsCoveredCount?: number;
  advanceAmount?: number;
  advanceMonthsCount?: number;
}

export interface ExamQuestion {
  id: string;
  courseId: string; // Target course or 'all'
  academicClass?: string; // e.g. "Class 10 (Secondary)", "Class 11 (Science)"
  subject: string; // e.g. "Computer Science", "Python", "Physics", "Mathematics"
  topic: string; // e.g. "Loops & Pointers", "OOP", "Calculus"
  questionText: string;
  codeSnippet?: string; // Optional code snippet
  options: string[]; // 4 options
  correctOptionIndex: number; // 0, 1, 2, or 3
  explanation?: string;
  marks: number; // e.g. 1, 2, 4
  difficulty: 'easy' | 'medium' | 'hard';
  createdAt: string;
}

export interface OnlineExam {
  id: string;
  title: string;
  examCode: string; // e.g. "EXAM-PY-101"
  courseId: string; // 'all' or specific course
  batchId: string; // 'all' or specific batch id
  academicClass?: string;
  subject: string;
  durationMinutes: number; // e.g. 30, 45, 60
  totalMarks: number;
  passingMarks: number; // e.g. 10
  passingPercentage?: number; // e.g. 40
  questionIds: string[];
  instructions?: string;
  status: 'scheduled' | 'active' | 'completed' | 'draft';
  scheduledDate: string; // YYYY-MM-DD
  startTime: string; // e.g. '10:00 AM'
  endTime: string; // e.g. '08:00 PM'
  isPublished: boolean;
  mode?: 'online' | 'offline';
  createdAt: string;
}

export interface ExamSubmission {
  id: string;
  examId: string;
  examTitle: string;
  studentId: string;
  studentName: string;
  studentRollNo?: string;
  studentRoll?: string;
  studentAadhaar?: string;
  courseId?: string;
  batchId?: string;
  answers: Record<string, number>; // questionId -> selectedOptionIndex (0-3)
  questionBreakdown: Array<{
    questionId: string;
    selectedOptionIndex: number | null;
    correctOptionIndex: number;
    isCorrect: boolean;
    marks: number;
  }>;
  score: number;
  totalMarks: number;
  percentage: number;
  passed: boolean;
  submittedAt: string;
  timeSpentSeconds: number;
  timeTakenMinutes?: number;
}

export type QuestionBankItem = ExamQuestion;

export type LiveClassPlatform = 'in_app' | 'google_meet' | 'zoom' | 'jitsi' | 'youtube_live' | 'custom';
export type LiveClassStatus = 'scheduled' | 'live' | 'completed' | 'cancelled' | 'postponed';
export type VideoSourceType = 'youtube' | 'drive' | 'mp4' | 'vimeo' | 'embed';

export interface LiveClassSession {
  id: string;
  title: string;
  targetClass?: string; // e.g. "Class 10 (Secondary)", "Class 11 Science", "All Classes"
  academicClass?: string; // Alias for targetClass
  subject?: string;
  courseId: string;
  batchId: string;
  educatorId?: string;
  educatorName?: string;
  description?: string;
  scheduledDate: string; // YYYY-MM-DD
  startTime: string; // e.g. "05:00 PM"
  endTime: string; // e.g. "06:30 PM"
  status: LiveClassStatus;
  platform: LiveClassPlatform;
  meetingUrl?: string; // External meeting link or stream
  meetingPassword?: string;
  inAppRoomId?: string; // e.g. "pixel-class-web-dev"
  isRecordingAvailable?: boolean;
  recordingId?: string;
  recordingUrl?: string;
  // Postponement & Reschedule Tracking
  isPostponed?: boolean;
  postponedReason?: string;
  originalDate?: string;
  originalStartTime?: string;
  originalEndTime?: string;
  rescheduledDate?: string;
  rescheduledStartTime?: string;
  rescheduledEndTime?: string;
  postponedAt?: string;
  // Notification & Venue
  notificationSent?: boolean;
  notificationSentAt?: string;
  mode?: 'online' | 'offline' | 'hybrid';
  roomNumber?: string;
  createdAt: string;
}

export type NotificationType = 'class_scheduled' | 'class_postponed' | 'class_rescheduled' | 'class_live' | 'general';

export interface StudentNotification {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  courseId?: string;
  batchId?: string; // 'all' or batch id
  studentId?: string; // 'all' or student id
  classSessionId?: string;
  classTitle?: string;
  scheduledDate?: string;
  rescheduledDate?: string;
  timeSlot?: string;
  reason?: string;
  createdAt: string;
  readBy?: string[]; // array of student ids who acknowledged/read
}

export interface ClassRecording {
  id: string;
  sessionId?: string;
  title: string;
  targetClass?: string;
  academicClass?: string;
  subject?: string;
  topic?: string;
  chapter?: string;
  courseId: string;
  batchId: string;
  educatorName?: string;
  recordedDate: string; // YYYY-MM-DD
  durationMinutes: number; // e.g. 60
  videoSourceType: VideoSourceType;
  videoUrl: string; // YouTube URL/ID, Drive preview URL, direct MP4 URL or embed
  thumbnailUrl?: string;
  notesPdfUrl?: string; // downloadable study material / lecture notes
  description?: string;
  viewCount?: number;
  tags?: string[];
  createdAt: string;
}

export interface FullDatabaseBackup {
  backupVersion: string;
  exportedAt: string;
  appTitle: string;
  centerInfo: CenterInfo;
  students: Student[];
  admissions: AdmissionApplication[];
  payments: FeePayment[];
  courses: Course[];
  batches: Batch[];
  educators: Educator[];
  expenses: Expense[];
  discounts: Discount[];
  adminAccounts: AdminAccount[];
  studyMaterials: StudyMaterial[];
  questions: ExamQuestion[];
  exams: OnlineExam[];
  examSubmissions: ExamSubmission[];
  liveClasses?: LiveClassSession[];
  classRecordings?: ClassRecording[];
  notifications?: StudentNotification[];
  summaryCounts?: {
    students: number;
    admissions: number;
    payments: number;
    courses: number;
    batches: number;
    educators: number;
    expenses: number;
    discounts: number;
    adminAccounts: number;
    studyMaterials: number;
    questions: number;
    exams: number;
    examSubmissions: number;
    liveClasses?: number;
    classRecordings?: number;
  };
}


