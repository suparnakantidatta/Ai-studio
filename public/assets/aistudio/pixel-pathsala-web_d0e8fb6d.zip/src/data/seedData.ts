import { 
  CenterInfo, 
  Course, 
  Educator, 
  Batch, 
  Student, 
  Discount, 
  FeePayment, 
  Expense, 
  AdmissionApplication,
  PlayzoneProblem,
  StudyMaterial,
  ExamQuestion,
  OnlineExam,
  ExamSubmission,
  LiveClassSession,
  ClassRecording,
  StudentNotification
} from '../types';

export const INITIAL_CENTER_INFO: CenterInfo = {
  name: 'Pixel Pathsala',
  tagline: 'Code your dream, decode the future',
  logoUrl: 'https://lh3.googleusercontent.com/gps-cs-s/AHRPTWmkXJcvkJ81xwi4NxqpKxQtoyMrzY2k1dOryC5CWeY0bBVUxfHpORGdJ1W2wUYA8IR0y05v1RfvCb4McybkreQUJqtTNZCd9nT9b0zB7uelTL-7B5z7M1aqR9mDohOwKNOYF5qjO2RbDeN1=s1360-w1360-h1020-rw',
  bgUrl: 'https://lh3.googleusercontent.com/gps-cs-s/AHRPTWkosGLnTUdSyNjD_qft1aTOQPyOnPZB0uy5j8dFgel7_leZVbbYyp_fjEkkRgsBF2C1512ZGpjzyCo0TBbLKl88Zx2eSYZHiuNJMx370aU9glHDJt3v48cFDsZR-ulR6OsHByk3KXJauy8T=s1360-w1360-h1020-rw',
  address: 'Raina Main Road, Near Bus Stand',
  cityState: 'Raina, Purba Bardhaman (Burdwan), West Bengal - 713424',
  phonePrimary: '+91 7908457219',
  phoneSecondary: '+91 9832014567',
  whatsapp: '+91 9775708722',
  email: 'pixelpathsala.edu@gmail.com',
  upiId: '9775708722@apl',
  upiName: 'Pixel Pathsala Center',
  establishedYear: '2021',
  admissionOpen: true,
  announcement: '📢 Admissions Open for Session 2026-27! Free Registration • Special Early-Bird & Merit Discounts available on all Batches.',
  welcomeMessage: 'Welcome to Pixel Pathsala — Premier Institute for Classwise School & College Syllabus, Competitive Exams, and Interactive Coding & DBMS Training.',
  facebookUrl: 'https://facebook.com/pixelpathsala',
  youtubeUrl: 'https://youtube.com/@pixelpathsala',
  apkDownloadUrl: 'https://drive.google.com/file/d/1XexampleApkPixelPathsala/view?usp=sharing',
  appDownloadUrl: 'https://drive.google.com/file/d/1XexampleApkPixelPathsala/view?usp=sharing'
};

export const INITIAL_EDUCATORS: Educator[] = [
  {
    id: 'edu-1',
    name: 'Prof. Subhasish Mukherjee',
    qualification: 'M.Tech (Computer Science), GATE Qualified',
    subject: 'Computer Science, C, Python & DBMS',
    phone: '9832104561',
    email: 'subhasish.cs@pixelpathsala.com',
    monthlySalary: 32000,
    assignedBatchIds: ['batch-1', 'batch-4'],
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    experienceYears: 9,
    joiningDate: '2022-01-15',
    status: 'active'
  },
  {
    id: 'edu-2',
    name: 'Dr. Ananya Roy',
    qualification: 'Ph.D. in Mathematics, Jadavpur University',
    subject: 'Higher Mathematics & JEE Advanced Prep',
    phone: '9832298712',
    email: 'ananya.maths@pixelpathsala.com',
    monthlySalary: 35000,
    assignedBatchIds: ['batch-2', 'batch-3'],
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
    experienceYears: 11,
    joiningDate: '2022-04-01',
    status: 'active'
  },
  {
    id: 'edu-3',
    name: 'Er. Rajesh Ghosh',
    qualification: 'B.Tech (ECE), Ex-Fiitjee Faculty',
    subject: 'Physics (Class 11, 12 & NEET/JEE)',
    phone: '9748561234',
    email: 'rajesh.physics@pixelpathsala.com',
    monthlySalary: 30000,
    assignedBatchIds: ['batch-2'],
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    experienceYears: 7,
    joiningDate: '2023-03-10',
    status: 'active'
  },
  {
    id: 'edu-4',
    name: 'Ms. Sharmila Paul',
    qualification: 'M.Sc (Chemistry), B.Ed',
    subject: 'Chemistry & Secondary Science (Class 9-10)',
    phone: '9800456711',
    email: 'sharmila.chem@pixelpathsala.com',
    monthlySalary: 26000,
    assignedBatchIds: ['batch-3'],
    photoUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80',
    experienceYears: 6,
    joiningDate: '2023-07-01',
    status: 'active'
  }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'course-1',
    title: 'Computer Science, C, Python & SQL Masterclass',
    code: 'CS-PRO-101',
    academicClass: 'Class 8-12, BCA & College',
    category: 'Computer Science & Coding',
    monthlyFee: 1200,
    description: 'Comprehensive hands-on programming course covering C logic, Python 3 automation & data structures, Web HTML/CSS basics, and SQL/DBMS database mastery.',
    syllabusPoints: [
      'C Language: Data types, loops, arrays, pointers, dynamic memory & file handling',
      'Python: Object-oriented programming, modules, JSON, file operations & scripting',
      'HTML/CSS/JS: Responsive web pages and UI development fundamentals',
      'DBMS & SQL: ER diagrams, Normalization, DDL, DML, Joins, Subqueries & Transactions'
    ],
    highlights: [
      'Interactive Browser Playzone Access',
      'Live Coding Assessments & Mini Projects',
      'Weekly Doubt Clearing & Dedicated Mentorship'
    ],
    isPopular: true,
    showOnWebsite: true,
    createdAt: '2025-01-10'
  },
  {
    id: 'course-2',
    title: 'Class 11-12 Science & JEE/NEET Integrated Batch',
    code: 'SCI-JEE-202',
    academicClass: 'Class 11 & Class 12 Science',
    category: 'Higher Secondary (11-12)',
    monthlyFee: 2500,
    description: 'Targeted preparation for WBCHSE / CBSE Board Examinations coupled with foundational JEE Main & NEET entrance question solving techniques.',
    syllabusPoints: [
      'Physics: Mechanics, Waves, Electromagnetism, Optics & Modern Physics',
      'Mathematics: Calculus, Coordinate Geometry, Vectors, Algebra & Trigonometry',
      'Chemistry: Physical, Organic Mechanisms & Inorganic Reactions',
      'Weekly Mock Tests with detailed analysis & OMR scoring'
    ],
    highlights: [
      'Chapter-wise Printed DPP & Modules',
      '1-on-1 Mentorship by Expert Faculties',
      'Air-conditioned smart classrooms with projector'
    ],
    isPopular: true,
    showOnWebsite: true,
    createdAt: '2025-01-12'
  },
  {
    id: 'course-3',
    title: 'Class 9-10 Secondary Board Mastery (Maths & Science)',
    code: 'SEC-BD-303',
    academicClass: 'Class 9 & Class 10',
    category: 'School (Class 8-10)',
    monthlyFee: 1500,
    description: 'Complete academic coaching for secondary school students covering Mathematics, Physical Science, and Life Science with rigorous periodic assessments.',
    syllabusPoints: [
      'Mathematics: Arithmetic, Algebra, Geometry, Mensuration & Statistics',
      'Physical Science: Force, Motion, Light, Electricity & Chemical Bonding',
      'Previous 10 Years Board Papers Solution & Answer Writing Drills',
      'Special focus on conceptual clarity and exam confidence'
    ],
    highlights: [
      'Small batch size (max 25 students)',
      'Monthly Progress Report for Parents',
      'Special Sunday revision clinics'
    ],
    isPopular: false,
    showOnWebsite: true,
    createdAt: '2025-01-15'
  },
  {
    id: 'course-4',
    title: 'Web Design, Frontend & Full-Stack Basics',
    code: 'WEB-DEV-404',
    academicClass: 'Class 9-12 & BCA / Diploma',
    category: 'Computer Science & Coding',
    monthlyFee: 1400,
    description: 'Learn modern web crafting with HTML5, modern CSS3, JavaScript ES6+, backend REST APIs, and SQLite database storage with practical capstone websites.',
    syllabusPoints: [
      'HTML5 semantic tags, Forms, Canvas & Media elements',
      'Modern CSS Flexbox, Grid, Animations & Tailwind utility classes',
      'JavaScript DOM Manipulation, Fetch API & Async/Await',
      'Building dynamic real-world interactive apps & hosting'
    ],
    highlights: [
      'Portfolio Ready 4 Real Projects',
      'Pixel Pathsala Certificate on Completion',
      'Code reviews by industry developers'
    ],
    isPopular: false,
    showOnWebsite: true,
    createdAt: '2025-02-01'
  }
];

export const INITIAL_BATCHES: Batch[] = [
  {
    id: 'batch-1',
    name: 'Batch C-Python Coding Alpha (MWF)',
    courseId: 'course-1',
    academicClass: 'Class 11 (Science)',
    educatorId: 'edu-1',
    scheduleDays: ['Mon', 'Wed', 'Fri'],
    timing: '04:30 PM - 06:00 PM',
    roomNumber: 'Lab-1 (Pixel Lab)',
    maxCapacity: 25,
    isActive: true,
    startDate: '2026-04-01',
    mode: 'offline'
  },
  {
    id: 'batch-2',
    name: 'Batch Science & JEE Pinnacle (TTS)',
    courseId: 'course-2',
    academicClass: 'Class 12 (Science)',
    educatorId: 'edu-2',
    scheduleDays: ['Tue', 'Thu', 'Sat'],
    timing: '05:30 PM - 07:30 PM',
    roomNumber: 'Hall-A (Smart Room)',
    maxCapacity: 30,
    isActive: true,
    startDate: '2026-04-01',
    mode: 'offline'
  },
  {
    id: 'batch-3',
    name: 'Batch Secondary Champions Class 10 (Daily)',
    courseId: 'course-3',
    academicClass: 'Class 10 (Secondary)',
    educatorId: 'edu-4',
    scheduleDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    timing: '06:30 PM - 08:00 PM',
    roomNumber: 'Room-201',
    maxCapacity: 25,
    isActive: true,
    startDate: '2026-04-01',
    mode: 'offline'
  },
  {
    id: 'batch-4',
    name: 'Batch Web & DBMS Weekend Fast-track',
    courseId: 'course-4',
    academicClass: 'BCA / B.Sc (Computer Science)',
    educatorId: 'edu-1',
    scheduleDays: ['Sat', 'Sun'],
    timing: '10:00 AM - 01:00 PM',
    roomNumber: 'Lab-2',
    maxCapacity: 20,
    isActive: true,
    startDate: '2026-05-01',
    mode: 'online'
  }
];

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'stu-101',
    rollNo: 'PP-2026-001',
    name: 'Rohan Sharma',
    studentClass: 'Class 11 (Science)',
    mode: 'offline',
    mobile: '9876543210',
    aadhaarNo: '4532 8901 2345',
    email: 'rohan.sharma@example.com',
    guardianName: 'Manoj Sharma',
    guardianPhone: '9876543211',
    address: 'Station Road, Raina, Purba Bardhaman',
    courseId: 'course-1',
    batchId: 'batch-1',
    admissionDate: '2026-04-05',
    admissionMonth: '2026-04',
    status: 'active',
    notes: 'Enthusiastic programmer, interested in C pointers and Python algorithms.'
  },
  {
    id: 'stu-102',
    rollNo: 'PP-2026-002',
    name: 'Priyanka Das',
    studentClass: 'Class 12 (Science)',
    mode: 'offline',
    mobile: '9832145678',
    aadhaarNo: '7890 1234 5678',
    email: 'priyanka.das@example.com',
    guardianName: 'Soumen Das',
    guardianPhone: '9832145679',
    address: 'Burdwan Town, Purba Bardhaman',
    courseId: 'course-2',
    batchId: 'batch-2',
    admissionDate: '2026-04-10',
    admissionMonth: '2026-04',
    status: 'active',
    notes: 'Aiming for JEE Advanced 2027.'
  },
  {
    id: 'stu-103',
    rollNo: 'PP-2026-003',
    name: 'Aniket Sengupta',
    studentClass: 'Class 10 (Secondary)',
    mode: 'offline',
    mobile: '9748901234',
    aadhaarNo: '2345 6789 0123',
    email: 'aniket.sen@example.com',
    guardianName: 'Debabrata Sengupta',
    guardianPhone: '9748901235',
    address: 'College Road, Raina, Purba Bardhaman',
    courseId: 'course-3',
    batchId: 'batch-3',
    admissionDate: '2026-05-02',
    admissionMonth: '2026-05',
    status: 'active',
    notes: 'Class 10 student preparing for WBBSE Board.'
  },
  {
    id: 'stu-104',
    rollNo: 'PP-2026-004',
    name: 'Debojyoti Banerjee',
    studentClass: 'Class 11 (Science)',
    mode: 'offline',
    mobile: '9800112233',
    aadhaarNo: '9012 3456 7890',
    email: 'debo.banerjee@example.com',
    guardianName: 'Partha Banerjee',
    guardianPhone: '9800112234',
    address: 'Madhabdihi, Raina, Purba Bardhaman',
    courseId: 'course-1',
    batchId: 'batch-1',
    admissionDate: '2026-04-12',
    admissionMonth: '2026-04',
    status: 'active',
    notes: 'Applied sibling concession.'
  },
  {
    id: 'stu-105',
    rollNo: 'PP-2025-089',
    name: 'Sneha Chakraborty',
    studentClass: 'BCA / B.Sc (Computer Science)',
    mode: 'online',
    mobile: '9733445566',
    aadhaarNo: '5678 9012 3456',
    email: 'sneha.c@example.com',
    guardianName: 'Kalyan Chakraborty',
    guardianPhone: '9733445567',
    address: 'Raina Bazaar, Purba Bardhaman',
    courseId: 'course-1',
    batchId: 'batch-1',
    admissionDate: '2025-06-10',
    admissionMonth: '2025-06',
    status: 'passed_out',
    notes: 'Successfully completed full C & Python syllabus with Distinction.'
  }
];

export const INITIAL_DISCOUNTS: Discount[] = [
  {
    id: 'disc-1',
    title: 'Batch Alpha Early-Bird Concession',
    type: 'flat',
    value: 200, // ₹200 off per month
    scope: 'course',
    courseId: 'course-1',
    applicableMonthsType: 'all_months',
    active: true,
    reason: 'Inaugural coding batch early-bird discount',
    createdAt: '2026-03-25'
  },
  {
    id: 'disc-2',
    title: 'Merit Scholarship - Priyanka Das',
    type: 'percentage',
    value: 20, // 20% off
    scope: 'student',
    studentId: 'stu-102',
    applicableMonthsType: 'all_months',
    active: true,
    reason: 'Scored 96.5% in Class 10 Board Exams',
    createdAt: '2026-04-08'
  },
  {
    id: 'disc-3',
    title: 'Monsoon Special Concession',
    type: 'flat',
    value: 300,
    scope: 'student',
    studentId: 'stu-101',
    applicableMonthsType: 'selected_months',
    selectedMonths: ['2026-07', '2026-08'],
    active: true,
    reason: 'Pixel Hackathon 1st Runner Up voucher',
    createdAt: '2026-06-28'
  },
  {
    id: 'disc-4',
    title: 'JEE / Board Merit Concession',
    type: 'percentage',
    value: 20, // 20% off
    scope: 'course',
    courseId: 'course-2',
    applicableMonthsType: 'all_months',
    active: true,
    reason: 'Special concession for Higher Secondary & Science students',
    createdAt: '2026-04-01'
  },
  {
    id: 'disc-5',
    title: 'Secondary Foundation Scholarship',
    type: 'flat',
    value: 250, // ₹250 flat off
    scope: 'course',
    courseId: 'course-3',
    applicableMonthsType: 'all_months',
    active: true,
    reason: 'Foundation booster concession for Class 9-10',
    createdAt: '2026-04-01'
  }
];

export const INITIAL_PAYMENTS: FeePayment[] = [];

export const INITIAL_EXPENSES: Expense[] = [
  {
    id: 'exp-01',
    title: 'Faculty Salary - July 2026 (Prof. Subhasish)',
    category: 'Educator Salary',
    amount: 32000,
    date: '2026-08-01',
    paidTo: 'Prof. Subhasish Mukherjee',
    paymentMode: 'BANK_TRANSFER',
    receiptNo: 'SAL/2026/07-01',
    notes: 'Monthly faculty compensation'
  },
  {
    id: 'exp-02',
    title: 'Center Premises Rent (August 2026)',
    category: 'Center Rent',
    amount: 22000,
    date: '2026-08-02',
    paidTo: 'Landlord - Heritage Plaza',
    paymentMode: 'BANK_TRANSFER',
    receiptNo: 'RENT/2026/08',
    notes: 'Center floor lease'
  },
  {
    id: 'exp-03',
    title: 'Electricity & AC Utility Bill',
    category: 'Electricity & Utilities',
    amount: 4850,
    date: '2026-08-05',
    paidTo: 'WBSEDCL Electricity Board',
    paymentMode: 'UPI',
    receiptNo: 'WB-ELEC-89912',
    notes: 'Center classrooms & air conditioning electricity'
  },
  {
    id: 'exp-04',
    title: 'C & Python Study Material & DPP Printing',
    category: 'Study Material & Printing',
    amount: 3600,
    date: '2026-08-10',
    paidTo: 'Sunrise Printers Burdwan',
    paymentMode: 'CASH',
    receiptNo: 'PRN/4412',
    notes: '50 sets of Chapter 1-5 printed modules'
  },
  {
    id: 'exp-05',
    title: 'High-speed Fiber Internet & Cloud Practice Server',
    category: 'Software, Hosting & SMS',
    amount: 1499,
    date: '2026-08-12',
    paidTo: 'Airtel Broadband & Cloud',
    paymentMode: 'UPI',
    receiptNo: 'AIR-NET-991',
    notes: '300 Mbps dedicated fiber line'
  }
];

export const INITIAL_ADMISSIONS: AdmissionApplication[] = [
  {
    id: 'adm-01',
    applicationNo: 'APP/2026/108',
    studentName: 'Tanmay Karmakar',
    mobile: '9832998811',
    aadhaarNo: '6789 1234 9012',
    email: 'tanmay.k@gmail.com',
    guardianName: 'Bimal Karmakar',
    guardianPhone: '9832998812',
    address: 'Raina Bazaar, Purba Bardhaman',
    targetCourseId: 'course-1',
    preferredBatchId: 'batch-1',
    previousSchoolOrCollege: 'Raina High School (Class 11)',
    remarks: 'Wants to master C programming and relational SQL for school projects.',
    initialPaymentStatus: 'paid_advance',
    initialPaymentMode: 'UPI',
    initialPaymentRef: 'UPI/9775708722/ADM7781',
    initialPaymentAmount: 1700, // 500 admission + 1200 month fee
    status: 'pending',
    appliedDate: '2026-08-17'
  },
  {
    id: 'adm-02',
    applicationNo: 'APP/2026/109',
    studentName: 'Sayan Roy',
    mobile: '9748332211',
    aadhaarNo: '3456 7890 1234',
    email: 'sayan.roy@gmail.com',
    guardianName: 'Tarun Roy',
    guardianPhone: '9748332212',
    address: 'Burdwan Sadar, Purba Bardhaman',
    targetCourseId: 'course-2',
    preferredBatchId: 'batch-2',
    previousSchoolOrCollege: 'Burdwan CMS High School (Class 11)',
    remarks: 'Preparing for JEE Mains & CBSE Boards.',
    initialPaymentStatus: 'at_center',
    status: 'pending',
    appliedDate: '2026-08-18'
  },
  {
    id: 'adm-03',
    applicationNo: 'APP/2026/105',
    studentName: 'Debojyoti Banerjee',
    mobile: '9800112233',
    aadhaarNo: '9012 3456 7890',
    email: 'debo.banerjee@example.com',
    guardianName: 'Partha Banerjee',
    guardianPhone: '9800112234',
    address: 'Madhabdihi, Raina, Purba Bardhaman',
    targetCourseId: 'course-1',
    preferredBatchId: 'batch-1',
    status: 'approved',
    appliedDate: '2026-04-10',
    processedDate: '2026-04-12',
    initialPaymentStatus: 'paid_advance',
    initialPaymentMode: 'CASH',
    initialPaymentAmount: 1500
  }
];

export const PLAYZONE_PROBLEMS: PlayzoneProblem[] = [
  // C Problems
  {
    id: 'c-1',
    language: 'c',
    title: 'C Program: Check Prime Number & Print Divisors',
    difficulty: 'Beginner',
    category: 'Math & Loops',
    description: 'Write a C program to check whether an integer is prime or composite, and print all its positive factors.',
    starterCode: `#include <stdio.h>
#include <stdbool.h>

int main() {
    int n = 29;
    bool isPrime = true;
    
    printf("Testing number: %d\\n", n);
    
    if (n <= 1) {
        isPrime = false;
    } else {
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                isPrime = false;
                break;
            }
        }
    }
    
    if (isPrime) {
        printf("Result: %d is a PRIME number!\\n", n);
    } else {
        printf("Result: %d is a COMPOSITE number.\\n", n);
    }
    
    printf("Factors of %d are: ", n);
    for (int i = 1; i <= n; i++) {
        if (n % i == 0) {
            printf("%d ", i);
        }
    }
    printf("\\n");
    
    return 0;
}`,
    expectedOutput: `Testing number: 29
Result: 29 is a PRIME number!
Factors of 29 are: 1 29`
  },
  {
    id: 'c-2',
    language: 'c',
    title: 'C Program: Matrix Transpose & Trace Calculation',
    difficulty: 'Intermediate',
    category: '2D Arrays & Pointers',
    description: 'Create a 3x3 square matrix, calculate its transpose matrix and compute the matrix trace (sum of main diagonal elements).',
    starterCode: `#include <stdio.h>

#define N 3

int main() {
    int matrix[N][N] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };
    int transpose[N][N];
    int trace = 0;

    printf("Original Matrix (%dx%d):\\n", N, N);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%3d", matrix[i][j]);
            transpose[j][i] = matrix[i][j];
            if (i == j) {
                trace += matrix[i][j];
            }
        }
        printf("\\n");
    }

    printf("\\nTranspose Matrix:\\n");
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            printf("%3d", transpose[i][j]);
        }
        printf("\\n");
    }

    printf("\\nMatrix Trace (Sum of Diagonal): %d\\n", trace);
    return 0;
}`,
    expectedOutput: `Original Matrix (3x3):
  1  2  3
  4  5  6
  7  8  9

Transpose Matrix:
  1  4  7
  2  5  8
  3  6  9

Matrix Trace (Sum of Diagonal): 15`
  },
  {
    id: 'c-3',
    language: 'c',
    title: 'C Program: Reverse a String using Pointers',
    difficulty: 'Beginner',
    category: 'Pointers & Strings',
    description: 'Demonstrate string reversal in-place using two-pointer technique.',
    starterCode: `#include <stdio.h>
#include <string.h>

void reverseString(char *str) {
    char *start = str;
    char *end = str + strlen(str) - 1;
    char temp;

    while (start < end) {
        temp = *start;
        *start = *end;
        *end = temp;
        start++;
        end--;
    }
}

int main() {
    char word[] = "PixelPathsala";
    printf("Original String : %s\\n", word);
    reverseString(word);
    printf("Reversed String : %s\\n", word);
    return 0;
}`,
    expectedOutput: `Original String : PixelPathsala
Reversed String : alasahtaPlexiP`
  },

  // Python Problems
  {
    id: 'py-1',
    language: 'python',
    title: 'Python: Student Grade Analyzer & Distribution',
    difficulty: 'Beginner',
    category: 'Lists & Dictionaries',
    description: 'Calculate average marks, highest scorer, and count grade distributions (A, B, C) for a batch of students.',
    starterCode: `# Student Marks Dictionary (Name: Score out of 100)
scores = {
    "Rohan": 92,
    "Priyanka": 98,
    "Aniket": 78,
    "Debojyoti": 85,
    "Sneha": 94,
    "Tanmay": 81
}

def get_grade(score):
    if score >= 90:
        return "Grade A+ (Distinction)"
    elif score >= 80:
        return "Grade A (First Class)"
    elif score >= 70:
        return "Grade B (Second Class)"
    else:
        return "Grade C"

print("--- PIXEL PATHSALA SCORE REPORT ---")
total = sum(scores.values())
count = len(scores)
avg = total / count

topper = max(scores, key=scores.get)

for name, score in scores.items():
    print(f"• {name:12}: {score}/100 -> {get_grade(score)}")

print("-----------------------------------")
print(f"Total Students : {count}")
print(f"Batch Average  : {avg:.2f} / 100")
print(f"Batch Topper   : {topper} with {scores[topper]} marks!")
`,
    expectedOutput: `--- PIXEL PATHSALA SCORE REPORT ---
• Rohan       : 92/100 -> Grade A+ (Distinction)
• Priyanka    : 98/100 -> Grade A+ (Distinction)
• Aniket      : 78/100 -> Grade B (Second Class)
• Debojyoti   : 85/100 -> Grade A (First Class)
• Sneha       : 94/100 -> Grade A+ (Distinction)
• Tanmay      : 81/100 -> Grade A (First Class)
-----------------------------------
Total Students : 6
Batch Average  : 88.00 / 100
Batch Topper   : Priyanka with 98 marks!`
  },
  {
    id: 'py-2',
    language: 'python',
    title: 'Python: Fibonacci Generator & List Comprehension',
    difficulty: 'Beginner',
    category: 'Algorithms & Sequences',
    description: 'Generate the first N Fibonacci numbers and filter out even numbers using list comprehension.',
    starterCode: `def fibonacci_series(n):
    series = []
    a, b = 0, 1
    for _ in range(n):
        series.append(a)
        a, b = b, a + b
    return series

terms = 12
fib = fibonacci_series(terms)
print(f"First {terms} Fibonacci numbers:")
print(fib)

# Filter even numbers using list comprehension
even_fib = [x for x in fib if x % 2 == 0]
print(f"\\nEven Fibonacci numbers in sequence:")
print(even_fib)

# Squares of sequence
squares = [x**2 for x in fib[:6]]
print(f"\\nSquares of first 6 terms:")
print(squares)
`,
    expectedOutput: `First 12 Fibonacci numbers:
[0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

Even Fibonacci numbers in sequence:
[0, 2, 8, 34]

Squares of first 6 terms:
[0, 1, 1, 4, 9, 25]`
  },
  {
    id: 'py-3',
    language: 'python',
    title: 'Python: Bank Account Class (OOP)',
    difficulty: 'Intermediate',
    category: 'Object Oriented Programming',
    description: 'Build an object-oriented BankAccount class with deposit, withdraw, and transaction history tracking.',
    starterCode: `class BankAccount:
    def __init__(self, account_holder, initial_balance=0):
        self.holder = account_holder
        self.balance = initial_balance
        self.transactions = [f"Account opened with Rs. {initial_balance}"]

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            self.transactions.append(f"Deposited: +Rs. {amount} (Bal: Rs. {self.balance})")
            print(f"✅ Deposited Rs. {amount} successfully.")
        else:
            print("❌ Invalid deposit amount.")

    def withdraw(self, amount):
        if 0 < amount <= self.balance:
            self.balance -= amount
            self.transactions.append(f"Withdrew:  -Rs. {amount} (Bal: Rs. {self.balance})")
            print(f"✅ Withdrew Rs. {amount} successfully.")
        else:
            print(f"❌ Insufficient funds! Current balance: Rs. {self.balance}")

    def statement(self):
        print(f"\\n=== MINI STATEMENT FOR {self.holder.upper()} ===")
        for tx in self.transactions:
            print("  • " + tx)
        print(f"Total Available Balance: Rs. {self.balance}\\n")

# Testing the class
acc = BankAccount("Rohan Sharma", 5000)
acc.deposit(2000)
acc.withdraw(1500)
acc.withdraw(8000)
acc.statement()
`,
    expectedOutput: `✅ Deposited Rs. 2000 successfully.
✅ Withdrew Rs. 1500 successfully.
❌ Insufficient funds! Current balance: Rs. 5500

=== MINI STATEMENT FOR ROHAN SHARMA ===
  • Account opened with Rs. 5000
  • Deposited: +Rs. 2000 (Bal: Rs. 7000)
  • Withdrew:  -Rs. 1500 (Bal: Rs. 5500)
Total Available Balance: Rs. 5500`
  },

  // HTML / CSS Problems
  {
    id: 'html-1',
    language: 'html',
    title: 'HTML & CSS: Interactive Student Profile Badge',
    difficulty: 'Beginner',
    category: 'Web Design',
    description: 'Design a responsive student ID card with CSS gradients, avatar, status pills, and interactive hover effects.',
    starterCode: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #0f172a;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
    }
    .id-card {
      background: #1e293b;
      border: 1px solid #334155;
      border-radius: 16px;
      width: 320px;
      padding: 24px;
      color: #f8fafc;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5);
      position: relative;
      overflow: hidden;
      transition: transform 0.3s ease;
    }
    .id-card:hover {
      transform: translateY(-4px);
    }
    .header-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      border-bottom: 1px solid #334155;
      padding-bottom: 12px;
    }
    .brand {
      font-weight: 700;
      color: #38bdf8;
      font-size: 14px;
      letter-spacing: 1px;
    }
    .status-pill {
      background: #059669;
      color: #ecfdf5;
      font-size: 11px;
      font-weight: 600;
      padding: 3px 10px;
      border-radius: 999px;
    }
    .avatar-wrapper {
      text-align: center;
      margin-bottom: 16px;
    }
    .avatar {
      width: 80px;
      height: 80px;
      border-radius: 50%;
      background: linear-gradient(135deg, #6366f1, #a855f7);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 32px;
      font-weight: bold;
      color: white;
      border: 3px solid #38bdf8;
    }
    .name {
      font-size: 20px;
      font-weight: 700;
      text-align: center;
      margin: 8px 0 2px 0;
    }
    .roll {
      text-align: center;
      color: #94a3b8;
      font-size: 13px;
      margin-bottom: 16px;
      font-family: monospace;
    }
    .info-row {
      display: flex;
      justify-content: space-between;
      font-size: 13px;
      padding: 8px 0;
      border-top: 1px dashed #334155;
    }
    .info-label {
      color: #94a3b8;
    }
    .info-val {
      font-weight: 600;
      color: #e2e8f0;
    }
    .qr-fake {
      margin-top: 16px;
      text-align: center;
      background: #0f172a;
      padding: 10px;
      border-radius: 8px;
      font-size: 11px;
      color: #38bdf8;
      letter-spacing: 0.5px;
    }
  </style>
</head>
<body>
  <div class="id-card">
    <div class="header-bar">
      <div class="brand">⚡ PIXEL PATHSALA</div>
      <div class="status-pill">ACTIVE</div>
    </div>
    <div class="avatar-wrapper">
      <div class="avatar">RS</div>
      <div class="name">Rohan Sharma</div>
      <div class="roll">ROLL: PP-2026-001</div>
    </div>
    <div class="info-row">
      <span class="info-label">Course:</span>
      <span class="info-val">C & Python Mastery</span>
    </div>
    <div class="info-row">
      <span class="info-label">Batch:</span>
      <span class="info-val">Alpha (MWF 4:30 PM)</span>
    </div>
    <div class="info-row">
      <span class="info-label">Valid Upto:</span>
      <span class="info-val">April 2027</span>
    </div>
    <div class="qr-fake">
      [ VERIFIED STUDENT CREDENTIAL ]
    </div>
  </div>
</body>
</html>`
  },

  // SQL / DBMS Problems
  {
    id: 'sql-1',
    language: 'sql',
    title: 'SQL: Query Students with Course Info & Total Paid Fees (JOIN)',
    difficulty: 'Beginner',
    category: 'SELECT, JOIN & GROUP BY',
    description: 'Write an SQL query to display student name, course title, and calculate total approved fee amount paid by each student using INNER JOIN.',
    starterCode: `-- Pre-loaded database tables:
-- students (id, roll_no, name, mobile, course_id, batch_id, status)
-- courses (id, title, category, monthly_fee)
-- fee_payments (id, student_id, month, amount_paid, status, payment_mode)

SELECT 
    s.roll_no AS "Roll Number",
    s.name AS "Student Name",
    c.title AS "Enrolled Course",
    c.monthly_fee AS "Monthly Fee (Rs.)",
    COALESCE(SUM(p.amount_paid), 0) AS "Total Fees Paid (Rs.)",
    COUNT(p.id) AS "Total Receipts"
FROM students s
INNER JOIN courses c ON s.course_id = c.id
LEFT JOIN fee_payments p ON s.id = p.student_id AND p.status = 'approved'
WHERE s.status = 'active'
GROUP BY s.id, s.roll_no, s.name, c.title, c.monthly_fee
ORDER BY "Total Fees Paid (Rs.)" DESC;
`,
    expectedOutput: `Running query on Pixel Pathsala Relational Database...`
  },
  {
    id: 'sql-2',
    language: 'sql',
    title: 'SQL: Find Batches with Capacity and Educator Details',
    difficulty: 'Beginner',
    category: 'JOIN & Aggregation',
    description: 'Join batches table with educators and courses to find the schedule and teacher in charge.',
    starterCode: `SELECT 
    b.name AS "Batch Name",
    c.title AS "Course",
    e.name AS "Faculty In-Charge",
    e.qualification AS "Qualification",
    b.timing AS "Schedule Timing",
    b.room_number AS "Room",
    b.max_capacity AS "Seats"
FROM batches b
JOIN courses c ON b.course_id = c.id
JOIN educators e ON b.educator_id = e.id
WHERE b.is_active = 1;
`
  },
  {
    id: 'sql-3',
    language: 'sql',
    title: 'SQL: Center Profit & Loss Summary (Aggregations)',
    difficulty: 'Intermediate',
    category: 'Subqueries & Summary',
    description: 'Calculate total approved fee income vs total center expenses and compute the net balance.',
    starterCode: `SELECT 
    (SELECT SUM(amount_paid) FROM fee_payments WHERE status = 'approved') AS "Total Fee Revenue (Rs.)",
    (SELECT SUM(amount) FROM expenses) AS "Total Center Expenses (Rs.)",
    (
      (SELECT SUM(amount_paid) FROM fee_payments WHERE status = 'approved') - 
      (SELECT SUM(amount) FROM expenses)
    ) AS "Net Center Balance (Rs.)";
`
  },
  {
    id: 'sql-4',
    language: 'sql',
    title: 'SQL: Practice Custom DDL & DML (CREATE TABLE & INSERT)',
    difficulty: 'Beginner',
    category: 'DDL & DML',
    description: 'Create a new table for test results and insert sample score records.',
    starterCode: `CREATE TABLE IF NOT EXISTS class_tests (
    test_id INT PRIMARY KEY,
    subject VARCHAR(50),
    max_marks INT,
    passing_marks INT
);

INSERT INTO class_tests VALUES 
(1, 'C Language Pointers & Memory', 50, 20),
(2, 'Python Data Structures', 50, 20),
(3, 'DBMS Normalization & SQL Queries', 100, 40);

SELECT * FROM class_tests;
`
  }
];

export const INITIAL_STUDY_MATERIALS: StudyMaterial[] = [
  {
    id: 'mat-1',
    title: 'Python 3 Programming Fundamentals & Cheatsheet',
    description: 'Complete reference notes for variables, loops, functions, lists, dictionaries, and file handling with code snippets.',
    batchId: 'batch-1',
    courseId: 'course-1',
    subject: 'Python 3.12 & Logic Building',
    fileType: 'pdf',
    fileUrl: 'https://docs.python.org/3/tutorial/',
    fileName: 'Python_3_Fundamentals_PixelPathsala.pdf',
    fileSize: '2.4 MB',
    uploadedBy: 'Prof. Subhasish Mukherjee',
    uploadedDate: '2026-04-02',
    downloadCount: 14
  },
  {
    id: 'mat-2',
    title: 'C Programming Language: Pointers & Dynamic Memory Allocation',
    description: 'Detailed module handout covering pointer arithmetic, memory structures, malloc/calloc, and linked list diagrams.',
    batchId: 'batch-1',
    courseId: 'course-1',
    subject: 'C Language Core',
    fileType: 'doc',
    fileUrl: 'https://en.cppreference.com/w/c',
    fileName: 'C_Pointers_and_Memory_Notes.docx',
    fileSize: '1.8 MB',
    uploadedBy: 'Prof. Subhasish Mukherjee',
    uploadedDate: '2026-04-05',
    downloadCount: 9
  },
  {
    id: 'mat-3',
    title: 'DBMS & SQL Mastery: Joins, Group By & Subquery Lab Sheet',
    description: 'Comprehensive assignment with 25 real-world database queries for practice on MySQL and SQLite.',
    batchId: 'all',
    courseId: 'course-1',
    subject: 'Relational Database & SQL',
    fileType: 'pdf',
    fileUrl: 'https://www.w3schools.com/sql/',
    fileName: 'SQL_Joins_Practice_Questions_PixelPathsala.pdf',
    fileSize: '3.1 MB',
    uploadedBy: 'Admin - Faculty Desk',
    uploadedDate: '2026-04-08',
    downloadCount: 22
  }
];

export const INITIAL_QUESTIONS: ExamQuestion[] = [
  // Computer Science & Coding Questions (Course 1)
  {
    id: 'q-cs-1',
    courseId: 'course-1',
    academicClass: 'Class 11 (Science)',
    subject: 'C Programming',
    topic: 'Pointers & Memory',
    questionText: 'In C language, what will be the output of printing `*(&x)` if `int x = 42;`?',
    options: ['The memory address of x', '42 (Value of x)', 'Syntax Error', 'Garbage Value'],
    correctOptionIndex: 1,
    explanation: '&x gives the address of variable x, and dereferencing it with * gives the value stored at that address, which is 42.',
    marks: 2,
    difficulty: 'easy',
    createdAt: '2026-04-01'
  },
  {
    id: 'q-cs-2',
    courseId: 'course-1',
    academicClass: 'Class 11 (Science)',
    subject: 'Python 3',
    topic: 'Data Types & Mutability',
    questionText: 'Which of the following built-in data types in Python 3 is IMMUTABLE?',
    options: ['List', 'Dictionary', 'Tuple', 'Set'],
    correctOptionIndex: 2,
    explanation: 'Tuples and Strings in Python are immutable; once created, their elements cannot be modified in place.',
    marks: 2,
    difficulty: 'easy',
    createdAt: '2026-04-01'
  },
  {
    id: 'q-cs-3',
    courseId: 'course-1',
    academicClass: 'Class 11 (Science)',
    subject: 'DBMS & SQL',
    topic: 'Relational Model',
    questionText: 'Which SQL clause is used to filter records after aggregate calculations like COUNT() or SUM()?',
    options: ['WHERE', 'HAVING', 'GROUP BY', 'ORDER BY'],
    correctOptionIndex: 1,
    explanation: 'The HAVING clause was added to SQL because the WHERE keyword cannot be used with aggregate functions.',
    marks: 2,
    difficulty: 'medium',
    createdAt: '2026-04-01'
  },
  {
    id: 'q-cs-4',
    courseId: 'course-1',
    academicClass: 'Class 11 (Science)',
    subject: 'C Programming',
    topic: 'Arrays & Indexing',
    questionText: 'What is the index of the last element in a C array declared as `int arr[10];`?',
    options: ['10', '9', '11', '0'],
    correctOptionIndex: 1,
    explanation: 'C uses 0-based indexing, so an array of size 10 has valid indices from 0 to 9.',
    marks: 2,
    difficulty: 'easy',
    createdAt: '2026-04-01'
  },
  {
    id: 'q-cs-5',
    courseId: 'course-1',
    academicClass: 'Class 11 (Science)',
    subject: 'Python 3',
    topic: 'List Comprehensions',
    questionText: 'What is the output of `[x**2 for x in range(4) if x % 2 != 0]` in Python?',
    options: ['[0, 1, 4, 9]', '[1, 9]', '[0, 4]', '[1, 4]'],
    correctOptionIndex: 1,
    explanation: 'range(4) produces 0, 1, 2, 3. The odd numbers are 1 and 3. Their squares are 1 and 9.',
    marks: 2,
    difficulty: 'medium',
    createdAt: '2026-04-01'
  },

  // Higher Secondary Science (Course 2 - JEE/NEET/Class 12)
  {
    id: 'q-sci-1',
    courseId: 'course-2',
    academicClass: 'Class 12 (Science)',
    subject: 'Physics',
    topic: 'Electrostatics',
    questionText: 'The electric flux through a closed surface enclosing a dipole of charges +q and -q in vacuum is:',
    options: ['q / ε₀', '2q / ε₀', 'Zero', 'Depends on dipole length'],
    correctOptionIndex: 2,
    explanation: 'By Gauss’s Law, Φ = Q_enclosed / ε₀. For an electric dipole, the total enclosed charge is (+q - q) = 0, so net flux is zero.',
    marks: 4,
    difficulty: 'medium',
    createdAt: '2026-04-02'
  },
  {
    id: 'q-sci-2',
    courseId: 'course-2',
    academicClass: 'Class 12 (Science)',
    subject: 'Mathematics',
    topic: 'Calculus & Derivatives',
    questionText: 'What is the derivative of f(x) = sin(x²) with respect to x?',
    options: ['cos(x²)', '2x * cos(x²)', '-2x * sin(x)', '2x * sin(x²)'],
    correctOptionIndex: 1,
    explanation: 'By chain rule, d/dx[sin(u)] = cos(u) * du/dx. Here u = x², so du/dx = 2x. Hence 2x cos(x²).',
    marks: 4,
    difficulty: 'easy',
    createdAt: '2026-04-02'
  },
  {
    id: 'q-sci-3',
    courseId: 'course-2',
    academicClass: 'Class 12 (Science)',
    subject: 'Chemistry',
    topic: 'Chemical Kinetics',
    questionText: 'For a first-order chemical reaction, the half-life period (t₁/₂) is:',
    options: ['Independent of initial concentration', 'Directly proportional to initial concentration', 'Inversely proportional to initial concentration', 'Proportional to square of initial concentration'],
    correctOptionIndex: 0,
    explanation: 'For first order reactions, t₁/₂ = 0.693 / k, which is completely independent of initial reactant concentration.',
    marks: 4,
    difficulty: 'easy',
    createdAt: '2026-04-02'
  },

  // Secondary Board Class 10 (Course 3)
  {
    id: 'q-sec-1',
    courseId: 'course-3',
    academicClass: 'Class 10 (Secondary)',
    subject: 'Mathematics',
    topic: 'Quadratic Equations',
    questionText: 'If the discriminant D = b² - 4ac of a quadratic equation ax² + bx + c = 0 is greater than zero (D > 0), the roots are:',
    options: ['Real and equal', 'Real and distinct (unequal)', 'Complex / Imaginary', 'Both roots are zero'],
    correctOptionIndex: 1,
    explanation: 'When D > 0, the quadratic formula yields two distinct real values.',
    marks: 2,
    difficulty: 'easy',
    createdAt: '2026-04-03'
  },
  {
    id: 'q-sec-2',
    courseId: 'course-3',
    academicClass: 'Class 10 (Secondary)',
    subject: 'Physical Science',
    topic: 'Light & Optics',
    questionText: 'The power of a convex lens having a focal length of +50 cm is:',
    options: ['+2 Dioptres (D)', '-2 Dioptres (D)', '+0.5 Dioptres (D)', '+5 Dioptres (D)'],
    correctOptionIndex: 0,
    explanation: 'Power P = 1 / f (in meters). f = 50 cm = 0.5 m. P = 1 / 0.5 = +2.0 D.',
    marks: 2,
    difficulty: 'easy',
    createdAt: '2026-04-03'
  },
  {
    id: 'q-sec-3',
    courseId: 'course-3',
    academicClass: 'Class 10 (Secondary)',
    subject: 'Life Science',
    topic: 'Genetics & Heredity',
    questionText: 'According to Gregor Mendel, the phenotypic ratio in a monohybrid cross F2 generation is:',
    options: ['1:2:1', '3:1', '9:3:3:1', '2:1'],
    correctOptionIndex: 1,
    explanation: 'The phenotypic ratio for a standard monohybrid cross is 3 dominant : 1 recessive (3:1), while the genotypic ratio is 1:2:1.',
    marks: 2,
    difficulty: 'easy',
    createdAt: '2026-04-03'
  },

  // Web Design & Full Stack Basics (Course 4)
  {
    id: 'q-web-1',
    courseId: 'course-4',
    academicClass: 'BCA / B.Sc (Computer Science)',
    subject: 'Web Development',
    topic: 'HTML5 & DOM',
    questionText: 'Which HTML5 semantic element is intended for standalone content that could be distributed independently, like a blog post or news story?',
    options: ['<section>', '<article>', '<aside>', '<header>'],
    correctOptionIndex: 1,
    explanation: 'The <article> tag specifies independent, self-contained content that makes sense on its own.',
    marks: 2,
    difficulty: 'easy',
    createdAt: '2026-04-04'
  }
];

export const INITIAL_EXAMS: OnlineExam[] = [
  {
    id: 'exam-1',
    title: 'Computer Science & Python Periodic Assessment (Mid-Term)',
    examCode: 'EXAM-PY-101',
    courseId: 'course-1',
    batchId: 'batch-1',
    academicClass: 'Class 11 (Science)',
    subject: 'Computer Science & Python',
    durationMinutes: 20,
    totalMarks: 10,
    passingMarks: 4,
    passingPercentage: 40,
    questionIds: ['q-cs-1', 'q-cs-2', 'q-cs-3', 'q-cs-4', 'q-cs-5'],
    instructions: '1. All 5 questions are compulsory.\n2. Each correct answer carries 2 marks.\n3. Negative marking: None.\n4. Timer will auto-submit when remaining time reaches 00:00.',
    status: 'active',
    scheduledDate: '2026-08-25',
    startTime: '10:00 AM',
    endTime: '11:00 AM',
    isPublished: true,
    mode: 'online',
    createdAt: '2026-04-10'
  },
  {
    id: 'exam-2',
    title: 'Class 12 Physics & Maths Sprint Mock Test (JEE Level)',
    examCode: 'EXAM-SCI-202',
    courseId: 'course-2',
    batchId: 'batch-2',
    academicClass: 'Class 12 (Science)',
    subject: 'Physics & Mathematics',
    durationMinutes: 30,
    totalMarks: 12,
    passingMarks: 6,
    passingPercentage: 50,
    questionIds: ['q-sci-1', 'q-sci-2', 'q-sci-3'],
    instructions: 'Objective question test covering Electrostatics, Calculus, and Chemical Kinetics. Calculators are not allowed.',
    status: 'scheduled',
    scheduledDate: '2026-08-28',
    startTime: '04:00 PM',
    endTime: '05:00 PM',
    isPublished: true,
    mode: 'offline',
    createdAt: '2026-04-12'
  },
  {
    id: 'exam-3',
    title: 'Class 10 Secondary Board Science & Math Diagnostic Quiz',
    examCode: 'EXAM-SEC-303',
    courseId: 'course-3',
    batchId: 'batch-3',
    academicClass: 'Class 10 (Secondary)',
    subject: 'Secondary Science & Maths',
    durationMinutes: 15,
    totalMarks: 6,
    passingMarks: 3,
    passingPercentage: 40,
    questionIds: ['q-sec-1', 'q-sec-2', 'q-sec-3'],
    instructions: 'Mandatory revision test covering Quadratics, Optics, and Mendel Laws.',
    status: 'active',
    scheduledDate: '2026-08-24',
    startTime: '05:30 PM',
    endTime: '06:30 PM',
    isPublished: true,
    mode: 'offline',
    createdAt: '2026-04-15'
  }
];

export const INITIAL_EXAM_SUBMISSIONS: ExamSubmission[] = [
  {
    id: 'sub-1',
    examId: 'exam-1',
    examTitle: 'Computer Science & Python Periodic Assessment (Mid-Term)',
    studentId: 'stu-101',
    studentName: 'Rohan Sharma',
    studentRollNo: 'PP-2026-001',
    studentRoll: 'PP-2026-001',
    studentAadhaar: '453289012345',
    courseId: 'course-1',
    batchId: 'batch-1',
    answers: {
      'q-cs-1': 1,
      'q-cs-2': 2,
      'q-cs-3': 1,
      'q-cs-4': 1,
      'q-cs-5': 1
    },
    questionBreakdown: [
      { questionId: 'q-cs-1', selectedOptionIndex: 1, correctOptionIndex: 1, isCorrect: true, marks: 2 },
      { questionId: 'q-cs-2', selectedOptionIndex: 2, correctOptionIndex: 2, isCorrect: true, marks: 2 },
      { questionId: 'q-cs-3', selectedOptionIndex: 1, correctOptionIndex: 1, isCorrect: true, marks: 2 },
      { questionId: 'q-cs-4', selectedOptionIndex: 1, correctOptionIndex: 1, isCorrect: true, marks: 2 },
      { questionId: 'q-cs-5', selectedOptionIndex: 1, correctOptionIndex: 1, isCorrect: true, marks: 2 }
    ],
    score: 10,
    totalMarks: 10,
    percentage: 100,
    passed: true,
    submittedAt: '2026-08-20T10:14:32.000Z',
    timeSpentSeconds: 840,
    timeTakenMinutes: 14
  }
];

export const INITIAL_LIVE_CLASSES: LiveClassSession[] = [
  {
    id: 'live-1',
    title: 'Data Structures & Pointers in C/C++ Live Workshop',
    targetClass: 'BCA / B.Sc Computer Science / Coding',
    academicClass: 'BCA / B.Sc Computer Science / Coding',
    subject: 'Computer Science & Coding',
    courseId: 'course-1',
    batchId: 'batch-1',
    educatorId: 'edu-1',
    educatorName: 'Dr. Debabrata Roy (Lead Educator)',
    description: 'Live interactive coding on pointer arithmetic, dynamic memory allocation with malloc/free, and linked list traversals.',
    scheduledDate: '2026-08-31',
    startTime: '05:00 PM',
    endTime: '06:30 PM',
    status: 'live',
    platform: 'in_app',
    inAppRoomId: 'pixel-cs-dsa-batch1',
    meetingUrl: 'https://meet.jit.si/PixelPathsala-CS-DSA-Live',
    isRecordingAvailable: true,
    recordingId: 'rec-2',
    createdAt: '2026-08-28'
  },
  {
    id: 'live-2',
    title: 'Python Object Oriented Programming & Algorithms',
    targetClass: 'BCA / B.Sc Computer Science / Coding',
    academicClass: 'BCA / B.Sc Computer Science / Coding',
    subject: 'Python & Data Structures',
    courseId: 'course-1',
    batchId: 'batch-1',
    educatorId: 'edu-1',
    educatorName: 'Dr. Debabrata Roy',
    description: 'Classes, inheritance, polymorphism, encapsulation, and implementing search/sort algorithms in Python.',
    scheduledDate: '2026-09-02',
    startTime: '05:00 PM',
    endTime: '06:30 PM',
    status: 'scheduled',
    platform: 'google_meet',
    meetingUrl: 'https://meet.google.com/pqp-vpxw-gky',
    isRecordingAvailable: false,
    createdAt: '2026-08-29'
  },
  {
    id: 'live-3',
    title: 'Class 12 Physics & Numerical Problem Solving Masterclass',
    targetClass: 'Class 12 (Higher Secondary)',
    academicClass: 'Class 12 (Higher Secondary)',
    subject: 'Physics (Science)',
    courseId: 'course-2',
    batchId: 'batch-2',
    educatorId: 'edu-2',
    educatorName: 'Prof. Amitava Mukherjee',
    description: 'Electromagnetic induction, alternating current circuits, and solving previous years JEE Advanced numerical problems.',
    scheduledDate: '2026-09-01',
    startTime: '06:00 PM',
    endTime: '07:30 PM',
    status: 'postponed',
    isPostponed: true,
    postponedReason: 'Faculty on urgent medical leave; session rescheduled to tomorrow.',
    originalDate: '2026-09-01',
    rescheduledDate: '2026-09-02',
    rescheduledStartTime: '06:00 PM',
    rescheduledEndTime: '07:30 PM',
    notificationSent: true,
    notificationSentAt: '2026-09-01',
    platform: 'google_meet',
    meetingUrl: 'https://meet.google.com/abc-phys-xyz',
    isRecordingAvailable: false,
    createdAt: '2026-08-29'
  },
  {
    id: 'live-4',
    title: 'Class 10 Mathematics Board Booster Series: Quadratic Equations',
    targetClass: 'Class 10 (Secondary)',
    academicClass: 'Class 10 (Secondary)',
    subject: 'Mathematics',
    courseId: 'course-3',
    batchId: 'batch-3',
    educatorId: 'edu-3',
    educatorName: 'Dr. Sarmistha Sen',
    description: 'Solving quadratic formulas, discriminant properties, word problems, and board examination score boosters.',
    scheduledDate: '2026-09-03',
    startTime: '04:30 PM',
    endTime: '06:00 PM',
    status: 'scheduled',
    platform: 'in_app',
    inAppRoomId: 'pixel-maths-class10',
    meetingUrl: 'https://meet.jit.si/PixelPathsala-Maths-Class10',
    isRecordingAvailable: false,
    createdAt: '2026-08-30'
  },
  {
    id: 'live-5',
    title: 'Modern JavaScript ES6+ & Full-Stack REST APIs',
    targetClass: 'College / Professional Tech',
    academicClass: 'College / Professional Tech',
    subject: 'Web Design & JavaScript',
    courseId: 'course-4',
    batchId: 'batch-4',
    educatorId: 'edu-1',
    educatorName: 'Dr. Debabrata Roy (Lead Educator)',
    description: 'Deep-dive into arrow functions, array destructuring, promises, async/await, and building REST API clients.',
    scheduledDate: '2026-08-31',
    startTime: '06:00 PM',
    endTime: '07:30 PM',
    status: 'live',
    platform: 'in_app',
    inAppRoomId: 'pixel-webdev-batch4-es6',
    meetingUrl: 'https://meet.jit.si/PixelPathsala-WebDev-ES6Live',
    isRecordingAvailable: true,
    recordingId: 'rec-1',
    createdAt: '2026-08-28'
  },
  {
    id: 'live-6',
    title: 'All-Batch Special Masterclass: Career Pathways & Tech Skills',
    targetClass: 'All Classes',
    academicClass: 'All Classes',
    subject: 'Special Academic Orientation',
    courseId: 'all',
    batchId: 'all',
    educatorId: 'edu-1',
    educatorName: 'Dr. Debabrata Roy & Guest Faculty',
    description: 'Open to all enrolled students: Choosing the right engineering/tech domain, competitive coding roadmap, and university admissions.',
    scheduledDate: '2026-09-06',
    startTime: '07:00 PM',
    endTime: '08:30 PM',
    status: 'scheduled',
    platform: 'youtube_live',
    meetingUrl: 'https://youtube.com/live/pixelpathsala-career-special',
    isRecordingAvailable: true,
    createdAt: '2026-08-29'
  }
];

export const INITIAL_CLASS_RECORDINGS: ClassRecording[] = [
  {
    id: 'rec-1',
    sessionId: 'live-1',
    title: 'HTML5 Semantic Layouts, Modern CSS Flexbox & Responsive Cards',
    targetClass: 'College / Professional Tech',
    academicClass: 'College / Professional Tech',
    subject: 'Web Design & Frontend',
    topic: 'Flexbox Architecture & Mobile First Layouts',
    chapter: 'Chapter 2: Modern CSS Layout Systems',
    courseId: 'course-4',
    batchId: 'batch-4',
    educatorName: 'Dr. Debabrata Roy',
    recordedDate: '2026-08-26',
    durationMinutes: 75,
    videoSourceType: 'youtube',
    videoUrl: 'https://www.youtube.com/watch?v=kUMe1FH4CHE',
    thumbnailUrl: 'https://images.unsplash.com/photo-1593720213428-28a5b9e94613?w=600&auto=format&fit=crop&q=60',
    notesPdfUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    description: 'Complete hands-on recording covering Flex container properties (justify-content, align-items, flex-wrap) and creating responsive pricing/course cards without media queries.',
    viewCount: 42,
    tags: ['HTML5', 'CSS Flexbox', 'Responsive UI', 'Frontend'],
    createdAt: '2026-08-26'
  },
  {
    id: 'rec-2',
    sessionId: 'live-3',
    title: 'Python Core Fundamentals: Lists, Dictionaries, Functions & Modules',
    targetClass: 'BCA / B.Sc Computer Science / Coding',
    academicClass: 'BCA / B.Sc Computer Science / Coding',
    subject: 'Computer Science & Python',
    topic: 'Python Data Structures & Clean Code Practices',
    chapter: 'Chapter 3: Collections & Modular Programming',
    courseId: 'course-1',
    batchId: 'batch-1',
    educatorName: 'Dr. Debabrata Roy',
    recordedDate: '2026-08-24',
    durationMinutes: 80,
    videoSourceType: 'youtube',
    videoUrl: 'https://www.youtube.com/watch?v=_uQrJ0TkZlc',
    thumbnailUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=600&auto=format&fit=crop&q=60',
    notesPdfUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    description: 'Comprehensive lecture on Python list comprehensions, dictionary lookups, lambda functions, and writing modular unit tests.',
    viewCount: 68,
    tags: ['Python', 'Data Structures', 'Functions', 'Algorithms'],
    createdAt: '2026-08-24'
  },
  {
    id: 'rec-3',
    title: 'JavaScript DOM Manipulation & Asynchronous Event Loops',
    targetClass: 'College / Professional Tech',
    academicClass: 'College / Professional Tech',
    subject: 'Web Design & JavaScript',
    topic: 'Event Listeners, Event Delegation & Web APIs',
    chapter: 'Chapter 4: JavaScript in the Browser',
    courseId: 'course-4',
    batchId: 'batch-4',
    educatorName: 'Dr. Debabrata Roy',
    recordedDate: '2026-08-20',
    durationMinutes: 90,
    videoSourceType: 'youtube',
    videoUrl: 'https://www.youtube.com/watch?v=hdI2bqOjy3c',
    thumbnailUrl: 'https://images.unsplash.com/photo-1579468118864-1b9ea3c0db4a?w=600&auto=format&fit=crop&q=60',
    notesPdfUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
    description: 'Understanding execution context, call stack, callback queue, microtasks, promises, and building an interactive shopping cart in vanilla JS.',
    viewCount: 55,
    tags: ['JavaScript', 'DOM', 'Event Loop', 'Async'],
    createdAt: '2026-08-20'
  }
];

export const INITIAL_STUDENT_NOTIFICATIONS: StudentNotification[] = [];


