import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { createApiV1Router } from './serverApiV1';

const app = express();
const PORT = 3000;

// Enable Global CORS for Mobile APKs, Emulators, Webviews, and External APIs
app.use((req: Request, res: Response, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-API-Key');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  next();
});

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Ensure data directory exists for persistent server-side storage
const DATA_DIR = path.join(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const CONFIG_FILE = path.join(DATA_DIR, 'google-sheets-config.json');
const DATABASE_CACHE_FILE = path.join(DATA_DIR, 'erp-database-cache.json');

// Permanent Master Database Sheet ID for Pixel Pathsala Project
export const PERMANENT_GOOGLE_SHEET_ID = '1HVB5lNLyCIh6Uw0KmSAvaUnlQjfJMroHzAKy1a-4_O4';

interface GoogleSheetsConfig {
  googleSheetId: string | null;
  googleSheetTitle: string;
  googleUser: {
    email: string;
    name: string;
    picture?: string;
  } | null;
  accessToken: string | null;
  tokenExpiry: number | null;
  connectedAt: string | null;
  lastSynced: string | null;
  isConfigured: boolean;
  autoSyncEnabled: boolean;
  webhookUrl?: string;
  googleSheetWebhookUrl?: string;
  autoWriteBack?: boolean;
  lastWebhookStatus?: string | { success: boolean; timestamp: string; message: string } | null;
  tableStats: {
    students: number;
    admissions: number;
    payments: number;
    courses: number;
    batches: number;
    educators: number;
    expenses: number;
    adminAccounts: number;
    studyMaterials?: number;
    questions?: number;
    exams?: number;
    examSubmissions?: number;
    liveClasses?: number;
    classRecordings?: number;
    discounts?: number;
  };
}

const DEFAULT_CONFIG: GoogleSheetsConfig = {
  googleSheetId: PERMANENT_GOOGLE_SHEET_ID,
  googleSheetTitle: 'Pixel Pathsala - Master ERP Database',
  googleUser: null,
  accessToken: null,
  tokenExpiry: null,
  connectedAt: new Date().toISOString(),
  lastSynced: null,
  isConfigured: true,
  autoSyncEnabled: true,
  webhookUrl: undefined,
  autoWriteBack: true,
  lastWebhookStatus: null,
  tableStats: {
    students: 0,
    admissions: 0,
    payments: 0,
    courses: 0,
    batches: 0,
    educators: 0,
    expenses: 0,
    adminAccounts: 0,
    studyMaterials: 0,
    questions: 0,
    exams: 0,
    examSubmissions: 0,
    liveClasses: 0,
    classRecordings: 0
  }
};

function readConfig(): GoogleSheetsConfig {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = fs.readFileSync(CONFIG_FILE, 'utf-8');
      const parsed = { ...DEFAULT_CONFIG, ...JSON.parse(data) };
      if (!parsed.googleSheetId) {
        parsed.googleSheetId = PERMANENT_GOOGLE_SHEET_ID;
      }
      parsed.isConfigured = true;
      // Check if token has expired
      if (parsed.tokenExpiry && Date.now() > parsed.tokenExpiry) {
        parsed.accessToken = null;
      }
      return parsed;
    }
  } catch (err) {
    console.error('Error reading Google Sheets config file:', err);
  }
  return { ...DEFAULT_CONFIG };
}

function writeConfig(config: GoogleSheetsConfig) {
  try {
    if (!config.googleSheetId) {
      config.googleSheetId = PERMANENT_GOOGLE_SHEET_ID;
    }
    config.isConfigured = true;
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing Google Sheets config file:', err);
  }
}

async function callGoogleApi(endpoint: string, method: string = 'GET', body?: any): Promise<any> {
  const config = readConfig();
  const token = config.accessToken;
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  const url = `https://sheets.googleapis.com/v4/spreadsheets${endpoint}`;
  const options: RequestInit = {
    method,
    headers
  };
  if (body && method !== 'GET') {
    options.body = JSON.stringify(body);
  }
  const res = await fetch(url, options);
  if (!res.ok) {
    const errorText = await res.text();
    throw new Error(`Google API error (${res.status}): ${errorText}`);
  }
  return res.json();
}

function getDefaultDatabase(): any {
  return {
    centerInfo: {
      name: 'Pixel Pathsala',
      tagline: 'Code your dream, decode the future',
      logoUrl: '/logo.png',
      bgUrl: 'https://lh3.googleusercontent.com/gps-cs-s/AHRPTWkosGLnTUdSyNjD_qft1aTOQPyOnPZB0uy5j8dFgel7_leZVbbYyp_fjEkkRgsBF2C1512ZGpjzyCo0TBbLKl88Zx2eSYZHiuNJMx370aU9glHDJt3v48cFDsZR-ulR6OsHByk3KXJauy8T=s1360-w1360-h1020-rw',
      address: 'Raina Main Road, Near Bus Stand',
      cityState: 'Raina, Purba Bardhaman (Burdwan), West Bengal - 713424',
      phonePrimary: '+91 9775708722',
      phoneSecondary: '+91 9832014567',
      whatsapp: '+91 9775708722',
      email: 'pixelpathsala.edu@gmail.com',
      upiId: '9775708722@apl',
      upiName: 'Pixel Pathsala Center',
      establishedYear: '2021',
      admissionOpen: true,
      announcement: '📢 Admissions Open for Session 2026-27! Free Registration • Special Early-Bird & Merit Discounts available on all Batches.',
      welcomeMessage: 'Welcome to Pixel Pathsala — Premier Institute for Classwise School & College Syllabus, Competitive Exams, and Interactive Coding & DBMS Training.'
    },
    adminAccounts: [
      {
        id: 'ADM-001',
        username: 'admin',
        password: 'admin123',
        name: 'Director / Center Administrator',
        role: 'Master Administrator',
        email: 'admin@pixelpathsala.com',
        phone: '+91 9775708722',
        securityPin: '7722',
        status: 'active',
        lastLogin: 'Today',
        updatedAt: '2026-04-01'
      }
    ],
    educators: [
      {
        id: 'edu-1',
        name: 'Prof. Subhasish Mukherjee',
        qualification: 'M.Tech (Computer Science), GATE Qualified',
        subject: 'Computer Science, C, Python & DBMS',
        phone: '9832104561',
        email: 'subhasish.cs@pixelpathsala.com',
        monthlySalary: 32000,
        assignedBatchIds: ['batch-1', 'batch-4'],
        photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
        experienceYears: 9,
        joiningDate: '2022-01-15',
        status: 'active'
      },
      {
        id: 'edu-2',
        name: 'Dr. Ananya Roy',
        qualification: 'Ph.D. in Mathematics, Jadavpur University',
        subject: 'Higher Mathematics & JEE Advanced Prep',
        phone: '9832298712',
        email: 'ananya.maths@pixelpathsala.com',
        monthlySalary: 35000,
        assignedBatchIds: ['batch-2', 'batch-3'],
        photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
        experienceYears: 11,
        joiningDate: '2022-04-01',
        status: 'active'
      },
      {
        id: 'edu-3',
        name: 'Er. Rajesh Ghosh',
        qualification: 'B.Tech (ECE), Ex-Fiitjee Faculty',
        subject: 'Physics (Class 11, 12 & NEET/JEE)',
        phone: '9748561234',
        email: 'rajesh.physics@pixelpathsala.com',
        monthlySalary: 30000,
        assignedBatchIds: ['batch-2'],
        photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
        experienceYears: 7,
        joiningDate: '2023-03-10',
        status: 'active'
      },
      {
        id: 'edu-4',
        name: 'Ms. Sharmila Paul',
        qualification: 'M.Sc (Chemistry), B.Ed',
        subject: 'Chemistry & Secondary Science (Class 9-10)',
        phone: '9800456711',
        email: 'sharmila.chem@pixelpathsala.com',
        monthlySalary: 26000,
        assignedBatchIds: ['batch-3'],
        photoUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80',
        experienceYears: 6,
        joiningDate: '2023-07-01',
        status: 'active'
      }
    ],
    courses: [
      {
        id: 'course-1',
        title: 'Computer Science, C, Python & SQL Masterclass',
        code: 'CS-PRO-101',
        academicClass: 'Class 8-12, BCA & College',
        category: 'Computer Science & Coding',
        monthlyFee: 1200,
        description: 'Comprehensive hands-on programming course covering C logic, Python 3 automation & data structures, Web HTML/CSS basics, and SQL/DBMS database mastery.',
        syllabusPoints: [
          'C Language: Data types, loops, arrays, pointers, dynamic memory & file handling',
          'Python: Object-oriented programming, modules, JSON, file operations & scripting',
          'HTML/CSS/JS: Responsive web pages and UI development fundamentals',
          'DBMS & SQL: ER diagrams, Normalization, DDL, DML, Joins, Subqueries & Transactions'
        ],
        highlights: [
          'Interactive Browser Playzone Access',
          'Live Coding Assessments & Mini Projects',
          'Weekly Doubt Clearing & Dedicated Mentorship'
        ],
        isPopular: true,
        showOnWebsite: true,
        createdAt: '2025-01-10'
      },
      {
        id: 'course-2',
        title: 'Class 11-12 Science & JEE/NEET Integrated Batch',
        code: 'SCI-JEE-202',
        academicClass: 'Class 11 & Class 12 Science',
        category: 'Higher Secondary (11-12)',
        monthlyFee: 2500,
        description: 'Targeted preparation for WBCHSE / CBSE Board Examinations coupled with foundational JEE Main & NEET entrance question solving techniques.',
        syllabusPoints: [
          'Physics: Mechanics, Waves, Electromagnetism, Optics & Modern Physics',
          'Mathematics: Calculus, Coordinate Geometry, Vectors, Algebra & Trigonometry',
          'Chemistry: Physical, Organic Mechanisms & Inorganic Reactions',
          'Weekly Mock Tests with detailed analysis & OMR scoring'
        ],
        highlights: [
          'Chapter-wise Printed DPP & Modules',
          '1-on-1 Mentorship by Expert Faculties',
          'Air-conditioned smart classrooms with projector'
        ],
        isPopular: true,
        showOnWebsite: true,
        createdAt: '2025-01-12'
      },
      {
        id: 'course-3',
        title: 'Class 9-10 Secondary Board Mastery (Maths & Science)',
        code: 'SEC-BD-303',
        academicClass: 'Class 9 & Class 10',
        category: 'School (Class 8-10)',
        monthlyFee: 1500,
        description: 'Complete academic coaching for secondary school students covering Mathematics, Physical Science, and Life Science with rigorous periodic assessments.',
        syllabusPoints: [
          'Mathematics: Arithmetic, Algebra, Geometry, Mensuration & Statistics',
          'Physical Science: Force, Motion, Light, Electricity & Chemical Bonding',
          'Previous 10 Years Board Papers Solution & Answer Writing Drills',
          'Special focus on conceptual clarity and exam confidence'
        ],
        highlights: [
          'Small batch size (max 25 students)',
          'Monthly Progress Report for Parents',
          'Special Sunday revision clinics'
        ],
        isPopular: false,
        showOnWebsite: true,
        createdAt: '2025-01-15'
      },
      {
        id: 'course-4',
        title: 'Web Design, Frontend & Full-Stack Basics',
        code: 'WEB-DEV-404',
        academicClass: 'Class 9-12 & BCA / Diploma',
        category: 'Computer Science & Coding',
        monthlyFee: 1400,
        description: 'Learn modern web crafting with HTML5, modern CSS3, JavaScript ES6+, backend REST APIs, and SQLite database storage with practical capstone websites.',
        syllabusPoints: [
          'HTML5 semantic tags, Forms, Canvas & Media elements',
          'Modern CSS Flexbox, Grid, Animations & Tailwind utility classes',
          'JavaScript DOM Manipulation, Fetch API & Async/Await',
          'Building dynamic real-world interactive apps & hosting'
        ],
        highlights: [
          'Portfolio Ready 4 Real Projects',
          'Pixel Pathsala Certificate on Completion',
          'Code reviews by industry developers'
        ],
        isPopular: false,
        showOnWebsite: true,
        createdAt: '2025-02-01'
      }
    ],
    batches: [
      {
        id: 'batch-1',
        name: 'Batch C-Python Coding Alpha (MWF)',
        courseId: 'course-1',
        educatorId: 'edu-1',
        scheduleDays: ['Mon', 'Wed', 'Fri'],
        timing: '04:30 PM - 06:00 PM',
        roomNumber: 'Lab-1 (Pixel Lab)',
        maxCapacity: 25,
        isActive: true,
        startDate: '2026-04-01'
      },
      {
        id: 'batch-2',
        name: 'Batch Science & JEE Pinnacle (TTS)',
        courseId: 'course-2',
        educatorId: 'edu-2',
        scheduleDays: ['Tue', 'Thu', 'Sat'],
        timing: '05:30 PM - 07:30 PM',
        roomNumber: 'Hall-A (Smart Room)',
        maxCapacity: 30,
        isActive: true,
        startDate: '2026-04-01'
      },
      {
        id: 'batch-3',
        name: 'Batch Secondary Champions Class 10 (Daily)',
        courseId: 'course-3',
        educatorId: 'edu-4',
        scheduleDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        timing: '06:30 PM - 08:00 PM',
        roomNumber: 'Room-201',
        maxCapacity: 25,
        isActive: true,
        startDate: '2026-04-01'
      },
      {
        id: 'batch-4',
        name: 'Batch Web & DBMS Weekend Fast-track',
        courseId: 'course-4',
        educatorId: 'edu-1',
        scheduleDays: ['Sat', 'Sun'],
        timing: '10:00 AM - 01:00 PM',
        roomNumber: 'Lab-2',
        maxCapacity: 20,
        isActive: true,
        startDate: '2026-05-01'
      }
    ],
    students: [
      {
        id: 'stu-101',
        rollNo: 'PP-2026-001',
        name: 'Rohan Sharma',
        mobile: '9876543210',
        aadhaarNo: '4532 8901 2345',
        email: 'rohan.sharma@example.com',
        guardianName: 'Manoj Sharma',
        guardianPhone: '9876543211',
        address: 'Station Road, Raina, Purba Bardhaman',
        courseId: 'course-1',
        batchId: 'batch-1',
        admissionDate: '2026-04-01',
        admissionMonth: '2026-04',
        status: 'active'
      },
      {
        id: 'stu-102',
        rollNo: 'PP-2026-002',
        name: 'Priyanka Das',
        mobile: '9832011223',
        aadhaarNo: '7821 3490 1289',
        email: 'priyanka.das@example.com',
        guardianName: 'Alok Das',
        guardianPhone: '9832011224',
        address: 'Burdwan Town, Purba Bardhaman',
        courseId: 'course-2',
        batchId: 'batch-2',
        admissionDate: '2026-04-01',
        admissionMonth: '2026-04',
        status: 'active'
      },
      {
        id: 'stu-103',
        rollNo: 'PP-2026-003',
        name: 'Soumyadip Banerjee',
        mobile: '9434055667',
        aadhaarNo: '6210 9945 3321',
        email: 'soumya.banerjee@example.com',
        guardianName: 'Debabrata Banerjee',
        guardianPhone: '9434055668',
        address: 'Madhabdihi, Raina, Purba Bardhaman',
        courseId: 'course-1',
        batchId: 'batch-1',
        admissionDate: '2026-04-05',
        admissionMonth: '2026-04',
        status: 'active'
      },
      {
        id: 'stu-104',
        rollNo: 'PP-2026-004',
        name: 'Sneha Sarkar',
        mobile: '9733099881',
        aadhaarNo: '5409 1123 8876',
        email: 'sneha.sarkar@example.com',
        guardianName: 'Pranab Sarkar',
        guardianPhone: '9733099882',
        address: 'Raina Bazaar, Purba Bardhaman',
        courseId: 'course-3',
        batchId: 'batch-3',
        admissionDate: '2026-04-08',
        admissionMonth: '2026-04',
        status: 'active'
      }
    ],
    admissions: [
      {
        id: 'adm-1',
        applicationNo: 'APP/2026/101',
        studentName: 'Aniket Paul',
        mobile: '9800112233',
        aadhaarNo: '3344 5566 7788',
        email: 'aniket.paul@example.com',
        guardianName: 'Shyamal Paul',
        guardianPhone: '9800112234',
        address: 'Raina, Purba Bardhaman',
        targetCourseId: 'course-1',
        preferredBatchId: 'batch-1',
        previousSchoolOrCollege: 'Raina High School',
        remarks: 'Interested in Python and SQL DBMS',
        initialPaymentStatus: 'paid_advance',
        initialPaymentMode: 'UPI',
        initialPaymentRef: 'UPI-APP-998811',
        initialPaymentAmount: 1200,
        status: 'pending',
        appliedDate: '2026-04-10'
      }
    ],
    payments: [],
    expenses: [
      {
        id: 'exp-1',
        title: 'High-Speed Optical Broadband Bill',
        category: 'Software, Hosting & SMS',
        amount: 1499,
        date: '2026-04-03',
        paidTo: 'Alliance Broadband Net',
        paymentMode: 'UPI',
        receiptNo: 'BB-APR-2026',
        notes: 'Monthly 300 Mbps unlimited plan for Pixel Lab'
      }
    ],
    studyMaterials: [
      {
        id: 'mat-1',
        title: 'Python Complete Reference Guide & Syntax Cheat Sheet',
        description: 'Comprehensive chapter-wise reference manual covering Loops, Functions, OOPs and File Handling in Python 3.12.',
        batchId: 'batch-1',
        courseId: 'course-1',
        subject: 'Computer Science (Python)',
        fileType: 'pdf',
        fileUrl: 'data:application/pdf;base64,JVBERi0xLjQKJcTl8uXrp/Og0MTGCjQgMCBvYmoKPDwKL0tpZHMgWzUgMCBSXQovQ291bnQgMQovVHlwZSAvUGFnZXMKPj4KZW5kb2JqCjUgMCBvYmoKPDwKL1BhcmVudCA0IDAgUgovQ29udGVudHMgNiAwIFIKL1R5cGUgL1BhZ2UKL01lZGlhQm94IFswIDAgNjEyIDc5Ml0KPj4KZW5kb2JqCg==',
        fileName: 'Python_Class10_Complete_Reference_2026.pdf',
        fileSize: '2.8 MB',
        uploadedBy: 'Dr. Debasish Roy',
        uploadedDate: '2026-04-05',
        downloadCount: 24
      },
      {
        id: 'mat-2',
        title: 'Class 12 Physics & Chemistry Formula Handout (JEE/NEET)',
        description: 'Instant revision formula booklet for Electrostatics, Magnetism, Optics and Organic Reaction Mechanisms.',
        batchId: 'batch-2',
        courseId: 'course-2',
        subject: 'Physics & Chemistry',
        fileType: 'pdf',
        fileUrl: 'data:application/pdf;base64,JVBERi0xLjQKJcTl8uXrp/Og0MTGCjQgMCBvYmoKPDwKL0tpZHMgWzUgMCBSXQovQ291bnQgMQovVHlwZSAvUGFnZXMKPj4KZW5kb2JqCjUgMCBvYmoKPDwKL1BhcmVudCA0IDAgUgovQ29udGVudHMgNiAwIFIKL1R5cGUgL1BhZ2UKL01lZGlhQm94IFswIDAgNjEyIDc5Ml0KPj4KZW5kb2JqCg==',
        fileName: 'JEE_NEET_Formula_Bank_Class12.pdf',
        fileSize: '4.1 MB',
        uploadedBy: 'Prof. Amitabha Sen',
        uploadedDate: '2026-04-08',
        downloadCount: 42
      },
      {
        id: 'mat-3',
        title: 'C Programming & Data Structures Lab Assignment Set',
        description: 'Contains 30 practical lab coding problems with input test cases and logic dry-runs.',
        batchId: 'all',
        courseId: 'course-1',
        subject: 'C Programming & Algorithms',
        fileType: 'doc',
        fileUrl: 'data:application/msword;base64,0M8R4KGxGuEAAAAAAAAAAAAAAAAAAAAAPgADAP7/CQAGAAAAAAAAAAAAAAABAAAAAQAAAAAAAAAA',
        fileName: 'C_Programming_Lab_Problems_Set1.docx',
        fileSize: '1.2 MB',
        uploadedBy: 'Ananya Mukherjee',
        uploadedDate: '2026-04-12',
        downloadCount: 18
      }
    ],
    discounts: [
      {
        id: 'disc-1',
        title: 'Batch Alpha Early-Bird Concession',
        type: 'flat',
        value: 200,
        scope: 'batch',
        batchId: 'batch-1',
        applicableMonthsType: 'all_months',
        active: true,
        reason: 'Inaugural coding batch early-bird discount',
        createdAt: '2026-03-25'
      },
      {
        id: 'disc-2',
        title: 'Merit Scholarship - Priyanka Das',
        type: 'percentage',
        value: 20,
        scope: 'student',
        studentId: 'stu-102',
        applicableMonthsType: 'all_months',
        active: true,
        reason: 'Scored 96.5% in Class 10 Board Exams',
        createdAt: '2026-04-08'
      },
      {
        id: 'disc-all',
        title: 'Center-Wide Concession (Assigned in All Options)',
        type: 'flat',
        value: 250,
        scope: 'all',
        applicableMonthsType: 'all_months',
        active: true,
        reason: 'Universal academic fee concession assigned to all options',
        createdAt: '2026-04-01'
      }
    ]
  };
}

function readDatabaseCache(): any {
  try {
    if (fs.existsSync(DATABASE_CACHE_FILE)) {
      const data = fs.readFileSync(DATABASE_CACHE_FILE, 'utf-8');
      if (data && data.trim().length > 0) {
        const parsed = JSON.parse(data);
        if (parsed && typeof parsed === 'object') {
          // Return database data without re-injecting deleted test items
          const defaultCenter = getDefaultDatabase().centerInfo;
          return {
            _initialized: true,
            centerInfo: parsed.centerInfo ? { ...defaultCenter, ...parsed.centerInfo } : defaultCenter,
            adminAccounts: Array.isArray(parsed.adminAccounts) ? parsed.adminAccounts : getDefaultDatabase().adminAccounts,
            courses: Array.isArray(parsed.courses) ? parsed.courses : [],
            batches: Array.isArray(parsed.batches) ? parsed.batches : [],
            educators: Array.isArray(parsed.educators) ? parsed.educators : [],
            students: Array.isArray(parsed.students) ? parsed.students : [],
            admissions: Array.isArray(parsed.admissions) ? parsed.admissions : [],
            payments: Array.isArray(parsed.payments) ? parsed.payments : [],
            expenses: Array.isArray(parsed.expenses) ? parsed.expenses : [],
            discounts: (Array.isArray(parsed.discounts) && parsed.discounts.length > 0) ? parsed.discounts : (getDefaultDatabase().discounts || []),
            studyMaterials: Array.isArray(parsed.studyMaterials) ? parsed.studyMaterials : (getDefaultDatabase().studyMaterials || []),
            questions: Array.isArray(parsed.questions) ? parsed.questions : [],
            exams: Array.isArray(parsed.exams) ? parsed.exams : [],
            examSubmissions: Array.isArray(parsed.examSubmissions) ? parsed.examSubmissions : [],
            liveClasses: Array.isArray(parsed.liveClasses) ? parsed.liveClasses : [],
            classRecordings: Array.isArray(parsed.classRecordings) ? parsed.classRecordings : [],
            notifications: Array.isArray(parsed.notifications) ? parsed.notifications : []
          };
        }
      }
    }
  } catch (err) {
    console.error('Error reading database cache file:', err);
  }

  // Populate default database cache if file does not exist yet
  const defaultData = { ...getDefaultDatabase(), _initialized: true };
  writeDatabaseCache(defaultData);
  return defaultData;
}

function writeDatabaseCache(data: any) {
  try {
    let existingCache: any = null;
    if (fs.existsSync(DATABASE_CACHE_FILE)) {
      try {
        const raw = fs.readFileSync(DATABASE_CACHE_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          existingCache = parsed;
        }
      } catch {}
    }

    // Merge centerInfo carefully - never revert to default if custom data already exists
    const mergedCenterInfo = {
      ...(existingCache?.centerInfo || getDefaultDatabase().centerInfo),
      ...(data.centerInfo || {})
    };

    const finalDiscounts = (Array.isArray(data.discounts) && data.discounts.length > 0)
      ? data.discounts
      : (Array.isArray(existingCache?.discounts) && existingCache.discounts.length > 0
        ? existingCache.discounts
        : (getDefaultDatabase().discounts || []));

    const payloadToSave = {
      _initialized: true,
      centerInfo: mergedCenterInfo,
      adminAccounts: Array.isArray(data.adminAccounts) ? data.adminAccounts : (existingCache?.adminAccounts || getDefaultDatabase().adminAccounts || []),
      courses: Array.isArray(data.courses) ? data.courses : (existingCache?.courses || []),
      batches: Array.isArray(data.batches) ? data.batches : (existingCache?.batches || []),
      educators: Array.isArray(data.educators) ? data.educators : (existingCache?.educators || []),
      students: Array.isArray(data.students) ? data.students : (existingCache?.students || []),
      admissions: Array.isArray(data.admissions) ? data.admissions : (existingCache?.admissions || []),
      payments: Array.isArray(data.payments) ? data.payments : (existingCache?.payments || []),
      expenses: Array.isArray(data.expenses) ? data.expenses : (existingCache?.expenses || []),
      discounts: finalDiscounts,
      studyMaterials: Array.isArray(data.studyMaterials) ? data.studyMaterials : (existingCache?.studyMaterials || []),
      questions: Array.isArray(data.questions) ? data.questions : (existingCache?.questions || []),
      exams: Array.isArray(data.exams) ? data.exams : (existingCache?.exams || []),
      examSubmissions: Array.isArray(data.examSubmissions) ? data.examSubmissions : (existingCache?.examSubmissions || []),
      liveClasses: Array.isArray(data.liveClasses) ? data.liveClasses : (existingCache?.liveClasses || []),
      classRecordings: Array.isArray(data.classRecordings) ? data.classRecordings : (existingCache?.classRecordings || []),
      notifications: Array.isArray(data.notifications) ? data.notifications : (existingCache?.notifications || [])
    };
    fs.writeFileSync(DATABASE_CACHE_FILE, JSON.stringify(payloadToSave, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing database cache file:', err);
  }
}

// Pre-initialize database cache on boot
readDatabaseCache();

// Extract clean spreadsheet ID from URL or ID string
function extractSpreadsheetId(input: string): string | null {
  if (!input) return null;
  const clean = input.trim();
  const urlMatch = clean.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (urlMatch && urlMatch[1]) {
    return urlMatch[1];
  }
  if (/^[a-zA-Z0-9-_]{20,}$/.test(clean)) {
    return clean;
  }
  return null;
}

// Helper function to fetch a single Google Sheet tab data via GViz JSON format
async function fetchGvizTab(sheetId: string, tabName: string): Promise<any[][]> {
  try {
    // &headers=0 forces Google Visualization API to return all rows (including row 1) as data rows,
    // avoiding the heuristic where mixed text/numeric columns (like Center_Overview) cause top rows to be collapsed into column headers.
    const url = `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:json&sheet=${encodeURIComponent(tabName)}&headers=0`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 7000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    if (!res.ok) {
      console.warn(`GViz fetch warning for tab ${tabName}: ${res.statusText}`);
      return [];
    }
    const text = await res.text();
    const startIdx = text.indexOf('{');
    const endIdx = text.lastIndexOf('}');
    if (startIdx === -1 || endIdx === -1) return [];
    const jsonStr = text.substring(startIdx, endIdx + 1);
    const parsed = JSON.parse(jsonStr);
    const rows = parsed.table?.rows || [];
    return rows.map((r: any) => {
      const cells = r.c || [];
      return cells.map((cell: any) => {
        if (!cell) return '';
        if (cell.f !== undefined && cell.f !== null) {
          return String(cell.f).trim();
        }
        if (cell.v !== undefined && cell.v !== null) {
          if (typeof cell.v === 'string' && cell.v.startsWith('Date(')) {
            const matches = cell.v.match(/\d+/g);
            if (matches && matches.length >= 3) {
              const y = matches[0];
              const m = String(Number(matches[1]) + 1).padStart(2, '0');
              const d = String(Number(matches[2])).padStart(2, '0');
              return `${y}-${m}-${d}`;
            }
          }
          return cell.v;
        }
        return '';
      });
    });
  } catch (err: any) {
    console.warn(`Error fetching GViz tab ${tabName}:`, err.message);
    return [];
  }
}

// Fetch all database tables directly from Google Sheet ID (e.g. 1HVB5lNLyCIh6Uw0KmSAvaUnlQjfJMroHzAKy1a-4_O4)
export async function fetchGoogleSheetDirectly(sheetId: string = PERMANENT_GOOGLE_SHEET_ID): Promise<any> {
  const targetId = sheetId || PERMANENT_GOOGLE_SHEET_ID;
  console.log(`[Google Sheets Database] Loading live records from Sheet ID: ${targetId}...`);

  const [
    studentsRows,
    admissionsRows,
    paymentsRows,
    coursesBatchesRows,
    educatorsRows,
    expensesRows,
    adminRows,
    overviewRows,
    studyMaterialsRows,
    questionsRows,
    examsRows,
    submissionsRows,
    liveClassesRows,
    classRecordingsRows,
    discountsRows
  ] = await Promise.all([
    fetchGvizTab(targetId, 'Students'),
    fetchGvizTab(targetId, 'Admissions'),
    fetchGvizTab(targetId, 'Fee_Transactions'),
    fetchGvizTab(targetId, 'Courses_Batches'),
    fetchGvizTab(targetId, 'Educators'),
    fetchGvizTab(targetId, 'Expenses'),
    fetchGvizTab(targetId, 'Admin_Credentials'),
    fetchGvizTab(targetId, 'Center_Overview'),
    fetchGvizTab(targetId, 'Study_Materials'),
    fetchGvizTab(targetId, 'Question_Bank'),
    fetchGvizTab(targetId, 'Exams'),
    fetchGvizTab(targetId, 'Exam_Submissions'),
    fetchGvizTab(targetId, 'Live_Classes'),
    fetchGvizTab(targetId, 'Class_Recordings'),
    fetchGvizTab(targetId, 'Discounts')
  ]);

  // Helper date formatter
  const formatDate = (val: any, fallback: string = new Date().toISOString().split('T')[0]): string => {
    if (!val) return fallback;
    const str = String(val).trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;
    if (str.startsWith('Date(')) {
      const m = str.match(/\d+/g);
      if (m && m.length >= 3) {
        return `${m[0]}-${String(Number(m[1]) + 1).padStart(2, '0')}-${String(Number(m[2])).padStart(2, '0')}`;
      }
    }
    const d = new Date(str);
    if (!isNaN(d.getTime())) {
      return d.toISOString().split('T')[0];
    }
    return fallback;
  };

  // Helper phone formatter
  const formatPhone = (val: any): string => {
    if (!val) return '';
    return String(val).replace(/[^\d+]/g, '').trim();
  };

  // 1. Courses & Batches
  const parsedCourses: any[] = [];
  const parsedBatches: any[] = [];
  for (const row of coursesBatchesRows) {
    if (!row || row.length < 2) continue;
    const type = String(row[0] || '').trim().toUpperCase();
    if (type === 'COURSE') {
      const feeNum = Number(String(row[6]).replace(/[^\d.]/g, '')) || 1200;
      parsedCourses.push({
        id: String(row[1] || `course-${Date.now()}`).trim(),
        title: String(row[2] || 'Course').trim(),
        code: String(row[3] || 'CRS').trim(),
        academicClass: String(row[4] || 'Class 9-10').trim(),
        category: String(row[5] || 'General').trim(),
        monthlyFee: feeNum,
        isPopular: String(row[7] || '').toLowerCase().includes('popular') || String(row[7] || '').toLowerCase().includes('yes'),
        description: String(row[8] || '').trim(),
        syllabusPoints: ['Comprehensive Curriculum', 'Formula Bank', 'Chapter Tests'],
        highlights: ['Smart Classrooms', 'Live Doubt Clearing', 'Doubt Sessions'],
        showOnWebsite: true
      });
    } else if (type === 'BATCH') {
      const capNum = parseInt(String(row[6]).replace(/\D/g, '')) || 30;
      const days = row[5] ? String(row[5]).split(',').map((s: string) => s.trim()).filter(Boolean) : ['Mon', 'Wed', 'Fri'];
      const rawMode = String(row[9] || '').toLowerCase().trim();
      const rawRoomOrName = String(row[8] || '').toLowerCase() + ' ' + String(row[2] || '').toLowerCase();
      const mode: 'offline' | 'online' = (rawMode.includes('online') || rawMode.includes('live')) 
        ? 'online' 
        : (rawMode.includes('offline') || rawMode.includes('classroom'))
        ? 'offline'
        : (rawRoomOrName.includes('online') || rawRoomOrName.includes('live'))
        ? 'online'
        : 'offline';

      parsedBatches.push({
        id: String(row[1] || `batch-${Date.now()}`).trim(),
        name: String(row[2] || 'Batch').trim(),
        courseId: String(row[3] || '').trim(),
        timing: String(row[4] || '5:00 PM - 6:30 PM').trim(),
        scheduleDays: days.length > 0 ? days : ['Mon', 'Wed', 'Fri'],
        maxCapacity: capNum,
        educatorId: String(row[7] || '').trim(),
        roomNumber: String(row[8] || 'Room 101').trim(),
        isActive: !String(row[8] || '').toLowerCase().includes('inactive'),
        mode,
        startDate: '2026-04-01'
      });
    }
  }

  // 2. Students
  const parsedStudents: any[] = [];
  for (const row of studentsRows) {
    if (!row || !row[0] || !row[2] || String(row[0]).toLowerCase() === 'student id') continue;
    const rawStatus = String(row[12] || '').toLowerCase().trim();
    const status = rawStatus === 'passed_out' || rawStatus === 'completed'
      ? 'passed_out'
      : rawStatus === 'dropped' || rawStatus === 'inactive'
      ? 'dropped'
      : 'active';
    
    const overrideFee = row[13] ? Number(String(row[13]).replace(/[^\d.]/g, '')) : undefined;
    const admDate = formatDate(row[11]);
    const studentCourseId = String(row[9] || 'course-1').trim();
    const studentBatchId = String(row[10] || 'batch-1').trim();
    const matchedCourse = parsedCourses.find(c => c.id === studentCourseId);
    const matchedBatch = parsedBatches.find(b => b.id === studentBatchId);
    const rawClass = row[14] && typeof row[14] === 'string' && row[14].toLowerCase().includes('class') ? String(row[14]).trim() : '';
    const resolvedClass = rawClass || matchedCourse?.academicClass || matchedBatch?.academicClass || (matchedCourse?.title?.includes('XII') ? 'Class 12' : matchedCourse?.title?.includes('XI') ? 'Class 11' : undefined);

    parsedStudents.push({
      id: String(row[0]).trim(),
      rollNo: String(row[1] || '').trim(),
      name: String(row[2]).trim(),
      studentClass: resolvedClass,
      mobile: formatPhone(row[3]),
      aadhaarNo: String(row[4] || '').trim(),
      email: String(row[5] || '').trim(),
      guardianName: String(row[6] || 'Parent/Guardian').trim(),
      guardianPhone: formatPhone(row[7]),
      address: String(row[8] || '').trim(),
      courseId: studentCourseId,
      batchId: studentBatchId,
      admissionDate: admDate,
      admissionMonth: admDate.substring(0, 7),
      status,
      customMonthlyFeeOverride: overrideFee && !isNaN(overrideFee) ? overrideFee : undefined
    });
  }

  // 3. Admissions
  const parsedAdmissions: any[] = [];
  for (const row of admissionsRows) {
    if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'application id') continue;
    const rawPaymentMode = String(row[11] || 'UPI').toUpperCase().trim();
    const paymentMode = ['UPI', 'CASH', 'ONLINE_GATEWAY', 'BANK_TRANSFER'].includes(rawPaymentMode)
      ? rawPaymentMode
      : 'UPI';
    const appDate = formatDate(row[9]);

    parsedAdmissions.push({
      id: String(row[0]).trim(),
      applicationNo: String(row[0]).trim(),
      studentName: String(row[1]).trim(),
      mobile: formatPhone(row[2]),
      aadhaarNo: String(row[3] || '').trim(),
      email: String(row[4] || '').trim(),
      guardianName: String(row[5] || '').trim(),
      guardianPhone: formatPhone(row[6]),
      address: String(row[15] || 'Raina, Purba Bardhaman, West Bengal').trim(),
      targetCourseId: String(row[7] || 'course-1').trim(),
      status: String(row[8] || 'pending').toLowerCase().trim(),
      appliedDate: appDate,
      initialPaymentStatus: row[10] === 'unpaid' ? 'unpaid' : row[10] === 'at_center' ? 'at_center' : 'paid_advance',
      initialPaymentMode: paymentMode,
      initialPaymentRef: String(row[12] || '').trim(),
      remarks: String(row[13] || '').trim(),
      rejectionReason: String(row[14] || '').trim()
    });
  }

  // 4. Fee Payments
  const parsedPayments: any[] = [];
  for (const row of paymentsRows) {
    if (!row || !row[1] || String(row[0]).toLowerCase() === 'receipt no') continue;
    let monthsList = ['2026-04'];
    if (row[6]) {
      const monthStr = String(row[6]).trim();
      if (monthStr.startsWith('Date(')) {
        const dStr = formatDate(monthStr);
        monthsList = [dStr.substring(0, 7)];
      } else {
        monthsList = monthStr.split(',').map((s: string) => s.trim()).filter(Boolean);
      }
    }
    const rawPaymentMode = String(row[5] || 'UPI').toUpperCase().trim();
    const paymentMode = ['UPI', 'CASH', 'ONLINE_GATEWAY', 'BANK_TRANSFER'].includes(rawPaymentMode)
      ? rawPaymentMode
      : 'UPI';
    const feeAmount = Number(String(row[4]).replace(/[^\d.]/g, '')) || 0;
    const payDate = formatDate(row[8]);

    parsedPayments.push({
      receiptNo: String(row[0] || `REC-${Date.now()}`).trim(),
      id: String(row[1]).trim(),
      studentId: String(row[2] || '').trim(),
      studentName: String(row[3] || '').trim(),
      studentMobile: '',
      studentAadhaar: '',
      courseTitle: 'Tuition Program',
      batchName: 'Active Batch',
      baseMonthlyFee: feeAmount,
      finalAmountPaid: feeAmount,
      totalBaseFee: feeAmount,
      totalDiscount: 0,
      remainingDue: 0,
      paymentMode,
      monthsCovered: monthsList,
      month: monthsList[0] || 'Monthly Fee',
      transactionRef: String(row[7] || '').trim(),
      paymentDate: payDate,
      status: String(row[9] || 'approved').toLowerCase().trim(),
      approvedBy: String(row[10] || 'Admin').trim(),
      rejectionReason: String(row[11] || '').trim(),
      createdAt: new Date().toISOString()
    });
  }

  // Link payment student names
  for (const pay of parsedPayments) {
    const match = parsedStudents.find(s => s.id === pay.studentId);
    if (match) {
      pay.studentName = match.name;
      pay.studentMobile = match.mobile;
      pay.studentAadhaar = match.aadhaarNo;
    }
  }

  // 5. Educators
  const parsedEducators: any[] = [];
  for (const row of educatorsRows) {
    if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'educator id') continue;
    const salary = Number(String(row[6]).replace(/[^\d.]/g, '')) || 25000;
    const exp = Number(String(row[7]).replace(/[^\d.]/g, '')) || 3;
    const joinDate = formatDate(row[9], '2022-04-01');

    parsedEducators.push({
      id: String(row[0]).trim(),
      name: String(row[1]).trim(),
      qualification: String(row[2] || 'M.Sc / B.Tech').trim(),
      subject: String(row[3] || 'Faculty').trim(),
      phone: formatPhone(row[4]),
      email: String(row[5] || '').trim(),
      monthlySalary: salary,
      assignedBatchIds: [],
      experienceYears: exp,
      status: String(row[8] || 'active').toLowerCase().trim(),
      joiningDate: joinDate,
      photoUrl: String(row[10] || '').trim()
    });
  }

  // 6. Expenses
  const parsedExpenses: any[] = [];
  for (const row of expensesRows) {
    if (!row || !row[0] || !row[2] || String(row[0]).toLowerCase() === 'expense id') continue;
    const amount = Number(String(row[3]).replace(/[^\d.]/g, '')) || 0;
    const expDate = formatDate(row[4]);

    parsedExpenses.push({
      id: String(row[0]).trim(),
      category: String(row[1] || 'general').toLowerCase().trim(),
      title: String(row[2]).trim(),
      amount,
      date: expDate,
      paidTo: String(row[5] || 'Vendor').trim(),
      paymentMode: String(row[6] || 'UPI').toUpperCase().trim(),
      receiptNo: String(row[7] || '').trim(),
      notes: String(row[8] || '').trim()
    });
  }

  // 7. Admin Accounts
  const parsedAdminAccounts: any[] = [];
  for (const row of adminRows) {
    if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'admin id') continue;
    parsedAdminAccounts.push({
      id: String(row[0]).trim(),
      username: String(row[1]).trim(),
      name: String(row[2] || 'Admin').trim(),
      role: String(row[3] || 'Administrator').trim(),
      email: String(row[4] || 'admin@pixelpathsala.com').trim(),
      password: String(row[5] || 'admin123').trim(),
      securityPin: String(row[6] || '7722').trim(),
      status: String(row[7] || 'active').toLowerCase().trim(),
      lastLogin: String(row[8] || '').trim(),
      updatedAt: String(row[9] || '').trim()
    });
  }

  // 8. Center Overview
  const parsedCenterInfo: Record<string, any> = {};
  for (const row of overviewRows) {
    if (!row || row.length < 2) continue;
    const key = String(row[0] || '').trim().toLowerCase();
    const val = (row[1] !== undefined && row[1] !== null) ? String(row[1]).trim() : '';
    if (!key || key.includes('parameter') || key.includes('center property')) continue;

    if ((key.includes('center name') || key.includes('institute name') || key === 'name') && val) {
      parsedCenterInfo.name = val;
    } else if ((key.includes('tagline') || key.includes('motto')) && val) {
      parsedCenterInfo.tagline = val;
    } else if ((key.includes('campus address') || key.includes('center address') || key === 'address') && val) {
      parsedCenterInfo.address = val;
    } else if ((key.includes('city') || key.includes('state')) && val) {
      parsedCenterInfo.cityState = val;
    } else if (((key.includes('primary helpline') || key.includes('primary phone') || (key.includes('phone') && !key.includes('alternate') && !key.includes('secondary') && !key.includes('office')) || key === 'phone' || key.includes('helpline'))) && val) {
      parsedCenterInfo.phonePrimary = val;
    } else if ((key.includes('alternate phone') || key.includes('office desk') || key.includes('secondary phone')) && val) {
      parsedCenterInfo.phoneSecondary = val;
    } else if (key.includes('whatsapp') && val) {
      parsedCenterInfo.whatsapp = val;
    } else if ((key.includes('official email') || key === 'email') && val) {
      parsedCenterInfo.email = val;
    } else if (key.includes('facebook') && val) {
      parsedCenterInfo.facebookUrl = val;
    } else if (key.includes('youtube') && val) {
      parsedCenterInfo.youtubeUrl = val;
    } else if ((key.includes('upi id') || key === 'upi' || key.includes('vpa')) && val) {
      parsedCenterInfo.upiId = val;
    } else if ((key.includes('upi name') || key.includes('payee name') || key.includes('account name') || key.includes('upi account')) && val) {
      parsedCenterInfo.upiName = val;
    } else if ((key.includes('registration number') || key.includes('reg number') || key.includes('reg. no') || key.includes('reg no')) && val) {
      parsedCenterInfo.regNumber = val;
    } else if ((key.includes('established year') || key.includes('estd') || key === 'year') && val) {
      parsedCenterInfo.establishedYear = val;
    } else if (key.includes('admission') && (key.includes('status') || key.includes('open')) && val) {
      parsedCenterInfo.admissionOpen = val.toLowerCase().includes('open') || val.toLowerCase().includes('yes') || val.toLowerCase().includes('true');
      parsedCenterInfo.isAdmissionsOpen = parsedCenterInfo.admissionOpen;
    } else if ((key.includes('announcement') || key.includes('notice')) && val) {
      parsedCenterInfo.announcement = val;
    } else if ((key.includes('welcome') || key.includes('homepage overview') || key.includes('overview')) && val) {
      parsedCenterInfo.welcomeMessage = val;
    } else if ((key.includes('webhook url') || key.includes('google sheet webhook')) && val) {
      parsedCenterInfo.googleSheetWebhookUrl = val;
    } else if ((key.includes('database id') || key.includes('sheet id') || key.includes('spreadsheet id')) && val) {
      parsedCenterInfo.googleSheetId = val;
    } else if ((key.includes('center logo') || key.includes('logo url') || key === 'logo') && val) {
      parsedCenterInfo.logoUrl = val;
    } else if ((key.includes('app download') || key.includes('apk download')) && val) {
      parsedCenterInfo.apkDownloadUrl = val;
      parsedCenterInfo.appDownloadUrl = val;
    } else if ((key.includes('background cover') || key.includes('bg url') || key.includes('background image')) && val) {
      parsedCenterInfo.bgUrl = val;
    }
  }

  // 9. Study Materials
  const parsedStudyMaterials: any[] = [];
  for (const row of studyMaterialsRows) {
    if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'material id') continue;
    const upDate = formatDate(row[10]);
    parsedStudyMaterials.push({
      id: String(row[0]).trim(),
      title: String(row[1]).trim(),
      subject: String(row[2] || '').trim(),
      courseId: String(row[3] || 'all').trim(),
      batchId: String(row[4] || 'all').trim(),
      fileType: String(row[5] || 'pdf').toLowerCase().trim(),
      fileName: String(row[6] || 'material.pdf').trim(),
      fileSize: String(row[7] || '1.5 MB').trim(),
      fileUrl: String(row[8] || '').trim(),
      uploadedBy: String(row[9] || 'Faculty').trim(),
      uploadedDate: upDate,
      downloadCount: Number(String(row[11]).replace(/\D/g, '')) || 0,
      description: String(row[12] || '').trim()
    });
  }

  // 10. Question Bank
  const parsedQuestions: any[] = [];
  for (const row of questionsRows) {
    if (!row || !row[0] || !row[7] || String(row[0]).toLowerCase() === 'question id') continue;
    const opt0 = String(row[8] || '').trim();
    const opt1 = String(row[9] || '').trim();
    const opt2 = String(row[10] || '').trim();
    const opt3 = String(row[11] || '').trim();
    const options = [opt0, opt1, opt2, opt3].filter(Boolean);
    const correctRaw = String(row[12] || '0').trim().toUpperCase();
    let correctIdx = 0;
    if (correctRaw === 'B' || correctRaw === '1') correctIdx = 1;
    else if (correctRaw === 'C' || correctRaw === '2') correctIdx = 2;
    else if (correctRaw === 'D' || correctRaw === '3') correctIdx = 3;

    parsedQuestions.push({
      id: String(row[0]).trim(),
      courseId: String(row[1] || 'all').trim(),
      academicClass: String(row[2] || '').trim(),
      subject: String(row[3] || 'General').trim(),
      topic: String(row[4] || 'Core Concepts').trim(),
      marks: Number(String(row[5]).replace(/[^\d.]/g, '')) || 1,
      difficulty: (['easy', 'medium', 'hard'].includes(String(row[6]).toLowerCase())) ? String(row[6]).toLowerCase() : 'medium',
      questionText: String(row[7]).trim(),
      options: options.length >= 2 ? options : ['Option A', 'Option B', 'Option C', 'Option D'],
      correctOptionIndex: correctIdx,
      codeSnippet: String(row[13] || '').trim(),
      explanation: String(row[14] || '').trim(),
      createdAt: formatDate(row[15])
    });
  }

  // 11. Exams
  const parsedExams: any[] = [];
  for (const row of examsRows) {
    if (!row || !row[0] || !row[2] || String(row[0]).toLowerCase() === 'exam id') continue;
    const qIdsStr = String(row[17] || '').trim();
    const qIds = qIdsStr ? qIdsStr.split(',').map((q: string) => q.trim()).filter(Boolean) : [];
    const schedDate = formatDate(row[13]);
    const isPub = String(row[19] || '').toLowerCase().includes('yes') || String(row[19] || '').toLowerCase().includes('true');

    parsedExams.push({
      id: String(row[0]).trim(),
      examCode: String(row[1] || `EX-${Date.now()}`).trim(),
      title: String(row[2]).trim(),
      courseId: String(row[3] || 'all').trim(),
      batchId: String(row[4] || 'all').trim(),
      academicClass: String(row[5] || '').trim(),
      subject: String(row[6] || 'General').trim(),
      durationMinutes: Number(String(row[7]).replace(/\D/g, '')) || 45,
      totalMarks: Number(String(row[8]).replace(/\D/g, '')) || 25,
      passingMarks: Number(String(row[9]).replace(/\D/g, '')) || 10,
      passingPercentage: Number(String(row[10]).replace(/\D/g, '')) || 40,
      status: (['scheduled', 'active', 'completed', 'draft'].includes(String(row[11]).toLowerCase())) ? String(row[11]).toLowerCase() : 'scheduled',
      mode: String(row[12] || '').toLowerCase().includes('online') ? 'online' : 'offline',
      scheduledDate: schedDate,
      startTime: String(row[14] || '10:00 AM').trim(),
      endTime: String(row[15] || '06:00 PM').trim(),
      questionIds: qIds,
      instructions: String(row[18] || '').trim(),
      isPublished: isPub,
      createdAt: formatDate(row[20])
    });
  }

  // 12. Exam Submissions
  const parsedSubmissions: any[] = [];
  for (const row of submissionsRows) {
    if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'submission id') continue;
    const scoreVal = Number(String(row[9]).replace(/[^\d.]/g, '')) || 0;
    const totalVal = Number(String(row[10]).replace(/[^\d.]/g, '')) || 25;
    const pctVal = Number(String(row[11]).replace(/[^\d.]/g, '')) || (totalVal > 0 ? (scoreVal / totalVal) * 100 : 0);
    const passVal = String(row[12] || '').toLowerCase().includes('pass') || pctVal >= 40;

    parsedSubmissions.push({
      id: String(row[0]).trim(),
      examId: String(row[1]).trim(),
      examTitle: String(row[2] || '').trim(),
      studentId: String(row[3] || '').trim(),
      studentName: String(row[4] || '').trim(),
      studentRollNo: String(row[5] || '').trim(),
      studentAadhaar: String(row[6] || '').trim(),
      courseId: String(row[7] || '').trim(),
      batchId: String(row[8] || '').trim(),
      score: scoreVal,
      totalMarks: totalVal,
      percentage: pctVal,
      passed: passVal,
      timeSpentSeconds: Number(String(row[13]).replace(/\D/g, '')) || 600,
      submittedAt: formatDate(row[14]),
      answers: {},
      questionBreakdown: []
    });
  }

  // 13. Live Classes
  const parsedLiveClasses: any[] = [];
  for (const row of liveClassesRows) {
    if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'session id') continue;
    
    let targetClass = 'All Classes';
    let subject = 'General';
    let courseId = 'all';
    let batchId = 'all';
    let educatorName = 'Faculty';
    let scheduledDate = new Date().toISOString().split('T')[0];
    let startTime = '10:00 AM';
    let endTime = '11:00 AM';
    let status = 'scheduled';
    let platform = 'google_meet';
    let meetingUrl = '';
    let isRecordingAvailable = false;
    let createdAt = new Date().toISOString();

    // Intelligent format detection (15-column with Academic Class vs 14-column legacy)
    const is15ColFormat = 
      row.length >= 15 ||
      ['scheduled', 'live', 'completed', 'cancelled'].includes(String(row[10] || '').toLowerCase().trim()) ||
      ['google_meet', 'zoom', 'youtube_live', 'in_app', 'jitsi', 'custom'].includes(String(row[11] || '').toLowerCase().trim()) ||
      (row[7] && /^\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(String(row[7]).trim())) ||
      (row[8] && /(am|pm|:\d{2})/i.test(String(row[8]).trim()));

    if (is15ColFormat) {
      targetClass = String(row[2] || 'All Classes').trim();
      subject = String(row[3] || 'General').trim();
      courseId = String(row[4] || 'all').trim();
      batchId = String(row[5] || 'all').trim();
      educatorName = String(row[6] || 'Faculty').trim();
      scheduledDate = formatDate(row[7]);
      startTime = String(row[8] || '10:00 AM').trim();
      endTime = String(row[9] || '11:00 AM').trim();
      status = (['scheduled', 'live', 'completed', 'cancelled'].includes(String(row[10] || '').toLowerCase().trim())) 
        ? String(row[10]).toLowerCase().trim() 
        : 'scheduled';
      platform = (['google_meet', 'zoom', 'youtube_live', 'in_app', 'jitsi', 'custom'].includes(String(row[11] || '').toLowerCase().trim()))
        ? String(row[11]).toLowerCase().trim()
        : 'google_meet';
      meetingUrl = String(row[12] || '').trim();
      isRecordingAvailable = String(row[13] || '').toLowerCase().includes('yes') || String(row[13] || '').toLowerCase().includes('true');
      createdAt = formatDate(row[14]);
    } else {
      subject = String(row[2] || 'General').trim();
      courseId = String(row[3] || 'all').trim();
      batchId = String(row[4] || 'all').trim();
      educatorName = String(row[5] || 'Faculty').trim();
      scheduledDate = formatDate(row[6]);
      startTime = String(row[7] || '10:00 AM').trim();
      endTime = String(row[8] || '11:00 AM').trim();
      status = (['scheduled', 'live', 'completed', 'cancelled'].includes(String(row[9] || '').toLowerCase().trim())) 
        ? String(row[9]).toLowerCase().trim() 
        : 'scheduled';
      platform = (['google_meet', 'zoom', 'youtube_live', 'in_app', 'jitsi', 'custom'].includes(String(row[10] || '').toLowerCase().trim()))
        ? String(row[10]).toLowerCase().trim()
        : 'google_meet';
      meetingUrl = String(row[11] || '').trim();
      isRecordingAvailable = String(row[12] || '').toLowerCase().includes('yes') || String(row[12] || '').toLowerCase().includes('true');
      createdAt = formatDate(row[13]);
    }

    parsedLiveClasses.push({
      id: String(row[0]).trim(),
      title: String(row[1]).trim(),
      academicClass: targetClass,
      targetClass,
      subject,
      courseId,
      batchId,
      educatorName,
      scheduledDate,
      date: scheduledDate,
      startTime,
      endTime,
      status,
      platform,
      meetingUrl,
      meetingLink: meetingUrl,
      isRecordingAvailable,
      recordingAvailable: isRecordingAvailable,
      createdAt
    });
  }

  // 14. Class Recordings
  const parsedClassRecordings: any[] = [];
  for (const row of classRecordingsRows) {
    if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'recording id') continue;
    
    let targetClass = 'All Classes';
    let subject = 'General';
    let topic = '';
    let chapter = '';
    let courseId = 'all';
    let batchId = 'all';
    let educatorName = 'Faculty';
    let recordedDate = new Date().toISOString().split('T')[0];
    let durationMinutes = 60;
    let videoSourceType = 'youtube';
    let videoUrl = '';
    let notesPdfUrl = '';
    let viewCount = 0;
    let createdAt = new Date().toISOString();

    const is16ColFormat =
      row.length >= 16 ||
      ['youtube', 'drive', 'mp4', 'vimeo', 'embed', 'zoom_cloud'].includes(String(row[11] || '').toLowerCase().trim()) ||
      (row[9] && /^\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(String(row[9]).trim()));

    if (is16ColFormat) {
      targetClass = String(row[2] || 'All Classes').trim();
      subject = String(row[3] || 'General').trim();
      topic = String(row[4] || '').trim();
      chapter = String(row[5] || '').trim();
      courseId = String(row[6] || 'all').trim();
      batchId = String(row[7] || 'all').trim();
      educatorName = String(row[8] || 'Faculty').trim();
      recordedDate = formatDate(row[9]);
      durationMinutes = Number(String(row[10]).replace(/\D/g, '')) || 60;
      videoSourceType = (['youtube', 'drive', 'mp4', 'vimeo', 'embed', 'zoom_cloud'].includes(String(row[11] || '').toLowerCase().trim()))
        ? String(row[11]).toLowerCase().trim()
        : 'youtube';
      videoUrl = String(row[12] || '').trim();
      notesPdfUrl = String(row[13] || '').trim();
      viewCount = Number(String(row[14]).replace(/\D/g, '')) || 0;
      createdAt = formatDate(row[15] || row[14]);
    } else {
      subject = String(row[2] || 'General').trim();
      topic = String(row[3] || '').trim();
      chapter = String(row[4] || '').trim();
      courseId = String(row[5] || 'all').trim();
      batchId = String(row[6] || 'all').trim();
      educatorName = String(row[7] || 'Faculty').trim();
      recordedDate = formatDate(row[8]);
      durationMinutes = Number(String(row[9]).replace(/\D/g, '')) || 60;
      videoSourceType = (['youtube', 'drive', 'mp4', 'vimeo', 'embed', 'zoom_cloud'].includes(String(row[10] || '').toLowerCase().trim()))
        ? String(row[10]).toLowerCase().trim()
        : 'youtube';
      videoUrl = String(row[11] || '').trim();
      notesPdfUrl = String(row[12] || '').trim();
      viewCount = Number(String(row[13]).replace(/\D/g, '')) || 0;
      createdAt = formatDate(row[14]);
    }

    parsedClassRecordings.push({
      id: String(row[0]).trim(),
      title: String(row[1]).trim(),
      academicClass: targetClass,
      targetClass,
      subject,
      topic,
      chapter,
      courseId,
      batchId,
      educatorName,
      recordedDate,
      durationMinutes,
      videoSourceType,
      sourceType: videoSourceType,
      videoUrl,
      notesPdfUrl,
      viewCount,
      createdAt
    });
  }

  // 15. Discounts
  const parsedDiscounts: any[] = [];
  for (const row of (discountsRows || [])) {
    if (!row || !row[0] || !row[1] || String(row[0]).toLowerCase() === 'discount id' || String(row[1]).toLowerCase() === 'discount title') continue;
    const type = String(row[2] || '').toLowerCase().includes('percent') ? 'percentage' : 'flat';
    const val = Number(String(row[3]).replace(/[^\d.]/g, '')) || 0;
    const rawScope = String(row[4] || '').toLowerCase().trim();
    const scope = (['all', 'class', 'course', 'batch', 'student'].includes(rawScope) ? rawScope : 'all') as 'all' | 'class' | 'course' | 'batch' | 'student';
    const rawMonthsType = String(row[9] || '').toLowerCase().includes('select') ? 'selected_months' : 'all_months';
    const months = row[10] ? String(row[10]).split(',').map((s: string) => s.trim()).filter(Boolean) : undefined;
    const active = !String(row[12] || '').toLowerCase().includes('disabled') && 
                   !String(row[12] || '').toLowerCase().includes('inactive') && 
                   !String(row[12] || '').toLowerCase().includes('false');

    parsedDiscounts.push({
      id: String(row[0]).trim(),
      title: String(row[1]).trim(),
      type,
      value: val,
      scope,
      academicClass: String(row[5] || '').trim() || undefined,
      courseId: String(row[6] || '').trim() || undefined,
      batchId: String(row[7] || '').trim() || undefined,
      studentId: String(row[8] || '').trim() || undefined,
      applicableMonthsType: rawMonthsType,
      selectedMonths: months,
      reason: String(row[11] || '').trim() || undefined,
      active,
      createdAt: formatDate(row[13])
    });
  }

  const existingCache = readDatabaseCache();

  // True two-way state resolution:
  // If the sheet tab was queried and returned rows (or an empty data table), the live Google Sheet state
  // is authoritative and row deletions in the sheet are accurately reflected in the ERP.
  const payload = {
    students: (studentsRows && studentsRows.length > 0) ? parsedStudents : (existingCache.students || []),
    admissions: (admissionsRows && admissionsRows.length > 0) ? parsedAdmissions : (existingCache.admissions || []),
    payments: (paymentsRows && paymentsRows.length > 0) ? parsedPayments : (existingCache.payments || []),
    courses: (coursesBatchesRows && coursesBatchesRows.length > 0) ? parsedCourses : (existingCache.courses || []),
    batches: (coursesBatchesRows && coursesBatchesRows.length > 0) ? parsedBatches : (existingCache.batches || []),
    educators: (educatorsRows && educatorsRows.length > 0) ? parsedEducators : (existingCache.educators || []),
    expenses: (expensesRows && expensesRows.length > 0) ? parsedExpenses : (existingCache.expenses || []),
    discounts: (discountsRows && discountsRows.length > 0 && parsedDiscounts.length > 0)
      ? parsedDiscounts
      : (Array.isArray(existingCache.discounts) && existingCache.discounts.length > 0
        ? existingCache.discounts
        : (getDefaultDatabase().discounts || [])),
    adminAccounts: (adminRows && adminRows.length > 0 && parsedAdminAccounts.length > 0) ? parsedAdminAccounts : (existingCache.adminAccounts || []),
    studyMaterials: (studyMaterialsRows && studyMaterialsRows.length > 0) ? parsedStudyMaterials : (existingCache.studyMaterials || []),
    questions: (questionsRows && questionsRows.length > 0) ? parsedQuestions : (existingCache.questions || []),
    exams: (examsRows && examsRows.length > 0) ? parsedExams : (existingCache.exams || []),
    examSubmissions: (submissionsRows && submissionsRows.length > 0) ? parsedSubmissions : (existingCache.examSubmissions || []),
    liveClasses: (liveClassesRows && liveClassesRows.length > 0) ? parsedLiveClasses : (existingCache.liveClasses || []),
    classRecordings: (classRecordingsRows && classRecordingsRows.length > 0) ? parsedClassRecordings : (existingCache.classRecordings || []),
    notifications: Array.isArray(existingCache.notifications) ? existingCache.notifications : [],
    centerInfo: { ...(existingCache.centerInfo || {}), ...parsedCenterInfo, googleSheetId: targetId }
  };

  const nowTime = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  const config = readConfig();
  config.googleSheetId = targetId;
  config.isConfigured = true;
  config.lastSynced = nowTime;
  config.tableStats = {
    students: payload.students.length,
    admissions: payload.admissions.length,
    payments: payload.payments.length,
    courses: payload.courses.length,
    batches: payload.batches.length,
    educators: payload.educators.length,
    expenses: payload.expenses.length,
    discounts: payload.discounts.length,
    adminAccounts: payload.adminAccounts.length,
    studyMaterials: payload.studyMaterials.length,
    questions: payload.questions.length,
    exams: payload.exams.length,
    examSubmissions: payload.examSubmissions.length,
    liveClasses: payload.liveClasses.length,
    classRecordings: payload.classRecordings.length
  };

  writeConfig(config);
  writeDatabaseCache(payload);
  console.log(`[Google Sheets Database] Successfully loaded & cached all 15 tables (${payload.students.length} students, ${payload.admissions.length} admissions, ${payload.payments.length} fees, ${payload.discounts.length} discounts, ${payload.studyMaterials.length} materials, ${payload.questions.length} questions, ${payload.exams.length} exams, ${(payload.liveClasses || []).length} live classes)!`);
  return payload;
}

// -------------------------------------------------------------
// API ROUTES
// -------------------------------------------------------------

// Health Check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Database & Connection Status
app.get('/api/db/status', (req: Request, res: Response) => {
  const config = readConfig();
  const sheetId = config.googleSheetId || PERMANENT_GOOGLE_SHEET_ID;
  res.json({
    success: true,
    isConfigured: true,
    isConnected: true,
    hasToken: !!config.accessToken,
    googleSheetId: sheetId,
    googleSheetTitle: config.googleSheetTitle || 'Pixel Pathsala - Master ERP Database',
    spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
    googleUser: config.googleUser,
    lastSynced: config.lastSynced,
    connectedAt: config.connectedAt,
    autoSyncEnabled: config.autoSyncEnabled,
    tableStats: config.tableStats
  });
});

// Save / Update Google OAuth session on the server
app.post('/api/db/session', async (req: Request, res: Response) => {
  try {
    const { accessToken, googleUser, expiresIn } = req.body;
    if (!accessToken) {
      return res.status(400).json({ success: false, error: 'accessToken is required' });
    }

    const config = readConfig();
    config.accessToken = accessToken;
    config.googleUser = googleUser || config.googleUser;
    config.connectedAt = new Date().toISOString();
    config.tokenExpiry = Date.now() + (expiresIn || 3600) * 1000;
    config.isConfigured = true;

    // Verify token by making a lightweight call
    try {
      await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { 'Authorization': `Bearer ${accessToken}` }
      });
    } catch {
      // continue
    }

    writeConfig(config);
    res.json({
      success: true,
      message: 'Google session persisted on server successfully.',
      config: {
        googleUser: config.googleUser,
        googleSheetId: config.googleSheetId,
        connectedAt: config.connectedAt
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Disconnect Google Account from server
app.post('/api/db/disconnect', (req: Request, res: Response) => {
  const config = readConfig();
  config.accessToken = null;
  config.tokenExpiry = null;
  config.googleUser = null;
  config.connectedAt = null;
  writeConfig(config);
  res.json({ success: true, message: 'Google account disconnected from server.' });
});

// Admin Authentication strictly against Database
app.post('/api/auth/admin-login', (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;
    const cleanUser = (username || '').trim().toLowerCase();
    const cleanPass = (password || '').trim();

    if (!cleanUser || !cleanPass) {
      return res.status(400).json({ success: false, message: 'Username/Email and Password are required.' });
    }

    const cached = readDatabaseCache() || {};
    const adminAccounts: any[] = cached.adminAccounts || [
      {
        id: 'ADM-001',
        username: 'admin',
        password: 'admin123',
        name: 'Director / Center Administrator',
        role: 'Master Administrator',
        email: 'admin@pixelpathsala.com',
        phone: '+91 9775708722',
        status: 'active'
      }
    ];

    const matched = adminAccounts.find(
      (a: any) =>
        (a.username?.toLowerCase() === cleanUser || a.email?.toLowerCase() === cleanUser) &&
        a.status === 'active' &&
        (a.password === cleanPass || (cleanPass === 'admin123' && a.password === 'admin123'))
    );

    if (matched) {
      const nowTime = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' });
      matched.lastLogin = nowTime;
      // Update cache
      writeDatabaseCache({ ...cached, adminAccounts });

      return res.json({
        success: true,
        message: 'Authentication successful from database.',
        adminUser: {
          id: matched.id,
          username: matched.username,
          name: matched.name,
          role: matched.role,
          email: matched.email,
          phone: matched.phone,
          lastLogin: nowTime
        }
      });
    }

    return res.status(401).json({
      success: false,
      message: 'Invalid Admin credentials. User account was not found or password does not match in database.'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Student Authentication strictly against Database
app.post('/api/auth/student-login', (req: Request, res: Response) => {
  try {
    const { mobile, aadhaarNo } = req.body;
    const cleanMobile = (mobile || '').replace(/\D/g, '').slice(-10);
    const cleanAadhaar = (aadhaarNo || '').replace(/\D/g, '');

    if (!cleanMobile || cleanMobile.length < 10) {
      return res.status(400).json({ success: false, message: 'Please provide a valid 10-digit registered mobile number.' });
    }

    const cached = readDatabaseCache() || {};
    const students: any[] = cached.students || [];

    const matched = students.find((s: any) => {
      const stuMobile = (s.mobile || '').replace(/\D/g, '').slice(-10);
      const stuAadhaar = (s.aadhaarNo || '').replace(/\D/g, '');
      const stuRoll = (s.rollNo || '').toLowerCase();

      const mobileMatches = stuMobile === cleanMobile;
      let identifierMatches = false;

      if (cleanAadhaar) {
        if (stuAadhaar === cleanAadhaar || stuAadhaar.endsWith(cleanAadhaar) || cleanAadhaar.endsWith(stuAadhaar)) {
          identifierMatches = true;
        }
      }

      if (!identifierMatches && aadhaarNo) {
        const checkRoll = aadhaarNo.trim().toLowerCase();
        if (stuRoll === checkRoll) {
          identifierMatches = true;
        }
      }

      return mobileMatches && (identifierMatches || !cleanAadhaar);
    });

    if (matched) {
      return res.json({
        success: true,
        message: `Welcome ${matched.name}!`,
        student: matched
      });
    }

    return res.status(404).json({
      success: false,
      message: 'No student record found matching this Mobile Number and Aadhaar/Roll No in database.'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Canonical 31-row Center Overview matrix generator to maintain consistent structure across all endpoints
function buildCanonicalCenterOverviewRows(centerInfo: any, payload: any = {}): any[][] {
  const c = centerInfo || {};
  return [
    ['Parameter / Property', 'Current Center Value'],
    ['Institute Name', c.name || 'Pixel Pathsala'],
    ['Tagline / Motto', c.tagline || ''],
    ['Campus Address', c.address || ''],
    ['City & State', c.cityState || ''],
    ['Primary Helpline Phone', c.phonePrimary || ''],
    ['Office Desk Phone (Alternate)', c.phoneSecondary || ''],
    ['Official WhatsApp Number', c.whatsapp || c.phonePrimary || ''],
    ['Official Email', c.email || ''],
    ['Facebook Page URL', c.facebookUrl || ''],
    ['YouTube Channel URL', c.youtubeUrl || ''],
    ['UPI ID for Fees', c.upiId || ''],
    ['UPI Payee Name', c.upiName || ''],
    ['Registration Number', c.regNumber || ''],
    ['Established Year', String(c.establishedYear || '2021')],
    ['Admissions Status', (c.isAdmissionsOpen !== false && c.admissionOpen !== false) ? 'Open' : 'Closed'],
    ['Announcement Notice Banner', c.announcement || ''],
    ['Homepage Welcome Overview', c.welcomeMessage || ''],
    ['Google Sheet Webhook URL', c.googleSheetWebhookUrl || ''],
    ['Google Sheet Database ID', c.googleSheetId || ''],
    ['Center Logo URL', c.logoUrl || ''],
    ['App Download URL', c.apkDownloadUrl || c.appDownloadUrl || ''],
    ['Background Cover URL', c.bgUrl || ''],
    ['Active Students Count', (payload.students || []).filter((s: any) => s.status === 'active').length],
    ['Total Enrolled Students', (payload.students || []).length],
    ['Total Admissions Count', (payload.admissions || []).length],
    ['Total Courses Count', (payload.courses || []).length],
    ['Total Batches Count', (payload.batches || []).length],
    ['Total Educators Count', (payload.educators || []).length],
    ['Total Fee Collections Count', (payload.payments || []).length],
    ['Total Fees Collected (₹)', (payload.payments || []).reduce((acc: number, p: any) => acc + (p.finalAmountPaid || 0), 0)],
    ['Total Expenses (₹)', (payload.expenses || []).reduce((acc: number, x: any) => acc + (x.amount || 0), 0)],
    ['Database Engine', 'Google Sheets Live Cloud Database (Pixel Pathsala ERP)'],
    ['Last Cloud Sync Time', new Date().toISOString()]
  ];
}

// Canonical Discounts matrix generator
function buildDiscountsData(discounts: any[]): any[][] {
  return [
    ['Discount ID', 'Discount Title', 'Discount Type (flat/percentage)', 'Value (₹ / %)', 'Scope (all/class/course/batch/student)', 'Target Academic Class', 'Target Course ID', 'Target Batch ID', 'Target Student ID', 'Applicable Months Type', 'Selected Months', 'Reason / Description', 'Active Status', 'Created At'],
    ...((discounts || []).map((d: any) => [
      d.id || `disc-${Date.now()}`,
      d.title || 'Concession Offer',
      d.type || 'flat',
      d.value || 0,
      d.scope || 'all',
      d.academicClass || '',
      d.courseId || '',
      d.batchId || '',
      d.studentId || '',
      d.applicableMonthsType || 'all_months',
      Array.isArray(d.selectedMonths) ? d.selectedMonths.join(', ') : '',
      d.reason || '',
      d.active !== false ? 'Active' : 'Disabled',
      d.createdAt || new Date().toISOString().split('T')[0]
    ]))
  ];
}

// Automatically ensure all required data table tabs exist in Google Sheet and format them
async function ensureAllSpreadsheetTabs(sheetId: string, accessToken?: string): Promise<{ created: string[]; existing: string[]; success: boolean }> {
  try {
    const config = readConfig();
    const token = accessToken || config.accessToken;
    if (accessToken) {
      config.accessToken = accessToken;
      writeConfig(config);
    }
    if (!token || !sheetId) {
      return { created: [], existing: [], success: false };
    }

    const meta = await callGoogleApi(`/${sheetId}?fields=sheets(properties(sheetId,title))`, 'GET');
    const existingTitles: string[] = (meta.sheets || []).map((s: any) => s.properties?.title).filter(Boolean);
    const existingSet = new Set(existingTitles);

    const requiredTables = [
      'Students',
      'Admissions',
      'Fee_Transactions',
      'Courses_Batches',
      'Educators',
      'Expenses',
      'Admin_Credentials',
      'Center_Overview',
      'Study_Materials',
      'Question_Bank',
      'Exams',
      'Exam_Submissions',
      'Live_Classes',
      'Class_Recordings',
      'Discounts'
    ];

    const missingTables = requiredTables.filter(t => !existingSet.has(t));
    const created: string[] = [];

    if (missingTables.length > 0) {
      const addSheetRequests = missingTables.map(title => ({
        addSheet: {
          properties: {
            title,
            gridProperties: {
              rowCount: 500,
              columnCount: 22
            }
          }
        }
      }));
      await callGoogleApi(`/${sheetId}:batchUpdate`, 'POST', {
        requests: addSheetRequests
      });
      created.push(...missingTables);
      console.log(`[Google Sheets Auto-Setup] Automatically created missing tables in sheet: ${missingTables.join(', ')}`);
    }

    // Write default headers & initial rows for tables (especially Discounts)
    const cache = readDatabaseCache();
    const payload = build15TablesPayload(cache);
    const valueUpdates: any[] = [];

    for (const tableName of requiredTables) {
      const tableRows = payload[tableName];
      if (tableRows && tableRows.length > 0) {
        valueUpdates.push({
          range: `${tableName}!A1:V${Math.max(2, tableRows.length)}`,
          values: tableRows
        });
      }
    }

    if (valueUpdates.length > 0) {
      await callGoogleApi(`/${sheetId}/values:batchUpdate`, 'POST', {
        valueInputOption: 'USER_ENTERED',
        data: valueUpdates
      });
      console.log(`[Google Sheets Auto-Setup] Formatted and wrote data tables for: ${requiredTables.join(', ')}`);
    }

    return { created, existing: existingTitles, success: true };
  } catch (err: any) {
    console.warn('[Google Sheets Auto-Setup note]:', err.message);
    return { created: [], existing: [], success: false };
  }
}

// Auto-Create Master Database Google Sheet with all 15 tables
app.post('/api/db/create-master-sheet', async (req: Request, res: Response) => {
  try {
    const config = readConfig();
    const { centerInfo, initialData } = req.body;
    const centerName = centerInfo?.name || 'Pixel Pathsala';

    const sheetTitles = [
      'Students',
      'Admissions',
      'Fee_Transactions',
      'Courses_Batches',
      'Educators',
      'Expenses',
      'Admin_Credentials',
      'Center_Overview',
      'Study_Materials',
      'Question_Bank',
      'Exams',
      'Exam_Submissions',
      'Live_Classes',
      'Class_Recordings',
      'Discounts'
    ];

    // Create Spreadsheet in Google Drive
    const createRes = await callGoogleApi('', 'POST', {
      properties: {
        title: `${centerName} - Master ERP Database`
      },
      sheets: sheetTitles.map(title => ({
        properties: {
          title,
          gridProperties: {
            rowCount: 500,
            columnCount: 22
          }
        }
      }))
    });

    const newSpreadsheetId = createRes.spreadsheetId;
    if (!newSpreadsheetId) {
      throw new Error('Google Drive did not return a valid Spreadsheet ID.');
    }

    // Prepare table headers and initial rows
    const studentsData = [
      ['Student ID', 'Roll No', 'Full Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Residential Address', 'Course ID', 'Batch ID', 'Admission Date', 'Status', 'Custom Fee Override (₹)', 'Monthly Base Fee (₹)', 'Total Paid (₹)', 'Outstanding Due (₹)'],
      ...((initialData?.students || []).map((s: any) => [
        s.id || '',
        s.rollNo || '',
        s.name || '',
        s.mobile || '',
        s.aadhaarNo || '',
        s.email || '',
        s.guardianName || '',
        s.guardianPhone || '',
        s.address || '',
        s.courseId || '',
        s.batchId || '',
        s.admissionDate || '',
        s.status || 'active',
        s.customMonthlyFeeOverride || '',
        s.monthlyFee || '',
        s.totalPaid || '',
        s.totalDue || ''
      ]))
    ];

    const admissionsData = [
      ['Application ID', 'Student Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Target Course ID', 'Status', 'Applied Date', 'Initial Fee Status', 'Payment Mode', 'Transaction Ref / UPI', 'Staff Remarks', 'Rejection Reason', 'Address'],
      ...((initialData?.admissions || []).map((a: any) => [
        a.id || '',
        a.studentName || '',
        a.mobile || '',
        a.aadhaarNo || '',
        a.email || '',
        a.guardianName || '',
        a.guardianPhone || '',
        a.targetCourseId || '',
        a.status || 'pending',
        a.appliedDate || '',
        a.initialPaymentStatus || 'paid_advance',
        a.initialPaymentMode || 'UPI',
        a.initialPaymentRef || '',
        a.remarks || '',
        a.rejectionReason || '',
        a.address || ''
      ]))
    ];

    const feePaymentsData = [
      ['Receipt No', 'Payment ID', 'Student ID', 'Student Name', 'Amount Paid (₹)', 'Payment Mode', 'Months Covered', 'Transaction Ref / UPI', 'Payment Date', 'Approval Status', 'Approved By', 'Rejection Reason'],
      ...((initialData?.payments || []).map((p: any) => [
        p.receiptNo || '',
        p.id || '',
        p.studentId || '',
        p.studentName || '',
        p.finalAmountPaid || 0,
        p.paymentMode || 'UPI',
        Array.isArray(p.monthsCovered) ? p.monthsCovered.join(', ') : (p.month || ''),
        p.transactionRef || '',
        p.paymentDate || '',
        p.status || 'approved',
        p.approvedBy || 'Admin',
        p.rejectionReason || ''
      ]))
    ];

    const coursesBatchesData = [
      ['Record Type', 'ID', 'Title / Batch Name', 'Code / Course ID', 'Academic Class / Timings', 'Category / Schedule Days', 'Monthly Fee (₹) / Max Capacity', 'Popular / Educator ID', 'Description / Room', 'Batch Mode / Delivery Mode'],
      ...((initialData?.courses || []).map((c: any) => [
        'COURSE',
        c.id || '',
        c.title || '',
        c.code || '',
        c.academicClass || '',
        c.category || '',
        c.monthlyFee || 0,
        c.isPopular ? 'Yes (Popular)' : 'Standard',
        c.description || '',
        'Offline & Online (Classroom & Live)'
      ])),
      ...((initialData?.batches || []).map((b: any) => [
        'BATCH',
        b.id || '',
        b.name || '',
        b.courseId || '',
        b.timing || '',
        Array.isArray(b.scheduleDays) ? b.scheduleDays.join(', ') : '',
        b.maxCapacity || 30,
        b.educatorId || '',
        b.roomNumber || '',
        b.mode === 'online' ? 'Online (Live)' : 'Offline (Classroom)'
      ]))
    ];

    const educatorsData = [
      ['Educator ID', 'Full Name', 'Qualification', 'Specialization Subject', 'Phone Number', 'Email Address', 'Monthly Salary (₹)', 'Experience (Yrs)', 'Employment Status', 'Joining Date', 'Photo URL'],
      ...((initialData?.educators || []).map((e: any) => [
        e.id || '',
        e.name || '',
        e.qualification || '',
        e.subject || '',
        e.phone || '',
        e.email || '',
        e.monthlySalary || 0,
        e.experienceYears || 0,
        e.status || 'active',
        e.joiningDate || e.joinDate || '',
        e.photoUrl || ''
      ]))
    ];

    const expensesData = [
      ['Expense ID', 'Category', 'Expense Title', 'Amount Paid (₹)', 'Payment Date', 'Paid To / Vendor', 'Payment Mode', 'Receipt Reference', 'Notes'],
      ...((initialData?.expenses || []).map((ex: any) => [
        ex.id || '',
        ex.category || 'general',
        ex.title || '',
        ex.amount || 0,
        ex.date || '',
        ex.paidTo || '',
        ex.paymentMode || 'UPI',
        ex.receiptNo || '',
        ex.notes || ''
      ]))
    ];

    const adminData = [
      ['Admin ID', 'Username', 'Full Name', 'Role Title', 'Email Address', 'Password Hash/Plain', 'Security PIN', 'Status', 'Last Login', 'Updated At'],
      ...((initialData?.adminAccounts || []).map((acc: any) => [
        acc.id || 'admin-1',
        acc.username || 'admin',
        acc.name || 'Center Administrator',
        acc.role || 'Super Admin',
        acc.email || centerInfo?.email || 'admin@pixelpathsala.com',
        acc.password || 'admin123',
        acc.securityPin || '7722',
        acc.status || 'active',
        acc.lastLogin || '',
        new Date().toISOString()
      ]))
    ];

    const overviewData = buildCanonicalCenterOverviewRows(centerInfo, initialData);

    const studyMaterialsData = [
      ['Material ID', 'Title', 'Subject', 'Course ID', 'Batch ID', 'File Type', 'File Name', 'File Size', 'File URL / Link', 'Uploaded By', 'Uploaded Date', 'Download Count', 'Description'],
      ...((initialData?.studyMaterials || []).map((m: any) => [
        m.id || '',
        m.title || '',
        m.subject || '',
        m.courseId || 'all',
        m.batchId || 'all',
        m.fileType || 'pdf',
        m.fileName || '',
        m.fileSize || '',
        m.fileUrl || '',
        m.uploadedBy || 'Faculty',
        m.uploadedDate || '',
        m.downloadCount || 0,
        m.description || ''
      ]))
    ];

    const questionsData = [
      ['Question ID', 'Course ID', 'Academic Class', 'Subject', 'Topic', 'Marks', 'Difficulty', 'Question Text', 'Option A', 'Option B', 'Option C', 'Option D', 'Correct Option Index', 'Code Snippet', 'Explanation', 'Created At'],
      ...((initialData?.questions || []).map((q: any) => [
        q.id || '',
        q.courseId || 'all',
        q.academicClass || '',
        q.subject || '',
        q.topic || '',
        q.marks || 1,
        q.difficulty || 'medium',
        q.questionText || '',
        (q.options && q.options[0]) || '',
        (q.options && q.options[1]) || '',
        (q.options && q.options[2]) || '',
        (q.options && q.options[3]) || '',
        q.correctOptionIndex ?? 0,
        q.codeSnippet || '',
        q.explanation || '',
        q.createdAt || ''
      ]))
    ];

    const examsData = [
      ['Exam ID', 'Exam Code', 'Title', 'Course ID', 'Batch ID', 'Academic Class', 'Subject', 'Duration (Mins)', 'Total Marks', 'Passing Marks', 'Passing %', 'Status', 'Mode', 'Scheduled Date', 'Start Time', 'End Time', 'Question Count', 'Question IDs', 'Instructions', 'Published', 'Created At'],
      ...((initialData?.exams || []).map((x: any) => [
        x.id || '',
        x.examCode || '',
        x.title || '',
        x.courseId || 'all',
        x.batchId || 'all',
        x.academicClass || '',
        x.subject || '',
        x.durationMinutes || 45,
        x.totalMarks || 25,
        x.passingMarks || 10,
        x.passingPercentage || 40,
        x.status || 'scheduled',
        x.mode || 'online',
        x.scheduledDate || '',
        x.startTime || '',
        x.endTime || '',
        (x.questionIds || []).length,
        (x.questionIds || []).join(', '),
        x.instructions || '',
        x.isPublished ? 'Yes' : 'No',
        x.createdAt || ''
      ]))
    ];

    const submissionsData = [
      ['Submission ID', 'Exam ID', 'Exam Title', 'Student ID', 'Student Name', 'Roll No', 'Aadhaar No', 'Course ID', 'Batch ID', 'Score Obtained', 'Total Marks', 'Percentage (%)', 'Result Status', 'Time Spent (Secs)', 'Submitted At', 'Answers Summary'],
      ...((initialData?.examSubmissions || []).map((sub: any) => [
        sub.id || '',
        sub.examId || '',
        sub.examTitle || '',
        sub.studentId || '',
        sub.studentName || '',
        sub.studentRollNo || '',
        sub.studentAadhaar || '',
        sub.courseId || '',
        sub.batchId || '',
        sub.score || 0,
        sub.totalMarks || 25,
        sub.percentage || 0,
        sub.passed ? 'PASSED' : 'NEEDS IMPROVEMENT',
        sub.timeSpentSeconds || 0,
        sub.submittedAt || '',
        JSON.stringify(sub.answers || {})
      ]))
    ];

    const discountsData = buildDiscountsData(initialData?.discounts || []);

    const liveClassesData = [
      ['Session ID', 'Class Title', 'Academic Class', 'Subject', 'Course ID', 'Batch ID', 'Educator Name', 'Date', 'Start Time', 'End Time', 'Status', 'Platform', 'Meeting Link / Room ID', 'Recording Available', 'Created At'],
      ...((initialData?.liveClasses || []).map((lc: any) => [
        lc.id || '', lc.title || '', lc.academicClass || lc.targetClass || 'All Classes', lc.subject || '', lc.courseId || 'all', lc.batchId || 'all', lc.educatorName || 'Faculty',
        lc.scheduledDate || '', lc.startTime || '', lc.endTime || '', lc.status || 'scheduled', lc.platform || 'in_app',
        lc.meetingUrl || lc.inAppRoomId || '', lc.isRecordingAvailable ? 'Yes' : 'No', lc.createdAt || ''
      ]))
    ];

    const recordingsData = [
      ['Recording ID', 'Title', 'Academic Class', 'Subject', 'Topic', 'Chapter', 'Course ID', 'Batch ID', 'Educator Name', 'Recorded Date', 'Duration (Mins)', 'Source Type', 'Video URL', 'Notes PDF URL', 'View Count', 'Created At'],
      ...((initialData?.classRecordings || []).map((rec: any) => [
        rec.id || '', rec.title || '', rec.academicClass || rec.targetClass || 'All Classes', rec.subject || '', rec.topic || '', rec.chapter || '', rec.courseId || 'all', rec.batchId || 'all',
        rec.educatorName || 'Faculty', rec.recordedDate || '', rec.durationMinutes || 60, rec.videoSourceType || 'youtube',
        rec.videoUrl || '', rec.notesPdfUrl || '', rec.viewCount || 0, rec.createdAt || ''
      ]))
    ];

    // Push initial values to all 15 sheets in batch
    await callGoogleApi(`/${newSpreadsheetId}/values:batchUpdate`, 'POST', {
      valueInputOption: 'USER_ENTERED',
      data: [
        { range: 'Students!A1:Q500', values: studentsData },
        { range: 'Admissions!A1:P500', values: admissionsData },
        { range: 'Fee_Transactions!A1:L500', values: feePaymentsData },
        { range: 'Courses_Batches!A1:J500', values: coursesBatchesData },
        { range: 'Educators!A1:K500', values: educatorsData },
        { range: 'Expenses!A1:I500', values: expensesData },
        { range: 'Admin_Credentials!A1:J100', values: adminData },
        { range: 'Center_Overview!A1:B50', values: overviewData },
        { range: 'Study_Materials!A1:M500', values: studyMaterialsData },
        { range: 'Question_Bank!A1:P500', values: questionsData },
        { range: 'Exams!A1:U500', values: examsData },
        { range: 'Exam_Submissions!A1:P500', values: submissionsData },
        { range: 'Live_Classes!A1:O500', values: liveClassesData },
        { range: 'Class_Recordings!A1:P500', values: recordingsData },
        { range: 'Discounts!A1:N500', values: discountsData }
      ]
    });

    // Update server config
    config.googleSheetId = newSpreadsheetId;
    config.googleSheetTitle = `${centerName} - Master ERP Database`;
    config.lastSynced = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    config.isConfigured = true;
    config.tableStats = {
      students: initialData?.students?.length || 0,
      admissions: initialData?.admissions?.length || 0,
      payments: initialData?.payments?.length || 0,
      courses: initialData?.courses?.length || 0,
      batches: initialData?.batches?.length || 0,
      educators: initialData?.educators?.length || 0,
      expenses: initialData?.expenses?.length || 0,
      discounts: (initialData?.discounts || []).length,
      adminAccounts: initialData?.adminAccounts?.length || 1,
      studyMaterials: initialData?.studyMaterials?.length || 0,
      questions: initialData?.questions?.length || 0,
      exams: initialData?.exams?.length || 0,
      examSubmissions: initialData?.examSubmissions?.length || 0,
      liveClasses: (initialData?.liveClasses || []).length,
      classRecordings: (initialData?.classRecordings || []).length
    };
    writeConfig(config);

    if (initialData) {
      writeDatabaseCache(initialData);
    }

    res.json({
      success: true,
      spreadsheetId: newSpreadsheetId,
      spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${newSpreadsheetId}/edit`,
      message: `Master Google Sheet Database created and linked successfully with all 14 tables!`
    });
  } catch (err: any) {
    console.error('Create Master Sheet Error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Link an existing Google Sheet ID
app.post('/api/db/link-sheet', async (req: Request, res: Response) => {
  try {
    const { spreadsheetIdOrUrl } = req.body;
    const cleanId = extractSpreadsheetId(spreadsheetIdOrUrl);
    if (!cleanId) {
      return res.status(400).json({ success: false, error: 'Invalid Google Sheet URL or ID format.' });
    }

    const metadata = await callGoogleApi(`/${cleanId}?fields=properties.title,sheets.properties.title`);
    const sheetTitle = metadata.properties?.title || 'Linked Google Sheet';
    const existingSheets = (metadata.sheets || []).map((s: any) => s.properties?.title);

    const config = readConfig();
    config.googleSheetId = cleanId;
    config.googleSheetTitle = sheetTitle;
    config.lastSynced = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    config.isConfigured = true;
    writeConfig(config);

    res.json({
      success: true,
      spreadsheetId: cleanId,
      title: sheetTitle,
      sheets: existingSheets,
      spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${cleanId}/edit`,
      message: `Successfully linked Google Sheet: "${sheetTitle}"`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Load all 8 database tables live from Google Sheets
app.get('/api/db/load-all', async (req: Request, res: Response) => {
  try {
    const config = readConfig();
    const queryId = (req.query.spreadsheetId as string) || (req.query.sheetId as string);
    const sheetId = queryId || config.googleSheetId || PERMANENT_GOOGLE_SHEET_ID;

    const payload = await fetchGoogleSheetDirectly(sheetId);
    const updatedConfig = readConfig();

    return res.json({
      success: true,
      fromLiveGoogleSheet: true,
      data: payload,
      counts: updatedConfig.tableStats,
      lastSynced: updatedConfig.lastSynced || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      spreadsheetId: sheetId,
      spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`
    });
  } catch (err: any) {
    console.warn('Load all from Google Sheets note (served local DB cache):', err.message);
    const cached = readDatabaseCache();
    const updatedConfig = readConfig();
    return res.json({
      success: true,
      fromCache: true,
      data: cached,
      counts: updatedConfig.tableStats,
      warning: err.message,
      message: 'Google Sheets direct read timed out; served latest server database cache.'
    });
  }
});

// Pull fresh state directly from Google Sheets
app.post('/api/db/pull-all', async (req: Request, res: Response) => {
  try {
    const config = readConfig();
    const targetSheetId = req.body.spreadsheetId || config.googleSheetId || PERMANENT_GOOGLE_SHEET_ID;
    const payload = await fetchGoogleSheetDirectly(targetSheetId);
    const updatedConfig = readConfig();

    return res.json({
      success: true,
      message: 'Successfully pulled latest records from Google Sheet database!',
      data: payload,
      counts: updatedConfig.tableStats,
      lastSynced: updatedConfig.lastSynced || new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
    });
  } catch (err: any) {
    console.error('Pull all error:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Helper function to build normalized 14-table matrix payload for Google Apps Script Webhook
function build14TablesPayload(payload: any): Record<string, any[][]> {
  return {
    Students: [
      ['Student ID', 'Roll No', 'Full Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Residential Address', 'Course ID', 'Batch ID', 'Admission Date', 'Status', 'Custom Fee Override (₹)', 'Monthly Base Fee (₹)', 'Total Paid (₹)', 'Outstanding Due (₹)'],
      ...((payload.students || []).map((s: any) => [
        s.id || '', s.rollNo || '', s.name || '', s.mobile || '', s.aadhaarNo || '', s.email || '',
        s.guardianName || '', s.guardianPhone || '', s.address || '', s.courseId || '', s.batchId || '',
        s.admissionDate || '', s.status || 'active', s.customMonthlyFeeOverride || '', s.monthlyFee || '',
        s.totalPaid || '', s.totalDue || ''
      ]))
    ],
    Admissions: [
      ['Application ID', 'Student Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Target Course ID', 'Status', 'Applied Date', 'Initial Fee Status', 'Payment Mode', 'Transaction Ref / UPI', 'Staff Remarks', 'Rejection Reason', 'Address'],
      ...((payload.admissions || []).map((a: any) => [
        a.id || a.applicationNo || '', a.studentName || '', a.mobile || '', a.aadhaarNo || '', a.email || '',
        a.guardianName || '', a.guardianPhone || '', a.targetCourseId || a.courseId || '', a.status || 'pending', a.appliedDate || '',
        a.initialPaymentStatus || a.initialFeeStatus || 'UNPAID', a.initialPaymentMode || a.paymentMode || 'UPI', a.initialPaymentRef || a.transactionRef || '', a.remarks || '', a.rejectionReason || '', a.address || ''
      ]))
    ],
    Fee_Transactions: [
      ['Receipt No', 'Payment ID', 'Student ID', 'Student Name', 'Amount Paid (₹)', 'Payment Mode', 'Months Covered', 'Transaction Ref / UPI', 'Payment Date', 'Approval Status', 'Approved By', 'Rejection Reason'],
      ...((payload.payments || []).map((p: any) => {
        const student = (payload.students || []).find((s: any) => 
          s.id === p.studentId || 
          (s.rollNo && s.rollNo === p.studentId) ||
          (s.aadhaarNo && s.aadhaarNo === p.studentId) ||
          (p.studentName && s.name && s.name.toLowerCase().trim() === p.studentName.toLowerCase().trim())
        );
        const name = p.studentName || student?.name || student?.rollNo || 'Student';
        const rawMonths = Array.isArray(p.monthsCovered) ? p.monthsCovered : [p.month || p.feeMonthsCovered];
        return [
          p.receiptNo || '', p.id || '', p.studentId || '', name, p.finalAmountPaid || p.amount || 0,
          p.paymentMode || 'UPI', rawMonths.filter(Boolean).join(', '), p.transactionRef || '', p.paymentDate || '',
          p.status || 'approved', p.approvedBy || 'Admin', p.rejectionReason || p.remarks || ''
        ];
      }))
    ],
    Courses_Batches: [
      ['Record Type', 'ID', 'Title / Batch Name', 'Code / Course ID', 'Academic Class / Timings', 'Category / Schedule Days', 'Monthly Fee (₹) / Max Capacity', 'Popular / Educator ID', 'Description / Room', 'Batch Mode / Delivery Mode'],
      ...((payload.courses || []).map((c: any) => [
        'COURSE', c.id || '', c.title || '', c.code || '', c.academicClass || '', c.category || '',
        c.monthlyFee || 0, c.isPopular ? 'Yes (Popular)' : 'Standard', c.description || '', 'Offline & Online (Classroom & Live)'
      ])),
      ...((payload.batches || []).map((b: any) => [
        'BATCH', b.id || '', b.name || '', b.courseId || '', b.timing || '', Array.isArray(b.scheduleDays) ? b.scheduleDays.join(', ') : (b.days ? b.days.join(', ') : ''),
        b.maxCapacity || b.capacity || 30, b.educatorId || '', b.room || '', b.mode || 'offline'
      ]))
    ],
    Educators: [
      ['Educator ID', 'Full Name', 'Qualification', 'Specialization Subject', 'Phone Number', 'Email Address', 'Monthly Salary (₹)', 'Experience (Yrs)', 'Employment Status', 'Joining Date', 'Photo URL'],
      ...((payload.educators || []).map((e: any) => [
        e.id || '', e.name || '', e.qualification || '', e.subject || '', e.phone || '', e.email || '',
        e.monthlySalary || 0, e.experienceYears || 0, e.status || 'active', e.joiningDate || e.joinDate || '', e.photoUrl || ''
      ]))
    ],
    Expenses: [
      ['Expense ID', 'Category', 'Expense Title', 'Amount Paid (₹)', 'Payment Date', 'Paid To / Vendor', 'Payment Mode', 'Receipt Reference', 'Notes'],
      ...((payload.expenses || []).map((x: any) => [
        x.id || '', x.category || '', x.title || '', x.amount || 0, x.date || '', x.paidTo || '',
        x.paymentMode || 'UPI', x.receiptNo || '', x.notes || ''
      ]))
    ],
    Admin_Credentials: [
      ['Admin ID', 'Username', 'Full Name', 'Role Title', 'Email Address', 'Password Hash/Plain', 'Security PIN', 'Status', 'Last Login', 'Updated At'],
      ...((payload.adminAccounts && payload.adminAccounts.length > 0 ? payload.adminAccounts : [{
        id: 'ADM-001', username: 'admin', password: '••••••••', name: 'Director', role: 'Master Admin', email: payload.centerInfo?.email || '', phone: payload.centerInfo?.phonePrimary, securityPin: '7722', status: 'active', lastLogin: '', updatedAt: ''
      }]).map((adm: any) => [
        adm.id || '', adm.username || '', adm.name || '', adm.role || '', adm.email || '', adm.password || '',
        adm.securityPin || '', adm.status || 'active', adm.lastLogin || '', adm.updatedAt || ''
      ]))
    ],
    Center_Overview: buildCanonicalCenterOverviewRows(payload.centerInfo, payload),
    Study_Materials: [
      ['Material ID', 'Title', 'Subject', 'Course ID', 'Batch ID', 'File Type', 'File Name', 'File Size', 'File URL / Link', 'Uploaded By', 'Uploaded Date', 'Download Count', 'Description'],
      ...((payload.studyMaterials || []).map((m: any) => [
        m.id || '', m.title || '', m.subject || '', m.courseId || 'all', m.batchId || 'all', m.fileType || 'pdf',
        m.fileName || '', m.fileSize || '', m.fileUrl || '', m.uploadedBy || 'Faculty', m.uploadedDate || '', m.downloadCount || 0, m.description || ''
      ]))
    ],
    Question_Bank: [
      ['Question ID', 'Course ID', 'Academic Class', 'Subject', 'Topic', 'Marks', 'Difficulty', 'Question Text', 'Option A', 'Option B', 'Option C', 'Option D', 'Correct Option Index', 'Code Snippet', 'Explanation', 'Created At'],
      ...((payload.questions || []).map((q: any) => [
        q.id || '', q.courseId || 'all', q.academicClass || '', q.subject || '', q.topic || '', q.marks || 1, q.difficulty || 'medium',
        q.questionText || '', (q.options && q.options[0]) || '', (q.options && q.options[1]) || '', (q.options && q.options[2]) || '',
        (q.options && q.options[3]) || '', q.correctOptionIndex ?? 0, q.codeSnippet || '', q.explanation || '', q.createdAt || ''
      ]))
    ],
    Exams: [
      ['Exam ID', 'Exam Code', 'Title', 'Course ID', 'Batch ID', 'Academic Class', 'Subject', 'Duration (Mins)', 'Total Marks', 'Passing Marks', 'Passing %', 'Status', 'Mode', 'Scheduled Date', 'Start Time', 'End Time', 'Question Count', 'Question IDs', 'Instructions', 'Published', 'Created At'],
      ...((payload.exams || []).map((x: any) => [
        x.id || '', x.examCode || '', x.title || '', x.courseId || 'all', x.batchId || 'all', x.academicClass || '', x.subject || '',
        x.durationMinutes || 45, x.totalMarks || 25, x.passingMarks || 10, x.passingPercentage || 40, x.status || 'scheduled', x.mode || 'online',
        x.scheduledDate || '', x.startTime || '', x.endTime || '', (x.questionIds || []).length, (x.questionIds || []).join(', '),
        x.instructions || '', x.isPublished ? 'Yes' : 'No', x.createdAt || ''
      ]))
    ],
    Exam_Submissions: [
      ['Submission ID', 'Exam ID', 'Exam Title', 'Student ID', 'Student Name', 'Roll No', 'Aadhaar No', 'Course ID', 'Batch ID', 'Score Obtained', 'Total Marks', 'Percentage (%)', 'Result Status', 'Time Spent (Secs)', 'Submitted At', 'Answers Summary'],
      ...((payload.examSubmissions || []).map((sub: any) => [
        sub.id || '', sub.examId || '', sub.examTitle || '', sub.studentId || '', sub.studentName || '', sub.studentRollNo || '',
        sub.studentAadhaar || '', sub.courseId || '', sub.batchId || '', sub.score || 0, sub.totalMarks || 25, sub.percentage || 0,
        sub.passed ? 'PASSED' : 'NEEDS IMPROVEMENT', sub.timeSpentSeconds || 0, sub.submittedAt || '', JSON.stringify(sub.answers || {})
      ]))
    ],
    Live_Classes: [
      ['Session ID', 'Class Title', 'Academic Class', 'Subject', 'Course ID', 'Batch ID', 'Educator Name', 'Date', 'Start Time', 'End Time', 'Status', 'Platform', 'Meeting Link / Room ID', 'Recording Available', 'Created At'],
      ...((payload.liveClasses || []).map((lc: any) => [
        lc.id || '', lc.title || '', lc.academicClass || lc.targetClass || 'All Classes', lc.subject || '', lc.courseId || 'all', lc.batchId || 'all', lc.educatorName || 'Faculty',
        lc.scheduledDate || '', lc.startTime || '', lc.endTime || '', lc.status || 'scheduled', lc.platform || 'in_app',
        lc.meetingUrl || lc.inAppRoomId || '', lc.isRecordingAvailable ? 'Yes' : 'No', lc.createdAt || ''
      ]))
    ],
    Class_Recordings: [
      ['Recording ID', 'Title', 'Academic Class', 'Subject', 'Topic', 'Chapter', 'Course ID', 'Batch ID', 'Educator Name', 'Recorded Date', 'Duration (Mins)', 'Source Type', 'Video URL', 'Notes PDF URL', 'View Count', 'Created At'],
      ...((payload.classRecordings || []).map((rec: any) => [
        rec.id || '', rec.title || '', rec.academicClass || rec.targetClass || 'All Classes', rec.subject || '', rec.topic || '', rec.chapter || '', rec.courseId || 'all', rec.batchId || 'all',
        rec.educatorName || 'Faculty', rec.recordedDate || '', rec.durationMinutes || 60, rec.videoSourceType || 'youtube',
        rec.videoUrl || '', rec.notesPdfUrl || '', rec.viewCount || 0, rec.createdAt || ''
      ]))
    ],
    Discounts: buildDiscountsData(payload.discounts || [])
  };
}

const build15TablesPayload = build14TablesPayload;
const build12TablesPayload = build14TablesPayload;

// Forward payload to Google Apps Script Live Webhook (Instant Write-Back)
async function forwardToWebhook(payload: any): Promise<{ success: boolean; message?: string; rawResponse?: string }> {
  try {
    const config = readConfig();
    const webhookUrl = payload.centerInfo?.googleSheetWebhookUrl || config.webhookUrl || config.googleSheetWebhookUrl;
    if (!webhookUrl || config.autoWriteBack === false) return { success: false, message: 'No webhook configured' };
    
    console.log(`[Google Sheets Webhook] Executing live write-back to webhook: ${webhookUrl.substring(0, 45)}...`);

    const tablesPayload = build14TablesPayload(payload);

    const res = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: payload.action || 'syncAll',
        timestamp: new Date().toISOString(),
        tables: tablesPayload,
        ...payload
      }),
      redirect: 'follow'
    });
    
    const resText = await res.text();
    console.log('[Google Sheets Webhook] Write-back response:', resText.substring(0, 200));

    // Check for Google login redirect (permissions issue in Apps Script deployment)
    if (resText.includes('accounts.google.com') || resText.includes('<html') && resText.includes('Sign in')) {
      const authError = 'Google Apps Script returned authentication page. Please deploy the Apps Script Web App with "Who has access: Anyone" (not "Only myself").';
      config.lastWebhookStatus = {
        success: false,
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        message: authError
      };
      writeConfig(config);
      return { success: false, message: authError, rawResponse: resText.substring(0, 200) };
    }

    config.lastWebhookStatus = {
      success: true,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      message: 'Live write-back synced all 14 tables successfully'
    };
    writeConfig(config);
    return { success: true, message: 'Live write-back synced all 14 tables successfully', rawResponse: resText.substring(0, 200) };
  } catch (err: any) {
    console.warn('[Google Sheets Webhook Write-Back Error]:', err.message);
    const config = readConfig();
    config.lastWebhookStatus = {
      success: false,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      message: err.message
    };
    writeConfig(config);
    return { success: false, message: err.message };
  }
}

// Full state batch push to Google Sheets and Server DB
app.post('/api/db/save-all', async (req: Request, res: Response) => {
  try {
    const config = readConfig();
    const sheetId = req.body.spreadsheetId || config.googleSheetId;
    const providedToken = req.body.accessToken || (req.headers.authorization ? req.headers.authorization.replace(/^Bearer\s+/i, '') : null);

    if (providedToken) {
      config.accessToken = providedToken;
    }

    const currentCache = readDatabaseCache();
    const discountsToSave = req.body.discounts !== undefined 
      ? req.body.discounts 
      : (Array.isArray(currentCache.discounts) && currentCache.discounts.length > 0 ? currentCache.discounts : (getDefaultDatabase().discounts || []));

    const {
      students = [],
      admissions = [],
      payments = [],
      courses = [],
      batches = [],
      educators = [],
      expenses = [],
      adminAccounts = [],
      studyMaterials = [],
      questions = [],
      exams = [],
      examSubmissions = [],
      liveClasses = [],
      classRecordings = [],
      centerInfo = {}
    } = req.body;

    const discounts = discountsToSave;

    const nowTime = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    config.lastSynced = nowTime;
    config.tableStats = {
      students: students.length,
      admissions: admissions.length,
      payments: payments.length,
      courses: courses.length,
      batches: batches.length,
      educators: educators.length,
      expenses: expenses.length,
      discounts: discounts.length,
      adminAccounts: adminAccounts.length,
      studyMaterials: studyMaterials.length,
      questions: questions.length,
      exams: exams.length,
      examSubmissions: examSubmissions.length,
      liveClasses: liveClasses.length,
      classRecordings: classRecordings.length
    };
    writeConfig(config);
    writeDatabaseCache({
      students,
      admissions,
      payments,
      courses,
      batches,
      educators,
      expenses,
      discounts,
      adminAccounts,
      studyMaterials,
      questions,
      exams,
      examSubmissions,
      liveClasses,
      classRecordings,
      notifications: Array.isArray(req.body.notifications) ? req.body.notifications : [],
      centerInfo
    });

    // Support passing accessToken in body or Authorization header
    const authHeader = req.headers.authorization;
    let token = req.body.accessToken;
    if (!token && authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.split(' ')[1];
    }
    if (token) {
      config.accessToken = token;
      writeConfig(config);
    }
    const effectiveToken = token || config.accessToken;

    // Push to Google Sheets or Webhook
    const shouldPushToSheets = req.body.pushToGoogleSheets !== false;
    const webhookUrl = req.body.centerInfo?.googleSheetWebhookUrl || config.webhookUrl || config.googleSheetWebhookUrl;

    if (webhookUrl && config.autoWriteBack !== false) {
      // Forward in background or return directly if explicitly requested
      if (shouldPushToSheets) {
        const wbRes = await forwardToWebhook(req.body);
        if (wbRes && wbRes.success) {
          return res.json({
            success: true,
            savedToLocalDb: true,
            needsClientSheetsSync: false,
            lastSynced: nowTime,
            message: `Successfully pushed all 15 tables to Google Sheets via Webhook!`
          });
        }
      } else {
        forwardToWebhook(req.body).catch(err => console.warn('Background auto write-back note:', err));
      }
    }

    if (!shouldPushToSheets || !sheetId || !effectiveToken) {
      return res.json({
        success: true,
        savedToLocalDb: true,
        needsClientSheetsSync: false,
        lastSynced: nowTime,
        message: `Successfully saved all 15 tables (${students.length} students, ${admissions.length} admissions, ${courses.length} courses, ${discounts.length} discounts, ${studyMaterials.length} study materials, ${exams.length} exams, ${liveClasses.length} live classes) to server database cache at ${nowTime}.`
      });
    }

    const studentsData = [
      ['Student ID', 'Roll No', 'Full Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Residential Address', 'Course ID', 'Batch ID', 'Admission Date', 'Status', 'Custom Fee Override (₹)', 'Monthly Base Fee (₹)', 'Total Paid (₹)', 'Outstanding Due (₹)'],
      ...students.map((s: any) => [
        s.id || '',
        s.rollNo || '',
        s.name || '',
        s.mobile || '',
        s.aadhaarNo || '',
        s.email || '',
        s.guardianName || '',
        s.guardianPhone || '',
        s.address || '',
        s.courseId || '',
        s.batchId || '',
        s.admissionDate || '',
        s.status || 'active',
        s.customMonthlyFeeOverride || '',
        s.monthlyFee || '',
        s.totalPaid || '',
        s.totalDue || ''
      ])
    ];

    const admissionsData = [
      ['Application ID', 'Student Name', 'Mobile Number', 'Aadhaar No', 'Email', 'Guardian Name', 'Guardian Phone', 'Target Course ID', 'Status', 'Applied Date', 'Initial Fee Status', 'Payment Mode', 'Transaction Ref / UPI', 'Staff Remarks', 'Rejection Reason', 'Address'],
      ...admissions.map((a: any) => [
        a.id || '',
        a.studentName || '',
        a.mobile || '',
        a.aadhaarNo || '',
        a.email || '',
        a.guardianName || '',
        a.guardianPhone || '',
        a.targetCourseId || '',
        a.status || 'pending',
        a.appliedDate || '',
        a.initialPaymentStatus || 'paid_advance',
        a.initialPaymentMode || 'UPI',
        a.initialPaymentRef || '',
        a.remarks || '',
        a.rejectionReason || '',
        a.address || ''
      ])
    ];

    const feePaymentsData = [
      ['Receipt No', 'Payment ID', 'Student ID', 'Student Name', 'Amount Paid (₹)', 'Payment Mode', 'Months Covered', 'Transaction Ref / UPI', 'Payment Date', 'Approval Status', 'Approved By', 'Rejection Reason'],
      ...payments.map((p: any) => [
        p.receiptNo || '',
        p.id || '',
        p.studentId || '',
        p.studentName || '',
        p.finalAmountPaid || 0,
        p.paymentMode || 'UPI',
        Array.isArray(p.monthsCovered) ? p.monthsCovered.join(', ') : (p.month || ''),
        p.transactionRef || '',
        p.paymentDate || '',
        p.status || 'approved',
        p.approvedBy || 'Admin',
        p.rejectionReason || ''
      ])
    ];

    const coursesBatchesData = [
      ['Record Type', 'ID', 'Title / Batch Name', 'Code / Course ID', 'Academic Class / Timings', 'Category / Schedule Days', 'Monthly Fee (₹) / Max Capacity', 'Popular / Educator ID', 'Description / Room', 'Batch Mode / Delivery Mode'],
      ...courses.map((c: any) => [
        'COURSE',
        c.id || '',
        c.title || '',
        c.code || '',
        c.academicClass || '',
        c.category || '',
        c.monthlyFee || 0,
        c.isPopular ? 'Yes (Popular)' : 'Standard',
        c.description || '',
        'Offline & Online (Classroom & Live)'
      ]),
      ...batches.map((b: any) => [
        'BATCH',
        b.id || '',
        b.name || '',
        b.courseId || '',
        b.timing || '',
        Array.isArray(b.scheduleDays) ? b.scheduleDays.join(', ') : '',
        b.maxCapacity || 30,
        b.educatorId || '',
        b.roomNumber || '',
        b.mode === 'online' ? 'Online (Live)' : 'Offline (Classroom)'
      ])
    ];

    const educatorsData = [
      ['Educator ID', 'Full Name', 'Qualification', 'Specialization Subject', 'Phone Number', 'Email Address', 'Monthly Salary (₹)', 'Experience (Yrs)', 'Employment Status', 'Joining Date', 'Photo URL'],
      ...educators.map((e: any) => [
        e.id || '',
        e.name || '',
        e.qualification || '',
        e.subject || '',
        e.phone || '',
        e.email || '',
        e.monthlySalary || 0,
        e.experienceYears || 0,
        e.status || 'active',
        e.joiningDate || e.joinDate || '',
        e.photoUrl || ''
      ])
    ];

    const expensesData = [
      ['Expense ID', 'Category', 'Expense Title', 'Amount Paid (₹)', 'Payment Date', 'Paid To / Vendor', 'Payment Mode', 'Receipt Reference', 'Notes'],
      ...expenses.map((ex: any) => [
        ex.id || '',
        ex.category || 'general',
        ex.title || '',
        ex.amount || 0,
        ex.date || '',
        ex.paidTo || '',
        ex.paymentMode || 'UPI',
        ex.receiptNo || '',
        ex.notes || ''
      ])
    ];

    const adminData = [
      ['Admin ID', 'Username', 'Full Name', 'Role Title', 'Email Address', 'Password Hash/Plain', 'Security PIN', 'Status', 'Last Login', 'Updated At'],
      ...adminAccounts.map((acc: any) => [
        acc.id || 'admin-1',
        acc.username || 'admin',
        acc.name || 'Center Administrator',
        acc.role || 'Super Admin',
        acc.email || centerInfo?.email || 'admin@pixelpathsala.com',
        acc.password || 'admin123',
        acc.securityPin || '7722',
        acc.status || 'active',
        acc.lastLogin || '',
        new Date().toISOString()
      ])
    ];

    const studyMaterialsData = [
      ['Material ID', 'Title', 'Subject', 'Course ID', 'Batch ID', 'File Type', 'File Name', 'File Size', 'File URL / Link', 'Uploaded By', 'Uploaded Date', 'Download Count', 'Description'],
      ...studyMaterials.map((m: any) => [
        m.id || '',
        m.title || '',
        m.subject || '',
        m.courseId || 'all',
        m.batchId || 'all',
        m.fileType || 'pdf',
        m.fileName || '',
        m.fileSize || '',
        m.fileUrl || '',
        m.uploadedBy || 'Faculty',
        m.uploadedDate || '',
        m.downloadCount || 0,
        m.description || ''
      ])
    ];

    const questionsData = [
      ['Question ID', 'Course ID', 'Academic Class', 'Subject', 'Topic', 'Marks', 'Difficulty', 'Question Text', 'Option A', 'Option B', 'Option C', 'Option D', 'Correct Option Index', 'Code Snippet', 'Explanation', 'Created At'],
      ...questions.map((q: any) => [
        q.id || '',
        q.courseId || 'all',
        q.academicClass || '',
        q.subject || '',
        q.topic || '',
        q.marks || 1,
        q.difficulty || 'medium',
        q.questionText || '',
        (q.options && q.options[0]) || '',
        (q.options && q.options[1]) || '',
        (q.options && q.options[2]) || '',
        (q.options && q.options[3]) || '',
        q.correctOptionIndex ?? 0,
        q.codeSnippet || '',
        q.explanation || '',
        q.createdAt || ''
      ])
    ];

    const examsData = [
      ['Exam ID', 'Exam Code', 'Title', 'Course ID', 'Batch ID', 'Academic Class', 'Subject', 'Duration (Mins)', 'Total Marks', 'Passing Marks', 'Passing %', 'Status', 'Mode', 'Scheduled Date', 'Start Time', 'End Time', 'Question Count', 'Question IDs', 'Instructions', 'Published', 'Created At'],
      ...exams.map((x: any) => [
        x.id || '',
        x.examCode || '',
        x.title || '',
        x.courseId || 'all',
        x.batchId || 'all',
        x.academicClass || '',
        x.subject || '',
        x.durationMinutes || 45,
        x.totalMarks || 25,
        x.passingMarks || 10,
        x.passingPercentage || 40,
        x.status || 'scheduled',
        x.mode || 'online',
        x.scheduledDate || '',
        x.startTime || '',
        x.endTime || '',
        (x.questionIds || []).length,
        (x.questionIds || []).join(', '),
        x.instructions || '',
        x.isPublished ? 'Yes' : 'No',
        x.createdAt || ''
      ])
    ];

    const submissionsData = [
      ['Submission ID', 'Exam ID', 'Exam Title', 'Student ID', 'Student Name', 'Roll No', 'Aadhaar No', 'Course ID', 'Batch ID', 'Score Obtained', 'Total Marks', 'Percentage (%)', 'Result Status', 'Time Spent (Secs)', 'Submitted At', 'Answers Summary'],
      ...examSubmissions.map((sub: any) => [
        sub.id || '',
        sub.examId || '',
        sub.examTitle || '',
        sub.studentId || '',
        sub.studentName || '',
        sub.studentRollNo || '',
        sub.studentAadhaar || '',
        sub.courseId || '',
        sub.batchId || '',
        sub.score || 0,
        sub.totalMarks || 25,
        sub.percentage || 0,
        sub.passed ? 'PASSED' : 'NEEDS IMPROVEMENT',
        sub.timeSpentSeconds || 0,
        sub.submittedAt || '',
        JSON.stringify(sub.answers || {})
      ])
    ];

    const liveClassesData = [
      ['Session ID', 'Class Title', 'Academic Class', 'Subject', 'Course ID', 'Batch ID', 'Educator Name', 'Date', 'Start Time', 'End Time', 'Status', 'Platform', 'Meeting Link / Room ID', 'Recording Available', 'Created At'],
      ...liveClasses.map((lc: any) => [
        lc.id || '',
        lc.title || '',
        lc.academicClass || lc.targetClass || 'All Classes',
        lc.subject || '',
        lc.courseId || 'all',
        lc.batchId || 'all',
        lc.educatorName || 'Faculty',
        lc.scheduledDate || '',
        lc.startTime || '',
        lc.endTime || '',
        lc.status || 'scheduled',
        lc.platform || 'in_app',
        lc.meetingUrl || lc.inAppRoomId || '',
        lc.isRecordingAvailable ? 'Yes' : 'No',
        lc.createdAt || ''
      ])
    ];

    const recordingsData = [
      ['Recording ID', 'Title', 'Academic Class', 'Subject', 'Topic', 'Chapter', 'Course ID', 'Batch ID', 'Educator Name', 'Recorded Date', 'Duration (Mins)', 'Source Type', 'Video URL', 'Notes PDF URL', 'View Count', 'Created At'],
      ...classRecordings.map((rec: any) => [
        rec.id || '',
        rec.title || '',
        rec.academicClass || rec.targetClass || 'All Classes',
        rec.subject || '',
        rec.topic || '',
        rec.chapter || '',
        rec.courseId || 'all',
        rec.batchId || 'all',
        rec.educatorName || 'Faculty',
        rec.recordedDate || '',
        rec.durationMinutes || 60,
        rec.videoSourceType || 'youtube',
        rec.videoUrl || '',
        rec.notesPdfUrl || '',
        rec.viewCount || 0,
        rec.createdAt || ''
      ])
    ];

    const overviewData = buildCanonicalCenterOverviewRows(centerInfo, {
      students, admissions, payments, courses, batches, educators, expenses
    });

    const discountsData = buildDiscountsData(discounts);

    // Ensure all 15 tables exist in Google Sheets (especially Discounts) before writing
    try {
      const authHeader = req.headers.authorization;
      let token = req.body.accessToken;
      if (!token && authHeader && authHeader.startsWith('Bearer ')) {
        token = authHeader.split(' ')[1];
      }
      await ensureAllSpreadsheetTabs(sheetId, token || config.accessToken);
    } catch (ensureErr: any) {
      console.warn('Auto ensure tables in save-all note:', ensureErr.message);
    }

    // Wipe stale rows prior to writing so deletions take immediate effect in Google Sheets
    try {
      await callGoogleApi(`/${sheetId}/values:batchClear`, 'POST', {
        ranges: [
          'Students!A2:Q1000',
          'Admissions!A2:P1000',
          'Fee_Transactions!A2:L1000',
          'Courses_Batches!A2:J1000',
          'Educators!A2:K1000',
          'Expenses!A2:I1000',
          'Admin_Credentials!A2:J500',
          'Center_Overview!A1:B50',
          'Study_Materials!A2:M1000',
          'Question_Bank!A2:P1000',
          'Exams!A2:U500',
          'Exam_Submissions!A2:P2000',
          'Live_Classes!A2:O1000',
          'Class_Recordings!A2:P1000',
          'Discounts!A2:N1000'
        ]
      });
    } catch (clearErr: any) {
      console.warn('Batch clear before write note:', clearErr.message);
    }

    await callGoogleApi(`/${sheetId}/values:batchUpdate`, 'POST', {
      valueInputOption: 'USER_ENTERED',
      data: [
        { range: 'Students!A1:Q500', values: studentsData },
        { range: 'Admissions!A1:P500', values: admissionsData },
        { range: 'Fee_Transactions!A1:L500', values: feePaymentsData },
        { range: 'Courses_Batches!A1:J500', values: coursesBatchesData },
        { range: 'Educators!A1:K500', values: educatorsData },
        { range: 'Expenses!A1:I500', values: expensesData },
        { range: 'Admin_Credentials!A1:J100', values: adminData },
        { range: 'Center_Overview!A1:B50', values: overviewData },
        { range: 'Study_Materials!A1:M500', values: studyMaterialsData },
        { range: 'Question_Bank!A1:P500', values: questionsData },
        { range: 'Exams!A1:U500', values: examsData },
        { range: 'Exam_Submissions!A1:P500', values: submissionsData },
        { range: 'Live_Classes!A1:O500', values: liveClassesData },
        { range: 'Class_Recordings!A1:P500', values: recordingsData },
        { range: 'Discounts!A1:N500', values: discountsData }
      ]
    });

    res.json({
      success: true,
      lastSynced: nowTime,
      spreadsheetId: sheetId,
      spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${sheetId}/edit`,
      message: `Successfully pushed all 15 tables to Google Sheets at ${nowTime}!`
    });
  } catch (err: any) {
    console.warn('Google Sheets live push note (persisted to server DB cache):', err.message);
    const config = readConfig();
    if (err.message && (err.message.includes('expired') || err.message.includes('revoked') || err.message.includes('401'))) {
      config.accessToken = null;
      writeConfig(config);
    }
    const syncTimestamp = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    res.json({
      success: true,
      savedToLocalDb: true,
      googleSyncPaused: true,
      warning: err.message,
      lastSynced: syncTimestamp,
      message: 'All ERP records safely persisted to server database.'
    });
  }
});

// Dedicated endpoint to save Center Information & Gateway Configuration
app.post('/api/db/save-center-info', async (req: Request, res: Response) => {
  try {
    const centerInfo = req.body || {};
    const cache = readDatabaseCache();
    cache.centerInfo = { ...(cache.centerInfo || {}), ...centerInfo };
    writeDatabaseCache(cache);

    // Also update server config if webhook URL or sheetId provided
    const config = readConfig();
    if (centerInfo.googleSheetWebhookUrl) {
      config.webhookUrl = centerInfo.googleSheetWebhookUrl;
      config.googleSheetWebhookUrl = centerInfo.googleSheetWebhookUrl;
    }
    if (centerInfo.googleSheetId) {
      config.googleSheetId = centerInfo.googleSheetId;
    }
    writeConfig(config);

    // Forward to webhook with action 'saveCenterInfo' and full tables payload
    const webhookRes = await forwardToWebhook({
      action: 'saveCenterInfo',
      centerInfo: cache.centerInfo,
      ...cache
    });

    // If Google Sheet API linked via OAuth / access token, update Center_Overview
    if (config.googleSheetId && config.accessToken) {
      try {
        const overviewData = buildCanonicalCenterOverviewRows(cache.centerInfo, cache);
        await callGoogleApi(`/${config.googleSheetId}/values/Center_Overview!A1:B50?valueInputOption=USER_ENTERED`, 'PUT', {
          values: overviewData
        });
      } catch (sheetErr: any) {
        console.warn('Center Overview direct sheet update note:', sheetErr.message);
      }
    }

    res.json({
      success: true,
      centerInfo: cache.centerInfo,
      webhookResult: webhookRes,
      message: 'Center Information & Gateway Configuration saved and synchronized to Google Sheet!'
    });
  } catch (err: any) {
    console.error('Error in /api/db/save-center-info:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Dedicated endpoint to approve student admission & record fee payment
app.post('/api/db/approve-admission', async (req: Request, res: Response) => {
  try {
    const { applicationId, student, payment, admission } = req.body;
    const cache = readDatabaseCache();
    
    // Update admissions in cache
    const currentAdmissions = cache.admissions || [];
    const targetAppId = applicationId || admission?.id || admission?.applicationNo;
    const updatedAdmissions = currentAdmissions.map((a: any) => {
      if (a.id === targetAppId || a.applicationNo === targetAppId) {
        return { ...a, status: 'approved', initialPaymentStatus: 'paid_advance' };
      }
      return a;
    });
    cache.admissions = updatedAdmissions;

    // Append student to cache
    const currentStudents = cache.students || [];
    if (student) {
      const existsIndex = currentStudents.findIndex((s: any) => s.id === student.id);
      if (existsIndex >= 0) {
        currentStudents[existsIndex] = student;
      } else {
        cache.students = [student, ...currentStudents];
      }
    }

    // Append payment to cache if payment is present
    if (payment && (payment.finalAmountPaid > 0 || payment.amount > 0)) {
      const currentPayments = cache.payments || [];
      const payExists = currentPayments.findIndex((p: any) => p.id === payment.id || (p.receiptNo && p.receiptNo === payment.receiptNo));
      if (payExists >= 0) {
        currentPayments[payExists] = payment;
      } else {
        cache.payments = [payment, ...currentPayments];
      }
    }

    writeDatabaseCache(cache);

    // Forward to webhook with action 'approveAdmission'
    const webhookRes = await forwardToWebhook({
      action: 'approveAdmission',
      applicationId: targetAppId,
      student,
      payment,
      admission,
      ...cache
    });

    // If OAuth linked, update sheets directly
    const config = readConfig();
    if (config.googleSheetId && config.accessToken) {
      try {
        if (student) {
          const stuRow = [
            student.id || `STU-${Date.now()}`,
            student.rollNo || '',
            student.name || '',
            student.mobile || '',
            student.aadhaarNo || '',
            student.email || '',
            student.guardianName || '',
            student.guardianPhone || '',
            student.address || '',
            student.courseId || '',
            student.batchId || '',
            student.admissionDate || new Date().toISOString().split('T')[0],
            'active',
            student.customMonthlyFeeOverride || '',
            student.monthlyFee || '',
            student.totalPaid || payment?.finalAmountPaid || 0,
            student.totalDue || 0
          ];
          await callGoogleApi(`/${config.googleSheetId}/values/Students!A1:append?valueInputOption=USER_ENTERED`, 'POST', {
            values: [stuRow]
          });
        }
        if (payment && (payment.finalAmountPaid > 0 || payment.amount > 0)) {
          const payRow = [
            payment.receiptNo || `REC-${Date.now()}`,
            payment.id || `PAY-${Date.now()}`,
            student?.id || payment.studentId || '',
            student?.name || payment.studentName || '',
            payment.finalAmountPaid || payment.amount || 0,
            payment.paymentMode || 'UPI',
            Array.isArray(payment.monthsCovered) ? payment.monthsCovered.join(', ') : (payment.month || '2026-04'),
            payment.transactionRef || '',
            payment.paymentDate || new Date().toISOString().split('T')[0],
            payment.status || 'approved',
            payment.approvedBy || 'Admin Approval',
            payment.remarks || `Admission Fee for App #${targetAppId}`
          ];
          await callGoogleApi(`/${config.googleSheetId}/values/Fee_Transactions!A1:append?valueInputOption=USER_ENTERED`, 'POST', {
            values: [payRow]
          });
        }
      } catch (sheetErr: any) {
        console.warn('Admission approval direct Google Sheet write note:', sheetErr.message);
      }
    }

    res.json({
      success: true,
      message: 'Admission approved and payment receipt recorded in Fee_Transactions successfully!',
      webhookResult: webhookRes
    });
  } catch (err: any) {
    console.error('Error in /api/db/approve-admission:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Live record mutation handler (single action append/update)
app.post('/api/db/mutate', async (req: Request, res: Response) => {
  try {
    const { action, payload } = req.body;
    const config = readConfig();
    const sheetId = config.googleSheetId;
    const cache = readDatabaseCache();

    if (!action) {
      return res.status(400).json({ success: false, error: 'action is required' });
    }

    // 1. Update server cache based on action
    if ((action === 'updateCenterInfo' || action === 'saveCenterInfo') && payload) {
      const cInfo = payload.centerInfo || payload;
      cache.centerInfo = { ...(cache.centerInfo || {}), ...cInfo };
      writeDatabaseCache(cache);
    } else if (action === 'approveAdmission' && payload) {
      const { applicationId, student, payment, admission } = payload;
      const targetAppId = applicationId || admission?.id;
      cache.admissions = (cache.admissions || []).map((a: any) =>
        (a.id === targetAppId || a.applicationNo === targetAppId)
          ? { ...a, status: 'approved', initialPaymentStatus: 'paid_advance' }
          : a
      );
      if (student) {
        cache.students = [student, ...(cache.students || []).filter((s: any) => s.id !== student.id)];
      }
      if (payment && (payment.finalAmountPaid > 0 || payment.amount > 0)) {
        cache.payments = [payment, ...(cache.payments || []).filter((p: any) => p.id !== payment.id)];
      }
      writeDatabaseCache(cache);
    } else if ((action === 'addPayment' || action === 'newFeePayment') && payload) {
      const p = payload.payment || payload;
      cache.payments = [p, ...(cache.payments || []).filter((item: any) => item.id !== p.id)];
      // Update student total paid in cache
      if (p.studentId && cache.students) {
        const stuIndex = cache.students.findIndex((s: any) => s.id === p.studentId || s.rollNo === p.studentId);
        if (stuIndex >= 0) {
          const prevPaid = Number(cache.students[stuIndex].totalPaid || 0);
          const newPaid = prevPaid + Number(p.finalAmountPaid || p.amount || 0);
          cache.students[stuIndex].totalPaid = newPaid;
          const baseFee = Number(cache.students[stuIndex].monthlyFee || cache.students[stuIndex].customMonthlyFeeOverride || 1500);
          cache.students[stuIndex].totalDue = Math.max(0, baseFee - newPaid);
        }
      }
      writeDatabaseCache(cache);
    } else if ((action === 'addAdmission' || action === 'newAdmission') && payload) {
      const a = payload.admission || payload;
      cache.admissions = [a, ...(cache.admissions || []).filter((item: any) => item.id !== a.id)];
      writeDatabaseCache(cache);
    } else if ((action === 'addStudent' || action === 'newStudent') && payload) {
      const s = payload.student || payload;
      cache.students = [s, ...(cache.students || []).filter((item: any) => item.id !== s.id)];
      writeDatabaseCache(cache);
    } else if ((action === 'addExpense' || action === 'newExpense') && payload) {
      const ex = payload.expense || payload;
      cache.expenses = [ex, ...(cache.expenses || []).filter((item: any) => item.id !== ex.id)];
      writeDatabaseCache(cache);
    } else if ((action === 'addLiveClass' || action === 'newLiveClass' || action === 'scheduleLiveClass') && payload) {
      const lc = payload.liveClass || payload;
      cache.liveClasses = [lc, ...(cache.liveClasses || []).filter((item: any) => item.id !== lc.id)];
      writeDatabaseCache(cache);
    } else if (action === 'updateLiveClass' && payload) {
      const id = payload.id;
      const updated = payload.updated || payload;
      cache.liveClasses = (cache.liveClasses || []).map((item: any) => item.id === id ? { ...item, ...updated } : item);
      writeDatabaseCache(cache);
    } else if (action === 'deleteLiveClass' && payload) {
      const id = payload.id;
      cache.liveClasses = (cache.liveClasses || []).filter((item: any) => item.id !== id);
      writeDatabaseCache(cache);
    } else if (action === 'setLiveClassStatus' && payload) {
      const { id, status } = payload;
      cache.liveClasses = (cache.liveClasses || []).map((item: any) => item.id === id ? { ...item, status } : item);
      writeDatabaseCache(cache);
    } else if ((action === 'addClassRecording' || action === 'newClassRecording') && payload) {
      const rec = payload.recording || payload;
      cache.classRecordings = [rec, ...(cache.classRecordings || []).filter((item: any) => item.id !== rec.id)];
      writeDatabaseCache(cache);
    } else if (action === 'updateClassRecording' && payload) {
      const id = payload.id;
      const updated = payload.updated || payload;
      cache.classRecordings = (cache.classRecordings || []).map((item: any) => item.id === id ? { ...item, ...updated } : item);
      writeDatabaseCache(cache);
    } else if (action === 'deleteClassRecording' && payload) {
      const id = payload.id;
      cache.classRecordings = (cache.classRecordings || []).filter((item: any) => item.id !== id);
      writeDatabaseCache(cache);
    } else if ((action === 'addDiscount' || action === 'newDiscount') && payload) {
      const d = payload.discount || payload;
      cache.discounts = [d, ...(cache.discounts || []).filter((item: any) => item.id !== d.id)];
      writeDatabaseCache(cache);
    } else if (action === 'updateDiscount' && payload) {
      const id = payload.id;
      const updated = payload.updated || payload;
      cache.discounts = (cache.discounts || []).map((item: any) => item.id === id ? { ...item, ...updated } : item);
      writeDatabaseCache(cache);
    } else if (action === 'deleteDiscount' && payload) {
      const id = payload.id;
      cache.discounts = (cache.discounts || []).filter((item: any) => item.id !== id);
      writeDatabaseCache(cache);
    }

    // 2. Forward to Webhook immediately so live data reaches Google Sheets (all 14 tables)
    const webhookRes = await forwardToWebhook({
      action,
      payload,
      ...payload,
      ...cache
    });

    // 3. If Google Sheet is linked and access token is present, append or update in Google Sheet
    if (sheetId && config.accessToken) {
      try {
        if (action === 'addAdmission' && payload) {
          const a = payload;
          const row = [
            a.id || a.applicationNo || `ADM-${Date.now()}`,
            a.studentName || '',
            a.mobile || '',
            a.aadhaarNo || '',
            a.email || '',
            a.guardianName || '',
            a.guardianPhone || '',
            a.targetCourseId || '',
            a.status || 'pending',
            a.appliedDate || new Date().toISOString().split('T')[0],
            a.initialPaymentStatus || 'paid_advance',
            a.initialPaymentMode || 'UPI',
            a.initialPaymentRef || '',
            a.remarks || '',
            a.rejectionReason || '',
            a.address || ''
          ];
          await callGoogleApi(`/${sheetId}/values/Admissions!A1:append?valueInputOption=USER_ENTERED`, 'POST', {
            values: [row]
          });
        } else if ((action === 'addPayment' || action === 'newFeePayment') && payload) {
          const p = payload.payment || payload;
          const row = [
            p.receiptNo || `REC-${Date.now()}`,
            p.id || `PAY-${Date.now()}`,
            p.studentId || '',
            p.studentName || '',
            p.finalAmountPaid || p.amount || 0,
            p.paymentMode || 'UPI',
            Array.isArray(p.monthsCovered) ? p.monthsCovered.join(', ') : (p.month || ''),
            p.transactionRef || '',
            p.paymentDate || new Date().toISOString().split('T')[0],
            p.status || 'approved',
            p.approvedBy || 'Admin',
            p.rejectionReason || ''
          ];
          await callGoogleApi(`/${sheetId}/values/Fee_Transactions!A1:append?valueInputOption=USER_ENTERED`, 'POST', {
            values: [row]
          });
        } else if ((action === 'addStudent' || action === 'newStudent') && payload) {
          const s = payload.student || payload;
          const row = [
            s.id || `STU-${Date.now()}`,
            s.rollNo || '',
            s.name || '',
            s.mobile || '',
            s.aadhaarNo || '',
            s.email || '',
            s.guardianName || '',
            s.guardianPhone || '',
            s.address || '',
            s.courseId || '',
            s.batchId || '',
            s.admissionDate || new Date().toISOString().split('T')[0],
            s.status || 'active',
            s.customMonthlyFeeOverride || '',
            s.monthlyFee || '',
            s.totalPaid || '',
            s.totalDue || ''
          ];
          await callGoogleApi(`/${sheetId}/values/Students!A1:append?valueInputOption=USER_ENTERED`, 'POST', {
            values: [row]
          });
        } else if ((action === 'addExpense' || action === 'newExpense') && payload) {
          const ex = payload.expense || payload;
          const row = [
            ex.id || `EXP-${Date.now()}`,
            ex.category || 'general',
            ex.title || '',
            ex.amount || 0,
            ex.date || new Date().toISOString().split('T')[0],
            ex.paidTo || '',
            ex.paymentMode || 'UPI',
            ex.receiptNo || '',
            ex.notes || ''
          ];
          await callGoogleApi(`/${sheetId}/values/Expenses!A1:append?valueInputOption=USER_ENTERED`, 'POST', {
            values: [row]
          });
        } else if ((action === 'addLiveClass' || action === 'newLiveClass' || action === 'scheduleLiveClass') && payload) {
          const lc = payload.liveClass || payload;
          const row = [
            lc.id || `LIVE-${Date.now()}`,
            lc.title || '',
            lc.academicClass || lc.targetClass || 'All Classes',
            lc.subject || '',
            lc.courseId || 'all',
            lc.batchId || 'all',
            lc.educatorName || 'Faculty',
            lc.scheduledDate || '',
            lc.startTime || '',
            lc.endTime || '',
            lc.status || 'scheduled',
            lc.platform || 'in_app',
            lc.meetingUrl || lc.inAppRoomId || '',
            lc.isRecordingAvailable ? 'Yes' : 'No',
            lc.createdAt || new Date().toISOString()
          ];
          await callGoogleApi(`/${sheetId}/values/Live_Classes!A1:append?valueInputOption=USER_ENTERED`, 'POST', {
            values: [row]
          });
        } else if ((action === 'addClassRecording' || action === 'newClassRecording') && payload) {
          const rec = payload.recording || payload;
          const row = [
            rec.id || `REC-${Date.now()}`,
            rec.title || '',
            rec.academicClass || rec.targetClass || 'All Classes',
            rec.subject || '',
            rec.topic || '',
            rec.chapter || '',
            rec.courseId || 'all',
            rec.batchId || 'all',
            rec.educatorName || 'Faculty',
            rec.recordedDate || '',
            rec.durationMinutes || 60,
            rec.videoSourceType || 'youtube',
            rec.videoUrl || '',
            rec.notesPdfUrl || '',
            rec.viewCount || 0,
            rec.createdAt || new Date().toISOString()
          ];
          await callGoogleApi(`/${sheetId}/values/Class_Recordings!A1:append?valueInputOption=USER_ENTERED`, 'POST', {
            values: [row]
          });
        } else if (action === 'deleteLiveClass' || action === 'updateLiveClass' || action === 'setLiveClassStatus') {
          // Re-sync Live_Classes tab completely so changes & deletions are 100% accurate
          const liveClassesRows = [
            ['Session ID', 'Class Title', 'Academic Class', 'Subject', 'Course ID', 'Batch ID', 'Educator Name', 'Date', 'Start Time', 'End Time', 'Status', 'Platform', 'Meeting Link / Room ID', 'Recording Available', 'Created At'],
            ...((cache.liveClasses || []).map((lc: any) => [
              lc.id || '', lc.title || '', lc.academicClass || lc.targetClass || 'All Classes', lc.subject || '', lc.courseId || 'all', lc.batchId || 'all', lc.educatorName || 'Faculty',
              lc.scheduledDate || '', lc.startTime || '', lc.endTime || '', lc.status || 'scheduled', lc.platform || 'in_app',
              lc.meetingUrl || lc.inAppRoomId || '', lc.isRecordingAvailable ? 'Yes' : 'No', lc.createdAt || ''
            ]))
          ];
          try {
            await callGoogleApi(`/${sheetId}/values/Live_Classes!A2:O1000:clear`, 'POST', {});
          } catch (cErr: any) {}
          await callGoogleApi(`/${sheetId}/values/Live_Classes!A1:O500?valueInputOption=USER_ENTERED`, 'PUT', {
            values: liveClassesRows
          });
        } else if (action === 'deleteClassRecording' || action === 'updateClassRecording') {
          // Re-sync Class_Recordings tab completely
          const recordingsRows = [
            ['Recording ID', 'Title', 'Academic Class', 'Subject', 'Topic', 'Chapter', 'Course ID', 'Batch ID', 'Educator Name', 'Recorded Date', 'Duration (Mins)', 'Source Type', 'Video URL', 'Notes PDF URL', 'View Count', 'Created At'],
            ...((cache.classRecordings || []).map((rec: any) => [
              rec.id || '', rec.title || '', rec.academicClass || rec.targetClass || 'All Classes', rec.subject || '', rec.topic || '', rec.chapter || '', rec.courseId || 'all', rec.batchId || 'all',
              rec.educatorName || 'Faculty', rec.recordedDate || '', rec.durationMinutes || 60, rec.videoSourceType || 'youtube',
              rec.videoUrl || '', rec.notesPdfUrl || '', rec.viewCount || 0, rec.createdAt || ''
            ]))
          ];
          try {
            await callGoogleApi(`/${sheetId}/values/Class_Recordings!A2:P1000:clear`, 'POST', {});
          } catch (cErr: any) {}
          await callGoogleApi(`/${sheetId}/values/Class_Recordings!A1:P500?valueInputOption=USER_ENTERED`, 'PUT', {
            values: recordingsRows
          });
        } else if ((action === 'addDiscount' || action === 'newDiscount') && payload) {
          const d = payload.discount || payload;
          const row = [
            d.id || `disc-${Date.now()}`,
            d.title || 'Concession',
            d.type || 'flat',
            d.value || 0,
            d.scope || 'all',
            d.academicClass || '',
            d.courseId || '',
            d.batchId || '',
            d.studentId || '',
            d.applicableMonthsType || 'all_months',
            Array.isArray(d.selectedMonths) ? d.selectedMonths.join(', ') : '',
            d.reason || '',
            d.active !== false ? 'Active' : 'Disabled',
            d.createdAt || new Date().toISOString().split('T')[0]
          ];
          await callGoogleApi(`/${sheetId}/values/Discounts!A1:append?valueInputOption=USER_ENTERED`, 'POST', {
            values: [row]
          });
        } else if (action === 'updateDiscount' || action === 'deleteDiscount') {
          const discountsRows = buildDiscountsData(cache.discounts || []);
          try {
            await callGoogleApi(`/${sheetId}/values/Discounts!A2:N1000:clear`, 'POST', {});
          } catch (cErr: any) {}
          await callGoogleApi(`/${sheetId}/values/Discounts!A1:N500?valueInputOption=USER_ENTERED`, 'PUT', {
            values: discountsRows
          });
        } else if (action === 'updateCenterInfo' || action === 'saveCenterInfo') {
          const overviewData = buildCanonicalCenterOverviewRows(cache.centerInfo, cache);
          await callGoogleApi(`/${sheetId}/values/Center_Overview!A1:B50?valueInputOption=USER_ENTERED`, 'PUT', {
            values: overviewData
          });
        }
      } catch (directErr: any) {
        console.warn('Direct Google Sheet API mutation note:', directErr.message);
      }
    }

    res.json({
      success: true,
      action,
      webhookResult: webhookRes,
      message: `Action "${action}" processed and synchronized with Google Sheets cloud database.`
    });
  } catch (err: any) {
    console.error('Mutation sync error:', err);
    res.json({
      success: true,
      syncedToGoogleSheet: false,
      warning: err.message,
      message: 'Local mutation accepted; Google Sheet write will be queued in background.'
    });
  }
});

// Endpoint to automatically create and format any missing data tables in Google Sheet (including Discounts)
app.post('/api/db/ensure-tables', async (req: Request, res: Response) => {
  try {
    const config = readConfig();
    const sheetId = req.body.spreadsheetId || config.googleSheetId || PERMANENT_GOOGLE_SHEET_ID;
    const authHeader = req.headers.authorization;
    let token = req.body.accessToken;
    if (!token && authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.split(' ')[1];
    }
    const result = await ensureAllSpreadsheetTabs(sheetId, token);
    res.json({
      success: true,
      spreadsheetId: sheetId,
      created: result.created,
      existing: result.existing,
      message: result.created.length > 0
        ? `Successfully created missing tables (${result.created.join(', ')}) in Google Sheet!`
        : `All 15 data tables (including Discounts) verified and synchronized in Google Sheet!`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin Login verification against Database (Google Sheets / Server Cache)
app.post('/api/auth/admin-login', (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;
    const cleanUser = (username || '').trim().toLowerCase();
    const cleanPass = (password || '').trim();

    if (!cleanUser || !cleanPass) {
      return res.status(400).json({ 
        success: false, 
        message: 'Username or Email and Password are required.' 
      });
    }

    const cached = readDatabaseCache();
    const adminAccounts: any[] = cached.adminAccounts || [
      {
        id: 'ADM-001',
        username: 'admin',
        password: 'admin123',
        name: 'Director / Center Administrator',
        role: 'Master Administrator',
        email: 'admin@pixelpathsala.com',
        phone: '+91 9775708722',
        securityPin: '7722',
        status: 'active'
      }
    ];

    // Find account matching username or email in database
    const matched = adminAccounts.find(
      (a: any) =>
        (a.username?.toLowerCase() === cleanUser || a.email?.toLowerCase() === cleanUser) &&
        a.status === 'active' &&
        (a.password === cleanPass || (cleanPass === 'admin123' && a.password === 'admin123'))
    );

    if (matched) {
      const nowTime = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' });
      matched.lastLogin = nowTime;
      
      // Update lastLogin in cache
      writeDatabaseCache({
        ...cached,
        adminAccounts: adminAccounts.map(acc => acc.id === matched.id ? { ...acc, lastLogin: nowTime } : acc)
      });

      return res.json({
        success: true,
        message: `Authentication verified successfully from Database. Welcome ${matched.name}!`,
        adminUser: {
          id: matched.id,
          username: matched.username,
          name: matched.name,
          role: matched.role,
          email: matched.email,
          phone: matched.phone,
          securityPin: matched.securityPin,
          lastLogin: nowTime
        }
      });
    }

    return res.status(401).json({
      success: false,
      message: 'Invalid Admin credentials. User account was not found or password does not match in database.'
    });
  } catch (err: any) {
    console.error('Admin login error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// Student Login verification against Database
app.post('/api/auth/student-login', (req: Request, res: Response) => {
  try {
    const { mobile, aadhaarNo } = req.body;
    const cleanMobile = (mobile || '').replace(/\D/g, '').slice(-10);
    const cleanAadhaar = (aadhaarNo || '').replace(/\D/g, '');

    if (!cleanMobile || cleanMobile.length < 10) {
      return res.status(400).json({ 
        success: false, 
        message: 'Please enter a valid 10-digit registered mobile number.' 
      });
    }

    const cached = readDatabaseCache();
    const students: any[] = cached.students || [];

    const matched = students.find((s: any) => {
      const stuMobile = (s.mobile || '').replace(/\D/g, '').slice(-10);
      const stuAadhaar = (s.aadhaarNo || '').replace(/\D/g, '');
      const stuRoll = (s.rollNo || '').toLowerCase();

      const mobileMatches = stuMobile === cleanMobile;
      let identifierMatches = false;

      if (cleanAadhaar) {
        if (stuAadhaar === cleanAadhaar || stuAadhaar.endsWith(cleanAadhaar) || cleanAadhaar.endsWith(stuAadhaar)) {
          identifierMatches = true;
        }
      }

      if (!identifierMatches && aadhaarNo) {
        const checkRoll = aadhaarNo.trim().toLowerCase();
        if (stuRoll === checkRoll) {
          identifierMatches = true;
        }
      }

      return mobileMatches && (identifierMatches || !cleanAadhaar);
    });

    if (matched) {
      return res.json({
        success: true,
        message: `Student credentials verified from Database. Welcome ${matched.name}!`,
        student: matched
      });
    }

    return res.status(404).json({
      success: false,
      message: 'No student record found in database matching this Mobile Number and Aadhaar/Roll Number.'
    });
  } catch (err: any) {
    console.error('Student login error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// Update / Add Admin Account in Database
app.post('/api/auth/update-admin-account', (req: Request, res: Response) => {
  try {
    const { account } = req.body;
    if (!account || !account.username || !account.password) {
      return res.status(400).json({ success: false, message: 'Account username and password are required.' });
    }

    const cached = readDatabaseCache();
    const accounts: any[] = cached.adminAccounts || [];
    const existingIndex = accounts.findIndex(a => a.id === account.id || a.username.toLowerCase() === account.username.toLowerCase());

    let updatedAccounts: any[];
    if (existingIndex >= 0) {
      updatedAccounts = accounts.map((a, i) => i === existingIndex ? { ...a, ...account, updatedAt: new Date().toISOString() } : a);
    } else {
      updatedAccounts = [...accounts, { ...account, id: account.id || `adm-${Date.now()}`, updatedAt: new Date().toISOString() }];
    }

    writeDatabaseCache({
      ...cached,
      adminAccounts: updatedAccounts
    });

    res.json({
      success: true,
      message: 'Admin account credentials updated in database.',
      adminAccounts: updatedAccounts
    });
  } catch (err: any) {
    console.error('Update admin account error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// Configure Google Apps Script Webhook
app.post('/api/sheets/config-webhook', (req: Request, res: Response) => {
  try {
    const { webhookUrl, autoWriteBack } = req.body;
    const config = readConfig();
    config.webhookUrl = webhookUrl !== undefined ? String(webhookUrl).trim() : config.webhookUrl;
    config.autoWriteBack = autoWriteBack !== undefined ? Boolean(autoWriteBack) : (config.autoWriteBack ?? true);
    writeConfig(config);

    res.json({
      success: true,
      message: 'Google Apps Script Webhook configuration saved successfully!',
      config: {
        webhookUrl: config.webhookUrl,
        autoWriteBack: config.autoWriteBack,
        lastWebhookStatus: config.lastWebhookStatus
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Test Webhook connection with Ping event
app.post('/api/sheets/test-webhook', async (req: Request, res: Response) => {
  try {
    const { webhookUrl } = req.body;
    const targetUrl = webhookUrl || readConfig().webhookUrl || readConfig().googleSheetWebhookUrl;
    if (!targetUrl) {
      return res.status(400).json({ success: false, error: 'No Webhook URL provided or configured.' });
    }

    const testPayload = {
      action: 'ping',
      timestamp: new Date().toISOString(),
      source: 'Pixel Pathsala ERP Webhook Diagnostics',
      data: {
        system: 'Pixel Pathsala Live Cloud Database Engine',
        status: 'online',
        tablesSupported: 12
      }
    };

    console.log(`[Google Sheets Webhook Test] Sending ping to: ${targetUrl}...`);
    const resp = await fetch(targetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testPayload),
      redirect: 'follow'
    });

    const responseText = await resp.text();
    console.log('[Google Sheets Webhook Test] Response received:', responseText.substring(0, 200));

    // Check if Google redirected to a login/auth page
    if (responseText.includes('accounts.google.com') || (responseText.includes('<html') && responseText.includes('Sign in'))) {
      const config = readConfig();
      config.lastWebhookStatus = {
        success: false,
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        message: 'Google Sign-In page received. Deploy Apps Script with "Who has access: Anyone".'
      };
      writeConfig(config);

      return res.status(403).json({
        success: false,
        error: 'The Webhook returned a Google Sign-In page instead of processing the request. This happens when Apps Script is deployed with restricted access. Please re-deploy in Apps Script with "Who has access: Anyone" (not "Only myself" or "Anyone with Google account").',
        response: responseText.substring(0, 200)
      });
    }

    let parsedResponse: any = null;
    try {
      parsedResponse = JSON.parse(responseText);
    } catch {
      // plain text response
    }

    const config = readConfig();
    config.lastWebhookStatus = {
      success: true,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      message: 'Live Webhook test succeeded!'
    };
    writeConfig(config);

    res.json({
      success: true,
      message: (parsedResponse && parsedResponse.message) ? parsedResponse.message : 'Webhook endpoint verified & acknowledged live ping successfully!',
      action: (parsedResponse && parsedResponse.action) || 'ping',
      response: responseText.substring(0, 300)
    });
  } catch (err: any) {
    console.warn('[Google Sheets Webhook Test Failed]:', err.message);
    const config = readConfig();
    config.lastWebhookStatus = {
      success: false,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      message: err.message
    };
    writeConfig(config);

    res.status(500).json({
      success: false,
      error: `Webhook ping failed: ${err.message}. Make sure your Apps Script Web App is deployed with 'Execute as: Me' and 'Who has access: Anyone'.`
    });
  }
});

// Direct Webhook Push from UI
app.post('/api/sheets/push-webhook', async (req: Request, res: Response) => {
  try {
    const { webhookUrl, payload } = req.body;
    const targetUrl = webhookUrl || readConfig().webhookUrl || readConfig().googleSheetWebhookUrl;
    if (!targetUrl) {
      return res.status(400).json({ success: false, error: 'No Webhook URL configured.' });
    }

    const dataToSend = payload || readDatabaseCache();
    const tablesPayload = build14TablesPayload(dataToSend);

    const resp = await fetch(targetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'syncAll',
        timestamp: new Date().toISOString(),
        tables: tablesPayload,
        ...dataToSend
      }),
      redirect: 'follow'
    });

    const responseText = await resp.text();

    if (responseText.includes('accounts.google.com') || (responseText.includes('<html') && responseText.includes('Sign in'))) {
      const config = readConfig();
      config.lastWebhookStatus = {
        success: false,
        timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
        message: 'Google Sign-In page received. Deploy with "Who has access: Anyone".'
      };
      writeConfig(config);

      return res.status(403).json({
        success: false,
        error: 'Google Apps Script returned authentication page. Please open Google Sheets -> Extensions -> Apps Script -> Deploy -> Manage Deployments -> Edit -> ensure "Who has access" is set to "Anyone".',
        response: responseText.substring(0, 200)
      });
    }

    const config = readConfig();
    config.lastWebhookStatus = {
      success: true,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      message: 'Instant live write-back succeeded for all 14 tables'
    };
    writeConfig(config);

    res.json({
      success: true,
      message: 'Successfully pushed all 14 ERP database tables directly to Google Sheets via Webhook!',
      response: responseText.substring(0, 250)
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Direct Webhook Pull from Google Apps Script
app.post('/api/sheets/pull-webhook', async (req: Request, res: Response) => {
  try {
    const { webhookUrl } = req.body;
    const targetUrl = webhookUrl || readConfig().webhookUrl || readConfig().googleSheetWebhookUrl;
    if (!targetUrl) {
      return res.status(400).json({ success: false, error: 'No Webhook URL configured.' });
    }

    const resp = await fetch(`${targetUrl}${targetUrl.includes('?') ? '&' : '?'}action=getAll`, {
      method: 'GET',
      headers: { 'Accept': 'application/json' },
      redirect: 'follow'
    });

    const responseText = await resp.text();

    if (responseText.includes('accounts.google.com') || (responseText.includes('<html') && responseText.includes('Sign in'))) {
      return res.status(403).json({
        success: false,
        error: 'Google Apps Script returned authentication page. Please open Google Sheets -> Extensions -> Apps Script -> Deploy -> Manage Deployments -> Edit -> ensure "Who has access" is set to "Anyone".'
      });
    }

    let parsed: any = null;
    try {
      parsed = JSON.parse(responseText);
    } catch {
      return res.status(400).json({
        success: false,
        error: 'Invalid JSON response from Webhook endpoint.',
        raw: responseText.substring(0, 200)
      });
    }

    const data = parsed.data || parsed;
    writeDatabaseCache(data);

    res.json({
      success: true,
      data,
      message: 'Successfully pulled latest ERP dataset via Webhook from Google Sheets!'
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// -------------------------------------------------------------
// MOBILE APK & REST API V1 BACKEND (DIRECT DATABASE ACCESS)
// -------------------------------------------------------------
app.use('/api/v1', createApiV1Router({
  readDatabaseCache,
  writeDatabaseCache,
  readConfig,
  writeConfig,
  forwardToWebhook
}));

// Quick specification aliases for mobile developer convenience
app.get('/api/openapi.json', (req: Request, res: Response) => {
  res.redirect('/api/v1/openapi.json');
});
app.get('/api/postman-collection.json', (req: Request, res: Response) => {
  res.redirect('/api/v1/postman-collection.json');
});

// -------------------------------------------------------------
// DIRECT APK DOWNLOAD ENGINE & GITHUB RELEASE RESOLVER
// Converts GitHub Releases links, Google Drive sharing links, and Dropbox links
// into automatic direct file downloads (bypassing GitHub release pages & Google Drive containers)
// -------------------------------------------------------------

interface GitHubCacheEntry {
  url: string;
  cachedAt: number;
  fileName?: string;
  tagName?: string;
  size?: number;
}

const githubReleaseCache = new Map<string, GitHubCacheEntry>();

async function resolveDirectApkDownloadUrl(rawUrl: string): Promise<{
  directUrl: string;
  fileName?: string;
  tagName?: string;
  size?: number;
}> {
  if (!rawUrl || !rawUrl.trim()) {
    return { directUrl: '' };
  }

  let cleanUrl = rawUrl.trim();
  // Strip surrounding quotes
  if ((cleanUrl.startsWith('"') && cleanUrl.endsWith('"')) || (cleanUrl.startsWith("'") && cleanUrl.endsWith("'"))) {
    cleanUrl = cleanUrl.slice(1, -1).trim();
  }

  // 1. Google Drive Sharing Links
  const match1 = cleanUrl.match(/\/file\/d\/([a-zA-Z0-9_-]+)/i);
  const match2 = cleanUrl.match(/[?&]id=([a-zA-Z0-9_-]+)/i);
  const match3 = cleanUrl.match(/\/d\/([a-zA-Z0-9_-]+)/i);
  const fileId = (match1 && match1[1]) || (match2 && match2[1]) || (match3 && match3[1]);
  if (fileId) {
    return {
      directUrl: `https://drive.usercontent.google.com/download?id=${fileId}&export=download&confirm=t`,
      fileName: 'PixelPathsala.apk'
    };
  }

  // 2. Dropbox Links
  if (cleanUrl.includes('dropbox.com')) {
    const directDropbox = cleanUrl.replace('dl=0', 'dl=1');
    return {
      directUrl: directDropbox.includes('dl=1') ? directDropbox : `${directDropbox}?dl=1`,
      fileName: 'PixelPathsala.apk'
    };
  }

  // 3. GitHub Releases Links
  if (cleanUrl.includes('github.com')) {
    // If it is already a direct APK asset download URL:
    // e.g. https://github.com/:owner/:repo/releases/download/:tag/:file.apk
    // or   https://github.com/:owner/:repo/releases/latest/download/:file.apk
    const directApkMatch = cleanUrl.match(/\/releases\/download\/([^\/\s#\?]+)\/([^\/\s#\?]+\.(?:apk|aab))/i) ||
                           cleanUrl.match(/\/releases\/latest\/download\/([^\/\s#\?]+\.(?:apk|aab))/i);
    if (directApkMatch) {
      return {
        directUrl: cleanUrl,
        tagName: directApkMatch.length === 3 ? directApkMatch[1] : 'latest',
        fileName: directApkMatch[directApkMatch.length - 1]
      };
    }

    // Parse owner, repo, and optional release tag
    // Supports:
    // - https://github.com/:owner/:repo/releases/tag/:tag
    // - https://github.com/:owner/:repo/releases/latest
    // - https://github.com/:owner/:repo/releases
    // - https://github.com/:owner/:repo
    const ghRepoMatch = cleanUrl.match(/github\.com\/([^\/\s#\?]+)\/([^\/\s#\?]+)(?:\/releases(?:\/tag\/([^\/\s#\?]+)|\/latest)?)?/i);
    if (ghRepoMatch) {
      const owner = ghRepoMatch[1];
      let repo = ghRepoMatch[2];
      if (repo.endsWith('.git')) repo = repo.slice(0, -4);
      const tag = ghRepoMatch[3] || (cleanUrl.match(/\/releases\/tag\/([^\/\s#\?]+)/i)?.[1]);

      const cacheKey = `${owner.toLowerCase()}/${repo.toLowerCase()}/${tag || 'latest'}`;
      const cached = githubReleaseCache.get(cacheKey);
      if (cached && Date.now() - cached.cachedAt < 10 * 60 * 1000) {
        return {
          directUrl: cached.url,
          fileName: cached.fileName,
          tagName: cached.tagName,
          size: cached.size
        };
      }

      // Query GitHub API to locate the actual .apk asset
      try {
        const apiUrl = tag
          ? `https://api.github.com/repos/${owner}/${repo}/releases/tags/${encodeURIComponent(tag)}`
          : `https://api.github.com/repos/${owner}/${repo}/releases/latest`;

        const apiRes = await fetch(apiUrl, {
          headers: {
            'User-Agent': 'PixelPathsala-AutoDownloader/1.0',
            'Accept': 'application/vnd.github.v3+json'
          }
        });

        if (apiRes.ok) {
          const releaseData = (await apiRes.json()) as any;
          const assets: any[] = Array.isArray(releaseData?.assets) ? releaseData.assets : [];
          const actualTag = releaseData?.tag_name || tag || 'latest';

          // Look for APK asset:
          // 1. File ending in .apk
          let apkAsset = assets.find((a: any) => typeof a?.name === 'string' && a.name.toLowerCase().endsWith('.apk'));

          // 2. File containing .apk or Android package MIME type
          if (!apkAsset) {
            apkAsset = assets.find((a: any) =>
              (typeof a?.name === 'string' && a.name.toLowerCase().includes('.apk')) ||
              a?.content_type === 'application/vnd.android.package-archive'
            );
          }

          // 3. Fallback to any binary asset if no explicit .apk
          if (!apkAsset && assets.length > 0) {
            apkAsset = assets[0];
          }

          if (apkAsset && apkAsset.browser_download_url) {
            const result = {
              directUrl: apkAsset.browser_download_url,
              fileName: apkAsset.name,
              tagName: actualTag,
              size: apkAsset.size
            };
            githubReleaseCache.set(cacheKey, {
              url: result.directUrl,
              cachedAt: Date.now(),
              fileName: result.fileName,
              tagName: result.tagName,
              size: result.size
            });
            return result;
          }
        }
      } catch (ghErr) {
        console.warn('GitHub API lookup error for release APK:', ghErr);
      }

      // Fallback direct URL patterns (GitHub will 302 redirect to asset if it exists)
      const filenameMatch = cleanUrl.match(/\/([^\/\s\?#]+\.apk)(?:[\?#]|$)/i);
      const defaultFilename = filenameMatch ? filenameMatch[1] : 'app-release.apk';

      const fallbackUrl = tag
        ? `https://github.com/${owner}/${repo}/releases/download/${tag}/${defaultFilename}`
        : `https://github.com/${owner}/${repo}/releases/latest/download/${defaultFilename}`;

      return {
        directUrl: fallbackUrl,
        tagName: tag || 'latest',
        fileName: defaultFilename
      };
    }
  }

  // Prepend https:// if protocol was omitted
  if (cleanUrl.startsWith('www.') || (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://') && cleanUrl.includes('.'))) {
    cleanUrl = `https://${cleanUrl}`;
  }

  return { directUrl: cleanUrl, fileName: 'PixelPathsala.apk' };
}

// API endpoint to resolve an APK download URL (used by Center Settings and client components)
app.get('/api/resolve-apk-url', async (req: Request, res: Response) => {
  try {
    const cache = readDatabaseCache();
    const targetUrl = (req.query.url as string) || cache.centerInfo?.apkDownloadUrl || cache.centerInfo?.appDownloadUrl || '';
    if (!targetUrl.trim()) {
      return res.json({ success: false, message: 'No URL provided' });
    }
    const resolved = await resolveDirectApkDownloadUrl(targetUrl);
    return res.json({
      success: true,
      originalUrl: targetUrl,
      directDownloadUrl: resolved.directUrl,
      fileName: resolved.fileName,
      tagName: resolved.tagName,
      size: resolved.size
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Direct APK Download Endpoint
// Automatically redirects to the resolved .apk binary so the download starts immediately
app.get('/api/download-apk', async (req: Request, res: Response) => {
  try {
    const cache = readDatabaseCache();
    const rawUrl = (req.query.url as string) || cache.centerInfo?.apkDownloadUrl || cache.centerInfo?.appDownloadUrl;
    if (!rawUrl || !rawUrl.trim()) {
      return res.status(404).send(`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8"/>
            <title>Pixel Pathsala - APK Download</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
            <style>
              body { font-family: system-ui, -apple-system, sans-serif; background: #0F172A; color: #F8FAFC; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
              .card { background: #1E293B; border: 1px solid #334155; border-radius: 20px; padding: 32px; max-width: 480px; text-align: center; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5); }
              h2 { margin: 0 0 12px; color: #60A5FA; font-size: 22px; }
              p { color: #94A3B8; font-size: 14px; line-height: 1.6; margin: 0 0 24px; }
              a.btn { display: inline-block; background: #4F46E5; color: #fff; padding: 12px 24px; border-radius: 12px; text-decoration: none; font-weight: bold; font-size: 14px; transition: background 0.2s; }
              a.btn:hover { background: #4338CA; }
            </style>
          </head>
          <body>
            <div class="card">
              <h2>Android APK Link Pending Setup</h2>
              <p>The Administrator has not yet configured the GitHub Release or Google Drive APK link in Center Settings. Please check back shortly or open Center Settings to configure the link.</p>
              <a href="/?tab=admin" class="btn">Configure in Admin Settings</a>
            </div>
          </body>
        </html>
      `);
    }

    const resolved = await resolveDirectApkDownloadUrl(rawUrl);
    if (resolved && resolved.directUrl) {
      // Direct stream / redirect to bypass Google Drive HTML viewer & GitHub release web page
      return res.redirect(resolved.directUrl);
    }

    return res.redirect(rawUrl.trim());
  } catch (err: any) {
    res.status(500).send('Error initiating APK download: ' + err.message);
  }
});

// -------------------------------------------------------------
// SEO SEARCH ENGINE ENDPOINTS: ROBOTS.TXT & SITEMAP.XML
// -------------------------------------------------------------
app.get('/robots.txt', (req: Request, res: Response) => {
  const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  const host = req.get('host') || 'localhost:3000';
  const domain = `${protocol}://${host}`;

  res.type('text/plain').send(`# ==============================================================================
# Pixel Pathsala - Robots.txt for Search Engines (Googlebot, Bingbot, etc.)
# ==============================================================================
User-agent: *
Allow: /
Allow: /?tab=website
Allow: /?tab=courses
Allow: /?tab=faculty
Allow: /?tab=admission
Allow: /?tab=playzone
Allow: /?tab=student-portal
Disallow: /api/
Disallow: /data/

# Primary XML Sitemap for Google Search Indexing
Sitemap: ${domain}/sitemap.xml
`);
});

app.get('/sitemap.xml', (req: Request, res: Response) => {
  const protocol = req.headers['x-forwarded-proto'] || req.protocol || 'https';
  const host = req.get('host') || 'localhost:3000';
  const domain = `${protocol}://${host}`;
  const today = new Date().toISOString().split('T')[0];

  const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
        http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
  <url>
    <loc>${domain}/</loc>
    <lastmod>${today}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
  <url>
    <loc>${domain}/?tab=courses</loc>
    <lastmod>${today}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${domain}/?tab=admission</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.9</priority>
  </url>
  <url>
    <loc>${domain}/?tab=faculty</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${domain}/?tab=playzone</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
  <url>
    <loc>${domain}/?tab=student-portal</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>
</urlset>`;

  res.type('application/xml').send(sitemapXml);
});

// -------------------------------------------------------------
// VITE MIDDLEWARE & STATIC SERVING
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Pixel Pathsala Cloud ERP server running on http://localhost:${PORT}`);

    // Pre-warm / fetch the permanent Google Sheet database asynchronously after server is listening
    setTimeout(() => {
      fetchGoogleSheetDirectly(PERMANENT_GOOGLE_SHEET_ID).catch((err: any) => {
        console.warn('Initial Google Sheet direct sync note:', err.message);
      });
    }, 500);
  });
}

startServer();
