import express, { Router, Request, Response } from 'express';

export interface DatabaseContext {
  readDatabaseCache: () => any;
  writeDatabaseCache: (data: any) => void;
  readConfig: () => any;
  writeConfig: (config: any) => void;
  forwardToWebhook: (payload: any) => Promise<any>;
}

// Generate simple opaque JWT-like base64url token for mobile apps
function createMobileToken(payload: { id: string; role: 'student' | 'admin'; username?: string; mobile?: string }): string {
  const data = {
    ...payload,
    issuedAt: Date.now(),
    expiresAt: Date.now() + 60 * 24 * 60 * 60 * 1000 // 60 days
  };
  const encoded = Buffer.from(JSON.stringify(data)).toString('base64url');
  return (payload.role === 'admin' ? 'adk_' : 'stk_') + encoded;
}

function parseMobileToken(tokenString?: string): { id: string; role: 'student' | 'admin'; username?: string; mobile?: string } | null {
  if (!tokenString) return null;
  const clean = tokenString.replace(/^Bearer\s+/i, '').trim();
  if (!clean.startsWith('adk_') && !clean.startsWith('stk_')) return null;
  try {
    const raw = clean.slice(4);
    const decoded = JSON.parse(Buffer.from(raw, 'base64url').toString('utf-8'));
    if (decoded && decoded.expiresAt && Date.now() > decoded.expiresAt) {
      return null;
    }
    return decoded;
  } catch {
    return null;
  }
}

export function createApiV1Router(ctx: DatabaseContext): Router {
  const router = Router();

  // Middleware: Allow CORS on all /api/v1 endpoints for external APKs & emulators
  router.use((req: Request, res: Response, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-API-Key');
    if (req.method === 'OPTIONS') {
      return res.status(200).end();
    }
    next();
  });

  // -------------------------------------------------------------
  // 1. HEALTH & METADATA
  // -------------------------------------------------------------
  
  router.get('/health', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    res.json({
      success: true,
      status: 'operational',
      version: '1.0.0',
      service: 'Pixel Pathsala Mobile Backend API',
      location: 'Raina, Purba Bardhaman (Burdwan), West Bengal',
      serverTime: new Date().toISOString(),
      databaseActive: !!cache
    });
  });

  router.get('/meta', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    const config = ctx.readConfig();
    const host = req.get('host') || 'localhost:3000';
    const proto = req.protocol || 'http';
    const baseUrl = `${proto}://${host}`;

    res.json({
      success: true,
      apiVersion: '1.0.0',
      apiName: 'Pixel Pathsala Mobile REST API',
      institute: {
        name: cache.centerInfo?.name || 'Pixel Pathsala',
        tagline: cache.centerInfo?.tagline || 'Code your dream, decode the future',
        campus: cache.centerInfo?.address || 'Raina Main Road, Near Bus Stand',
        cityState: cache.centerInfo?.cityState || 'Raina, Purba Bardhaman (Burdwan), West Bengal - 713424',
        helpline: cache.centerInfo?.phonePrimary || '+91 9775708722',
        whatsapp: cache.centerInfo?.whatsapp || '+91 9775708722',
        upiId: cache.centerInfo?.upiId || '9775708722@apl'
      },
      baseUrl,
      database: {
        provider: 'Google Sheets Master Database + Realtime Server Cache',
        sheetId: config.googleSheetId,
        stats: {
          students: (cache.students || []).length,
          courses: (cache.courses || []).length,
          batches: (cache.batches || []).length,
          admissions: (cache.admissions || []).length,
          payments: (cache.payments || []).length,
          studyMaterials: (cache.studyMaterials || []).length,
          exams: (cache.exams || []).length,
          liveClasses: (cache.liveClasses || []).length,
          educators: (cache.educators || []).length
        }
      },
      endpoints: {
        public: [
          'GET /api/v1/health',
          'GET /api/v1/meta',
          'GET /api/v1/center',
          'GET /api/v1/courses',
          'GET /api/v1/batches',
          'GET /api/v1/educators',
          'POST /api/v1/admissions/apply',
          'GET /api/v1/admissions/status',
          'GET /api/v1/openapi.json',
          'GET /api/v1/postman-collection.json'
        ],
        auth: [
          'POST /api/v1/auth/student-login',
          'POST /api/v1/auth/admin-login',
          'GET /api/v1/auth/verify'
        ],
        studentPortal: [
          'GET /api/v1/student/profile',
          'GET /api/v1/student/fees',
          'POST /api/v1/student/pay-fee',
          'GET /api/v1/student/materials',
          'GET /api/v1/student/exams',
          'POST /api/v1/student/submit-exam',
          'GET /api/v1/student/classes'
        ],
        adminPortal: [
          'GET /api/v1/admin/dashboard',
          'GET /api/v1/admin/students',
          'POST /api/v1/admin/students',
          'DELETE /api/v1/admin/students/:id',
          'GET /api/v1/admin/admissions',
          'POST /api/v1/admin/admissions/approve',
          'GET /api/v1/admin/payments',
          'POST /api/v1/admin/record-payment',
          'PUT /api/v1/admin/payments/:id/approve',
          'POST /api/v1/admin/announcement'
        ]
      }
    });
  });

  // -------------------------------------------------------------
  // 2. CENTER & GENERAL INFO
  // -------------------------------------------------------------

  router.get('/center', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    res.json({
      success: true,
      centerInfo: cache.centerInfo || {}
    });
  });

  // -------------------------------------------------------------
  // 3. AUTHENTICATION (STUDENT & ADMIN)
  // -------------------------------------------------------------

  // Student Login via Mobile & Aadhaar / Roll No
  router.post('/auth/student-login', (req: Request, res: Response) => {
    try {
      const { mobile, aadhaarNo, rollNo } = req.body;
      const cleanMobile = (mobile || '').replace(/\D/g, '').slice(-10);
      const cleanAadhaar = (aadhaarNo || '').replace(/\D/g, '');
      const cleanRoll = (rollNo || aadhaarNo || '').trim().toLowerCase();

      if (!cleanMobile || cleanMobile.length < 10) {
        return res.status(400).json({
          success: false,
          message: 'Please provide a valid 10-digit registered mobile number.'
        });
      }

      const cache = ctx.readDatabaseCache();
      const students: any[] = cache.students || [];

      const matched = students.find((s: any) => {
        const stuMobile = (s.mobile || '').replace(/\D/g, '').slice(-10);
        const stuAadhaar = (s.aadhaarNo || '').replace(/\D/g, '');
        const stuRoll = (s.rollNo || '').toLowerCase();

        const mobileMatches = stuMobile === cleanMobile;
        let idMatches = false;

        if (cleanAadhaar) {
          if (cleanAadhaar.length === 12) {
            idMatches = stuAadhaar === cleanAadhaar;
          } else if (cleanAadhaar.length === 4) {
            idMatches = stuAadhaar.endsWith(cleanAadhaar);
          }
        }

        if (!idMatches && cleanRoll) {
          if (stuRoll === cleanRoll || stuRoll.includes(cleanRoll)) {
            idMatches = true;
          }
        }

        return mobileMatches && (idMatches || !cleanAadhaar);
      });

      if (!matched) {
        return res.status(404).json({
          success: false,
          message: 'No student account found with this Mobile Number and Aadhaar/Roll Number.'
        });
      }

      // Generate APK session token
      const token = createMobileToken({
        id: matched.id,
        role: 'student',
        mobile: matched.mobile
      });

      // Find student enrolled courses & batches
      const courses = (cache.courses || []).filter((c: any) => c.id === matched.courseId);
      const batches = (cache.batches || []).filter((b: any) => b.id === matched.batchId);
      const studentPayments = (cache.payments || []).filter((p: any) => p.studentId === matched.id || p.studentName === matched.name);
      
      const totalPaid = studentPayments
        .filter((p: any) => p.status === 'approved')
        .reduce((sum: number, p: any) => sum + Number(p.finalAmountPaid || p.amount || 0), 0);

      const baseMonthlyFee = Number(matched.monthlyFee || matched.customMonthlyFeeOverride || 1200);

      res.json({
        success: true,
        message: `Welcome back, ${matched.name}!`,
        token,
        tokenType: 'Bearer',
        student: matched,
        enrolledCourses: courses,
        assignedBatches: batches,
        feeOverview: {
          monthlyFee: baseMonthlyFee,
          totalPaid,
          totalDue: Math.max(0, baseMonthlyFee - totalPaid),
          paymentsCount: studentPayments.length,
          upiId: cache.centerInfo?.upiId || '9775708722@apl',
          upiName: cache.centerInfo?.upiName || 'Pixel Pathsala Center'
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Admin Login via Username / Email & Password
  router.post('/auth/admin-login', (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      const cleanUser = (username || '').trim().toLowerCase();
      const cleanPass = (password || '').trim();

      if (!cleanUser || !cleanPass) {
        return res.status(400).json({
          success: false,
          message: 'Username/Email and Password are required.'
        });
      }

      const cache = ctx.readDatabaseCache();
      const accounts: any[] = cache.adminAccounts || [];

      const matched = accounts.find((a: any) =>
        (a.username?.toLowerCase() === cleanUser || a.email?.toLowerCase() === cleanUser) &&
        a.status === 'active' &&
        (a.password === cleanPass || (cleanPass === 'admin123' && a.password === 'admin123'))
      );

      if (!matched) {
        return res.status(401).json({
          success: false,
          message: 'Invalid Admin credentials or account is inactive.'
        });
      }

      const nowTime = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' });
      matched.lastLogin = nowTime;
      ctx.writeDatabaseCache({
        ...cache,
        adminAccounts: accounts.map(a => a.id === matched.id ? { ...a, lastLogin: nowTime } : a)
      });

      const token = createMobileToken({
        id: matched.id,
        role: 'admin',
        username: matched.username
      });

      res.json({
        success: true,
        message: `Admin login successful. Welcome, ${matched.name}!`,
        token,
        tokenType: 'Bearer',
        adminUser: {
          id: matched.id,
          username: matched.username,
          name: matched.name,
          role: matched.role,
          email: matched.email,
          phone: matched.phone,
          lastLogin: nowTime
        }
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Verify Session Token (Bearer Token or X-API-Key)
  router.get('/auth/verify', (req: Request, res: Response) => {
    const authHeader = req.headers['authorization'] || req.headers['x-api-key'];
    const parsed = parseMobileToken(authHeader as string);

    if (!parsed) {
      return res.status(401).json({
        success: false,
        message: 'Invalid or expired authorization token. Provide Authorization: Bearer <token>'
      });
    }

    const cache = ctx.readDatabaseCache();
    if (parsed.role === 'admin') {
      const admin = (cache.adminAccounts || []).find((a: any) => a.id === parsed.id || a.username === parsed.username);
      if (!admin) {
        return res.status(404).json({ success: false, message: 'Admin account not found in database.' });
      }
      return res.json({
        success: true,
        role: 'admin',
        user: {
          id: admin.id,
          username: admin.username,
          name: admin.name,
          role: admin.role,
          email: admin.email,
          phone: admin.phone
        }
      });
    } else {
      const student = (cache.students || []).find((s: any) => s.id === parsed.id);
      if (!student) {
        return res.status(404).json({ success: false, message: 'Student account not found in database.' });
      }
      return res.json({
        success: true,
        role: 'student',
        user: student
      });
    }
  });

  // -------------------------------------------------------------
  // 4. STUDENT PORTAL ENDPOINTS (APK)
  // -------------------------------------------------------------

  // Student Profile
  router.get('/student/profile', (req: Request, res: Response) => {
    const auth = parseMobileToken(req.headers['authorization'] as string);
    const studentId = (req.query.studentId as string) || auth?.id;

    if (!studentId) {
      return res.status(400).json({ success: false, message: 'studentId query param or Bearer token is required.' });
    }

    const cache = ctx.readDatabaseCache();
    const student = (cache.students || []).find((s: any) => s.id === studentId || s.rollNo === studentId);

    if (!student) {
      return res.status(404).json({ success: false, message: 'Student not found.' });
    }

    const course = (cache.courses || []).find((c: any) => c.id === student.courseId);
    const batch = (cache.batches || []).find((b: any) => b.id === student.batchId);

    res.json({
      success: true,
      student: {
        ...student,
        courseTitle: course?.title || 'Enrolled Course',
        batchName: batch?.name || 'Class Batch',
        batchSchedule: batch?.days ? `${batch.days.join(', ')} (${batch.time})` : ''
      }
    });
  });

  // Student Fees & Receipts History
  router.get('/student/fees', (req: Request, res: Response) => {
    const auth = parseMobileToken(req.headers['authorization'] as string);
    const studentId = (req.query.studentId as string) || auth?.id;

    if (!studentId) {
      return res.status(400).json({ success: false, message: 'studentId query param or Bearer token is required.' });
    }

    const cache = ctx.readDatabaseCache();
    const student = (cache.students || []).find((s: any) => s.id === studentId || s.rollNo === studentId);

    if (!student) {
      return res.status(404).json({ success: false, message: 'Student not found.' });
    }

    const payments = (cache.payments || []).filter((p: any) => p.studentId === student.id || p.studentName === student.name);
    const totalPaid = payments
      .filter((p: any) => p.status === 'approved')
      .reduce((sum: number, p: any) => sum + Number(p.finalAmountPaid || p.amount || 0), 0);

    const monthlyFee = Number(student.monthlyFee || student.customMonthlyFeeOverride || 1200);

    res.json({
      success: true,
      studentId: student.id,
      studentName: student.name,
      rollNo: student.rollNo,
      monthlyFee,
      totalPaid,
      totalDue: Math.max(0, monthlyFee - totalPaid),
      upiDetails: {
        upiId: cache.centerInfo?.upiId || '9775708722@apl',
        upiName: cache.centerInfo?.upiName || 'Pixel Pathsala Center'
      },
      payments
    });
  });

  // Student Submit Fee Payment Request (UPI / Cash / Online)
  router.post('/student/pay-fee', async (req: Request, res: Response) => {
    try {
      const auth = parseMobileToken(req.headers['authorization'] as string);
      const {
        studentId,
        studentName,
        rollNo,
        amount,
        month,
        monthsCovered,
        paymentMode,
        transactionRef,
        notes
      } = req.body;

      const effectiveStudentId = studentId || auth?.id;
      if (!effectiveStudentId) {
        return res.status(400).json({ success: false, message: 'studentId is required.' });
      }

      const numAmount = Number(amount);
      if (!numAmount || numAmount <= 0) {
        return res.status(400).json({ success: false, message: 'A valid payment amount is required.' });
      }

      const cache = ctx.readDatabaseCache();
      const student = (cache.students || []).find((s: any) => s.id === effectiveStudentId || s.rollNo === effectiveStudentId);

      const resolvedStudentName = student?.name || studentName || 'Student';
      const resolvedRollNo = student?.rollNo || rollNo || '';
      const receiptNo = `REC/${new Date().getFullYear()}/${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(100 + Math.random() * 900))}`;

      const newPayment = {
        id: `pay-${Date.now()}`,
        receiptNo,
        studentId: student?.id || effectiveStudentId,
        studentName: resolvedStudentName,
        studentMobile: student?.mobile || '',
        studentAadhaar: student?.aadhaarNo || '',
        rollNo: resolvedRollNo,
        courseTitle: student?.courseTitle || 'Tuition Course',
        batchName: student?.batchName || 'General Batch',
        month: month || new Date().toLocaleString('default', { month: 'long', year: 'numeric' }),
        monthsCovered: Array.isArray(monthsCovered) && monthsCovered.length > 0 ? monthsCovered : [new Date().toISOString().slice(0, 7)],
        baseMonthlyFee: Number(student?.monthlyFee || numAmount),
        totalBaseFee: numAmount,
        totalDiscount: 0,
        finalAmountPaid: numAmount,
        remainingDue: 0,
        paymentMode: paymentMode || 'UPI',
        transactionRef: transactionRef || `UPI-TXN-${Date.now()}`,
        status: 'pending', // Pending Admin approval
        paymentDate: new Date().toISOString().split('T')[0],
        approvedBy: 'Pending Admin Verification',
        notes: notes || 'Submitted via Mobile APK App',
        createdAt: new Date().toISOString()
      };

      cache.payments = [newPayment, ...(cache.payments || [])];
      ctx.writeDatabaseCache(cache);

      // Async sync to Google Sheets webhook
      ctx.forwardToWebhook({
        action: 'newFeePayment',
        payload: { payment: newPayment },
        ...cache
      }).catch(err => console.warn('Payment webhook sync note:', err.message));

      res.status(201).json({
        success: true,
        message: 'Payment details submitted successfully! Your receipt is in queue for Admin verification.',
        receipt: newPayment
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Student Study Materials & Notes
  router.get('/student/materials', (req: Request, res: Response) => {
    const { batchId, courseId } = req.query;
    const cache = ctx.readDatabaseCache();
    let materials = cache.studyMaterials || [];

    if (batchId && batchId !== 'all') {
      materials = materials.filter((m: any) => m.batchId === batchId || m.batchId === 'all');
    }
    if (courseId) {
      materials = materials.filter((m: any) => m.courseId === courseId || !m.courseId);
    }

    res.json({
      success: true,
      count: materials.length,
      materials
    });
  });

  // Student Exams & Test Results
  router.get('/student/exams', (req: Request, res: Response) => {
    const auth = parseMobileToken(req.headers['authorization'] as string);
    const studentId = (req.query.studentId as string) || auth?.id;
    const batchId = req.query.batchId as string;

    const cache = ctx.readDatabaseCache();
    let exams = cache.exams || [];
    if (batchId && batchId !== 'all') {
      exams = exams.filter((e: any) => e.batchId === batchId || e.batchId === 'all');
    }

    let submissions: any[] = [];
    if (studentId) {
      submissions = (cache.examSubmissions || []).filter((s: any) => s.studentId === studentId);
    }

    res.json({
      success: true,
      exams,
      mySubmissions: submissions
    });
  });

  // Student Submit Exam Answers
  router.post('/student/submit-exam', async (req: Request, res: Response) => {
    try {
      const auth = parseMobileToken(req.headers['authorization'] as string);
      const { examId, studentId, studentName, rollNo, score, totalMarks, percentage, answers } = req.body;

      const effectiveStudentId = studentId || auth?.id;
      if (!examId || !effectiveStudentId) {
        return res.status(400).json({ success: false, message: 'examId and studentId are required.' });
      }

      const cache = ctx.readDatabaseCache();
      const submission = {
        id: `sub-${Date.now()}`,
        examId,
        studentId: effectiveStudentId,
        studentName: studentName || 'Student',
        rollNo: rollNo || '',
        score: Number(score || 0),
        totalMarks: Number(totalMarks || 100),
        percentage: Number(percentage || 0),
        answers: answers || {},
        submittedAt: new Date().toISOString()
      };

      cache.examSubmissions = [submission, ...(cache.examSubmissions || [])];
      ctx.writeDatabaseCache(cache);

      res.status(201).json({
        success: true,
        message: 'Exam submitted successfully!',
        submission
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Student Live Classes & Recordings
  router.get('/student/classes', (req: Request, res: Response) => {
    const { batchId } = req.query;
    const cache = ctx.readDatabaseCache();
    
    let liveClasses = cache.liveClasses || [];
    let recordings = cache.classRecordings || [];

    if (batchId && batchId !== 'all') {
      liveClasses = liveClasses.filter((c: any) => c.batchId === batchId || c.batchId === 'all');
      recordings = recordings.filter((r: any) => r.batchId === batchId || r.batchId === 'all');
    }

    res.json({
      success: true,
      liveClasses,
      recordings
    });
  });

  // -------------------------------------------------------------
  // 5. PUBLIC & ADMISSIONS ENDPOINTS
  // -------------------------------------------------------------

  // Courses Catalog
  router.get('/courses', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    const { academicClass, category, search } = req.query;

    let list = cache.courses || [];
    if (academicClass) {
      list = list.filter((c: any) => c.academicClass?.toLowerCase().includes((academicClass as string).toLowerCase()));
    }
    if (category) {
      list = list.filter((c: any) => c.category?.toLowerCase() === (category as string).toLowerCase());
    }
    if (search) {
      const q = (search as string).toLowerCase();
      list = list.filter((c: any) =>
        c.title?.toLowerCase().includes(q) ||
        c.code?.toLowerCase().includes(q) ||
        c.description?.toLowerCase().includes(q)
      );
    }

    res.json({
      success: true,
      count: list.length,
      courses: list
    });
  });

  // Batches
  router.get('/batches', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    const { courseId } = req.query;

    let list = cache.batches || [];
    if (courseId) {
      list = list.filter((b: any) => b.courseId === courseId);
    }

    res.json({
      success: true,
      count: list.length,
      batches: list
    });
  });

  // Educators / Faculty
  router.get('/educators', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    res.json({
      success: true,
      count: (cache.educators || []).length,
      educators: cache.educators || []
    });
  });

  // Online Student Admission Application (from APK)
  router.post('/admissions/apply', async (req: Request, res: Response) => {
    try {
      const {
        name,
        gender,
        dob,
        academicClass,
        school,
        previousMarks,
        guardianName,
        guardianRelation,
        guardianPhone,
        mobile,
        email,
        address,
        aadhaarNo,
        courseId,
        preferredBatch,
        admissionMonth,
        notes
      } = req.body;

      if (!name || !mobile) {
        return res.status(400).json({
          success: false,
          message: 'Student Name and Mobile Number are required.'
        });
      }

      const cache = ctx.readDatabaseCache();
      const appNumber = `APP-2026-${String(Math.floor(1000 + Math.random() * 9000))}`;
      const course = (cache.courses || []).find((c: any) => c.id === courseId);

      const newAdmission = {
        id: `adm-${Date.now()}`,
        applicationNo: appNumber,
        name: name.trim(),
        gender: gender || 'Not Specified',
        dob: dob || '',
        academicClass: academicClass || 'General School Syllabus',
        school: school || '',
        previousMarks: previousMarks || '',
        guardianName: guardianName || '',
        guardianRelation: guardianRelation || 'Parent',
        guardianPhone: guardianPhone || mobile,
        mobile: mobile.replace(/\D/g, '').slice(-10),
        email: email || '',
        address: address || 'Raina, Purba Bardhaman, West Bengal',
        aadhaarNo: (aadhaarNo || '').replace(/\D/g, ''),
        courseId: courseId || 'course-1',
        courseTitle: course?.title || 'Selected Course',
        preferredBatch: preferredBatch || 'batch-1',
        admissionMonth: admissionMonth || new Date().toISOString().slice(0, 7),
        notes: notes || 'Online application from Mobile APK',
        status: 'pending',
        appliedAt: new Date().toISOString()
      };

      cache.admissions = [newAdmission, ...(cache.admissions || [])];
      ctx.writeDatabaseCache(cache);

      // Webhook sync to Google Sheets
      ctx.forwardToWebhook({
        action: 'newAdmission',
        payload: { admission: newAdmission },
        ...cache
      }).catch(err => console.warn('Admission webhook sync note:', err.message));

      res.status(201).json({
        success: true,
        message: 'Admission application registered successfully! The center will contact you shortly.',
        applicationNo: appNumber,
        admission: newAdmission
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Check Admission Status
  router.get('/admissions/status', (req: Request, res: Response) => {
    const { applicationNo, mobile } = req.query;
    if (!applicationNo && !mobile) {
      return res.status(400).json({ success: false, message: 'applicationNo or mobile number is required.' });
    }

    const cache = ctx.readDatabaseCache();
    const admissions: any[] = cache.admissions || [];

    const matched = admissions.find((a: any) => {
      if (applicationNo && (a.applicationNo === applicationNo || a.id === applicationNo)) return true;
      if (mobile && a.mobile && a.mobile.replace(/\D/g, '').endsWith((mobile as string).replace(/\D/g, '').slice(-10))) return true;
      return false;
    });

    if (!matched) {
      return res.status(404).json({ success: false, message: 'No admission record found.' });
    }

    // Check if enrolled student exists
    const student = (cache.students || []).find((s: any) => s.mobile === matched.mobile || s.aadhaarNo === matched.aadhaarNo);

    res.json({
      success: true,
      applicationNo: matched.applicationNo,
      status: matched.status,
      name: matched.name,
      courseTitle: matched.courseTitle,
      appliedAt: matched.appliedAt,
      enrolledStudent: student ? { id: student.id, rollNo: student.rollNo, name: student.name } : null
    });
  });

  // -------------------------------------------------------------
  // 6. ADMIN MANAGEMENT ENDPOINTS (FOR ADMIN APK / BACKEND)
  // -------------------------------------------------------------

  // Admin Dashboard Statistics
  router.get('/admin/dashboard', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    const students = cache.students || [];
    const payments = cache.payments || [];
    const admissions = cache.admissions || [];
    const batches = cache.batches || [];
    const courses = cache.courses || [];

    const pendingAdmissions = admissions.filter((a: any) => a.status === 'pending').length;
    const pendingPayments = payments.filter((p: any) => p.status === 'pending').length;

    const totalCollected = payments
      .filter((p: any) => p.status === 'approved')
      .reduce((sum: number, p: any) => sum + Number(p.finalAmountPaid || p.amount || 0), 0);

    res.json({
      success: true,
      stats: {
        totalStudents: students.length,
        activeBatches: batches.length,
        totalCourses: courses.length,
        pendingAdmissions,
        pendingPayments,
        totalFeeCollection: totalCollected,
        activeEducators: (cache.educators || []).length
      },
      recentAdmissions: admissions.slice(0, 5),
      recentPayments: payments.slice(0, 5)
    });
  });

  // Admin List Students
  router.get('/admin/students', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    const { q, batchId, status } = req.query;

    let students = cache.students || [];
    if (batchId) {
      students = students.filter((s: any) => s.batchId === batchId);
    }
    if (status) {
      students = students.filter((s: any) => (s.status || 'active').toLowerCase() === (status as string).toLowerCase());
    }
    if (q) {
      const term = (q as string).toLowerCase();
      students = students.filter((s: any) =>
        s.name?.toLowerCase().includes(term) ||
        s.rollNo?.toLowerCase().includes(term) ||
        s.mobile?.includes(term) ||
        s.aadhaarNo?.includes(term)
      );
    }

    res.json({
      success: true,
      count: students.length,
      students
    });
  });

  // Admin Add / Update Student
  router.post('/admin/students', async (req: Request, res: Response) => {
    try {
      const studentData = req.body;
      if (!studentData.name || !studentData.mobile) {
        return res.status(400).json({ success: false, message: 'Student Name and Mobile are required.' });
      }

      const cache = ctx.readDatabaseCache();
      const students: any[] = cache.students || [];

      let updatedStudents: any[];
      const isEdit = studentData.id && students.some(s => s.id === studentData.id);

      if (isEdit) {
        updatedStudents = students.map(s => s.id === studentData.id ? { ...s, ...studentData } : s);
      } else {
        const newStu = {
          id: studentData.id || `stu-${Date.now()}`,
          rollNo: studentData.rollNo || `PP-2026-${String(students.length + 1).padStart(3, '0')}`,
          status: 'active',
          admissionDate: new Date().toISOString().split('T')[0],
          ...studentData
        };
        updatedStudents = [newStu, ...students];
      }

      cache.students = updatedStudents;
      ctx.writeDatabaseCache(cache);

      ctx.forwardToWebhook({
        action: isEdit ? 'updateStudent' : 'newStudent',
        payload: { student: studentData },
        ...cache
      }).catch(() => {});

      res.status(isEdit ? 200 : 201).json({
        success: true,
        message: isEdit ? 'Student record updated in database.' : 'New student registered in database.',
        student: studentData
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Admin Delete Student
  router.delete('/admin/students/:id', async (req: Request, res: Response) => {
    try {
      const studentId = req.params.id;
      const cache = ctx.readDatabaseCache();
      const students = (cache.students || []).filter((s: any) => s.id !== studentId);

      cache.students = students;
      ctx.writeDatabaseCache(cache);

      res.json({ success: true, message: `Student ${studentId} removed from database.` });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Admin List Admissions
  router.get('/admin/admissions', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    const { status } = req.query;

    let admissions = cache.admissions || [];
    if (status && status !== 'all') {
      admissions = admissions.filter((a: any) => a.status === status);
    }

    res.json({
      success: true,
      count: admissions.length,
      admissions
    });
  });

  // Admin Approve Admission
  router.post('/admin/admissions/approve', async (req: Request, res: Response) => {
    try {
      const { applicationId, rollNo, batchId, customFee, paymentMode, advancePaidAmount, billingMonth } = req.body;
      if (!applicationId) {
        return res.status(400).json({ success: false, message: 'applicationId is required.' });
      }

      const cache = ctx.readDatabaseCache();
      const admissions = cache.admissions || [];
      const targetAdmission = admissions.find((a: any) => a.id === applicationId || a.applicationNo === applicationId);

      if (!targetAdmission) {
        return res.status(404).json({ success: false, message: 'Admission application not found.' });
      }

      // Mark admission approved
      targetAdmission.status = 'approved';
      targetAdmission.approvedAt = new Date().toISOString();

      const newStudentId = `stu-${Date.now()}`;
      const assignedRollNo = rollNo || `PP-2026-${String((cache.students || []).length + 1).padStart(3, '0')}`;
      const course = (cache.courses || []).find((c: any) => c.id === targetAdmission.courseId);
      const feeAmount = Number(customFee || course?.monthlyFee || 1200);
      const advanceAmount = Number(advancePaidAmount || feeAmount);

      const newStudent = {
        id: newStudentId,
        rollNo: assignedRollNo,
        name: targetAdmission.name,
        gender: targetAdmission.gender || 'Not Specified',
        mobile: targetAdmission.mobile,
        guardianName: targetAdmission.guardianName,
        guardianPhone: targetAdmission.guardianPhone,
        aadhaarNo: targetAdmission.aadhaarNo,
        email: targetAdmission.email,
        address: targetAdmission.address || 'Raina, Purba Bardhaman, West Bengal',
        courseId: targetAdmission.courseId,
        courseTitle: course?.title || targetAdmission.courseTitle || 'Tuition Course',
        batchId: batchId || targetAdmission.preferredBatch || 'batch-1',
        academicClass: targetAdmission.academicClass,
        admissionDate: new Date().toISOString().split('T')[0],
        status: 'active',
        monthlyFee: feeAmount,
        totalPaid: advanceAmount,
        totalDue: Math.max(0, feeAmount - advanceAmount)
      };

      cache.students = [newStudent, ...(cache.students || [])];

      // Create initial fee payment receipt
      const receiptNo = `REC/${new Date().getFullYear()}/${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(100 + Math.random() * 900))}`;
      const newPayment = {
        id: `pay-${Date.now()}`,
        receiptNo,
        studentId: newStudentId,
        studentName: targetAdmission.name,
        studentMobile: targetAdmission.mobile,
        studentAadhaar: targetAdmission.aadhaarNo,
        rollNo: assignedRollNo,
        courseTitle: newStudent.courseTitle,
        batchName: 'Default Batch',
        month: billingMonth || new Date().toLocaleString('default', { month: 'long', year: 'numeric' }),
        monthsCovered: [billingMonth || new Date().toISOString().slice(0, 7)],
        baseMonthlyFee: feeAmount,
        totalBaseFee: feeAmount,
        totalDiscount: 0,
        finalAmountPaid: advanceAmount,
        remainingDue: Math.max(0, feeAmount - advanceAmount),
        paymentMode: paymentMode || 'UPI',
        transactionRef: `ADM-PAY-${Date.now()}`,
        status: 'approved',
        paymentDate: new Date().toISOString().split('T')[0],
        approvedBy: 'Admin Admission Desk',
        notes: `Admission & First Month Fee for Roll #${assignedRollNo}`
      };

      cache.payments = [newPayment, ...(cache.payments || [])];
      ctx.writeDatabaseCache(cache);

      // Webhook sync to Google Sheets
      ctx.forwardToWebhook({
        action: 'approveAdmission',
        payload: {
          applicationId,
          student: newStudent,
          payment: newPayment
        },
        ...cache
      }).catch(() => {});

      res.json({
        success: true,
        message: `Admission approved! Student roll number is ${assignedRollNo}.`,
        student: newStudent,
        receipt: newPayment
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Admin List Payments
  router.get('/admin/payments', (req: Request, res: Response) => {
    const cache = ctx.readDatabaseCache();
    const { status, studentId, month } = req.query;

    let payments = cache.payments || [];
    if (status && status !== 'all') {
      payments = payments.filter((p: any) => p.status === status);
    }
    if (studentId) {
      payments = payments.filter((p: any) => p.studentId === studentId);
    }
    if (month) {
      payments = payments.filter((p: any) => p.month?.includes(month as string) || (p.monthsCovered && p.monthsCovered.includes(month as string)));
    }

    res.json({
      success: true,
      count: payments.length,
      payments
    });
  });

  // Admin Record Payment
  router.post('/admin/record-payment', async (req: Request, res: Response) => {
    try {
      const {
        studentId,
        amount,
        paymentMode,
        month,
        monthsCovered,
        transactionRef,
        status,
        remarks
      } = req.body;

      if (!studentId || !amount) {
        return res.status(400).json({ success: false, message: 'studentId and amount are required.' });
      }

      const cache = ctx.readDatabaseCache();
      const student = (cache.students || []).find((s: any) => s.id === studentId || s.rollNo === studentId);
      if (!student) {
        return res.status(404).json({ success: false, message: 'Student not found.' });
      }

      const numAmount = Number(amount);
      const receiptNo = `REC/${new Date().getFullYear()}/${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(Math.floor(100 + Math.random() * 900))}`;

      const payment = {
        id: `pay-${Date.now()}`,
        receiptNo,
        studentId: student.id,
        studentName: student.name,
        studentMobile: student.mobile || '',
        studentAadhaar: student.aadhaarNo || '',
        rollNo: student.rollNo || '',
        courseTitle: student.courseTitle || 'Tuition Course',
        batchName: student.batchName || 'Tuition Batch',
        month: month || new Date().toLocaleString('default', { month: 'long', year: 'numeric' }),
        monthsCovered: Array.isArray(monthsCovered) && monthsCovered.length > 0 ? monthsCovered : [new Date().toISOString().slice(0, 7)],
        baseMonthlyFee: Number(student.monthlyFee || numAmount),
        totalBaseFee: numAmount,
        totalDiscount: 0,
        finalAmountPaid: numAmount,
        remainingDue: 0,
        paymentMode: paymentMode || 'Cash',
        transactionRef: transactionRef || `TXN-${Date.now()}`,
        status: status || 'approved',
        paymentDate: new Date().toISOString().split('T')[0],
        approvedBy: 'Admin Desk',
        notes: remarks || 'Recorded via Admin API'
      };

      cache.payments = [payment, ...(cache.payments || [])];

      // Update student total paid & total due
      student.totalPaid = Number(student.totalPaid || 0) + numAmount;
      const baseFee = Number(student.monthlyFee || 1200);
      student.totalDue = Math.max(0, baseFee - student.totalPaid);

      ctx.writeDatabaseCache(cache);

      ctx.forwardToWebhook({
        action: 'newFeePayment',
        payload: { payment },
        ...cache
      }).catch(() => {});

      res.status(201).json({
        success: true,
        message: 'Payment recorded and receipt generated successfully.',
        payment
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Admin Approve Pending Payment
  router.put('/admin/payments/:id/approve', async (req: Request, res: Response) => {
    try {
      const paymentId = req.params.id;
      const cache = ctx.readDatabaseCache();
      const payments: any[] = cache.payments || [];

      const target = payments.find((p: any) => p.id === paymentId || p.receiptNo === paymentId);
      if (!target) {
        return res.status(404).json({ success: false, message: 'Payment record not found.' });
      }

      target.status = 'approved';
      target.approvedBy = 'Admin Verification Desk';
      target.approvedAt = new Date().toISOString();

      // Update student dues
      const student = (cache.students || []).find((s: any) => s.id === target.studentId);
      if (student) {
        student.totalPaid = Number(student.totalPaid || 0) + Number(target.finalAmountPaid || target.amount || 0);
        const baseFee = Number(student.monthlyFee || 1200);
        student.totalDue = Math.max(0, baseFee - student.totalPaid);
      }

      ctx.writeDatabaseCache(cache);

      res.json({
        success: true,
        message: `Receipt ${target.receiptNo} marked approved.`,
        payment: target
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // Admin Update Bulletin Announcement
  router.post('/admin/announcement', (req: Request, res: Response) => {
    try {
      const { announcement } = req.body;
      if (typeof announcement !== 'string') {
        return res.status(400).json({ success: false, message: 'announcement text is required.' });
      }

      const cache = ctx.readDatabaseCache();
      cache.centerInfo = {
        ...(cache.centerInfo || {}),
        announcement
      };

      ctx.writeDatabaseCache(cache);

      res.json({
        success: true,
        message: 'Bulletin announcement updated.',
        announcement
      });
    } catch (err: any) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  // -------------------------------------------------------------
  // 7. OPENAPI 3.0 SPECIFICATION & POSTMAN COLLECTION
  // -------------------------------------------------------------

  router.get('/openapi.json', (req: Request, res: Response) => {
    const host = req.get('host') || 'localhost:3000';
    const proto = req.protocol || 'http';
    const baseUrl = `${proto}://${host}`;

    const openApiSpec = {
      openapi: '3.0.3',
      info: {
        title: 'Pixel Pathsala - Mobile APK & ERP Backend API',
        description: 'Complete RESTful API suite for Pixel Pathsala mobile application (Android APK, Flutter, React Native, and Kotlin) to interact with the master coaching institute database.',
        version: '1.0.0',
        contact: {
          name: 'Pixel Pathsala Support',
          email: 'pixelpathsala.edu@gmail.com',
          phone: '+91 9775708722'
        }
      },
      servers: [
        {
          url: `${baseUrl}/api/v1`,
          description: 'Current Live Server Environment'
        }
      ],
      components: {
        securitySchemes: {
          bearerAuth: {
            type: 'http',
            scheme: 'bearer',
            bearerFormat: 'JWT',
            description: 'Mobile authentication token received from /api/v1/auth/student-login or /api/v1/auth/admin-login'
          },
          apiKeyAuth: {
            type: 'apiKey',
            in: 'header',
            name: 'X-API-Key',
            description: 'API Key authentication header'
          }
        }
      },
      paths: {
        '/health': {
          get: {
            summary: 'Health Check',
            description: 'Verifies server and database connection status.',
            responses: {
              '200': { description: 'Server is operational' }
            }
          }
        },
        '/meta': {
          get: {
            summary: 'API Metadata & Endpoints Catalog',
            description: 'Provides information about the running API version, database tables, and endpoint index.',
            responses: {
              '200': { description: 'Metadata returned successfully' }
            }
          }
        },
        '/center': {
          get: {
            summary: 'Get Center & Institute Info',
            description: 'Returns center address (Raina, Purba Bardhaman), contact numbers, WhatsApp, UPI ID, logo, and announcements.',
            responses: {
              '200': { description: 'Center details returned' }
            }
          }
        },
        '/auth/student-login': {
          post: {
            summary: 'Student Authentication',
            description: 'Authenticate student via registered mobile number and Aadhaar/Roll No.',
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['mobile'],
                    properties: {
                      mobile: { type: 'string', example: '9832011223' },
                      aadhaarNo: { type: 'string', example: '1289' }
                    }
                  }
                }
              }
            },
            responses: {
              '200': { description: 'Authentication successful with Bearer token' },
              '404': { description: 'Student not found' }
            }
          }
        },
        '/auth/admin-login': {
          post: {
            summary: 'Admin Authentication',
            description: 'Authenticate administrator via username/email and password.',
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['username', 'password'],
                    properties: {
                      username: { type: 'string', example: 'admin' },
                      password: { type: 'string', example: 'admin123' }
                    }
                  }
                }
              }
            },
            responses: {
              '200': { description: 'Admin authentication verified' },
              '401': { description: 'Invalid credentials' }
            }
          }
        },
        '/student/profile': {
          get: {
            summary: 'Get Student Profile',
            security: [{ bearerAuth: [] }],
            parameters: [
              { name: 'studentId', in: 'query', schema: { type: 'string' }, required: false }
            ],
            responses: {
              '200': { description: 'Student profile returned' }
            }
          }
        },
        '/student/fees': {
          get: {
            summary: 'Get Student Fee History & Due Balance',
            security: [{ bearerAuth: [] }],
            parameters: [
              { name: 'studentId', in: 'query', schema: { type: 'string' }, required: false }
            ],
            responses: {
              '200': { description: 'Fee ledger and receipts' }
            }
          }
        },
        '/student/pay-fee': {
          post: {
            summary: 'Submit Fee Payment Details',
            security: [{ bearerAuth: [] }],
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['studentId', 'amount'],
                    properties: {
                      studentId: { type: 'string', example: 'stu-101' },
                      amount: { type: 'number', example: 1200 },
                      month: { type: 'string', example: 'May 2026' },
                      paymentMode: { type: 'string', example: 'UPI' },
                      transactionRef: { type: 'string', example: 'UPI-77889900' }
                    }
                  }
                }
              }
            },
            responses: {
              '201': { description: 'Payment recorded and pending admin verification' }
            }
          }
        },
        '/courses': {
          get: {
            summary: 'List Courses',
            description: 'Returns all available coaching & programming courses.',
            responses: {
              '200': { description: 'List of courses' }
            }
          }
        },
        '/batches': {
          get: {
            summary: 'List Batches',
            description: 'Returns batch schedules, timings, and educator assignments.',
            responses: {
              '200': { description: 'List of batches' }
            }
          }
        },
        '/admissions/apply': {
          post: {
            summary: 'Submit Online Admission Form',
            description: 'Register a new student application from the APK mobile app.',
            requestBody: {
              required: true,
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    required: ['name', 'mobile'],
                    properties: {
                      name: { type: 'string', example: 'Amit Karmakar' },
                      mobile: { type: 'string', example: '9832014567' },
                      guardianName: { type: 'string', example: 'Swapan Karmakar' },
                      courseId: { type: 'string', example: 'course-1' }
                    }
                  }
                }
              }
            },
            responses: {
              '201': { description: 'Admission application registered' }
            }
          }
        },
        '/admin/dashboard': {
          get: {
            summary: 'Get Admin Dashboard Summary Stats',
            security: [{ bearerAuth: [] }],
            responses: {
              '200': { description: 'Summary statistics returned' }
            }
          }
        },
        '/admin/students': {
          get: {
            summary: 'List Students (Admin)',
            security: [{ bearerAuth: [] }],
            responses: {
              '200': { description: 'List of all enrolled students' }
            }
          }
        }
      }
    };

    res.json(openApiSpec);
  });

  router.get('/postman-collection.json', (req: Request, res: Response) => {
    const host = req.get('host') || 'localhost:3000';
    const proto = req.protocol || 'http';
    const baseUrl = `${proto}://${host}/api/v1`;

    const postman = {
      info: {
        name: 'Pixel Pathsala - Mobile APK REST API Collection',
        _postman_id: 'pixel-pathsala-apk-api-v1',
        description: 'Complete Postman Collection for Pixel Pathsala Mobile APK & ERP Backend. Import this directly into Postman or Insomnia to test and integrate all endpoints with the same database.',
        schema: 'https://schema.getpostman.com/json/collection/v2.1.0/collection.json'
      },
      variable: [
        {
          key: 'baseUrl',
          value: baseUrl,
          type: 'string'
        },
        {
          key: 'authToken',
          value: '',
          type: 'string'
        }
      ],
      item: [
        {
          name: '1. System & Center Info',
          item: [
            {
              name: 'Health Check',
              request: {
                method: 'GET',
                header: [],
                url: { raw: '{{baseUrl}}/health', host: ['{{baseUrl}}'], path: ['health'] }
              }
            },
            {
              name: 'API Metadata & Endpoints',
              request: {
                method: 'GET',
                header: [],
                url: { raw: '{{baseUrl}}/meta', host: ['{{baseUrl}}'], path: ['meta'] }
              }
            },
            {
              name: 'Get Center Info & Address',
              request: {
                method: 'GET',
                header: [],
                url: { raw: '{{baseUrl}}/center', host: ['{{baseUrl}}'], path: ['center'] }
              }
            }
          ]
        },
        {
          name: '2. Authentication',
          item: [
            {
              name: 'Student Login',
              request: {
                method: 'POST',
                header: [{ key: 'Content-Type', value: 'application/json' }],
                body: {
                  mode: 'raw',
                  raw: JSON.stringify({
                    mobile: '9832011223',
                    aadhaarNo: '1289'
                  }, null, 2)
                },
                url: { raw: '{{baseUrl}}/auth/student-login', host: ['{{baseUrl}}'], path: ['auth', 'student-login'] }
              }
            },
            {
              name: 'Admin Login',
              request: {
                method: 'POST',
                header: [{ key: 'Content-Type', value: 'application/json' }],
                body: {
                  mode: 'raw',
                  raw: JSON.stringify({
                    username: 'admin',
                    password: 'admin123'
                  }, null, 2)
                },
                url: { raw: '{{baseUrl}}/auth/admin-login', host: ['{{baseUrl}}'], path: ['auth', 'admin-login'] }
              }
            },
            {
              name: 'Verify Token',
              request: {
                method: 'GET',
                header: [{ key: 'Authorization', value: 'Bearer {{authToken}}' }],
                url: { raw: '{{baseUrl}}/auth/verify', host: ['{{baseUrl}}'], path: ['auth', 'verify'] }
              }
            }
          ]
        },
        {
          name: '3. Student Mobile Portal',
          item: [
            {
              name: 'Get Student Profile',
              request: {
                method: 'GET',
                header: [{ key: 'Authorization', value: 'Bearer {{authToken}}' }],
                url: { raw: '{{baseUrl}}/student/profile', host: ['{{baseUrl}}'], path: ['student', 'profile'] }
              }
            },
            {
              name: 'Get Student Fees & Dues',
              request: {
                method: 'GET',
                header: [{ key: 'Authorization', value: 'Bearer {{authToken}}' }],
                url: { raw: '{{baseUrl}}/student/fees', host: ['{{baseUrl}}'], path: ['student', 'fees'] }
              }
            },
            {
              name: 'Pay / Submit Fee',
              request: {
                method: 'POST',
                header: [
                  { key: 'Content-Type', value: 'application/json' },
                  { key: 'Authorization', value: 'Bearer {{authToken}}' }
                ],
                body: {
                  mode: 'raw',
                  raw: JSON.stringify({
                    studentId: 'stu-101',
                    amount: 1200,
                    month: 'May 2026',
                    paymentMode: 'UPI',
                    transactionRef: 'UPI-TXN-123456789'
                  }, null, 2)
                },
                url: { raw: '{{baseUrl}}/student/pay-fee', host: ['{{baseUrl}}'], path: ['student', 'pay-fee'] }
              }
            },
            {
              name: 'Get Study Materials & Notes',
              request: {
                method: 'GET',
                header: [],
                url: { raw: '{{baseUrl}}/student/materials?batchId=all', host: ['{{baseUrl}}'], path: ['student', 'materials'], query: [{ key: 'batchId', value: 'all' }] }
              }
            },
            {
              name: 'Get Scheduled Exams',
              request: {
                method: 'GET',
                header: [],
                url: { raw: '{{baseUrl}}/student/exams', host: ['{{baseUrl}}'], path: ['student', 'exams'] }
              }
            }
          ]
        },
        {
          name: '4. Public & Admissions',
          item: [
            {
              name: 'List Courses',
              request: {
                method: 'GET',
                header: [],
                url: { raw: '{{baseUrl}}/courses', host: ['{{baseUrl}}'], path: ['courses'] }
              }
            },
            {
              name: 'List Batches',
              request: {
                method: 'GET',
                header: [],
                url: { raw: '{{baseUrl}}/batches', host: ['{{baseUrl}}'], path: ['batches'] }
              }
            },
            {
              name: 'List Faculty & Educators',
              request: {
                method: 'GET',
                header: [],
                url: { raw: '{{baseUrl}}/educators', host: ['{{baseUrl}}'], path: ['educators'] }
              }
            },
            {
              name: 'Submit Admission Application',
              request: {
                method: 'POST',
                header: [{ key: 'Content-Type', value: 'application/json' }],
                body: {
                  mode: 'raw',
                  raw: JSON.stringify({
                    name: 'Dipayan Ghosh',
                    gender: 'Male',
                    academicClass: 'Class 10',
                    school: 'Raina High School',
                    mobile: '9832014567',
                    guardianName: 'Subhasish Ghosh',
                    guardianPhone: '9832014567',
                    address: 'Raina, Purba Bardhaman, WB',
                    courseId: 'course-1',
                    preferredBatch: 'batch-1'
                  }, null, 2)
                },
                url: { raw: '{{baseUrl}}/admissions/apply', host: ['{{baseUrl}}'], path: ['admissions', 'apply'] }
              }
            },
            {
              name: 'Check Admission Status',
              request: {
                method: 'GET',
                header: [],
                url: { raw: '{{baseUrl}}/admissions/status?mobile=9832014567', host: ['{{baseUrl}}'], path: ['admissions', 'status'], query: [{ key: 'mobile', value: '9832014567' }] }
              }
            }
          ]
        },
        {
          name: '5. Admin Management',
          item: [
            {
              name: 'Admin Dashboard Stats',
              request: {
                method: 'GET',
                header: [{ key: 'Authorization', value: 'Bearer {{authToken}}' }],
                url: { raw: '{{baseUrl}}/admin/dashboard', host: ['{{baseUrl}}'], path: ['admin', 'dashboard'] }
              }
            },
            {
              name: 'Admin List Students',
              request: {
                method: 'GET',
                header: [{ key: 'Authorization', value: 'Bearer {{authToken}}' }],
                url: { raw: '{{baseUrl}}/admin/students', host: ['{{baseUrl}}'], path: ['admin', 'students'] }
              }
            },
            {
              name: 'Admin List Admissions',
              request: {
                method: 'GET',
                header: [{ key: 'Authorization', value: 'Bearer {{authToken}}' }],
                url: { raw: '{{baseUrl}}/admin/admissions?status=pending', host: ['{{baseUrl}}'], path: ['admin', 'admissions'], query: [{ key: 'status', value: 'pending' }] }
              }
            },
            {
              name: 'Admin List Payments',
              request: {
                method: 'GET',
                header: [{ key: 'Authorization', value: 'Bearer {{authToken}}' }],
                url: { raw: '{{baseUrl}}/admin/payments', host: ['{{baseUrl}}'], path: ['admin', 'payments'] }
              }
            }
          ]
        }
      ]
    };

    res.json(postman);
  });

  return router;
}
